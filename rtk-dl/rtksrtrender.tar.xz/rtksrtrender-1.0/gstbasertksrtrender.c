/* GStreamer
 * Copyright (C) <1999> Erik Walthinsen <omega@cse.ogi.edu>
 * Copyright (C) <2003> David Schleef <ds@schleef.org>
 * Copyright (C) <2006> Julien Moutte <julien@moutte.net>
 * Copyright (C) <2006> Zeeshan Ali <zeeshan.ali@nokia.com>
 * Copyright (C) <2006-2008> Tim-Philipp Müller <tim centricular net>
 * Copyright (C) <2009> Young-Ho Cha <ganadist@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gst/video/video.h>
#include <gst/video/gstvideometa.h>

#include "gstbasertksrtrender.h"
#include "gstrtksrtrender.h"
#include <gstrtkdmaallocator.h>
#include <gstrtksubtitlepool.h>
#include <string.h>
#include <math.h>

/* FIXME:
 *  - use proper strides and offset for I420
 *  - if text is wider than the video picture, it does not get
 *    clipped properly during blitting (if wrapping is disabled)
 */

#define DEFAULT_PROP_AUTO_ADJUST_SIZE TRUE
#define DEFAULT_PROP_DRAW_SHADOW TRUE
#define DEFAULT_PROP_DRAW_OUTLINE TRUE
#define DEFAULT_PROP_COLOR      0xffffffff
#define DEFAULT_PROP_OUTLINE_COLOR 0xff000000

#define MINIMUM_OUTLINE_OFFSET 1.0
#define DEFAULT_SCALE_BASIS    640
#define DEFAULT_PROP_SILENT FALSE
#define DEFAULT_PROP_USECMA FALSE
#define DEFAULT_PROP_EXTRA_SUBTITLE FALSE

enum
{
  PROP_0,
  PROP_CLEAR,
  PROP_SILENT,
  PROP_USECMA,
  PROP_EXTRA_SUBTITLE,
  PROP_LAST
};

GST_DEBUG_CATEGORY_STATIC (base_rtksrtrender_debug);
#define GST_CAT_DEFAULT base_rtksrtrender_debug

#define VIDEO_FORMATS GST_VIDEO_OVERLAY_COMPOSITION_BLEND_FORMATS

#define BASE_RTKSRTRENDER_CAPS GST_VIDEO_CAPS_MAKE (VIDEO_FORMATS)

#define BASE_RTKSRTRENDER_ALL_CAPS BASE_RTKSRTRENDER_CAPS ";" \
    GST_VIDEO_CAPS_MAKE_WITH_FEATURES ("ANY", GST_VIDEO_FORMATS_ALL)

static GstStaticCaps sw_template_caps =
GST_STATIC_CAPS (BASE_RTKSRTRENDER_CAPS);

static GstStaticPadTemplate video_src_template_factory =
GST_STATIC_PAD_TEMPLATE ("video_src",
    GST_PAD_SRC,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS (BASE_RTKSRTRENDER_ALL_CAPS)
    );

static GstStaticPadTemplate text_src_template_factory =
GST_STATIC_PAD_TEMPLATE ("text_src",
    GST_PAD_SRC,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS (BASE_RTKSRTRENDER_ALL_CAPS)
    );

static GstStaticPadTemplate video_sink_template_factory =
GST_STATIC_PAD_TEMPLATE ("video_sink",
    GST_PAD_SINK,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS (BASE_RTKSRTRENDER_ALL_CAPS)
    );

#define GST_BASE_RTKSRTRENDER_GET_LOCK(ov) (&GST_BASE_RTKSRTRENDER (ov)->lock)
#define GST_BASE_RTKSRTRENDER_GET_COND(ov) (&GST_BASE_RTKSRTRENDER (ov)->cond)
#define GST_BASE_RTKSRTRENDER_LOCK(ov)     (g_mutex_lock (GST_BASE_RTKSRTRENDER_GET_LOCK (ov)))
#define GST_BASE_RTKSRTRENDER_UNLOCK(ov)   (g_mutex_unlock (GST_BASE_RTKSRTRENDER_GET_LOCK (ov)))
#define GST_BASE_RTKSRTRENDER_WAIT(ov)     (g_cond_wait (GST_BASE_RTKSRTRENDER_GET_COND (ov), GST_BASE_RTKSRTRENDER_GET_LOCK (ov)))
#define GST_BASE_RTKSRTRENDER_SIGNAL(ov)   (g_cond_signal (GST_BASE_RTKSRTRENDER_GET_COND (ov)))
#define GST_BASE_RTKSRTRENDER_BROADCAST(ov)(g_cond_broadcast (GST_BASE_RTKSRTRENDER_GET_COND (ov)))

#define GST_BASE_RTKSRTRENDER_GET_TEXT_BUFFER_LOCK(ov) (&GST_BASE_RTKSRTRENDER (ov)->text_buffer_lock)
#define GST_BASE_RTKSRTRENDER_TEXT_BUFFER_LOCK(ov)     (g_mutex_lock (GST_BASE_RTKSRTRENDER_GET_TEXT_BUFFER_LOCK (ov)))
#define GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(ov)   (g_mutex_unlock (GST_BASE_RTKSRTRENDER_GET_TEXT_BUFFER_LOCK (ov)))

static GstElementClass *parent_class = NULL;
static void gst_base_rtksrtrender_class_init (GstBaseRtkSrtRenderClass * klass);
static void gst_base_rtksrtrender_init (GstBaseRtkSrtRender * overlay,
    GstBaseRtkSrtRenderClass * klass);

static GstStateChangeReturn gst_base_rtksrtrender_change_state (GstElement *
    element, GstStateChange transition);

static GstCaps *gst_base_rtksrtrender_get_videosink_caps (GstPad * pad,
    GstBaseRtkSrtRender * overlay, GstCaps * filter);
static GstCaps *gst_base_rtksrtrender_get_video_src_caps (GstPad * pad,
    GstBaseRtkSrtRender * overlay, GstCaps * filter);
static gboolean gst_base_rtksrtrender_setcaps (GstBaseRtkSrtRender * overlay,
    GstCaps * caps);
static gboolean gst_base_rtksrtrender_setcaps_txt (GstBaseRtkSrtRender * overlay,
    GstCaps * caps);
static gboolean gst_base_rtksrtrender_video_src_event (GstPad * pad,
    GstObject * parent, GstEvent * event);
static gboolean gst_base_rtksrtrender_video_src_query (GstPad * pad,
    GstObject * parent, GstQuery * query);

static gboolean gst_base_rtksrtrender_text_src_event (GstPad * pad,
    GstObject * parent, GstEvent * event);
static gboolean gst_base_rtksrtrender_text_src_query (GstPad * pad,
    GstObject * parent, GstQuery * query);

static gboolean gst_base_rtksrtrender_video_event (GstPad * pad,
    GstObject * parent, GstEvent * event);
static gboolean gst_base_rtksrtrender_video_query (GstPad * pad,
    GstObject * parent, GstQuery * query);
static GstFlowReturn gst_base_rtksrtrender_video_chain (GstPad * pad,
    GstObject * parent, GstBuffer * buffer);

static gboolean gst_base_rtksrtrender_text_event (GstPad * pad,
    GstObject * parent, GstEvent * event);
static GstFlowReturn gst_base_rtksrtrender_text_chain (GstPad * pad,
    GstObject * parent, GstBuffer * buffer);
static GstPadLinkReturn gst_base_rtksrtrender_text_pad_link (GstPad * pad,
    GstObject * parent, GstPad * peer);
static void gst_base_rtksrtrender_text_pad_unlink (GstPad * pad,
    GstObject * parent);
static void gst_base_rtksrtrender_pop_text (GstBaseRtkSrtRender * overlay);

static void gst_base_rtksrtrender_finalize (GObject * object);
static void gst_base_rtksrtrender_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec);
static void gst_base_rtksrtrender_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec);

static void
gst_base_rtksrtrender_adjust_values_with_fontdesc (GstBaseRtkSrtRender * overlay,
    PangoFontDescription * desc);
static gboolean gst_base_rtksrtrender_can_handle_caps (GstCaps * incaps);
static gboolean
gst_base_rtksrtrender_text_src_negotiate (GstBaseRtkSrtRender * overlay);

GType
gst_base_rtksrtrender_get_type (void)
{
  static GType type = 0;

  if (g_once_init_enter ((gsize *) & type)) {
    static const GTypeInfo info = {
      sizeof (GstBaseRtkSrtRenderClass),
      (GBaseInitFunc) NULL,
      NULL,
      (GClassInitFunc) gst_base_rtksrtrender_class_init,
      NULL,
      NULL,
      sizeof (GstBaseRtkSrtRender),
      0,
      (GInstanceInitFunc) gst_base_rtksrtrender_init,
    };

    g_once_init_leave ((gsize *) & type,
        g_type_register_static (GST_TYPE_ELEMENT, "GstBaseRtkSrtRender", &info,
            0));
  }

  return type;
}

static gchar *
gst_base_rtksrtrender_get_text (GstBaseRtkSrtRender * overlay,
    GstBuffer * video_frame)
{
  return g_strdup (overlay->default_text);
}

static void
gst_base_rtksrtrender_class_init (GstBaseRtkSrtRenderClass * klass)
{
  GObjectClass *gobject_class;
  GstElementClass *gstelement_class;

  GST_DEBUG_CATEGORY_INIT (base_rtksrtrender_debug, "basertksrtrender", 0,
      "Base Text Overlay");

  gobject_class = (GObjectClass *) klass;
  gstelement_class = (GstElementClass *) klass;

  parent_class = g_type_class_peek_parent (klass);

  gobject_class->finalize = gst_base_rtksrtrender_finalize;
  gobject_class->set_property = gst_base_rtksrtrender_set_property;
  gobject_class->get_property = gst_base_rtksrtrender_get_property;

  g_object_class_install_property (gobject_class, PROP_CLEAR,
      g_param_spec_boolean ("clear", "Clear",
          "Clear rendering of subtitles", FALSE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_SILENT,
      g_param_spec_boolean ("silent", "Silent",
          "Silent rendering of subtitles", FALSE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_USECMA,
      g_param_spec_boolean ("usecma", "Usecma",
          "Use cma for subtitle buffer", FALSE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_EXTRA_SUBTITLE,
      g_param_spec_boolean ("extra-subtitle", "Extra subtitle",
          "Use extra subtitle", FALSE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  gst_element_class_add_static_pad_template (gstelement_class,
      &video_src_template_factory);
  gst_element_class_add_static_pad_template (gstelement_class,
      &text_src_template_factory);

  gst_element_class_add_static_pad_template (gstelement_class,
      &video_sink_template_factory);

  gstelement_class->change_state =
      GST_DEBUG_FUNCPTR (gst_base_rtksrtrender_change_state);

  klass->get_text = gst_base_rtksrtrender_get_text;

  gst_type_mark_as_plugin_api (GST_TYPE_BASE_RTKSRTRENDER, 0);
}

static void
gst_base_rtksrtrender_finalize (GObject * object)
{
  GstBaseRtkSrtRender *overlay = GST_BASE_RTKSRTRENDER (object);

  g_free (overlay->default_text);

  if (overlay->layout) {
    g_object_unref (overlay->layout);
    overlay->layout = NULL;
  }

  GST_BASE_RTKSRTRENDER_TEXT_BUFFER_LOCK(overlay);
  if (overlay->text_buffer) {
    gst_buffer_unref (overlay->text_buffer);
    overlay->text_buffer = NULL;
  }
  GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(overlay);

  if (overlay->pango_context) {
    g_object_unref (overlay->pango_context);
    overlay->pango_context = NULL;
  }

  if (overlay->text_caps) {
    gst_caps_unref(overlay->text_caps);
    overlay->text_caps = NULL;
  }

  if (overlay->text_pool) {
    g_object_unref(overlay->text_pool);
    overlay->text_pool = NULL;
  }

  GST_BASE_RTKSRTRENDER_BROADCAST (overlay);
  g_mutex_clear (&overlay->lock);
  g_cond_clear (&overlay->cond);
  g_mutex_clear (&overlay->text_buffer_lock);

  while (!g_queue_is_empty(overlay->clear_time_list)) {
    void *item = (void *)g_queue_pop_head(overlay->clear_time_list);
    if (item != NULL)
      free(item);
  }

  g_queue_free(overlay->clear_time_list);
  G_OBJECT_CLASS (parent_class)->finalize (object);
}

static void
gst_base_rtksrtrender_init (GstBaseRtkSrtRender * overlay,
    GstBaseRtkSrtRenderClass * klass)
{
  GstPadTemplate *template;
  PangoFontDescription *desc;
  PangoFontMap *fontmap;

  fontmap = pango_cairo_font_map_new ();
  overlay->pango_context =
      pango_font_map_create_context (PANGO_FONT_MAP (fontmap));
  g_object_unref (fontmap);
  pango_context_set_base_gravity (overlay->pango_context, PANGO_GRAVITY_SOUTH);

  /* video sink */
  template = gst_static_pad_template_get (&video_sink_template_factory);
  overlay->video_sinkpad = gst_pad_new_from_template (template, "video_sink");
  gst_object_unref (template);
  gst_pad_set_event_function (overlay->video_sinkpad,
      GST_DEBUG_FUNCPTR (gst_base_rtksrtrender_video_event));
  gst_pad_set_chain_function (overlay->video_sinkpad,
      GST_DEBUG_FUNCPTR (gst_base_rtksrtrender_video_chain));
  gst_pad_set_query_function (overlay->video_sinkpad,
      GST_DEBUG_FUNCPTR (gst_base_rtksrtrender_video_query));
  GST_PAD_SET_PROXY_ALLOCATION (overlay->video_sinkpad);
  gst_element_add_pad (GST_ELEMENT (overlay), overlay->video_sinkpad);

  template =
      gst_element_class_get_pad_template (GST_ELEMENT_CLASS (klass),
      "text_sink");
  if (template) {
    /* text sink */
    overlay->text_sinkpad = gst_pad_new_from_template (template, "text_sink");

    gst_pad_set_event_function (overlay->text_sinkpad,
        GST_DEBUG_FUNCPTR (gst_base_rtksrtrender_text_event));
    gst_pad_set_chain_function (overlay->text_sinkpad,
        GST_DEBUG_FUNCPTR (gst_base_rtksrtrender_text_chain));
    gst_pad_set_link_function (overlay->text_sinkpad,
        GST_DEBUG_FUNCPTR (gst_base_rtksrtrender_text_pad_link));
    gst_pad_set_unlink_function (overlay->text_sinkpad,
        GST_DEBUG_FUNCPTR (gst_base_rtksrtrender_text_pad_unlink));
    gst_element_add_pad (GST_ELEMENT (overlay), overlay->text_sinkpad);
  }

  /* (video) source */
  template = gst_static_pad_template_get (&video_src_template_factory);
  overlay->video_srcpad = gst_pad_new_from_template (template, "video_src");
  gst_object_unref (template);
  gst_pad_set_event_function (overlay->video_srcpad,
      GST_DEBUG_FUNCPTR (gst_base_rtksrtrender_video_src_event));
  gst_pad_set_query_function (overlay->video_srcpad,
      GST_DEBUG_FUNCPTR (gst_base_rtksrtrender_video_src_query));
  gst_element_add_pad (GST_ELEMENT (overlay), overlay->video_srcpad);

  /* (text) source */
  template = gst_static_pad_template_get (&text_src_template_factory);
  overlay->text_srcpad = gst_pad_new_from_template (template, "text_src");
  gst_object_unref (template);
  gst_pad_set_event_function (overlay->text_srcpad,
      GST_DEBUG_FUNCPTR (gst_base_rtksrtrender_text_src_event));
  gst_pad_set_query_function (overlay->text_srcpad,
      GST_DEBUG_FUNCPTR (gst_base_rtksrtrender_text_src_query));
  gst_element_add_pad (GST_ELEMENT (overlay), overlay->text_srcpad);

  overlay->layout = pango_layout_new (overlay->pango_context);
  desc = pango_context_get_font_description (overlay->pango_context);
  gst_base_rtksrtrender_adjust_values_with_fontdesc (overlay, desc);

  overlay->color = DEFAULT_PROP_COLOR;
  overlay->outline_color = DEFAULT_PROP_OUTLINE_COLOR;

  overlay->draw_shadow = DEFAULT_PROP_DRAW_SHADOW;
  overlay->draw_outline = DEFAULT_PROP_DRAW_OUTLINE;
  overlay->auto_adjust_size = DEFAULT_PROP_AUTO_ADJUST_SIZE;

  overlay->text_image = NULL;

  overlay->text_buffer = NULL;
  overlay->text_buffer_running_time = GST_CLOCK_TIME_NONE;
  overlay->text_buffer_running_time_end = GST_CLOCK_TIME_NONE;
  overlay->text_linked = FALSE;

  overlay->width = 1;
  overlay->height = 1;

  g_mutex_init (&overlay->lock);
  g_cond_init (&overlay->cond);
  g_mutex_init (&overlay->text_buffer_lock);
  gst_segment_init (&overlay->segment, GST_FORMAT_TIME);

  GstVideoInfo info;

  gst_video_info_set_format(&info, GST_VIDEO_FORMAT_BGRA, SOLID_WIDTH, SOLID_HEIGHT);
  overlay->text_caps  = gst_video_info_to_caps(&info);
  overlay->text_pool = gst_rtk_subtitle_pool_new();
  overlay->silent = DEFAULT_PROP_SILENT;
  overlay->usecma = DEFAULT_PROP_USECMA;
  overlay->extra_subtitle = DEFAULT_PROP_EXTRA_SUBTITLE;
  overlay->preload_gap = 0;
  overlay->last_text_timestamp = GST_CLOCK_TIME_NONE;
  overlay->last_video_timestamp = GST_CLOCK_TIME_NONE;
  overlay->last_video_duration = GST_CLOCK_TIME_NONE;
  overlay->clear_time_list = g_queue_new();
  overlay->video_segment_need_update = FALSE;
  overlay->text_updating = FALSE;
  overlay->text_after_flush = FALSE;
  overlay->rate = 1.0;
  overlay->text_direct_render = FALSE;
}

static gboolean
gst_base_rtksrtrender_setcaps_txt (GstBaseRtkSrtRender * overlay, GstCaps * caps)
{
  GstStructure *structure;
  const gchar *format;
  gst_base_rtksrtrender_text_src_negotiate (overlay);
  structure = gst_caps_get_structure (caps, 0);
  format = gst_structure_get_string (structure, "format");
  overlay->have_pango_markup = (strcmp (format, "pango-markup") == 0);

  return TRUE;
}

/* only negotiate/query video overlay composition support for now */
static gboolean
gst_base_rtksrtrender_video_src_negotiate (GstBaseRtkSrtRender * overlay, GstCaps * caps)
{
  gboolean ret = TRUE;
  GST_DEBUG_OBJECT (overlay, "performing negotiation");

  /* Clear any pending reconfigure to avoid negotiating twice */
  gst_pad_check_reconfigure (overlay->video_srcpad);

  if (!caps)
    caps = gst_pad_get_current_caps (overlay->video_sinkpad);
  else
    gst_caps_ref (caps);

  if (!caps || gst_caps_is_empty (caps))
    goto no_format;

  ret = gst_base_rtksrtrender_can_handle_caps (caps);

  if (ret) {
    GST_DEBUG_OBJECT (overlay, "Using caps %" GST_PTR_FORMAT, caps);
    ret = gst_pad_set_caps (overlay->video_srcpad, caps);
  }

  if (!ret) {
    GST_DEBUG_OBJECT (overlay, "negotiation failed, schedule reconfigure");
    gst_pad_mark_reconfigure (overlay->video_srcpad);
  }

  gst_caps_unref (caps);

  return ret;

no_format:
  {
    if (caps)
      gst_caps_unref (caps);
    gst_pad_mark_reconfigure (overlay->video_srcpad);
    return FALSE;
  }
}

static gboolean
gst_base_rtksrtrender_text_src_negotiate (GstBaseRtkSrtRender * overlay)
{
  gboolean ret = TRUE;
  GST_DEBUG_OBJECT (overlay, "performing negotiation");

  gst_pad_check_reconfigure (overlay->text_srcpad);

  if (!overlay->text_caps || gst_caps_is_empty (overlay->text_caps))
    goto no_format;

  ret = gst_base_rtksrtrender_can_handle_caps (overlay->text_caps);

  if (ret) {
    GST_DEBUG_OBJECT (overlay, "Using caps %" GST_PTR_FORMAT, overlay->text_caps);
    ret = gst_pad_set_caps (overlay->text_srcpad, overlay->text_caps);
  }

  if (!ret) {
    GST_DEBUG_OBJECT (overlay, "negotiation failed, schedule reconfigure");
    gst_pad_mark_reconfigure (overlay->text_srcpad);
  }

  return ret;

no_format:
  {
    gst_pad_mark_reconfigure (overlay->text_srcpad);
    return FALSE;
  }
}

static gboolean
gst_base_rtksrtrender_can_handle_caps (GstCaps * incaps)
{
  gboolean ret;
  GstCaps *caps;

  caps = gst_static_caps_get (&sw_template_caps);
  ret = gst_caps_is_subset (incaps, caps);
  gst_caps_unref (caps);

  return ret;
}

static gboolean
gst_base_rtksrtrender_setcaps (GstBaseRtkSrtRender * overlay, GstCaps * caps)
{
  GstVideoInfo info;
  gboolean ret = FALSE;
  if (!gst_video_info_from_caps (&info, caps))
    goto invalid_caps;

  overlay->info = info;
  overlay->format = GST_VIDEO_INFO_FORMAT (&info);

  if (GST_VIDEO_INFO_WIDTH (&info) * GST_VIDEO_INFO_HEIGHT (&info) > 1920 * 1080) {
    overlay->width = GST_VIDEO_INFO_WIDTH (&info) >> 1;
    overlay->height = GST_VIDEO_INFO_HEIGHT (&info) >> 1;
  } else {
    overlay->width = GST_VIDEO_INFO_WIDTH (&info);
    overlay->height = GST_VIDEO_INFO_HEIGHT (&info);
  }

  ret = gst_base_rtksrtrender_video_src_negotiate (overlay, caps);

  GstVideoInfo text_info;

  if (overlay->text_caps) {
     gst_caps_unref(overlay->text_caps);
     overlay->text_caps = NULL;
  }

  gst_video_info_set_format(&text_info, GST_VIDEO_FORMAT_BGRA, overlay->width, overlay->height);
  overlay->text_caps  = gst_video_info_to_caps(&text_info);

  ret = gst_base_rtksrtrender_text_src_negotiate (overlay);

  GstStructure *structure;
  GstAllocator *alloc;

  structure = gst_buffer_pool_get_config (overlay->text_pool);
  gst_buffer_pool_config_set_params (structure, overlay->text_caps, 4 * overlay->width * overlay->height, 0, SOLID_TOTAL_BUFFER_COUNT);
  gst_buffer_pool_config_add_option (structure, GST_BUFFER_POOL_OPTION_RTK_SUBTITLE_META);

  alloc = gst_rtk_dma_allocator_new ();
  if(!overlay->usecma)
    gst_rtk_dma_allocator_set_heap(alloc, DMA_BUF_SYSTEM);

  gst_buffer_pool_config_set_allocator (structure, alloc, NULL);
  gst_buffer_pool_set_config (overlay->text_pool, structure);

  gst_object_unref(alloc);
  gst_buffer_pool_set_active (overlay->text_pool, TRUE);
  return ret;

  /* ERRORS */
invalid_caps:
  {
    GST_DEBUG_OBJECT (overlay, "could not parse caps");
    return FALSE;
  }
}

static void
gst_base_rtksrtrender_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec)
{
  GstBaseRtkSrtRender *overlay = GST_BASE_RTKSRTRENDER (object);
  GstFlowReturn ret = GST_FLOW_OK;

  GST_BASE_RTKSRTRENDER_LOCK (overlay);
  switch (prop_id) {
    case PROP_CLEAR:
      GstBuffer *clear_buffer;
      ret = gst_buffer_pool_acquire_buffer (overlay->text_pool, &clear_buffer, NULL);
      if (ret == GST_FLOW_OK) {
        GST_BUFFER_TIMESTAMP(clear_buffer) = overlay->last_video_timestamp;
        GST_BUFFER_DURATION(clear_buffer) = GST_CLOCK_TIME_NONE;
        gst_pad_push (overlay->text_srcpad, clear_buffer);
      }
      break;
    case PROP_SILENT:
      overlay->silent = g_value_get_boolean (value);
      if (overlay->silent == TRUE) {
        gst_buffer_pool_set_active (overlay->text_pool, FALSE);
        gst_rtk_subtitle_pool_reset_pool(overlay->text_pool);
      } else
        gst_buffer_pool_set_active (overlay->text_pool, TRUE);

      break;
    case PROP_USECMA:
      overlay->usecma = g_value_get_boolean (value);
      break;
    case PROP_EXTRA_SUBTITLE:
      overlay->extra_subtitle = g_value_get_boolean (value);
      break;
    default:
      break;
  }

  GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
}

static void
gst_base_rtksrtrender_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec)
{
  GstBaseRtkSrtRender *overlay = GST_BASE_RTKSRTRENDER (object);

  GST_BASE_RTKSRTRENDER_LOCK (overlay);
  switch (prop_id) {
    case PROP_CLEAR:
    case PROP_SILENT:
    case PROP_USECMA:
    case PROP_EXTRA_SUBTITLE:
      break;
    default:
      break;
  }

  GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
}

static gboolean
gst_base_rtksrtrender_video_src_query (GstPad * pad, GstObject * parent,
    GstQuery * query)
{
  gboolean ret = FALSE;
  GstBaseRtkSrtRender *overlay;

  overlay = GST_BASE_RTKSRTRENDER (parent);

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_CAPS:
    {
      GstCaps *filter, *caps;

      gst_query_parse_caps (query, &filter);
      caps = gst_base_rtksrtrender_get_video_src_caps (pad, overlay, filter);
      gst_query_set_caps_result (query, caps);
      gst_caps_unref (caps);
      ret = TRUE;
      break;
    }
    default:
      ret = gst_pad_query_default (pad, parent, query);
      break;
  }

  return ret;
}

static gboolean
gst_base_rtksrtrender_text_src_query (GstPad * pad, GstObject * parent,
    GstQuery * query)
{
  gboolean ret = FALSE;
  GstBaseRtkSrtRender *overlay;

  overlay = GST_BASE_RTKSRTRENDER (parent);

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_CAPS:
    {
      gst_query_set_caps_result (query, overlay->text_caps);
      ret = TRUE;
      break;
    }
    default:
      ret = gst_pad_query_default (pad, parent, query);
      break;
  }

  return ret;
}

static gboolean
gst_base_rtksrtrender_video_src_event (GstPad * pad, GstObject * parent,
    GstEvent * event)
{
  GstBaseRtkSrtRender *overlay;
  gboolean ret;

  overlay = GST_BASE_RTKSRTRENDER (parent);

  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_SEEK:
      GstFormat format;
      GstSeekFlags flags;
      GstSeekType start_type, stop_type;
      gint64 start, stop;
      gdouble rate;
      gboolean update;
      gst_event_parse_seek (event, &rate, &format, &flags,
          &start_type, &start, &stop_type, &stop);
      overlay->rate = rate;
      if (overlay->rate <= 1.0)
        overlay->text_direct_render = FALSE;
      break;
    default:
      break;
  }

  ret = gst_pad_push_event (overlay->video_sinkpad, event);

  return ret;
}

static gboolean
gst_base_rtksrtrender_text_src_event (GstPad * pad, GstObject * parent,
    GstEvent * event)
{
  GstBaseRtkSrtRender *overlay;
  gboolean ret = FALSE;

  overlay = GST_BASE_RTKSRTRENDER (parent);

  if (overlay->text_linked) {
    ret = gst_pad_push_event (overlay->text_sinkpad, event);
  }

  return ret;
}

/* gst_base_rtksrtrender_add_feature_and_intersect:
 *
 * Creates a new #GstCaps containing the (given caps +
 * given caps feature) + (given caps intersected by the
 * given filter).
 *
 * Returns: the new #GstCaps
 */
static GstCaps *
gst_base_rtksrtrender_add_feature_and_intersect (GstCaps * caps,
    const gchar * feature, GstCaps * filter)
{
  int i, caps_size;
  GstCaps *new_caps;

  new_caps = gst_caps_copy (caps);

  caps_size = gst_caps_get_size (new_caps);
  for (i = 0; i < caps_size; i++) {
    GstCapsFeatures *features = gst_caps_get_features (new_caps, i);

    if (!gst_caps_features_is_any (features)) {
      gst_caps_features_add (features, feature);
    }
  }

  gst_caps_append (new_caps, gst_caps_intersect_full (caps,
          filter, GST_CAPS_INTERSECT_FIRST));

  return new_caps;
}

/* gst_base_rtksrtrender_intersect_by_feature:
 *
 * Creates a new #GstCaps based on the following filtering rule.
 *
 * For each individual caps contained in given caps, if the
 * caps uses the given caps feature, keep a version of the caps
 * with the feature and an another one without. Otherwise, intersect
 * the caps with the given filter.
 *
 * Returns: the new #GstCaps
 */
static GstCaps *
gst_base_rtksrtrender_intersect_by_feature (GstCaps * caps,
    const gchar * feature, GstCaps * filter)
{
  int i, caps_size;
  GstCaps *new_caps;

  new_caps = gst_caps_new_empty ();

  caps_size = gst_caps_get_size (caps);
  for (i = 0; i < caps_size; i++) {
    GstStructure *caps_structure = gst_caps_get_structure (caps, i);
    GstCapsFeatures *caps_features =
        gst_caps_features_copy (gst_caps_get_features (caps, i));
    GstCaps *filtered_caps;
    GstCaps *simple_caps =
        gst_caps_new_full (gst_structure_copy (caps_structure), NULL);
    gst_caps_set_features (simple_caps, 0, caps_features);

    if (gst_caps_features_contains (caps_features, feature)) {
      gst_caps_append (new_caps, gst_caps_copy (simple_caps));

      gst_caps_features_remove (caps_features, feature);
      filtered_caps = gst_caps_ref (simple_caps);
    } else {
      filtered_caps = gst_caps_intersect_full (simple_caps, filter,
          GST_CAPS_INTERSECT_FIRST);
    }

    gst_caps_unref (simple_caps);
    gst_caps_append (new_caps, filtered_caps);
  }

  return new_caps;
}

static GstCaps *
gst_base_rtksrtrender_get_videosink_caps (GstPad * pad,
    GstBaseRtkSrtRender * overlay, GstCaps * filter)
{
  GstPad *video_srcpad = overlay->video_srcpad;
  GstCaps *peer_caps = NULL, *caps = NULL, *overlay_filter = NULL;

  if (filter) {
    /* filter caps + composition feature + filter caps
     * filtered by the software caps. */
    GstCaps *sw_caps = gst_static_caps_get (&sw_template_caps);
    overlay_filter = gst_base_rtksrtrender_add_feature_and_intersect (filter,
        GST_CAPS_FEATURE_META_GST_VIDEO_OVERLAY_COMPOSITION, sw_caps);
    gst_caps_unref (sw_caps);

    GST_DEBUG_OBJECT (overlay, "overlay filter %" GST_PTR_FORMAT,
        overlay_filter);
  }

  peer_caps = gst_pad_peer_query_caps (video_srcpad, overlay_filter);

  if (overlay_filter)
    gst_caps_unref (overlay_filter);

  if (peer_caps) {

    GST_DEBUG_OBJECT (pad, "peer caps  %" GST_PTR_FORMAT, peer_caps);

    if (gst_caps_is_any (peer_caps)) {
      /* if peer returns ANY caps, return filtered src pad template caps */
      caps = gst_caps_copy (gst_pad_get_pad_template_caps (video_srcpad));
    } else {

      /* duplicate caps which contains the composition into one version with
       * the meta and one without. Filter the other caps by the software caps */
      GstCaps *sw_caps = gst_static_caps_get (&sw_template_caps);
      caps = gst_base_rtksrtrender_intersect_by_feature (peer_caps,
          GST_CAPS_FEATURE_META_GST_VIDEO_OVERLAY_COMPOSITION, sw_caps);
      gst_caps_unref (sw_caps);
    }

    gst_caps_unref (peer_caps);

  } else {
    /* no peer, our padtemplate is enough then */
    caps = gst_pad_get_pad_template_caps (pad);
  }

  if (filter) {
    GstCaps *intersection = gst_caps_intersect_full (filter, caps,
        GST_CAPS_INTERSECT_FIRST);
    gst_caps_unref (caps);
    caps = intersection;
  }

  GST_DEBUG_OBJECT (overlay, "returning  %" GST_PTR_FORMAT, caps);

  return caps;
}

static GstCaps *
gst_base_rtksrtrender_get_video_src_caps (GstPad * pad, GstBaseRtkSrtRender * overlay,
    GstCaps * filter)
{
  GstPad *sinkpad = overlay->video_sinkpad;
  GstCaps *peer_caps = NULL, *caps = NULL, *overlay_filter = NULL;

  if (filter) {
    /* duplicate filter caps which contains the composition into one version
     * with the meta and one without. Filter the other caps by the software
     * caps */
    GstCaps *sw_caps = gst_static_caps_get (&sw_template_caps);
    overlay_filter =
        gst_base_rtksrtrender_intersect_by_feature (filter,
        GST_CAPS_FEATURE_META_GST_VIDEO_OVERLAY_COMPOSITION, sw_caps);
    gst_caps_unref (sw_caps);
  }

  peer_caps = gst_pad_peer_query_caps (sinkpad, overlay_filter);

  if (overlay_filter)
    gst_caps_unref (overlay_filter);

  if (peer_caps) {

    GST_DEBUG_OBJECT (pad, "peer caps  %" GST_PTR_FORMAT, peer_caps);

    if (gst_caps_is_any (peer_caps)) {

      /* if peer returns ANY caps, return filtered sink pad template caps */
      caps = gst_caps_copy (gst_pad_get_pad_template_caps (sinkpad));

    } else {

      /* return upstream caps + composition feature + upstream caps
       * filtered by the software caps. */
      GstCaps *sw_caps = gst_static_caps_get (&sw_template_caps);
      caps = gst_base_rtksrtrender_add_feature_and_intersect (peer_caps,
          GST_CAPS_FEATURE_META_GST_VIDEO_OVERLAY_COMPOSITION, sw_caps);
      gst_caps_unref (sw_caps);
    }

    gst_caps_unref (peer_caps);

  } else {
    /* no peer, our padtemplate is enough then */
    caps = gst_pad_get_pad_template_caps (pad);
  }

  if (filter) {
    GstCaps *intersection;

    intersection =
        gst_caps_intersect_full (filter, caps, GST_CAPS_INTERSECT_FIRST);
    gst_caps_unref (caps);
    caps = intersection;
  }
  GST_DEBUG_OBJECT (overlay, "returning  %" GST_PTR_FORMAT, caps);

  return caps;
}

static void
gst_base_rtksrtrender_adjust_values_with_fontdesc (GstBaseRtkSrtRender * overlay,
    PangoFontDescription * desc)
{
  gint font_size = pango_font_description_get_size (desc) / PANGO_SCALE;
  overlay->shadow_offset = (double) (font_size) / 13.0;
  overlay->outline_offset = (double) (font_size) / 15.0;
  if (overlay->outline_offset < MINIMUM_OUTLINE_OFFSET)
    overlay->outline_offset = MINIMUM_OUTLINE_OFFSET;
}

static gboolean
gst_rtksrtrender_filter_foreground_attr (PangoAttribute * attr, gpointer data)
{
  if (attr->klass->type == PANGO_ATTR_FOREGROUND) {
    return FALSE;
  } else {
    return TRUE;
  }
}

static GstFlowReturn
gst_base_rtksrtrender_render_pangocairo (GstBaseRtkSrtRender * overlay,
    const gchar * string, gint textlen)
{
  cairo_t *cr;
  cairo_surface_t *surface;
  PangoRectangle ink_rect, logical_rect;
  cairo_matrix_t cairo_matrix;
  double scalef_x = 1.0, scalef_y = 1.0;
  double a, r, g, b;
  GstBuffer *buffer;
  GstMapInfo map;
  GstFlowReturn ret = GST_FLOW_OK;

  if (overlay->auto_adjust_size) {
    /* 640 pixel is default */
    scalef_x = scalef_y = (double) (overlay->width) / DEFAULT_SCALE_BASIS;
  }

  pango_layout_set_width (overlay->layout, -1);
  /* set text on pango layout */
  pango_layout_set_markup (overlay->layout, string, textlen);

  /* get srtrender image size */
  pango_layout_get_pixel_extents (overlay->layout, &ink_rect, &logical_rect);

  GST_DEBUG_OBJECT (overlay, "Rendering with ink rect (%d, %d) %dx%d and "
      "logical rect (%d, %d) %dx%d", ink_rect.x, ink_rect.y, ink_rect.width,
      ink_rect.height, logical_rect.x, logical_rect.y, logical_rect.width,
      logical_rect.height);

  cairo_matrix_init_scale (&cairo_matrix, scalef_x, scalef_y);

  ret = gst_buffer_pool_acquire_buffer (overlay->text_pool, &buffer, NULL);
  if (ret != GST_FLOW_OK)
      return GST_FLOW_ERROR;

  overlay->text_image = buffer;
  gst_buffer_map (buffer, &map, GST_MAP_READWRITE);
  surface = cairo_image_surface_create_for_data (map.data,
      CAIRO_FORMAT_ARGB32, overlay->width, overlay->height, overlay->width * 4);
  cr = cairo_create (surface);

  /* clear surface */
  cairo_set_operator (cr, CAIRO_OPERATOR_CLEAR);
  cairo_paint (cr);

  cairo_set_operator (cr, CAIRO_OPERATOR_OVER);

  /* apply transformations */
  cairo_set_matrix (cr, &cairo_matrix);

  /* FIXME: We use show_layout everywhere except for the surface
   * because it's really faster and internally does all kinds of
   * caching. Unfortunately we have to paint to a cairo path for
   * the outline and this is slow. Once Pango supports user fonts
   * we should use them, see
   * https://bugzilla.gnome.org/show_bug.cgi?id=598695
   *
   * Idea would the be, to create a cairo user font that
   * does shadow, outline, text painting in the
   * render_glyph function.
   */

  double move_x, move_y;
  move_x = (overlay->width/2 - logical_rect.width*scalef_x/2)/scalef_x;
  move_y = (overlay->height - logical_rect.height*scalef_y)/scalef_y - SUBTITLE_HEIGHT_OFFSET;

  /* draw shadow text */
  if (overlay->draw_shadow) {
    PangoAttrList *origin_attr, *filtered_attr, *temp_attr;

    /* Store a ref on the original attributes for later restoration */
    origin_attr =
        pango_attr_list_ref (pango_layout_get_attributes (overlay->layout));
    /* Take a copy of the original attributes, because pango_attr_list_filter
     * modifies the passed list */
    temp_attr = pango_attr_list_copy (origin_attr);
    filtered_attr =
        pango_attr_list_filter (temp_attr,
        gst_rtksrtrender_filter_foreground_attr, NULL);
    pango_attr_list_unref (temp_attr);

    cairo_move_to(cr, move_x, move_y);
    cairo_save (cr);
    cairo_translate (cr, overlay->shadow_offset, overlay->shadow_offset);
    cairo_set_source_rgba (cr, 0.0, 0.0, 0.0, 0.5);
    pango_layout_set_attributes (overlay->layout, filtered_attr);
    pango_cairo_show_layout (cr, overlay->layout);
    pango_layout_set_attributes (overlay->layout, origin_attr);
    pango_attr_list_unref (filtered_attr);
    pango_attr_list_unref (origin_attr);
    cairo_restore (cr);
  }

  /* draw outline text */
  if (overlay->draw_outline) {
    a = (overlay->outline_color >> 24) & 0xff;
    r = (overlay->outline_color >> 16) & 0xff;
    g = (overlay->outline_color >> 8) & 0xff;
    b = (overlay->outline_color >> 0) & 0xff;

    cairo_move_to(cr, move_x, move_y);
    cairo_save (cr);
    cairo_set_source_rgba (cr, r / 255.0, g / 255.0, b / 255.0, a / 255.0);
    cairo_set_line_width (cr, overlay->outline_offset);
    pango_cairo_layout_path (cr, overlay->layout);
    cairo_stroke (cr);
    cairo_restore (cr);
  }

  a = (overlay->color >> 24) & 0xff;
  r = (overlay->color >> 16) & 0xff;
  g = (overlay->color >> 8) & 0xff;
  b = (overlay->color >> 0) & 0xff;

  /* draw text */
  cairo_move_to(cr, move_x, move_y);
  cairo_save (cr);
  cairo_set_source_rgba (cr, r / 255.0, g / 255.0, b / 255.0, a / 255.0);
  pango_cairo_show_layout (cr, overlay->layout);
  cairo_restore (cr);

  cairo_destroy (cr);
  cairo_surface_destroy (surface);
  gst_buffer_unmap (buffer, &map);
  return ret;
}

static GstFlowReturn
gst_base_rtksrtrender_render_text (GstBaseRtkSrtRender * overlay,
    const gchar * text, gint textlen)
{
  gchar *string;
  GstFlowReturn ret = GST_FLOW_OK;

  /* -1 is the whole string */
  if (text != NULL && textlen < 0) {
    textlen = strlen (text);
  }

  if (text != NULL) {
    string = g_strndup (text, textlen);
  } else {                      /* empty string */
    string = g_strdup (" ");
  }
  g_strdelimit (string, "\r\t", ' ');
  textlen = strlen (string);

  /* FIXME: should we check for UTF-8 here? */

  GST_DEBUG ("Rendering '%s'", string);
  ret = gst_base_rtksrtrender_render_pangocairo (overlay, string, textlen);
  g_free (string);

  return ret;
}

static GstPadLinkReturn
gst_base_rtksrtrender_text_pad_link (GstPad * pad, GstObject * parent,
    GstPad * peer)
{
  GstBaseRtkSrtRender *overlay;

  overlay = GST_BASE_RTKSRTRENDER (parent);
  if (G_UNLIKELY (!overlay))
    return GST_PAD_LINK_REFUSED;

  GST_DEBUG_OBJECT (overlay, "Text pad linked");

  overlay->text_linked = TRUE;

  return GST_PAD_LINK_OK;
}

static void
gst_base_rtksrtrender_text_pad_unlink (GstPad * pad, GstObject * parent)
{
  GstBaseRtkSrtRender *overlay;

  /* don't use gst_pad_get_parent() here, will deadlock */
  overlay = GST_BASE_RTKSRTRENDER (parent);

  GST_DEBUG_OBJECT (overlay, "Text pad unlinked");

  overlay->text_linked = FALSE;

  gst_segment_init (&overlay->text_segment, GST_FORMAT_UNDEFINED);
}

static gboolean
gst_base_rtksrtrender_text_event (GstPad * pad, GstObject * parent,
    GstEvent * event)
{
  gboolean ret = FALSE;
  GstBaseRtkSrtRender *overlay = NULL;

  overlay = GST_BASE_RTKSRTRENDER (parent);

  GST_LOG_OBJECT (pad, "received event %s", GST_EVENT_TYPE_NAME (event));

  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_STREAM_START:
      /* Clear any pending EOS and segment on a new stream start */
      GST_BASE_RTKSRTRENDER_LOCK (overlay);
      GST_INFO_OBJECT (overlay, "text stream-start");
      overlay->text_flushing = FALSE;
      overlay->text_eos = FALSE;
      GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      gst_base_rtksrtrender_pop_text (overlay);
      gst_segment_init (&overlay->text_segment, GST_FORMAT_TIME);
      ret = gst_pad_push_event(overlay->text_srcpad, event);
      break;
    case GST_EVENT_CAPS:
    {
      GstCaps *caps;

      gst_event_parse_caps (event, &caps);
      ret = gst_base_rtksrtrender_setcaps_txt (overlay, caps);
      gst_event_unref (event);
      break;
    }
    case GST_EVENT_SEGMENT:
    {
      const GstSegment *segment;

      overlay->text_eos = FALSE;

      gst_event_parse_segment (event, &segment);

      if (segment->format == GST_FORMAT_TIME) {
        GST_BASE_RTKSRTRENDER_LOCK (overlay);
        gst_segment_copy_into (segment, &overlay->text_segment);
        GST_DEBUG_OBJECT (overlay, "TEXT SEGMENT now: %" GST_SEGMENT_FORMAT,
            &overlay->text_segment);
        GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      } else {
        GST_ELEMENT_WARNING (overlay, STREAM, MUX, (NULL),
            ("received non-TIME newsegment event on text input"));
      }

      overlay->video_segment_need_update = TRUE;
      ret = gst_pad_push_event(overlay->text_srcpad, event);

      /* wake up the video chain, it might be waiting for a text buffer or
       * a text segment update */
      GST_BASE_RTKSRTRENDER_LOCK (overlay);
      GST_BASE_RTKSRTRENDER_BROADCAST (overlay);
      GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      break;
    }
    case GST_EVENT_GAP:
    {
      GstClockTime start, duration;

      gst_event_parse_gap (event, &start, &duration);
      if (GST_CLOCK_TIME_IS_VALID (duration))
        start += duration;
      /* we do not expect another buffer until after gap,
       * so that is our position now */
      overlay->text_segment.position = start;

      /* wake up the video chain, it might be waiting for a text buffer or
       * a text segment update */
      GST_BASE_RTKSRTRENDER_LOCK (overlay);
      GST_BASE_RTKSRTRENDER_BROADCAST (overlay);
      GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      gst_event_unref(event);
      //ret = gst_pad_push_event(overlay->text_srcpad, event);
      break;
    }
    case GST_EVENT_FLUSH_STOP:
      GST_BASE_RTKSRTRENDER_LOCK (overlay);
      GST_INFO_OBJECT (overlay, "text flush stop");
      overlay->text_flushing = FALSE;
      overlay->text_eos = FALSE;
      overlay->text_after_flush = TRUE;
      GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      gst_base_rtksrtrender_pop_text (overlay);
      gst_segment_init (&overlay->text_segment, GST_FORMAT_TIME);
      ret = gst_pad_push_event(overlay->text_srcpad, event);
      break;
    case GST_EVENT_FLUSH_START:
      overlay->preload_gap = 0;
      GST_BASE_RTKSRTRENDER_LOCK (overlay);
      GST_INFO_OBJECT (overlay, "text flush start");
      overlay->text_flushing = TRUE;
      GST_BASE_RTKSRTRENDER_BROADCAST (overlay);
      GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      ret = gst_pad_push_event(overlay->text_srcpad, event);
      break;
    case GST_EVENT_EOS:
      GST_BASE_RTKSRTRENDER_LOCK (overlay);
      overlay->text_eos = TRUE;
      GST_INFO_OBJECT (overlay, "text EOS");
      /* wake up the video chain, it might be waiting for a text buffer or
       * a text segment update */
      GST_BASE_RTKSRTRENDER_BROADCAST (overlay);
      GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      if (overlay->extra_subtitle == TRUE) {
        gst_event_unref (event);
        ret = TRUE;
      } else {
        ret = gst_pad_push_event(overlay->text_srcpad, event);
      }
      break;
    default:
      ret = gst_pad_event_default (pad, parent, event);
      break;
  }

  return ret;
}

static gboolean
gst_base_rtksrtrender_video_event (GstPad * pad, GstObject * parent,
    GstEvent * event)
{
  gboolean ret = FALSE;
  GstBaseRtkSrtRender *overlay = NULL;

  overlay = GST_BASE_RTKSRTRENDER (parent);

  GST_DEBUG_OBJECT (pad, "received event %s", GST_EVENT_TYPE_NAME (event));

  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_STREAM_START:
      /* Clear any EOS and segment on a new stream */
      GST_BASE_RTKSRTRENDER_LOCK (overlay);
      GST_INFO_OBJECT (overlay, "video stream-start");
      overlay->video_flushing = FALSE;
      overlay->video_eos = FALSE;
      gst_segment_init (&overlay->segment, GST_FORMAT_TIME);
      GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      ret = gst_pad_push_event(overlay->video_srcpad, event);
      break;
    case GST_EVENT_CAPS:
    {
      GstCaps *caps;

      gst_event_parse_caps (event, &caps);
      ret = gst_base_rtksrtrender_setcaps (overlay, caps);
      gst_event_unref (event);
      break;
    }
    case GST_EVENT_SEGMENT:
    {
      const GstSegment *segment;

      GST_DEBUG_OBJECT (overlay, "received new segment");

      gst_event_parse_segment (event, &segment);

      if (segment->format == GST_FORMAT_TIME) {
        gst_segment_copy_into (segment, &overlay->segment);
        GST_DEBUG_OBJECT (overlay, "VIDEO SEGMENT now: %" GST_SEGMENT_FORMAT,
            &overlay->segment);
      } else {
        GST_ELEMENT_WARNING (overlay, STREAM, MUX, (NULL),
            ("received non-TIME newsegment event on video input"));
      }
      overlay->last_video_timestamp = overlay->segment.start;
      overlay->video_segment_need_update = FALSE;
      ret = gst_pad_push_event(overlay->video_srcpad, event);
      break;
    }
    case GST_EVENT_EOS:
      GST_BASE_RTKSRTRENDER_LOCK (overlay);
      GST_INFO_OBJECT (overlay, "video EOS");
      overlay->video_eos = TRUE;
      GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      ret = gst_pad_push_event(overlay->video_srcpad, event);
      if (overlay->extra_subtitle == TRUE)
        gst_pad_push_event(overlay->text_srcpad, gst_event_new_eos());
      break;
    case GST_EVENT_FLUSH_START:
      GST_BASE_RTKSRTRENDER_LOCK (overlay);
      GST_INFO_OBJECT (overlay, "video flush start");
      overlay->video_flushing = TRUE;
      GST_BASE_RTKSRTRENDER_BROADCAST (overlay);
      GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      ret = gst_pad_push_event(overlay->video_srcpad, event);
      break;
    case GST_EVENT_FLUSH_STOP:
      GST_BASE_RTKSRTRENDER_LOCK (overlay);
      GST_INFO_OBJECT (overlay, "video flush stop");
      overlay->video_flushing = FALSE;
      overlay->video_eos = FALSE;
      gst_segment_init (&overlay->segment, GST_FORMAT_TIME);
      GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      ret = gst_pad_push_event(overlay->video_srcpad, event);
      break;
    default:
      ret = gst_pad_event_default (pad, parent, event);
      break;
  }

  return ret;
}

static gboolean
gst_base_rtksrtrender_video_query (GstPad * pad, GstObject * parent,
    GstQuery * query)
{
  gboolean ret = FALSE;
  GstBaseRtkSrtRender *overlay;

  overlay = GST_BASE_RTKSRTRENDER (parent);

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_CAPS:
    {
      GstCaps *filter, *caps;

      gst_query_parse_caps (query, &filter);
      caps = gst_base_rtksrtrender_get_videosink_caps (pad, overlay, filter);
      gst_query_set_caps_result (query, caps);
      gst_caps_unref (caps);
      ret = TRUE;
      break;
    }
    default:
      ret = gst_pad_query_default (pad, parent, query);
      break;
  }

  return ret;
}

/* Called with lock held */
static void
gst_base_rtksrtrender_pop_text (GstBaseRtkSrtRender * overlay)
{
  g_return_if_fail (GST_IS_BASE_RTKSRTRENDER (overlay));
  GST_BASE_RTKSRTRENDER_TEXT_BUFFER_LOCK(overlay);
  if (overlay->text_buffer) {
    GST_DEBUG_OBJECT (overlay, "releasing text buffer %p",
        overlay->text_buffer);
    gst_buffer_unref (overlay->text_buffer);
    overlay->text_buffer = NULL;
    overlay->text_buffer_running_time = overlay->text_buffer_running_time_end =
        GST_CLOCK_TIME_NONE;
  }

  while (!g_queue_is_empty(overlay->clear_time_list)) {
    void *item = (void *)g_queue_pop_head(overlay->clear_time_list);
    if (item != NULL)
      free(item);
  }

  /* Let the text task know we used that buffer */
  GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(overlay);
  GST_BASE_RTKSRTRENDER_BROADCAST (overlay);
}

static void
gst_base_rtksubtitle_process_subtitle(GstBaseRtkSrtRender *overlay, gboolean use_video_time)
{
  GstMapInfo map;
  gchar *in_text;
  gsize in_size;
  gchar *text = NULL;

  GST_BASE_RTKSRTRENDER_TEXT_BUFFER_LOCK(overlay);
  if (overlay->text_buffer == NULL) {
    GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(overlay);
    return;
  }
  gst_buffer_map (overlay->text_buffer, &map, GST_MAP_READ);
  in_text = (gchar *) map.data;
  in_size = map.size;
  GstFlowReturn ret = GST_FLOW_OK;

  if (in_size > 0) {
    if (!g_utf8_validate (in_text, in_size, NULL)) {
      const gchar *end = NULL;

      GST_WARNING_OBJECT (overlay, "received invalid UTF-8");
      in_text = g_strndup (in_text, in_size);
      while (!g_utf8_validate (in_text, in_size, &end) && end)
        *((gchar *) end) = '*';
    }

    if (overlay->have_pango_markup) {
      text = g_strndup (in_text, in_size);
    } else {
      text = g_markup_escape_text (in_text, in_size);
    }

    if (text != NULL && *text != '\0') {
      gint text_len = strlen (text);
      while (text_len > 0 && (text[text_len - 1] == '\n' ||
                text[text_len - 1] == '\r')) {
        --text_len;
      }
      GST_DEBUG_OBJECT (overlay, "Rendering text '%*s'", text_len, text);
      ret = gst_base_rtksrtrender_render_text (overlay, text, text_len);
      if (use_video_time == TRUE && overlay->last_video_timestamp != GST_CLOCK_TIME_NONE)
        GST_BUFFER_TIMESTAMP (overlay->text_image) = overlay->last_video_timestamp;
      else
        GST_BUFFER_TIMESTAMP (overlay->text_image) = GST_BUFFER_TIMESTAMP(overlay->text_buffer);

      if (use_video_time == TRUE) {
        if (overlay->text_after_flush == TRUE && overlay->last_video_timestamp - GST_BUFFER_TIMESTAMP(overlay->text_buffer) > 0)
          GST_BUFFER_DURATION (overlay->text_image) = GST_BUFFER_DURATION (overlay->text_buffer) - (overlay->last_video_timestamp - GST_BUFFER_TIMESTAMP(overlay->text_buffer));
        else
          GST_BUFFER_DURATION (overlay->text_image) = 800000000;
      } else {
          GST_BUFFER_DURATION (overlay->text_image) = GST_BUFFER_DURATION (overlay->text_buffer);
      }

      overlay->text_after_flush = FALSE;

      gst_buffer_unmap (overlay->text_buffer, &map);
      gst_buffer_unref(overlay->text_buffer);
      overlay->text_buffer = NULL;
      GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(overlay);
      if (ret == GST_FLOW_OK) {
         overlay->last_text_timestamp = GST_BUFFER_TIMESTAMP (overlay->text_image);
         gst_pad_push (overlay->text_srcpad, overlay->text_image);
      }
    }
  }
  overlay->text_direct_render = FALSE;
  overlay->text_updating = FALSE;
  GST_BASE_RTKSRTRENDER_BROADCAST (overlay);
}

static GstFlowReturn
gst_base_rtksrtrender_text_chain (GstPad * pad, GstObject * parent,
    GstBuffer * buffer)
{
  GstFlowReturn ret = GST_FLOW_OK;
  GstBaseRtkSrtRender *overlay = NULL;
  gboolean in_seg = FALSE;
  guint64 clip_start = 0, clip_stop = 0;
  overlay = GST_BASE_RTKSRTRENDER (parent);
  GST_BASE_RTKSRTRENDER_LOCK (overlay);
  if (overlay->silent == TRUE)
  {
     gst_buffer_unref(buffer);
     GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
     return GST_FLOW_OK;
  }

  if (overlay->text_flushing) {
    GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
    ret = GST_FLOW_OK;
    GST_LOG_OBJECT (overlay, "text flushing");
    goto beach;
  }

  if (overlay->text_eos) {
    GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
    ret = GST_FLOW_EOS;
    GST_LOG_OBJECT (overlay, "text EOS");
    goto beach;
  }

  if  (overlay->video_segment_need_update == FALSE && buffer != NULL) {
    if (GST_BUFFER_TIMESTAMP_IS_VALID (buffer) && GST_BUFFER_DURATION_IS_VALID (buffer)) {
      if (GST_BUFFER_TIMESTAMP (buffer) + GST_BUFFER_DURATION (buffer) <= overlay->last_video_timestamp)
      {
        gst_buffer_unref(buffer);
        GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
        return GST_FLOW_OK;
      }
    }
  }

  GST_LOG_OBJECT (overlay, "%" GST_SEGMENT_FORMAT "  BUFFER: ts=%"
      GST_TIME_FORMAT ", end=%" GST_TIME_FORMAT, &overlay->segment,
      GST_TIME_ARGS (GST_BUFFER_TIMESTAMP (buffer)),
      GST_TIME_ARGS (GST_BUFFER_TIMESTAMP (buffer) +
          GST_BUFFER_DURATION (buffer)));

  if (G_LIKELY (GST_BUFFER_TIMESTAMP_IS_VALID (buffer))) {
    GstClockTime stop;

    if (G_LIKELY (GST_BUFFER_DURATION_IS_VALID (buffer)))
      stop = GST_BUFFER_TIMESTAMP (buffer) + GST_BUFFER_DURATION (buffer);
    else
      stop = GST_CLOCK_TIME_NONE;

    in_seg = gst_segment_clip (&overlay->text_segment, GST_FORMAT_TIME,
        GST_BUFFER_TIMESTAMP (buffer), stop, &clip_start, &clip_stop);
  } else {
    in_seg = TRUE;
  }

  if (in_seg) {
    /* about to change metadata */
    buffer = gst_buffer_make_writable (buffer);
    if (GST_BUFFER_TIMESTAMP_IS_VALID (buffer))
      GST_BUFFER_TIMESTAMP (buffer) = clip_start;
    if (GST_BUFFER_DURATION_IS_VALID (buffer))
      GST_BUFFER_DURATION (buffer) = clip_stop - clip_start;

    /* Wait for the previous buffer to go away */
    while (overlay->text_buffer != NULL) {
      GST_DEBUG ("Pad %s:%s has a buffer queued, waiting",
          GST_DEBUG_PAD_NAME (pad));
      GST_BASE_RTKSRTRENDER_WAIT (overlay);
      GST_DEBUG ("Pad %s:%s resuming", GST_DEBUG_PAD_NAME (pad));
      if (overlay->text_flushing) {
        GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
        ret = GST_FLOW_FLUSHING;
        goto beach;
      }
    }

    /* Calculate and store the running time for this text buffer in 
     * the current segment. We might receive a new text pad segment
     * event while this buffer is still active, and that would
     * lead to incorrect running time calculations if we did it later.
     */
    overlay->text_buffer_running_time = overlay->text_buffer_running_time_end =
        GST_CLOCK_TIME_NONE;

    if (GST_BUFFER_TIMESTAMP_IS_VALID (buffer)) {
      GstClockTime text_start = GST_BUFFER_TIMESTAMP (buffer);

      overlay->text_segment.position = clip_start;
      overlay->text_buffer_running_time =
          gst_segment_to_running_time (&overlay->text_segment,
          GST_FORMAT_TIME, text_start);

      if (GST_BUFFER_DURATION_IS_VALID (buffer)) {
        GstClockTime text_end = text_start + GST_BUFFER_DURATION (buffer);
        overlay->text_buffer_running_time_end =
            gst_segment_to_running_time (&overlay->text_segment,
            GST_FORMAT_TIME, text_end);
        GstClockTime *clear_time = (GstClockTime *)malloc(sizeof(GstClockTime));
        *clear_time = overlay->text_buffer_running_time_end;
        g_queue_push_tail(overlay->clear_time_list, clear_time);
      }
    }
    GST_BASE_RTKSRTRENDER_TEXT_BUFFER_LOCK(overlay);
    overlay->text_buffer = buffer;
    GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(overlay);
    buffer = NULL;
  }

  GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
  if (overlay->extra_subtitle == FALSE)
    gst_base_rtksubtitle_process_subtitle(overlay, FALSE);

  GST_BASE_RTKSRTRENDER_TEXT_BUFFER_LOCK(overlay);
  if (overlay->extra_subtitle == TRUE && overlay->text_direct_render == TRUE && overlay->text_buffer != NULL) {
    if (GST_BUFFER_PTS(overlay->text_buffer) + GST_BUFFER_DURATION(overlay->text_buffer) <= overlay->last_video_timestamp) {
      gst_buffer_unref(overlay->text_buffer);
      overlay->text_buffer = NULL;
      overlay->text_updating = FALSE;
      GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(overlay);
      GST_BASE_RTKSRTRENDER_BROADCAST (overlay);
    } else {
      if (GST_BUFFER_PTS(overlay->text_buffer) <= overlay->last_video_timestamp) {
        GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(overlay);
        gst_base_rtksubtitle_process_subtitle(overlay, TRUE);
        overlay->text_direct_render = FALSE;
      } else {
        GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(overlay);
        GstBuffer *clear_buffer;
        ret = gst_buffer_pool_acquire_buffer (overlay->text_pool, &clear_buffer, NULL);
        if (ret == GST_FLOW_OK) {
          GST_BUFFER_TIMESTAMP(clear_buffer) = overlay->last_video_timestamp;
          GST_BUFFER_DURATION(clear_buffer) = GST_CLOCK_TIME_NONE;
          gst_pad_push (overlay->text_srcpad, clear_buffer);
        }
        overlay->text_direct_render = FALSE;
      }
    }
  } else {
    GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(overlay);
  }

beach:
  if (buffer)
    gst_buffer_unref (buffer);

  return ret;
}

void *process_subtitle(void *data)
{
  GstBaseRtkSrtRender *overlay = (GstBaseRtkSrtRender *)data;
  GST_BASE_RTKSRTRENDER_LOCK (overlay);
  if (overlay->text_flushing == TRUE) {
    GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
    return NULL;
  }

  GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
  gst_base_rtksubtitle_process_subtitle(overlay, TRUE);
}

static GstFlowReturn
gst_base_rtksrtrender_video_chain (GstPad * pad, GstObject * parent,
    GstBuffer * buffer)
{
  GstBaseRtkSrtRender *overlay;
  GstFlowReturn ret = GST_FLOW_OK;
  gboolean in_seg = FALSE;
  guint64 start, stop, clip_start = 0, clip_stop = 0;
  overlay = GST_BASE_RTKSRTRENDER (parent);
  GstClockTime vid_running_time;
  if (!GST_BUFFER_TIMESTAMP_IS_VALID (buffer))
    goto missing_timestamp;

  /* ignore buffers that are outside of the current segment */
  start = GST_BUFFER_TIMESTAMP (buffer);

  if (!GST_BUFFER_DURATION_IS_VALID (buffer)) {
    stop = GST_CLOCK_TIME_NONE;
  } else {
    stop = start + GST_BUFFER_DURATION (buffer);
  }

  GST_LOG_OBJECT (overlay, "%" GST_SEGMENT_FORMAT "  BUFFER: ts=%"
      GST_TIME_FORMAT ", end=%" GST_TIME_FORMAT, &overlay->segment,
      GST_TIME_ARGS (start), GST_TIME_ARGS (stop));

  /* segment_clip() will adjust start unconditionally to segment_start if
   * no stop time is provided, so handle this ourselves */
  if (stop == GST_CLOCK_TIME_NONE && start < overlay->segment.start)
    goto out_of_segment;

  in_seg = gst_segment_clip (&overlay->segment, GST_FORMAT_TIME, start, stop,
      &clip_start, &clip_stop);

  if (!in_seg)
    goto out_of_segment;

  /* if the buffer is only partially in the segment, fix up stamps */
  if (clip_start != start || (stop != -1 && clip_stop != stop)) {
    GST_DEBUG_OBJECT (overlay, "clipping buffer timestamp/duration to segment");
    buffer = gst_buffer_make_writable (buffer);
    GST_BUFFER_TIMESTAMP (buffer) = clip_start;
    if (stop != -1)
      GST_BUFFER_DURATION (buffer) = clip_stop - clip_start;
  }

  /* now, after we've done the clipping, fix up end time if there's no
   * duration (we only use those estimated values internally though, we
   * don't want to set bogus values on the buffer itself) */
  if (stop == -1) {
    if (overlay->info.fps_n && overlay->info.fps_d) {
      GST_DEBUG_OBJECT (overlay, "estimating duration based on framerate");
      stop = start + gst_util_uint64_scale_int (GST_SECOND,
          overlay->info.fps_d, overlay->info.fps_n);
    } else {
      GST_LOG_OBJECT (overlay, "no duration, assuming minimal duration");
      stop = start + 1;         /* we need to assume some interval */
    }
  }

  gst_object_sync_values (GST_OBJECT (overlay), GST_BUFFER_TIMESTAMP (buffer));

  GST_BASE_RTKSRTRENDER_LOCK (overlay);

  if (overlay->silent == TRUE)
  {
    gst_buffer_unref(buffer);
    GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
    return GST_FLOW_OK;
  }

  if (overlay->video_flushing)
    goto flushing;

  if (overlay->video_eos)
    goto have_eos;

  vid_running_time =
          gst_segment_to_running_time (&overlay->segment, GST_FORMAT_TIME,
          start);

  GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
  overlay->last_video_timestamp = GST_BUFFER_TIMESTAMP(buffer);
  overlay->last_video_duration = GST_BUFFER_DURATION(buffer);

  if (overlay->usecma) {
    if(!GST_CLOCK_TIME_IS_VALID (overlay->last_text_timestamp) || overlay->last_video_timestamp > overlay->last_text_timestamp) {
      GstEvent *gap_event = gst_event_new_gap(overlay->last_video_timestamp, overlay->last_video_duration);
      gst_pad_push_event(overlay->text_srcpad, gap_event);
    }
  }
  else if (overlay->preload_gap < 3) {
    GstEvent *gap_event = gst_event_new_gap(overlay->last_video_timestamp, GST_CLOCK_TIME_NONE);
    overlay->preload_gap++;
    gst_pad_push_event(overlay->text_srcpad, gap_event);
  }

  ret = gst_pad_push (overlay->video_srcpad, buffer);

  GST_BASE_RTKSRTRENDER_TEXT_BUFFER_LOCK(overlay);
  overlay->text_direct_render = FALSE;
  if (overlay->extra_subtitle == TRUE && overlay->text_updating == FALSE &&
           overlay->text_buffer != NULL && overlay->text_buffer_running_time <= vid_running_time && overlay->video_segment_need_update == FALSE) {
    overlay->text_updating = TRUE;
    if (overlay->text_buffer_running_time_end <= vid_running_time)
    {
      if (overlay->rate > 1.0) {
        overlay->text_direct_render = TRUE;
      } else {
        GstBuffer *clear_buffer;
        ret = gst_buffer_pool_acquire_buffer (overlay->text_pool, &clear_buffer, NULL);
        if (ret == GST_FLOW_OK) {
          GST_BUFFER_TIMESTAMP(clear_buffer) = overlay->last_video_timestamp;
          GST_BUFFER_DURATION(clear_buffer) = GST_CLOCK_TIME_NONE;
          gst_pad_push (overlay->text_srcpad, clear_buffer);
        }
      }

      gst_buffer_unref(overlay->text_buffer);
      overlay->text_buffer = NULL;
      overlay->text_updating = FALSE;
      GST_BASE_RTKSRTRENDER_BROADCAST (overlay);
      GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(overlay);
    } else {
      GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(overlay);

      pthread_t tid;
      pthread_attr_t attr;

      pthread_attr_init(&attr);
      pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
      pthread_create(&tid, &attr, process_subtitle, overlay);
      pthread_attr_destroy(&attr);
    }

    GstClockTime *clear_time = NULL;
    while (!g_queue_is_empty(overlay->clear_time_list)) {
      clear_time = (GstClockTime *)g_queue_pop_head(overlay->clear_time_list);
      if (clear_time != NULL && *clear_time <= vid_running_time) {
        free(clear_time);
      } else {
        if (clear_time != NULL && *clear_time > vid_running_time) {
          g_queue_push_head(overlay->clear_time_list, clear_time);
        }
        break;
      }
    }
//    gst_base_rtksubtitle_process_subtitle(overlay);
  } else {
    GST_BASE_RTKSRTRENDER_TEXT_BUFFER_UNLOCK(overlay);

    GstClockTime *clear_time = NULL;
    GstClockTime last_clear_time = GST_CLOCK_TIME_NONE;

    while (!g_queue_is_empty(overlay->clear_time_list)) {
      clear_time = (GstClockTime *)g_queue_pop_head(overlay->clear_time_list);
      if (clear_time != NULL && *clear_time <= vid_running_time) {
        last_clear_time = *clear_time;
        free(clear_time);
      } else {
        if (clear_time != NULL && *clear_time > vid_running_time) {
          g_queue_push_head(overlay->clear_time_list, clear_time);
          break;
        }
      }
    }

    if (last_clear_time != GST_CLOCK_TIME_NONE) {
      GstBuffer *clear_buffer;
      ret = gst_buffer_pool_acquire_buffer (overlay->text_pool, &clear_buffer, NULL);
      if (ret == GST_FLOW_OK) {
        GST_BUFFER_TIMESTAMP(clear_buffer) = overlay->last_video_timestamp;
        GST_BUFFER_DURATION(clear_buffer) = GST_CLOCK_TIME_NONE;
        gst_pad_push (overlay->text_srcpad, clear_buffer);
      }
    }
  }
  /* Update position */
  overlay->segment.position = clip_start;

  return ret;

missing_timestamp:
  {
    GST_WARNING_OBJECT (overlay, "buffer without timestamp, discarding");
    gst_buffer_unref (buffer);
    return GST_FLOW_OK;
  }

flushing:
  {
    GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
    GST_DEBUG_OBJECT (overlay, "flushing, discarding buffer");
    gst_buffer_unref (buffer);
    return GST_FLOW_FLUSHING;
  }
have_eos:
  {
    GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
    GST_DEBUG_OBJECT (overlay, "eos, discarding buffer");
    gst_buffer_unref (buffer);
    return GST_FLOW_EOS;
  }
out_of_segment:
  {
    GST_DEBUG_OBJECT (overlay, "buffer out of segment, discarding");
    gst_buffer_unref (buffer);
    return GST_FLOW_OK;
  }
}

static GstStateChangeReturn
gst_base_rtksrtrender_change_state (GstElement * element,
    GstStateChange transition)
{
  GstStateChangeReturn ret = GST_STATE_CHANGE_SUCCESS;
  GstBaseRtkSrtRender *overlay = GST_BASE_RTKSRTRENDER (element);

  switch (transition) {
    case GST_STATE_CHANGE_PAUSED_TO_READY:
      GST_BASE_RTKSRTRENDER_LOCK (overlay);
      GST_BASE_RTKSRTRENDER_BROADCAST (overlay);
      overlay->text_flushing = TRUE;
      overlay->video_flushing = TRUE;
      /* pop_text will broadcast on the GCond and thus also make the video
       * chain exit if it's waiting for a text buffer */
      GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      gst_base_rtksrtrender_pop_text (overlay);
      break;
    case GST_STATE_CHANGE_PLAYING_TO_PAUSED:
    case GST_STATE_CHANGE_PAUSED_TO_PLAYING:
      if (!overlay->usecma) {
        overlay->preload_gap = 0;
        GstEvent *event = gst_event_new_gap(overlay->last_video_timestamp, GST_CLOCK_TIME_NONE);
        gst_pad_push_event(overlay->text_srcpad, event);
      }
      break;
    default:
      break;
  }

  ret = parent_class->change_state (element, transition);
  if (ret == GST_STATE_CHANGE_FAILURE)
    return ret;

  switch (transition) {
    case GST_STATE_CHANGE_READY_TO_PAUSED:
      GST_BASE_RTKSRTRENDER_LOCK (overlay);
      GST_BASE_RTKSRTRENDER_BROADCAST (overlay);
      overlay->text_flushing = FALSE;
      overlay->video_flushing = FALSE;
      overlay->video_eos = FALSE;
      overlay->text_eos = FALSE;
      gst_segment_init (&overlay->segment, GST_FORMAT_TIME);
      gst_segment_init (&overlay->text_segment, GST_FORMAT_TIME);
      GST_BASE_RTKSRTRENDER_UNLOCK (overlay);
      break;
    default:
      break;
  }

  return ret;
}
