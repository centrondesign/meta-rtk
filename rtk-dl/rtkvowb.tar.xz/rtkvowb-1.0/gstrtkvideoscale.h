#ifndef __GST_RTK_VIDEO_SCALE_H__
#define __GST_RTK_VIDEO_SCALE_H__

#include <gst/gst.h>
#include <gst/base/gstbasetransform.h>
#include <gst/video/video.h>
#include "ext/ve_common.h"

G_BEGIN_DECLS

#define GST_TYPE_RTK_VIDEO_SCALE \
  (gst_rtk_video_scale_get_type())
#define GST_RTK_VIDEO_SCALE(obj) \
  (G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_RTK_VIDEO_SCALE,GstRtkVideoScale))
#define GST_RTK_VIDEO_SCALE_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_CAST((klass),GST_TYPE_RTK_VIDEO_SCALE,GstRtkVideoScaleClass))
#define GST_IS_RTK_VIDEO_SCALE(obj) \
  (G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_TYPE_RTK_VIDEO_SCALE))
#define GST_IS_RTK_VIDEO_SCALE_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_TYPE((klass),GST_TYPE_RTK_VIDEO_SCALE))
#define GST_RTK_VIDEO_SCALE_CAST(obj)       ((GstRtkVideoScale *)(obj))

#define GST_RTK_VIDEO_SCALE_GET_LOCK(obj) (&GST_RTK_VIDEO_SCALE(obj)->lock)
#define GST_RTK_VIDEO_SCALE_LOCK(obj) \
  g_mutex_lock(GST_RTK_VIDEO_SCALE_GET_LOCK(obj))
#define GST_RTK_VIDEO_SCALE_UNLOCK(obj) \
  g_mutex_unlock(GST_RTK_VIDEO_SCALE_GET_LOCK(obj))

typedef struct _GstRtkVideoScale GstRtkVideoScale;
typedef struct _GstRtkVideoScaleClass GstRtkVideoScaleClass;

struct _GstRtkVideoScale {
  GstBaseTransform        parent;

  /// Global mutex lock.
  GMutex                  lock;

  GstVideoInfo            *ininfo;
  GstVideoInfo            *outinfo;

  // Features of the negotiated input and output caps.
  GQuark                  infeature;
  GQuark                  outfeature;

  // Output buffer pool
  GstBufferPool           *outpool;
  GstVideoAlignment       out_video_align;

  gboolean                ignore_bit_depth;
  gboolean                bit_depth_10;
  gboolean                ve2_compress;
  gboolean                force_passthrough;
  gboolean                interleaved;
  gboolean                transferCharacteristics;
  gboolean                debug;
  guint                   drmfd;

  struct yuv_state        input_yuvs;
  struct yuv_state        input_yuvs_prev;
  struct yuv_state        input_yuvs_prev_two;

  GstBuffer *inbuffer;
  GstBuffer *inbuffer_prev;
  GstBuffer *inbuffer_prev_two;

};

struct _GstRtkVideoScaleClass {
  GstBaseTransformClass parent;
};

G_GNUC_INTERNAL GType gst_rtk_video_scale_get_type (void);

G_END_DECLS

#endif // __GST_RTK_VIDEO_SCALE_H__