#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "gstrtkvideoscale.h"
#include <gstrtkdmaallocator.h>
#include "ext/rtk_drm_vowb.h"
#include "ext/ve_common.h"
#include "ext/rtk_heap.h"
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <xf86drm.h>

#define DRM_IOCTL_RTK_VOWB_RUN_CMD          DRM_IOWR(DRM_COMMAND_BASE + 0x47, struct rtk_drm_vowb_run_cmd)
#define DRM_IOCTL_RTK_VOWB_CHECK_CMD        DRM_IOWR(DRM_COMMAND_BASE + 0x48, struct rtk_drm_vowb_check_cmd)
#define DRM_IOCTL_RTK_VOWB_GET_FEATURES     DRM_IOWR(DRM_COMMAND_BASE + 0x49, struct rtk_drm_vowb_run_cmd)

#define ROUNDUP(x, y)     ((x + y - 1) & ~(y - 1))
#define ROUNDUP4(x)       ROUNDUP(x, 4)
#define ROUNDUP16(x)      ROUNDUP(x, 16)
#define ROUNDUP32(x)      ROUNDUP(x, 32)
#define ROUNDUP64(x)      ROUNDUP(x, 64)

#define GST_CAT_DEFAULT gst_rtk_video_scale_debug
GST_DEBUG_CATEGORY_STATIC (gst_rtk_video_scale_debug);

#define gst_rtk_video_scale_parent_class parent_class
G_DEFINE_TYPE (GstRtkVideoScale, gst_rtk_video_scale, GST_TYPE_BASE_TRANSFORM);

#define DEFAULT_PROP_IGNORE_BIT_DEPTH     FALSE
#define DEFAULT_FORCE_PASSTHROUGH         FALSE
#define DEFAULT_PROP_MIN_BUFFERS      4
#define DEFAULT_PROP_MAX_BUFFERS      10
#define DEFAULT_OFFSET 2048

#undef GST_VIDEO_SIZE_RANGE
#define GST_VIDEO_SIZE_RANGE "(int) [ 1, 32767 ]"

#undef GST_VIDEO_FPS_RANGE
#define GST_VIDEO_FPS_RANGE "(fraction) [ 0, 255 ]"

#define GST_SINK_VIDEO_FORMATS \
  "{ NV12 }"

#define GST_SRC_VIDEO_FORMATS \
  "{ NV12 }"

enum
{
  PROP_0,
  PROP_IGNORE_BIT_DEPTH,
  PROP_FORCE_PASSTHROUGH,
};

static GstCaps *
gst_rtk_video_scale_sink_caps (void)
{
  static GstCaps *caps = NULL;
  static gsize inited = 0;

  if (g_once_init_enter (&inited)) {
    caps = gst_caps_from_string (GST_VIDEO_CAPS_MAKE (GST_SINK_VIDEO_FORMATS));

    g_once_init_leave (&inited, 1);
  }
  return caps;
}

static GstCaps *
gst_rtk_video_scale_src_caps (void)
{
  static GstCaps *caps = NULL;
  static gsize inited = 0;

  if (g_once_init_enter (&inited)) {
    caps = gst_caps_from_string (GST_VIDEO_CAPS_MAKE (GST_SRC_VIDEO_FORMATS));

    g_once_init_leave (&inited, 1);
  }
  return caps;
}

static GstPadTemplate *
gst_rtk_video_scale_sink_template (void)
{
  return gst_pad_template_new ("sink", GST_PAD_SINK, GST_PAD_ALWAYS,
      gst_rtk_video_scale_sink_caps ());
}

static GstPadTemplate *
gst_rtk_video_scale_src_template (void)
{
  return gst_pad_template_new ("src", GST_PAD_SRC, GST_PAD_ALWAYS,
      gst_rtk_video_scale_src_caps ());
}

static void
gst_rtk_video_scale_determine_passthrough (GstRtkVideoScale * vscale)
{
  gboolean passthrough = TRUE;

  // Determine whether we are going to operate in passthrough mode.
  if (vscale->ininfo != NULL && vscale->outinfo != NULL) {
    passthrough &= vscale->ininfo->width == vscale->outinfo->width &&
        vscale->ininfo->height == vscale->outinfo->height;
    passthrough &=
        vscale->ininfo->finfo->format == vscale->outinfo->finfo->format;
  }

  passthrough &= vscale->outfeature == vscale->infeature;
  passthrough &= (vscale->ignore_bit_depth == TRUE || vscale->bit_depth_10 == FALSE);
  passthrough &= (vscale->ve2_compress == FALSE);
  passthrough &= (vscale->interleaved == FALSE);
  passthrough &= (vscale->transferCharacteristics == FALSE);
  passthrough |= vscale->force_passthrough;

  GST_DEBUG_OBJECT (vscale, "Passthrough has been %s",
      passthrough ? "enabled" : "disabled");

  gst_base_transform_set_passthrough (GST_BASE_TRANSFORM (vscale), passthrough);
}

static GstBufferPool *
gst_rtk_video_scale_create_pool (GstRtkVideoScale * vscale, GstCaps * caps)
{
  GstBufferPool *pool = NULL;
  GstStructure *config = NULL;
  GstAllocator *allocator = NULL;
  GstVideoInfo info;

  if (!gst_video_info_from_caps (&info, caps)) {
    GST_ERROR_OBJECT (vscale, "Invalid caps %" GST_PTR_FORMAT, caps);
    return NULL;
  }
  
  GstVideoFormat format;
  GstVideoAlignment video_align;
  guint width, height,buffer_size;
  guint padding_width, padding_height;

  width = GST_VIDEO_INFO_WIDTH (&info);
  height = GST_VIDEO_INFO_HEIGHT (&info);
  format = GST_VIDEO_INFO_FORMAT (&info);

  pool = gst_video_buffer_pool_new ();
  config = gst_buffer_pool_get_config (pool);

  allocator = gst_rtk_dma_allocator_new ();
  if (allocator == NULL) {
    GST_ERROR_OBJECT (vscale, "Failed to create dma allocator");
    gst_clear_object (&pool);
    return NULL;
  }

  padding_width = ROUNDUP32(width);
  padding_height = ROUNDUP32(height);
  if(vscale->ignore_bit_depth)
    buffer_size = padding_width * 1.25 * padding_height * 1.5 + DEFAULT_OFFSET;
  else
    buffer_size = padding_width * padding_height * 1.5 + DEFAULT_OFFSET;
  video_align.stride_align[0]=0;
  video_align.stride_align[1]=0;
  video_align.stride_align[2]=0;
  video_align.stride_align[3]=0;
  video_align.padding_top   = 0;
  video_align.padding_left  = 0;
  video_align.padding_bottom = padding_height - height;
  video_align.padding_right = padding_width - width;
  gst_structure_set (config,
      "padding-top", G_TYPE_UINT, video_align.padding_top,
      "padding-bottom", G_TYPE_UINT, video_align.padding_bottom,
      "padding-left", G_TYPE_UINT, video_align.padding_left,
      "padding-right", G_TYPE_UINT, video_align.padding_right,
      "stride-align0", G_TYPE_UINT, video_align.stride_align[0],
      "stride-align1", G_TYPE_UINT, video_align.stride_align[1],
      "stride-align2", G_TYPE_UINT, video_align.stride_align[2],
      "stride-align3", G_TYPE_UINT, video_align.stride_align[3], NULL);

  GST_DEBUG_OBJECT (vscale, "padding_width %d padding_height %d",padding_width,padding_height);
  GST_DEBUG_OBJECT (vscale, "align.padding_bottom %d align.padding_right %d",video_align.padding_bottom,video_align.padding_right);
  gst_buffer_pool_config_set_params (config, caps, buffer_size,
      DEFAULT_PROP_MIN_BUFFERS, DEFAULT_PROP_MAX_BUFFERS);
  gst_buffer_pool_config_set_allocator (config, allocator, NULL);
  gst_buffer_pool_config_add_option (config, GST_BUFFER_POOL_OPTION_VIDEO_META);
  gst_buffer_pool_config_add_option (config, GST_BUFFER_POOL_OPTION_VIDEO_ALIGNMENT);

  if (!gst_buffer_pool_set_config (pool, config)) {
    GST_WARNING_OBJECT (vscale, "Failed to set pool configuration!");
    g_object_unref (pool);
    pool = NULL;
  }

  g_object_unref (allocator);

  return pool;
}

static gboolean
gst_rtk_video_scale_propose_allocation (GstBaseTransform * base,
    GstQuery * inquery, GstQuery * outquery)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE_CAST (base);

  GstCaps *caps = NULL;
  GstBufferPool *pool = NULL;
  GstVideoInfo info;
  guint size = 0;
  gboolean needpool = FALSE;

  if (NULL != inquery)
    gst_pad_peer_query (base->srcpad, outquery);

  if (!GST_BASE_TRANSFORM_CLASS (parent_class)->propose_allocation (
        base, inquery, outquery))
    return FALSE;

  // No input query, nothing to do.
  if (NULL == inquery)
    return TRUE;

  // Extract caps from the query.
  gst_query_parse_allocation (outquery, &caps, &needpool);

  if (NULL == caps) {
    GST_ERROR_OBJECT (vscale, "Failed to extract caps from query!");
    return FALSE;
  }

  if (!gst_video_info_from_caps (&info, caps)) {
    GST_ERROR_OBJECT (vscale, "Failed to get video info!");
    return FALSE;
  }

  // Get the size from video info.
  size = GST_VIDEO_INFO_SIZE (&info);
  //GST_ERROR_OBJECT (vscale, "gst_rtk_video_scale_propose_allocation size %d",size);
  if (needpool) {
    GstStructure *structure = NULL;
    GstAllocator *allocator = NULL;
    GstVideoAlignment align;
    pool = gst_rtk_video_scale_create_pool (vscale, caps);
    structure = gst_buffer_pool_get_config (pool);
    // Set caps and size in query.
    //gst_buffer_pool_config_set_params (structure, caps, size, 0, 0);

    gst_buffer_pool_config_get_allocator (structure, &allocator, NULL);
    gst_query_add_allocation_param (outquery, allocator, NULL);

    if (!gst_buffer_pool_set_config (pool, structure)) {
      GST_ERROR_OBJECT (vscale, "Failed to set buffer pool configuration!");
      gst_object_unref (pool);
      return FALSE;
    }
  }

  // If upstream does't have a pool requirement, set only size in query.
  gst_query_add_allocation_pool (outquery, needpool ? pool : NULL, size, 0, 0);

  if (pool != NULL)
    gst_object_unref (pool);

  gst_query_add_allocation_meta (outquery, GST_VIDEO_META_API_TYPE, NULL);
  return TRUE;
}

static gboolean
gst_rtk_video_scale_decide_allocation (GstBaseTransform * base,
    GstQuery * query)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE_CAST (base);

  GstCaps *caps = NULL;
  GstBufferPool *pool = NULL;
  GstStructure *config = NULL;
  GstAllocator *allocator = NULL;
  guint size, minbuffers, maxbuffers;
  GstAllocationParams params;

  gst_query_parse_allocation (query, &caps, NULL);
  if (!caps) {
    GST_ERROR_OBJECT (vscale, "Failed to parse the decide_allocation caps!");
    return FALSE;
  }

  // Invalidate the cached pool if there is an allocation_query.
  if (vscale->outpool) {
    gst_buffer_pool_set_active (vscale->outpool, FALSE);
    gst_object_unref (vscale->outpool);
  }

  // Create a new buffer pool.
  pool = gst_rtk_video_scale_create_pool (vscale, caps);
  vscale->outpool = pool;

  // Get the configured pool properties in order to set in query.
  config = gst_buffer_pool_get_config (pool);
  gst_buffer_pool_config_get_params (config, &caps, &size, &minbuffers,
      &maxbuffers);

  if (gst_buffer_pool_config_get_allocator (config, &allocator, &params))
    gst_query_add_allocation_param (query, allocator, &params);

  gst_buffer_pool_config_get_video_alignment(config,&vscale->out_video_align);
  gst_structure_free (config);

  // Check whether the query has pool.
  if (gst_query_get_n_allocation_pools (query) > 0)
    gst_query_set_nth_allocation_pool (query, 0, pool, size, minbuffers,
        maxbuffers);
  else
    gst_query_add_allocation_pool (query, pool, size, minbuffers,
        maxbuffers);

  gst_query_add_allocation_meta (query, GST_VIDEO_META_API_TYPE, NULL);
  return TRUE;
}

static GstFlowReturn
gst_rtk_video_scale_prepare_output_buffer (GstBaseTransform * base,
    GstBuffer * inbuffer, GstBuffer ** outbuffer)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE_CAST (base);
  GstBufferPool *pool = vscale->outpool;
  gboolean passthrough = FALSE, writable = TRUE, is_dmabuf_mem;
  gsize in_size, in_offset, in_maxsize;
  gsize out_size, out_offset, out_maxsize;
  GstMemory *in_mem,*out_mem;
  GstMapInfo mapinfo;
  struct ve_frame_info *veframe_info = NULL;

  in_mem = gst_buffer_peek_memory (inbuffer, 0);
  if(gst_is_dmabuf_memory(in_mem)) {
    in_size = gst_memory_get_sizes (in_mem, &in_offset, &in_maxsize);
    if(in_offset == DEFAULT_OFFSET) {
      gst_memory_map (in_mem, &mapinfo, GST_MAP_READ);
      veframe_info = (struct ve_frame_info *)(mapinfo.data - in_offset);

      GST_DEBUG_OBJECT (vscale, "veframe_info->yuvs.bufBitDepth %d",veframe_info->yuvs.bufBitDepth);
      GST_DEBUG_OBJECT (vscale, "veframe_info->yuvs.mode %d",veframe_info->yuvs.mode);

      if(veframe_info->yuvs.bufBitDepth == 10)
          vscale->bit_depth_10 = TRUE;
      if(veframe_info->yuvs.lumaOffTblAddr != 0xffffffff)
            vscale->ve2_compress = TRUE;
      if(veframe_info->yuvs.mode != CONSECUTIVE_FRAME)
            vscale->interleaved = TRUE;
      if(veframe_info->yuvs.transferCharacteristics == 2 || veframe_info->yuvs.transferCharacteristics == 6)
            vscale->transferCharacteristics = TRUE;
      vscale->input_yuvs= veframe_info->yuvs;
      gst_memory_unmap (in_mem, &mapinfo);
    } else {
      GST_DEBUG_OBJECT (vscale, "in_offset = %d",in_offset);
    }
    // Check whether passthrough should be true/false based on parameters.
    gst_rtk_video_scale_determine_passthrough (vscale);
  } else {
    GST_DEBUG_OBJECT (vscale, "inbuffer is not dmabuf, passthrough has been enabled");
    gst_base_transform_set_passthrough (GST_BASE_TRANSFORM (vscale), TRUE);
  }

  passthrough = gst_base_transform_is_passthrough (base);
  writable = gst_buffer_is_writable (inbuffer);

  // Force a copy when the buffer is not writable.
  if (passthrough && !writable) {
    GST_TRACE_OBJECT (vscale, "Input buffer not writable, disable passthrough");
    gst_base_transform_set_passthrough (base, FALSE);
  } else if (passthrough) {
    GST_LOG_OBJECT (vscale, "Passthrough, no need to do anything");
    *outbuffer = inbuffer;
    return GST_FLOW_OK;
  }

  g_return_val_if_fail (pool != NULL, GST_FLOW_ERROR);

  if (!gst_buffer_pool_is_active (pool) &&
      !gst_buffer_pool_set_active (pool, TRUE)) {
    GST_ERROR_OBJECT (vscale, "Failed to activate output video buffer pool!");
    return GST_FLOW_ERROR;
  }

  // Input is marked as GAP, nothing to process. Create a GAP output buffer.
  if (gst_buffer_get_size (inbuffer) == 0 &&
      GST_BUFFER_FLAG_IS_SET (inbuffer, GST_BUFFER_FLAG_GAP))
    *outbuffer = gst_buffer_new ();

  if ((*outbuffer == NULL) &&
      gst_buffer_pool_acquire_buffer (pool, outbuffer, NULL) != GST_FLOW_OK) {
    GST_ERROR_OBJECT (vscale, "Failed to create output video buffer!");
    return GST_FLOW_ERROR;
  }

  out_mem = gst_buffer_peek_memory (*outbuffer, 0);
  if(gst_is_dmabuf_memory(out_mem)) {
    out_size = gst_memory_get_sizes (out_mem, &out_offset, &out_maxsize);
    if(out_offset != DEFAULT_OFFSET){
      gst_memory_resize(out_mem,DEFAULT_OFFSET,out_maxsize - DEFAULT_OFFSET);
      GST_LOG_OBJECT (vscale, "gst_memory_resize out_mem %d",DEFAULT_OFFSET);
    }
  }

  // Copy the flags and timestamps from the input buffer.
  gst_buffer_copy_into (*outbuffer, inbuffer,
      GST_BUFFER_COPY_FLAGS | GST_BUFFER_COPY_TIMESTAMPS, 0, -1);

  return GST_FLOW_OK;
}

static GstCaps *
gst_rtk_video_scale_transform_caps (GstBaseTransform * base,
    GstPadDirection direction, GstCaps * caps, GstCaps * filter)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE (base);
  GstCaps *result = NULL;
  GstStructure *structure = NULL;
  GstCapsFeatures *features = NULL;
  gint idx = 0, length = 0;

  GST_DEBUG_OBJECT (vscale, "Transforming caps %" GST_PTR_FORMAT
      " in direction %s", caps, (direction == GST_PAD_SINK) ? "sink" : "src");
  GST_DEBUG_OBJECT (vscale, "Filter caps %" GST_PTR_FORMAT, filter);


  result = gst_caps_new_empty ();

  length = gst_caps_get_size (caps);

  for (idx = 0; idx < length; idx++) {
    structure = gst_caps_get_structure (caps, idx);
    features = gst_caps_get_features (caps, idx);

    // If this is already expressed by the existing caps skip this structure.
    if (idx > 0 && gst_caps_is_subset_structure_full (result, structure, features))
      continue;

    // Make a copy that will be modified.
    structure = gst_structure_copy (structure);

    // Set width and height to a range instead of fixed value.
    gst_structure_set (structure, "width", GST_TYPE_INT_RANGE, 1, G_MAXINT,
        "height", GST_TYPE_INT_RANGE, 1, G_MAXINT, NULL);

    // If pixel aspect ratio, make a range of it.
    if (gst_structure_has_field (structure, "pixel-aspect-ratio")) {
      gst_structure_set (structure, "pixel-aspect-ratio",
          GST_TYPE_FRACTION_RANGE, 1, G_MAXINT, G_MAXINT, 1, NULL);
    }

    if (!vscale->force_passthrough && gst_structure_has_field (structure, "interlace-mode")) {
      gst_structure_remove_fields (structure, "interlace-mode", NULL);
    }

    // Remove the format/color/compression related fields.
    gst_structure_remove_fields (structure, "format", "colorimetry",
        "chroma-site", "compression", NULL);

    gst_caps_append_structure_full (result, structure,
        gst_caps_features_copy (features));
  }

  if (filter) {
    GstCaps *intersection  =
        gst_caps_intersect_full (filter, result, GST_CAPS_INTERSECT_FIRST);
    gst_caps_unref (result);
    result = intersection;
  }

  GST_DEBUG_OBJECT (vscale, "Returning caps: %" GST_PTR_FORMAT, result);
  return result;
}

static gboolean
gst_rtk_video_scale_set_caps (GstBaseTransform * base, GstCaps * incaps,
    GstCaps * outcaps)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE (base);
  const gchar *feature = NULL;
  GstVideoInfo ininfo, outinfo;
  gint in_dar_n, in_dar_d, out_dar_n, out_dar_d;

  if (!gst_video_info_from_caps (&ininfo, incaps)) {
    GST_ERROR_OBJECT (vscale, "Failed to get input video info from caps!");
    return FALSE;
  }

  if (!gst_video_info_from_caps (&outinfo, outcaps)) {
    GST_ERROR_OBJECT (vscale, "Failed to get output video info from caps!");
    return FALSE;
  }

  if (!gst_util_fraction_multiply (ininfo.width, ininfo.height,
          ininfo.par_n, ininfo.par_d, &in_dar_n, &in_dar_d)) {
    GST_WARNING_OBJECT (vscale, "Failed to calculate input DAR!");
    in_dar_n = in_dar_d = -1;
  }

  if (!gst_util_fraction_multiply (outinfo.width, outinfo.height,
          outinfo.par_n, outinfo.par_d, &out_dar_n, &out_dar_d)) {
    GST_WARNING_OBJECT (vscale, "Failed to calculate output DAR!");
    out_dar_n = out_dar_d = -1;
  }

  GST_DEBUG_OBJECT (vscale, "From %dx%d (PAR: %d/%d, DAR: %d/%d), size %"
      G_GSIZE_FORMAT " -> To %dx%d (PAR: %d/%d, DAR: %d/%d), size %"
      G_GSIZE_FORMAT, ininfo.width, ininfo.height, ininfo.par_n, ininfo.par_d,
      in_dar_n, in_dar_d, ininfo.size, outinfo.width, outinfo.height,
      outinfo.par_n, outinfo.par_d, out_dar_n, out_dar_d, outinfo.size);

  if (vscale->ininfo != NULL)
    gst_video_info_free (vscale->ininfo);

  vscale->ininfo = gst_video_info_copy (&ininfo);

  if (vscale->outinfo != NULL)
    gst_video_info_free (vscale->outinfo);

  vscale->outinfo = gst_video_info_copy (&outinfo);

  feature = NULL;
  vscale->infeature = g_quark_from_static_string (feature);

  feature = NULL;
  vscale->outfeature = g_quark_from_static_string (feature);

  // Disable passthrough in order to decide output allocation.
  gst_base_transform_set_passthrough (base, FALSE);
  return TRUE;
}

static gboolean
gst_rtk_video_scale_fill_pixel_aspect_ratio (GstRtkVideoScale * vscale,
    GstPadDirection direction, GstStructure * input, GstStructure * output)
{
  const GValue *in_par, *out_par;

  in_par = gst_structure_get_value (input, "pixel-aspect-ratio");
  out_par = gst_structure_get_value (output, "pixel-aspect-ratio");

  switch (direction) {
    case GST_PAD_SRC:
      if ((NULL == in_par) || !gst_value_is_fixed (in_par))
        gst_structure_set (input, "pixel-aspect-ratio",
            GST_TYPE_FRACTION, 1, 1, NULL);

      if ((NULL == out_par) || !gst_value_is_fixed (out_par))
        gst_structure_set (output, "pixel-aspect-ratio",
            GST_TYPE_FRACTION, 1, 1, NULL);
      break;
    case GST_PAD_SINK:
      if ((NULL == in_par) || !gst_value_is_fixed (in_par))
        gst_structure_set (input, "pixel-aspect-ratio",
            GST_TYPE_FRACTION, 1, 1, NULL);

      if (NULL == out_par)
        gst_structure_set (output, "pixel-aspect-ratio",
            GST_TYPE_FRACTION_RANGE, 1, G_MAXINT, G_MAXINT, 1, NULL);
      break;
    case GST_PAD_UNKNOWN:
    default:
      GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
          ("Invalid or unknown pad direction!"));
      return FALSE;
  }
  return TRUE;
}

static void
gst_rtk_video_scale_fixate_width (GstRtkVideoScale * vscale,
    GstStructure * input, GstStructure * output, gint out_height)
{
  const GValue *in_par, *out_par;
  gint in_par_n, in_par_d, in_dar_n, in_dar_d, in_width, in_height;
  gboolean success;

  GST_DEBUG_OBJECT (vscale, "Output height is fixed to: %d", out_height);

  // Retrieve the PAR (pixel aspect ratio) values for the input and output.
  in_par = gst_structure_get_value (input, "pixel-aspect-ratio");
  out_par = gst_structure_get_value (output, "pixel-aspect-ratio");

  in_par_n = gst_value_get_fraction_numerator (in_par);
  in_par_d = gst_value_get_fraction_denominator (in_par);

  // Retrieve the input width and height.
  gst_structure_get_int (input, "width", &in_width);
  gst_structure_get_int (input, "height", &in_height);

  // Calculate input DAR (display aspect ratio) from the dimensions and PAR.
  success = gst_util_fraction_multiply (in_width, in_height,
      in_par_n, in_par_d, &in_dar_n, &in_dar_d);

  if (!success) {
    GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
        ("Error calculating the input DAR!"));
    return;
  }

  GST_DEBUG_OBJECT (vscale, "Input DAR is: %d/%d", in_dar_n, in_dar_d);

  // PAR is fixed, choose width that is nearest to the width with the same DAR.
  if (gst_value_is_fixed (out_par)) {
    gint out_par_n, out_par_d, num, den, out_width;

    out_par_d = gst_value_get_fraction_denominator (out_par);
    out_par_n = gst_value_get_fraction_numerator (out_par);

    GST_DEBUG_OBJECT (vscale, "Output PAR fixed to: %d/%d",
        out_par_n, out_par_d);

    // Calculate width scale factor from input DAR and output PAR.
    success = gst_util_fraction_multiply (in_dar_n, in_dar_d,
        out_par_d, out_par_n, &num, &den);

    if (!success) {
      GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output width scale factor!"));
      return;
    }

    out_width = GST_ROUND_UP_4 (
        gst_util_uint64_scale_int (out_height, num, den));

    gst_structure_fixate_field_nearest_int (output, "width", out_width);
    gst_structure_get_int (output, "width", &out_width);

    GST_DEBUG_OBJECT (vscale, "Output width fixated to: %d", out_width);
  } else {
    // PAR is not fixed, try to keep the input DAR and PAR.
    GstStructure *structure = gst_structure_copy (output);
    gint out_par_n, out_par_d, set_par_n, set_par_d, num, den, out_width;

    // Calculate output width scale factor from input DAR and PAR.
    success = gst_util_fraction_multiply (in_dar_n, in_dar_d,
        in_par_n, in_par_d, &num, &den);

    if (!success) {
      GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output width scale factor!"));
      gst_structure_free (structure);
      return;
    }

    // Scale the output width to a value nearest to the input with same DAR
    // and adjust the output PAR if needed.
    out_width = GST_ROUND_UP_4 (
        gst_util_uint64_scale_int (out_height, num, den));

    gst_structure_fixate_field_nearest_int (structure, "width", out_width);
    gst_structure_get_int (structure, "width", &out_width);

    success = gst_util_fraction_multiply (in_dar_n, in_dar_d,
        out_height, out_width, &out_par_n, &out_par_d);

    if (!success) {
      GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output PAR!"));
      gst_structure_free (structure);
      return;
    }

    gst_structure_fixate_field_nearest_fraction (structure,
        "pixel-aspect-ratio", out_par_n, out_par_d);
    gst_structure_get_fraction (structure, "pixel-aspect-ratio",
        &set_par_n, &set_par_d);

    gst_structure_free (structure);

    // Validate the adjusted output PAR and update the output fields.
    if (set_par_n == out_par_n && set_par_d == out_par_d) {
      gst_structure_set (output, "width", G_TYPE_INT, out_width,
          "pixel-aspect-ratio", GST_TYPE_FRACTION, set_par_n, set_par_d, NULL);

      GST_DEBUG_OBJECT (vscale, "Output width fixated to: %d, and PAR fixated"
          " to: %d/%d", out_width, set_par_n, set_par_d);
      return;
    }

    // The above approach failed, scale the width to the new PAR.
    success = gst_util_fraction_multiply (in_dar_n, in_dar_d,
        set_par_d, set_par_n, &num, &den);

    if (!success) {
      GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output width!"));
      return;
    }

    out_width = GST_ROUND_UP_4 (gst_util_uint64_scale_int (out_height, num, den));
    gst_structure_fixate_field_nearest_int (output, "width", out_width);
    gst_structure_get_int (structure, "width", &out_width);

    gst_structure_set (output, "pixel-aspect-ratio", GST_TYPE_FRACTION,
        set_par_n, set_par_d, NULL);

    GST_DEBUG_OBJECT (vscale, "Output width fixated to: %d, and PAR fixated"
        " to: %d/%d", out_width, set_par_n, set_par_d);
  }

  return;
}

static void
gst_rtk_video_scale_fixate_height (GstRtkVideoScale * vscale,
    GstStructure * input, GstStructure * output, gint out_width)
{
  const GValue *in_par, *out_par;
  gint in_par_n, in_par_d, in_dar_n, in_dar_d, in_width, in_height;
  gboolean success;

  GST_DEBUG_OBJECT (vscale, "Output width is fixed to: %d", out_width);

  // Retrieve the PAR (pixel aspect ratio) values for the input and output.
  in_par = gst_structure_get_value (input, "pixel-aspect-ratio");
  out_par = gst_structure_get_value (output, "pixel-aspect-ratio");

  in_par_n = gst_value_get_fraction_numerator (in_par);
  in_par_d = gst_value_get_fraction_denominator (in_par);

  // Retrieve the input width and height.
  gst_structure_get_int (input, "width", &in_width);
  gst_structure_get_int (input, "height", &in_height);

  // Calculate input DAR (display aspect ratio) from the dimensions and PAR.
  success = gst_util_fraction_multiply (in_width, in_height,
      in_par_n, in_par_d, &in_dar_n, &in_dar_d);

  if (!success) {
    GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
        ("Error calculating the input DAR!"));
    return;
  }

  GST_DEBUG_OBJECT (vscale, "Input DAR is: %d/%d", in_dar_n, in_dar_d);

  // PAR is fixed, choose height that is nearest to the height with the same DAR.
  if (gst_value_is_fixed (out_par)) {
    gint out_par_n, out_par_d, num, den, out_height;

    out_par_n = gst_value_get_fraction_numerator (out_par);
    out_par_d = gst_value_get_fraction_denominator (out_par);

    GST_DEBUG_OBJECT (vscale, "Output PAR fixed to: %d/%d",
        out_par_n, out_par_d);

    // Calculate height from input DAR and output PAR.
    success = gst_util_fraction_multiply (in_dar_n, in_dar_d,
        out_par_d, out_par_n, &num, &den);

    if (!success) {
      GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output width!"));
      return;
    }


    out_height = GST_ROUND_UP_4 (
        gst_util_uint64_scale_int (out_width, den, num));

    gst_structure_fixate_field_nearest_int (output, "height", out_height);
    gst_structure_get_int (output, "height", &out_height);

    GST_DEBUG_OBJECT (vscale, "Output height fixated to: %d", out_height);
  } else {
    // PAR is not fixed, try to keep the input DAR and PAR.
    GstStructure *structure = gst_structure_copy (output);
    gint out_par_n, out_par_d, set_par_n, set_par_d, num, den, out_height;

    // Calculate output width scale factor from input DAR and PAR.
    success = gst_util_fraction_multiply (in_dar_n, in_dar_d,
        in_par_n, in_par_d, &num, &den);

    if (!success) {
      GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output height scale factor!"));
      gst_structure_free (structure);
      return;
    }

    // Scale the output height to a value nearest to the input with same DAR
    // and adjust the output PAR if needed.
    out_height = GST_ROUND_UP_4 (
        gst_util_uint64_scale_int (out_width, den, num));

    gst_structure_fixate_field_nearest_int (structure, "height", out_height);
    gst_structure_get_int (structure, "height", &out_height);

    success = gst_util_fraction_multiply (in_dar_n, in_dar_d,
        out_height, out_width, &out_par_n, &out_par_d);

    if (!success) {
      GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output PAR!"));
      gst_structure_free (structure);
      return;
    }

    gst_structure_fixate_field_nearest_fraction (structure,
        "pixel-aspect-ratio", out_par_n, out_par_d);
    gst_structure_get_fraction (structure, "pixel-aspect-ratio",
        &set_par_n, &set_par_d);

    gst_structure_free (structure);

    // Validate the adjusted output PAR and update the output fields.
    if (set_par_n == out_par_n && set_par_d == out_par_d) {
      gst_structure_set (output, "height", G_TYPE_INT, out_height,
          "pixel-aspect-ratio", GST_TYPE_FRACTION, set_par_n, set_par_d, NULL);

      GST_DEBUG_OBJECT (vscale, "Output height fixated to: %d, and PAR fixated"
          " to: %d/%d", out_height, set_par_n, set_par_d);
      return;
    }

    // The above approach failed, scale the width to the new PAR.
    success = gst_util_fraction_multiply (in_dar_n, in_dar_d,
        set_par_d, set_par_n, &num, &den);

    if (!success) {
      GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output width!"));
      return;
    }

    out_height = GST_ROUND_UP_4 (gst_util_uint64_scale_int (out_width, den, num));
    gst_structure_fixate_field_nearest_int (output, "height", out_height);
    gst_structure_get_int (output, "height", &out_height);

    gst_structure_set (output, "pixel-aspect-ratio", GST_TYPE_FRACTION,
        set_par_n, set_par_d, NULL);

    GST_DEBUG_OBJECT (vscale, "Output height fixated to: %d, and PAR fixated"
        " to: %d/%d", out_height, set_par_n, set_par_d);
  }

  return;
}

static void
gst_rtk_video_scale_fixate_width_and_height (GstRtkVideoScale * vscale,
    GstStructure * input, GstStructure * output, const GValue *out_par)
{
  gint in_par_n, in_par_d, in_dar_n, in_dar_d, in_width, in_height;
  gint out_par_n, out_par_d;
  gboolean success;

  out_par_n = gst_value_get_fraction_numerator (out_par);
  out_par_d = gst_value_get_fraction_denominator (out_par);

  GST_DEBUG_OBJECT (vscale, "Output PAR is fixed to: %d/%d",
      out_par_n, out_par_d);

  {
    // Retrieve the PAR (pixel aspect ratio) values for the input.
    const GValue *in_par = gst_structure_get_value (input,
        "pixel-aspect-ratio");

    in_par_n = gst_value_get_fraction_numerator (in_par);
    in_par_d = gst_value_get_fraction_denominator (in_par);
  }

  // Retrieve the input width and height.
  gst_structure_get_int (input, "width", &in_width);
  gst_structure_get_int (input, "height", &in_height);

  // Calculate input DAR (display aspect ratio) from the dimensions and PAR.
  success = gst_util_fraction_multiply (in_width, in_height,
      in_par_n, in_par_d, &in_dar_n, &in_dar_d);

  if (!success) {
    GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
        ("Error calculating the input DAR!"));
    return;
  }

  GST_DEBUG_OBJECT (vscale, "Input DAR is: %d/%d", in_dar_n, in_dar_d);

  {
    GstStructure *structure = gst_structure_copy (output);
    gint out_width, out_height, set_w, set_h, num, den, value;

    // Calculate output dimensions scale factor from input DAR and output PAR.
    success = gst_util_fraction_multiply (in_dar_n, in_dar_d, out_par_n,
        out_par_d, &num, &den);

    if (!success) {
      GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output scale factor!"));
      gst_structure_free (structure);
      return;
    }

    // Keep the input height (because of interlacing).
    gst_structure_fixate_field_nearest_int (structure, "height", in_height);
    gst_structure_get_int (structure, "height", &set_h);

    // Scale width in order to keep DAR.
    set_w = GST_ROUND_UP_4 (gst_util_uint64_scale_int (set_h, num, den));

    gst_structure_fixate_field_nearest_int (structure, "width", set_w);
    gst_structure_get_int (structure, "width", &value);

    // We kept the DAR and the height nearest to the original.
    if (set_w == value) {
      gst_structure_set (output, "width", G_TYPE_INT, set_w,
          "height", G_TYPE_INT, set_h, NULL);
      gst_structure_free (structure);

      GST_DEBUG_OBJECT (vscale, "Output dimensions fixated to: %dx%d",
          set_w, set_h);
      return;
    }

    // Store the values from initial run, they will be used if all else fails.
    out_width = set_w;
    out_height = set_h;

    // Failed to set output width while keeping the input height, try width.
    gst_structure_fixate_field_nearest_int (structure, "width", in_width);
    gst_structure_get_int (structure, "width", &set_w);

    // Scale height in order to keep DAR.
    set_h = GST_ROUND_UP_4 (gst_util_uint64_scale_int (set_w, den, num));

    gst_structure_fixate_field_nearest_int (structure, "height", set_h);
    gst_structure_get_int (structure, "height", &value);

    gst_structure_free (structure);

    // We kept the DAR and the width nearest to the original.
    if (set_h == value) {
      gst_structure_set (output, "width", G_TYPE_INT, set_w,
          "height", G_TYPE_INT, set_h, NULL);

      GST_DEBUG_OBJECT (vscale, "Output dimensions fixated to: %dx%d",
          set_w, set_h);
      return;
    }

    // All of the above approaches failed, keep the height that was
    // nearest to the original height and the nearest possible width.
    gst_structure_set (output, "width", G_TYPE_INT, out_width,
        "height", G_TYPE_INT, out_height, NULL);

    GST_DEBUG_OBJECT (vscale, "Output dimensions fixated to: %dx%d",
        out_width, out_height);
  }

  return;
}

static void
gst_rtk_video_scale_fixate_dimensions (GstRtkVideoScale * vscale,
    GstStructure * input, GstStructure * output)
{
  gint in_par_n, in_par_d, in_dar_n, in_dar_d, in_width, in_height;
  gboolean success;

  {
    // Retrieve the PAR (pixel aspect ratio) values for the input.
    const GValue *in_par = gst_structure_get_value (input,
        "pixel-aspect-ratio");

    in_par_n = gst_value_get_fraction_numerator (in_par);
    in_par_d = gst_value_get_fraction_denominator (in_par);
  }

  // Retrieve the input width and height.
  gst_structure_get_int (input, "width", &in_width);
  gst_structure_get_int (input, "height", &in_height);

  // Calculate input DAR (display aspect ratio) from the dimensions and PAR.
  success = gst_util_fraction_multiply (in_width, in_height,
      in_par_n, in_par_d, &in_dar_n, &in_dar_d);

  if (!success) {
    GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
        ("Error calculating the input DAR!"));
    return;
  }

  GST_DEBUG_OBJECT (vscale, "Input DAR is: %d/%d", in_dar_n, in_dar_d);

  {
    // Keep the dimensions as near as possible to the input and scale PAR.
    GstStructure *structure = gst_structure_copy (output);
    gint set_h, set_w, set_par_n, set_par_d, num, den, value;
    gint out_par_n, out_par_d, out_width, out_height;

    gst_structure_fixate_field_nearest_int (structure, "width", in_width);
    gst_structure_get_int (structure, "width", &out_width);

    gst_structure_fixate_field_nearest_int (structure, "height", in_height);
    gst_structure_get_int (structure, "height", &out_height);

    success = gst_util_fraction_multiply (in_dar_n, in_dar_d,
        out_height, out_width, &out_par_n, &out_par_d);

    if (!success) {
      GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output PAR!"));
      gst_structure_free (structure);
      return;
    }

    gst_structure_fixate_field_nearest_fraction (structure,
        "pixel-aspect-ratio", out_par_n, out_par_d);
    gst_structure_get_fraction (structure, "pixel-aspect-ratio",
        &set_par_n, &set_par_d);

    // Validate the output PAR and update the output fields.
    if (set_par_n == out_par_n && set_par_d == out_par_d) {
      gst_structure_set (output, "width", G_TYPE_INT, out_width,
          "height", G_TYPE_INT, out_height, NULL);

      gst_structure_set (output, "pixel-aspect-ratio", GST_TYPE_FRACTION,
          set_par_n, set_par_d, NULL);

      GST_DEBUG_OBJECT (vscale, "Output dimensions fixated to: %dx%d, and PAR"
          " fixated to: %d/%d", out_width, out_height, set_par_n, set_par_d);

      gst_structure_free (structure);
      return;
    }

    // Above failed, scale width to keep the DAR with the set PAR and height.
    success = gst_util_fraction_multiply (in_dar_n, in_dar_d, set_par_d,
        set_par_n, &num, &den);

    if (!success) {
      GST_ELEMENT_ERROR (vscale, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output width!"));
      gst_structure_free (structure);
      return;
    }

    set_w = gst_util_uint64_scale_int (out_height, num, den);
    gst_structure_fixate_field_nearest_int (structure, "width", set_w);
    gst_structure_get_int (structure, "width", &value);

    if (set_w == value) {
      gst_structure_set (output, "width", G_TYPE_INT, set_w,
          "height", G_TYPE_INT, out_height, NULL);

      gst_structure_set (output, "pixel-aspect-ratio", GST_TYPE_FRACTION,
          set_par_n, set_par_d, NULL);

      GST_DEBUG_OBJECT (vscale, "Output dimensions fixated to: %dx%d, and PAR"
          " fixated to: %d/%d", out_width, out_height, set_par_n, set_par_d);

      gst_structure_free (structure);
      return;
    }

    // Above failed, scale height to keep the DAR with the set PAR and width.
    set_h = gst_util_uint64_scale_int (out_width, den, num);
    gst_structure_fixate_field_nearest_int (structure, "height", set_h);
    gst_structure_get_int (structure, "height", &value);

    gst_structure_free (structure);

    if (set_h == value) {
      gst_structure_set (output, "width", G_TYPE_INT, out_width,
          "height", G_TYPE_INT, set_h, NULL);

      gst_structure_set (output, "pixel-aspect-ratio", GST_TYPE_FRACTION,
          set_par_n, set_par_d, NULL);

      GST_DEBUG_OBJECT (vscale, "Output dimensions fixated to: %dx%d, and PAR"
          " fixated to: %d/%d", out_width, out_height, set_par_n, set_par_d);
      return;
    }

    // All approaches failed, take the values from the 1st iteration.
    gst_structure_set (output, "width", G_TYPE_INT, out_width,
        "height", G_TYPE_INT, out_height, NULL);
    gst_structure_set (output, "pixel-aspect-ratio", GST_TYPE_FRACTION,
        out_par_n, out_par_d, NULL);

    GST_DEBUG_OBJECT (vscale, "Output dimensions fixated to: %dx%d, and PAR"
        " fixated to: %d/%d", out_width, out_height, out_par_n, out_par_d);
  }

  return;
}

static GstCaps *
gst_rtk_video_scale_fixate_caps (GstBaseTransform * base,
    GstPadDirection direction, GstCaps * incaps, GstCaps * outcaps)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE (base);
  GstStructure *input, *output;

  // Truncate and make the output caps writable.
  outcaps = gst_caps_truncate (outcaps);
  outcaps = gst_caps_make_writable (outcaps);

  output = gst_caps_get_structure (outcaps, 0);

  // Take a copy of the input caps structure so we can freely modify it.
  input = gst_caps_get_structure (incaps, 0);
  input = gst_structure_copy (input);

  GST_DEBUG_OBJECT (vscale, "Trying to fixate output caps %" GST_PTR_FORMAT
      " based on caps %" GST_PTR_FORMAT, outcaps, incaps);

  {
    // Fill the pixel-aspect-ratio fields if they weren't set in the caps.
    gboolean success = gst_rtk_video_scale_fill_pixel_aspect_ratio (
        vscale, direction, input, output);
    g_return_val_if_fail (success, outcaps);
  }

  {
    // Fixate output width, height and PAR.
    gint width = 0, height = 0;
    const GValue *par = NULL;

    // Retrieve the output width and height.
    gst_structure_get_int (output, "width", &width);
    gst_structure_get_int (output, "height", &height);

    if(!vscale->force_passthrough) {
      gst_structure_set (output, "interlace-mode", G_TYPE_STRING,
          "progressive", NULL);
    }

    // Retrieve the output PAR (pixel aspect ratio) value.
    par = gst_structure_get_value (output, "pixel-aspect-ratio");

    // Check which values are fixed and take the necessary actions.
    if ((width != 0) && (height != 0) && !gst_value_is_fixed (par)) {
      // The output dimensions are set but the PAR is not fixated.
      gst_structure_fixate_field_nearest_fraction (output,
          "pixel-aspect-ratio", 1, 1);
    } else if ((width != 0) && (height == 0)) {
      // The output width is set, try to calculate output height.
      gst_rtk_video_scale_fixate_height (vscale, input, output, width);
    } else if ((height != 0) && (width == 0)) {
      // The output height is set, try to calculate output width.
      gst_rtk_video_scale_fixate_width (vscale, input, output, height);
    } else if (gst_value_is_fixed (par)) {
      // The output PAR is set, try to calculate the output width and height.
      gst_rtk_video_scale_fixate_width_and_height (vscale, input, output, par);
    } else {
      // Neither the dimensions nor the PAR are fixated at the output.
      gst_rtk_video_scale_fixate_dimensions (vscale, input, output);
    }
  }

  outcaps = gst_caps_fixate (outcaps);

  // Free the local copy of the input caps structure.
  gst_structure_free (input);

  GST_DEBUG_OBJECT (vscale, "Fixated caps to %" GST_PTR_FORMAT, outcaps);
  return outcaps;
}

static GstFlowReturn
gst_rtk_video_scale_handle_output (GstBaseTransform * base, GstBuffer * inbuffer,
    GstBuffer * outbuffer, struct rtk_drm_vowb_run_cmd arg)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE_CAST (base);
  GstVideoFrame inframe = { 0, }, outframe = { 0, };
  GstMemory *in_mem,*out_mem,*current_mem,*prev_mem,*prev_two_mem;
  GstClockTime time = GST_CLOCK_TIME_NONE;
  GstMapInfo mapinfo;
  struct ve_frame_info *veframe_info = NULL;
  struct drm_prime_handle in_prime_handle, out_prime_handle;
  struct drm_prime_handle current_prime_handle, prev_prime_handle, prev_two_prime_handle;
  int ret, retry = 0, bufBitDepth = 8, addr_offset = 0;
  gint in_ori_height, in_ori_width;
  gint out_ori_height, out_ori_width;
  gsize in_size, in_offset, in_maxsize;
  gsize out_size, out_offset, out_maxsize;
  gint in_width, in_height;
  gint out_width, out_height;

  memset(&in_prime_handle, 0, sizeof(in_prime_handle));
  memset(&out_prime_handle, 0, sizeof(out_prime_handle));
  memset(&current_prime_handle, 0, sizeof(current_prime_handle));
  memset(&prev_prime_handle, 0, sizeof(prev_prime_handle));
  memset(&prev_two_prime_handle, 0, sizeof(prev_two_prime_handle));
  in_mem = gst_buffer_peek_memory (inbuffer, 0);
  out_mem = gst_buffer_peek_memory (outbuffer, 0);

  in_prime_handle.fd = gst_dmabuf_memory_get_fd (in_mem);
  out_prime_handle.fd = gst_dmabuf_memory_get_fd (out_mem);

  ret = ioctl (vscale->drmfd, DRM_IOCTL_PRIME_FD_TO_HANDLE, &in_prime_handle);
  if (ret != 0) {
    GST_ERROR_OBJECT (vscale, "DRM_IOCTL_PRIME_FD_TO_HANDLE in fail! Error = (%s)\n", strerror(errno));
  }

  ret = ioctl (vscale->drmfd, DRM_IOCTL_PRIME_FD_TO_HANDLE, &out_prime_handle);
  if (ret != 0) {
    GST_ERROR_OBJECT (vscale, "DRM_IOCTL_PRIME_FD_TO_HANDLE out fail! Error = (%s)\n", strerror(errno));
  }

  in_ori_width = vscale->ininfo->width;
  in_ori_height = vscale->ininfo->height;

  out_ori_width = vscale->outinfo->width;
  out_ori_height = vscale->outinfo->height;

  GstVideoMeta *in_meta;
  in_meta = gst_buffer_get_video_meta (inbuffer);
  in_width = in_ori_width + in_meta->alignment.padding_right + in_meta->alignment.padding_left;
  in_height = in_ori_height + in_meta->alignment.padding_top + in_meta->alignment.padding_bottom;
  GST_LOG_OBJECT (vscale, "in_ori_width %d in_ori_height %d",in_ori_width,in_ori_height);
  GST_LOG_OBJECT (vscale, "in_width %d in_height %d",in_width,in_height);
  GstVideoMeta *out_meta;
  out_meta = gst_buffer_get_video_meta (outbuffer);
  gst_video_meta_set_alignment (out_meta, vscale->out_video_align);
  out_width = out_ori_width + out_meta->alignment.padding_right + out_meta->alignment.padding_left;
  out_height = out_ori_height + out_meta->alignment.padding_top + out_meta->alignment.padding_bottom;
  GST_LOG_OBJECT (vscale, "out_ori_width %d out_ori_height %d",out_ori_width,out_ori_height);
  GST_LOG_OBJECT (vscale, "out_width %d out_height %d",out_width,out_height);

  in_size = gst_memory_get_sizes (in_mem, &in_offset, &in_maxsize);
  GST_LOG_OBJECT (vscale, "in_size %d in_offset %d in_maxsize %d",in_size,in_offset,in_maxsize);
  out_size = gst_memory_get_sizes (out_mem, &out_offset, &out_maxsize);
  GST_LOG_OBJECT (vscale, "out_size %d out_offset %d out_maxsize %d",out_size,out_offset,out_maxsize);

  if(in_size > in_width * in_height * 1.5) {
    GST_LOG_OBJECT (vscale, "in_size not metch in_width * in_height * 1.5");
    if(in_size == ROUNDUP32(in_width) * ROUNDUP32(in_height) * 1.5) {
      GST_LOG_OBJECT (vscale, "in_size metch ROUNDUP32(in_width) * ROUNDUP32(in_height) * 1.5");
      in_width = ROUNDUP32(in_width);
      in_height = ROUNDUP32(in_height);
      GST_LOG_OBJECT (vscale, "update src_width %d src_height %d",in_width,in_height);
    }
  }

  arg.pic.src_handle = in_prime_handle.handle; // handle of y_addr & c_addr
  arg.pic.y_offset = in_offset;
  arg.pic.c_offset = in_offset + in_width * in_height;
  arg.pic.y_pitch = in_width;
  arg.pic.c_pitch = in_width;
  arg.pic.w = in_ori_width;
  arg.pic.h = in_ori_height;
  arg.pic.crop_x = 0;
  arg.pic.crop_y = 0;
  arg.pic.crop_w = 0;
  arg.pic.crop_h = 0;
  arg.pic.wb_handle = out_prime_handle.handle; // handle of wb_y_addr & wb_c_addr
  arg.pic.wb_y_offset = out_offset;
  arg.pic.wb_c_offset = out_width * out_height + out_offset;
  arg.pic.wb_pitch = out_width;
  arg.pic.wb_w = out_ori_width;
  arg.pic.wb_h = out_ori_height;

  arg.pic.brightness = 32;
  arg.pic.contrast = 32;
  arg.pic.hue = 32;
  arg.pic.saturation = 32;
  arg.pic.sub_enable = 0;

  if(vscale->bit_depth_10)
    arg.pic.buf_bit_depth = 10;   //10 => RTK 10bit
  else
    arg.pic.buf_bit_depth = 0;    // 0 => NV12

  if(vscale->ignore_bit_depth && vscale->bit_depth_10) {
    //see enum wb_targetFormat...
    //bit 0=>NV21, 1:NV21, 0:NV12;
    //bit 1=>422, 1:422, 0:420
    //bit 2=>bit depth, 1:10 bits, 0: 8 bits;
    //bit 3=>mode_10b, 0: use 2 bytes to store 1 components. MSB justified. 1: use 4 bytes to store 3 components, LSB justified.
    //bit 4=>wb_use_v1: config vo use which plane to do transcode, 1:V1, 0:V2
    //bit 5=>wb_mix1: transcode content after mixer 1(OSD+V1+...), 1:mixer 1, 0: V1/V2 only
    arg.pic.target_format = 12;
    bufBitDepth = 10;
    arg.pic.wb_c_offset = out_width * 1.25 * out_height + DEFAULT_OFFSET;
    arg.pic.wb_pitch = out_width * 1.25;
    GST_LOG_OBJECT (vscale, "arg.pic.target_format %d",arg.pic.target_format);
  }
  else
    arg.pic.target_format = 0;

  if(vscale->ve2_compress) {
    GST_LOG_OBJECT (vscale, "ve2_compress");
    arg.pic.w = vscale->input_yuvs.width;
    arg.pic.h = vscale->input_yuvs.height;
    arg.pic.y_pitch = vscale->input_yuvs.Y_pitch;
    arg.pic.c_pitch = vscale->input_yuvs.C_pitch;
    arg.pic.tvve_picture_width = vscale->input_yuvs.tvve_picture_width;
    arg.pic.tvve_lossy_en = vscale->input_yuvs.tvve_lossy_en;
    arg.pic.tvve_bypass_en = vscale->input_yuvs.tvve_bypass_en;
    arg.pic.tvve_qlevel_sel_y = vscale->input_yuvs.tvve_qlevel_sel_y;
    arg.pic.tvve_qlevel_sel_c = vscale->input_yuvs.tvve_qlevel_sel_c;
    arg.pic.luma_off_tbl_addr = vscale->input_yuvs.lumaOffTblAddr;
    arg.pic.chroma_off_tbl_addr = vscale->input_yuvs.chromaOffTblAddr;
  }

  arg.pic.transferCharacteristics = vscale->input_yuvs.transferCharacteristics;
  arg.pic.video_full_range_flag = vscale->input_yuvs.video_full_range_flag;
  arg.pic.matrix_coefficients = vscale->input_yuvs.matrix_coefficients;

  if(vscale->input_yuvs.mode == INTERLEAVED_TOP_BOT_FIELD || vscale->input_yuvs.mode == INTERLEAVED_BOT_TOP_FIELD) {
    if(arg.pic.mode == CONSECUTIVE_BOT_FIELD) {
      arg.pic.y_offset = in_offset + in_width;
      arg.pic.c_offset = in_offset + in_width * in_height + in_width;
      addr_offset = 0;
    } else if(arg.pic.mode == CONSECUTIVE_TOP_FIELD)
      addr_offset = in_width;
    arg.pic.y_pitch = in_width << 1;
    arg.pic.c_pitch = in_width << 1;

    current_mem = gst_buffer_peek_memory (vscale->inbuffer, 0);
    current_prime_handle.fd = gst_dmabuf_memory_get_fd (current_mem);
    ret = ioctl (vscale->drmfd, DRM_IOCTL_PRIME_FD_TO_HANDLE, &current_prime_handle);
    if (ret != 0) {
      GST_ERROR_OBJECT (vscale, "DRM_IOCTL_PRIME_FD_TO_HANDLE current fail! Error = (%s)\n", strerror(errno));
    }

    if(vscale->inbuffer_prev) {
      prev_mem = gst_buffer_peek_memory (vscale->inbuffer_prev, 0);
      prev_prime_handle.fd = gst_dmabuf_memory_get_fd (prev_mem);
      ret = ioctl (vscale->drmfd, DRM_IOCTL_PRIME_FD_TO_HANDLE, &prev_prime_handle);
      if (ret != 0) {
        GST_ERROR_OBJECT (vscale, "DRM_IOCTL_PRIME_FD_TO_HANDLE prev fail! Error = (%s)\n", strerror(errno));
      }
      arg.pic.prev_handle   = prev_prime_handle.handle;
      arg.pic.prev_y_offset = in_offset + addr_offset;
      arg.pic.prev_c_offset = in_offset + in_width * in_height + addr_offset;
    } else {
      arg.pic.prev_handle   = current_prime_handle.handle;
      arg.pic.prev_y_offset = in_offset + addr_offset;
      arg.pic.prev_c_offset = in_offset + in_width * in_height + addr_offset;
    }
    arg.pic.next_handle   = current_prime_handle.handle;
    arg.pic.next_y_offset = in_offset + addr_offset;
    arg.pic.next_c_offset = in_offset + in_width * in_height + addr_offset;
  } else if(vscale->input_yuvs.mode == CONSECUTIVE_TOP_FIELD || vscale->input_yuvs.mode == CONSECUTIVE_BOT_FIELD) {
    arg.pic.h       = in_ori_height << 1;
    if(vscale->inbuffer_prev_two) {
      prev_two_mem = gst_buffer_peek_memory (vscale->inbuffer_prev_two, 0);
      prev_two_prime_handle.fd = gst_dmabuf_memory_get_fd (prev_two_mem);
      ret = ioctl (vscale->drmfd, DRM_IOCTL_PRIME_FD_TO_HANDLE, &prev_two_prime_handle);
      if (ret != 0) {
        GST_ERROR_OBJECT (vscale, "DRM_IOCTL_PRIME_FD_TO_HANDLE prev_two fail! Error = (%s)\n", strerror(errno));
      }
      arg.pic.prev_handle   = prev_two_prime_handle.handle;
      arg.pic.prev_y_offset = in_offset + addr_offset;
      arg.pic.prev_c_offset = in_offset + in_width * in_height + addr_offset;
    } else {
      arg.pic.prev_handle   = current_prime_handle.handle;
      arg.pic.prev_y_offset = in_offset + addr_offset;
      arg.pic.prev_c_offset = in_offset + in_width * in_height + addr_offset;
    }
    arg.pic.next_handle   = current_prime_handle.handle;
    arg.pic.next_y_offset = in_offset + addr_offset;
    arg.pic.next_c_offset = in_offset + in_width * in_height + addr_offset;
  }

  if(vscale->debug){
    GST_INFO_OBJECT (vscale, "vscale->input_yuvs width = %d height = %d Y_pitch = %d",vscale->input_yuvs.width,vscale->input_yuvs.height,vscale->input_yuvs.Y_pitch);
    GST_INFO_OBJECT (vscale, "arg.pic.w = %d arg.pic.h = %d arg.pic.y_offset = %d arg.pic.c_offset = %d arg.pic.y_pitch %d arg.pic.c_pitch %d",arg.pic.w,arg.pic.h,arg.pic.y_offset,arg.pic.c_offset,arg.pic.y_pitch,arg.pic.c_pitch);
    GST_INFO_OBJECT (vscale, "vscale->input_yuvs.mode = %d vscale->bit_depth_10 = %d vscale->ve2_compress = %d",vscale->input_yuvs.mode,vscale->bit_depth_10,vscale->ve2_compress);
    vscale->debug = FALSE;
  }

  ret = ioctl(vscale->drmfd, DRM_IOCTL_RTK_VOWB_RUN_CMD, &arg);
  while (ret < 0) {
    if(retry > 100) {
      GST_ERROR_OBJECT (vscale, "DRM_IOCTL_RTK_VOWB_RUN_CMD retry fail! Error = (%s)\n", strerror(errno));
      return GST_FLOW_ERROR;
    }
    usleep(10000);
    GST_LOG_OBJECT (vscale, "DRM_IOCTL_RTK_VOWB_RUN_CMD retry %d fail! Error = (%s)\n",++retry, strerror(errno));
    ret = ioctl(vscale->drmfd, DRM_IOCTL_RTK_VOWB_RUN_CMD, &arg);
  }

  GST_LOG_OBJECT (vscale, "DRM_IOCTL_RTK_VOWB_RUN_CMD done");

  struct rtk_drm_vowb_check_cmd check_arg = { .job_id = arg.job_id, .flags = RTK_DRM_VOWB_FLAGS_CHECK_CMD_BLOCK, };

  ret = ioctl(vscale->drmfd, DRM_IOCTL_RTK_VOWB_CHECK_CMD, &check_arg);
  retry = 0;
  while (ret < 0) {
    if(retry > 100) {
      GST_ERROR_OBJECT (vscale, "DRM_IOCTL_RTK_VOWB_CHECK_CMD retry fail! Error = (%s)\n", strerror(errno));
      return GST_FLOW_ERROR;
    }
    usleep(10000);
    GST_LOG_OBJECT (vscale, "DRM_IOCTL_RTK_VOWB_CHECK_CMD retry %d fail! Error = (%s)\n",++retry, strerror(errno));
    ret = ioctl(vscale->drmfd, DRM_IOCTL_RTK_VOWB_CHECK_CMD, &check_arg);
  }

  if (ret || check_arg.job_done != 1){
    GST_LOG_OBJECT (vscale, "DRM_IOCTL_RTK_VOWB_CHECK_CMD error check_arg.job_done %d",check_arg.job_done);
    GST_ERROR_OBJECT (vscale, "DRM_IOCTL_RTK_VOWB_CHECK_CMD fail! Error = (%s)\n", strerror(errno));
    return GST_FLOW_ERROR;
  }
  else
    GST_LOG_OBJECT (vscale, "DRM_IOCTL_RTK_VOWB_CHECK_CMD done");

  struct rheap_ioc_phy_info data;
  data.handle = out_prime_handle.fd;
  data.addr   = 0;
  data.len    = 0;
  int rtk_fd = open("/dev/rtk_heap", O_RDWR | O_CLOEXEC);
  if (ioctl(rtk_fd, RHEAP_GET_PHYINFO, &data) < 0) {
    printf("RHEAP_GET_PHYINFO Error = %s\n", strerror(errno));
    return GST_FLOW_ERROR;
  }

  gst_memory_map (out_mem, &mapinfo, GST_MAP_WRITE);
  veframe_info = (struct ve_frame_info *)(mapinfo.data - out_offset);
  memset(veframe_info, 0, sizeof(struct ve_frame_info));

  veframe_info->yuvs.lumaOffTblAddr = 0xffffffff;
  veframe_info->yuvs.chromaOffTblAddr = 0xffffffff;
  veframe_info->yuvs.lumaOffTblAddrR = 0xffffffff;
  veframe_info->yuvs.chromaOffTblAddrR = 0xffffffff;
  veframe_info->yuvs.bufBitDepth = bufBitDepth;
  veframe_info->yuvs.matrix_coefficients = 1;
  veframe_info->yuvs.tch_hdr_metadata[0] = -1;

  veframe_info->yuvs.Y_addr_Right = 0xffffffff;
  veframe_info->yuvs.U_addr_Right = 0xffffffff;
  veframe_info->yuvs.pLock_Right = 0xffffffff;
  veframe_info->rtk_meta_buf_id =  0x52544B6D; //RTKm

  veframe_info->yuvs.width = arg.pic.wb_w;
  veframe_info->yuvs.height = arg.pic.wb_h;
  veframe_info->yuvs.Y_addr = data.addr + arg.pic.wb_y_offset;
  veframe_info->yuvs.U_addr = data.addr + arg.pic.wb_c_offset;
  veframe_info->yuvs.Y_pitch = arg.pic.wb_pitch;
  veframe_info->yuvs.C_pitch = arg.pic.wb_pitch;

  veframe_info->yuvs.mode = CONSECUTIVE_FRAME;
  close(rtk_fd);
  gst_memory_unmap (out_mem, &mapinfo);

  struct drm_gem_close in_gem_close = {0};
  struct drm_gem_close out_gem_close = {0};
  in_gem_close.handle = in_prime_handle.handle;
  if (ioctl(vscale->drmfd, DRM_IOCTL_GEM_CLOSE, &in_gem_close) < 0) {
    GST_WARNING_OBJECT (vscale, "Failed to close in DRM handle");
  }

  out_gem_close.handle = out_prime_handle.handle;
  if (ioctl(vscale->drmfd, DRM_IOCTL_GEM_CLOSE, &out_gem_close) < 0) {
    GST_WARNING_OBJECT (vscale, "Failed to close out DRM handle");
  }

  if(current_prime_handle.fd != 0 && current_prime_handle.fd != in_prime_handle.fd) {
    struct drm_gem_close current_gem_close = {0};
    current_gem_close.handle = current_prime_handle.handle;
    if (ioctl(vscale->drmfd, DRM_IOCTL_GEM_CLOSE, &current_gem_close) < 0) {
      GST_WARNING_OBJECT (vscale, "Failed to close current DRM handle");
    }
  }

  if(prev_prime_handle.fd != 0 && prev_prime_handle.fd != in_prime_handle.fd) {
    struct drm_gem_close prev_gem_close = {0};
    prev_gem_close.handle = prev_prime_handle.handle;
    if (ioctl(vscale->drmfd, DRM_IOCTL_GEM_CLOSE, &prev_gem_close) < 0) {
      GST_WARNING_OBJECT (vscale, "Failed to close prev DRM handle");
    }
  }

  if(prev_two_prime_handle.fd != 0 && prev_two_prime_handle.fd != in_prime_handle.fd) {
    struct drm_gem_close prev_two_gem_close = {0};
    prev_two_gem_close.handle = prev_two_prime_handle.handle;
    if (ioctl(vscale->drmfd, DRM_IOCTL_GEM_CLOSE, &prev_two_gem_close) < 0) {
      GST_WARNING_OBJECT (vscale, "Failed to close prev two DRM handle");
    }
  }
  return GST_FLOW_OK;
}
static GstFlowReturn
gst_rtk_video_scale_transform (GstBaseTransform * base, GstBuffer * inbuffer,
    GstBuffer * outbuffer)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE_CAST (base);
  int ret;
  struct rtk_drm_vowb_run_cmd arg = {0};
  guint64 features = 0;

  if(vscale->drmfd == -1) {
    GST_ERROR_OBJECT (vscale, "Failed to get display-subsystem fd");
    return GST_FLOW_ERROR;
  }

  ret = ioctl(vscale->drmfd, DRM_IOCTL_RTK_VOWB_GET_FEATURES, &features);
  if (ret != 0) {
    GST_ERROR_OBJECT (vscale, "DRM_IOCTL_RTK_VOWB_GET_FEATURES fail! Error = (%s)\n", strerror(errno));
  }

  if(vscale->interleaved) {
    GST_DEBUG_OBJECT (vscale, "vscale->interleaved vscale->input_yuvs.mode = %d", vscale->input_yuvs.mode);
    if((features & RTK_DRM_VOWB_FEATURE_DEINTERLACE_SUPPORT) == 0) {
      GST_ERROR_OBJECT (vscale, "Video interleaved but cheapset not support deinterleace.\n");
      arg.pic.mode = CONSECUTIVE_FRAME;
      gst_rtk_video_scale_handle_output (vscale, inbuffer, outbuffer, arg);
    }
    else if(vscale->input_yuvs.mode == INTERLEAVED_TOP_BOT_FIELD || vscale->input_yuvs.mode == INTERLEAVED_BOT_TOP_FIELD) {
      vscale->inbuffer = inbuffer;
      if(vscale->inbuffer_prev) {
        GstBuffer * transform_buffer;
        GstMemory *transform_mem;
        gsize transform_size, transform_offset, transform_maxsize;
        gst_buffer_pool_acquire_buffer (vscale->outpool, &transform_buffer, NULL);
        gst_buffer_copy_into (transform_buffer, vscale->inbuffer_prev, GST_BUFFER_COPY_FLAGS | GST_BUFFER_COPY_TIMESTAMPS, 0, -1);
        GST_BUFFER_PTS (transform_buffer) = (GST_BUFFER_PTS (vscale->inbuffer_prev) + GST_BUFFER_PTS (inbuffer)) / 2;
        transform_mem = gst_buffer_peek_memory (transform_buffer, 0);
        if(gst_is_dmabuf_memory(transform_mem)) {
          transform_size = gst_memory_get_sizes (transform_mem, &transform_offset, &transform_maxsize);
          if(transform_offset != DEFAULT_OFFSET){
            gst_memory_resize(transform_mem,DEFAULT_OFFSET,transform_maxsize - DEFAULT_OFFSET);
          }
        }
        if(vscale->input_yuvs.mode == INTERLEAVED_TOP_BOT_FIELD)
          arg.pic.mode = CONSECUTIVE_BOT_FIELD;
        else if(vscale->input_yuvs.mode == INTERLEAVED_BOT_TOP_FIELD)
          arg.pic.mode = CONSECUTIVE_TOP_FIELD;

        gst_rtk_video_scale_handle_output (vscale, vscale->inbuffer_prev, transform_buffer, arg);
        gst_pad_push(GST_BASE_TRANSFORM_SRC_PAD(vscale),transform_buffer);
      } else {
        GST_DEBUG_OBJECT (vscale, "do nothing");
      }

      if(vscale->input_yuvs.mode == INTERLEAVED_TOP_BOT_FIELD)
        arg.pic.mode = CONSECUTIVE_TOP_FIELD;
      else if(vscale->input_yuvs.mode == INTERLEAVED_BOT_TOP_FIELD)
        arg.pic.mode = CONSECUTIVE_BOT_FIELD;
      gst_rtk_video_scale_handle_output (vscale, inbuffer, outbuffer, arg);

      if (vscale->inbuffer_prev)
        gst_buffer_unref (vscale->inbuffer_prev);
      vscale->inbuffer_prev = gst_buffer_ref (inbuffer);
      vscale->input_yuvs_prev = vscale->input_yuvs;
      vscale->inbuffer = NULL;
    } else if(vscale->input_yuvs.mode == CONSECUTIVE_TOP_FIELD || vscale->input_yuvs.mode == CONSECUTIVE_BOT_FIELD) {
      if(vscale->inbuffer_prev) {
        arg.pic.mode = vscale->input_yuvs_prev.mode;
        vscale->inbuffer = inbuffer;
        gst_rtk_video_scale_handle_output (vscale, vscale->inbuffer_prev, outbuffer, arg);
      } else {
        GST_DEBUG_OBJECT (vscale, "do nothing");
      }
      if (vscale->inbuffer_prev_two)
        gst_buffer_unref (vscale->inbuffer_prev_two);
      if (vscale->inbuffer_prev) {
        vscale->inbuffer_prev_two = gst_buffer_ref (vscale->inbuffer_prev);
        gst_buffer_unref (vscale->inbuffer_prev);
      }
      vscale->inbuffer_prev = gst_buffer_ref (inbuffer);
      vscale->input_yuvs_prev_two = vscale->input_yuvs_prev;
      vscale->input_yuvs_prev = vscale->input_yuvs;
      vscale->inbuffer = NULL;
    }
  } else {
    arg.pic.mode = CONSECUTIVE_FRAME;
    gst_rtk_video_scale_handle_output (vscale, inbuffer, outbuffer, arg);
  }

  return GST_FLOW_OK;
}

static void
gst_rtk_video_scale_set_ignore_bit_depth (GstBaseTransform * base, gboolean ignore_bit_depth)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE_CAST (base);

  GST_OBJECT_LOCK (vscale);
  if (ignore_bit_depth != vscale->ignore_bit_depth) {

    GST_LOG_OBJECT (vscale, "Changing ignore_bit_depth method from %d to %d", vscale->ignore_bit_depth, ignore_bit_depth);

    vscale->ignore_bit_depth = ignore_bit_depth;

    GST_OBJECT_UNLOCK (vscale);

  } else {
    GST_OBJECT_UNLOCK (vscale);
  }
}

static void
gst_rtk_video_scale_set_force_passthrough (GstBaseTransform * base, gboolean force_passthrough)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE_CAST (base);

  GST_OBJECT_LOCK (vscale);
  if (force_passthrough != vscale->force_passthrough) {

    GST_LOG_OBJECT (vscale, "Changing force_passthrough method from %d to %d", vscale->force_passthrough, force_passthrough);

    vscale->force_passthrough = force_passthrough;

    GST_OBJECT_UNLOCK (vscale);

    gst_base_transform_set_passthrough (base, force_passthrough);

    gst_base_transform_reconfigure_src (base);
  } else {
    GST_OBJECT_UNLOCK (vscale);
  }
}

static void
gst_rtk_video_scale_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE (object);
  const gchar *propname = g_param_spec_get_name (pspec);
  GstState state = GST_STATE (vscale);

  GST_RTK_VIDEO_SCALE_LOCK (vscale);

  switch (prop_id) {
    case PROP_IGNORE_BIT_DEPTH:
      gst_rtk_video_scale_set_ignore_bit_depth(vscale, g_value_get_boolean (value));
      break;
    case PROP_FORCE_PASSTHROUGH:
      gst_rtk_video_scale_set_force_passthrough(vscale, g_value_get_boolean (value));
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }

  GST_RTK_VIDEO_SCALE_UNLOCK (vscale);
}

static void
gst_rtk_video_scale_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE (object);

  GST_RTK_VIDEO_SCALE_LOCK (vscale);

  switch (prop_id) {
    case PROP_IGNORE_BIT_DEPTH:
      g_value_set_boolean (value, vscale->ignore_bit_depth);
      break;
    case PROP_FORCE_PASSTHROUGH:
      g_value_set_boolean (value, vscale->force_passthrough);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }

  GST_RTK_VIDEO_SCALE_UNLOCK (vscale);
}

static void
gst_rtk_video_scale_finalize (GObject * object)
{
  GstRtkVideoScale *vscale = GST_RTK_VIDEO_SCALE (object);

  if (vscale->ininfo != NULL)
    gst_video_info_free (vscale->ininfo);

  if (vscale->outinfo != NULL)
    gst_video_info_free (vscale->outinfo);

  if (vscale->outpool != NULL)
    gst_object_unref (vscale->outpool);

  if(vscale->drmfd != -1)
    close(vscale->drmfd);

  if (vscale->inbuffer_prev)
    gst_buffer_unref (vscale->inbuffer_prev);

  if (vscale->inbuffer_prev_two)
    gst_buffer_unref (vscale->inbuffer_prev_two);

  g_mutex_clear (&(vscale)->lock);

  G_OBJECT_CLASS (parent_class)->finalize (G_OBJECT (vscale));
}

static void
gst_rtk_video_scale_class_init (GstRtkVideoScaleClass * klass)
{
  GObjectClass *gobject        = G_OBJECT_CLASS (klass);
  GstElementClass *element     = GST_ELEMENT_CLASS (klass);
  GstBaseTransformClass *base = GST_BASE_TRANSFORM_CLASS (klass);

  GST_DEBUG_CATEGORY_INIT (gst_rtk_video_scale_debug, "rtkvideoscale", 0,
      "rtkvideoscale video transform");

  gobject->set_property = GST_DEBUG_FUNCPTR (gst_rtk_video_scale_set_property);
  gobject->get_property = GST_DEBUG_FUNCPTR (gst_rtk_video_scale_get_property);
  gobject->finalize     = GST_DEBUG_FUNCPTR (gst_rtk_video_scale_finalize);

  g_object_class_install_property (gobject, PROP_IGNORE_BIT_DEPTH,
      g_param_spec_boolean ("ignore-bit-depth", "ignore_bit_depth or not",
          "Is video image ignore bit depth", DEFAULT_PROP_IGNORE_BIT_DEPTH,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject, PROP_FORCE_PASSTHROUGH,
      g_param_spec_boolean ("force-passthrough", "force_passthrough or not",
          "Is video force_passthrough", DEFAULT_FORCE_PASSTHROUGH,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  gst_element_class_set_static_metadata (element,
      "Video transformer", "Video/Scaler",
      "Resizes, colorspace converts", "RTK");

  gst_element_class_add_pad_template (element,
      gst_rtk_video_scale_sink_template ());
  gst_element_class_add_pad_template (element,
      gst_rtk_video_scale_src_template ());

  base->propose_allocation =
      GST_DEBUG_FUNCPTR (gst_rtk_video_scale_propose_allocation);
  base->decide_allocation =
      GST_DEBUG_FUNCPTR (gst_rtk_video_scale_decide_allocation);
  base->prepare_output_buffer =
      GST_DEBUG_FUNCPTR (gst_rtk_video_scale_prepare_output_buffer);
  base->transform_caps =
      GST_DEBUG_FUNCPTR (gst_rtk_video_scale_transform_caps);
  base->fixate_caps = GST_DEBUG_FUNCPTR (gst_rtk_video_scale_fixate_caps);
  base->set_caps = GST_DEBUG_FUNCPTR (gst_rtk_video_scale_set_caps);
  base->transform = GST_DEBUG_FUNCPTR (gst_rtk_video_scale_transform);
}

static void
gst_rtk_video_scale_init (GstRtkVideoScale * vscale)
{
  g_mutex_init (&(vscale)->lock);

  vscale->ignore_bit_depth = DEFAULT_PROP_IGNORE_BIT_DEPTH;
  vscale->force_passthrough  = DEFAULT_FORCE_PASSTHROUGH;
  vscale->bit_depth_10 = FALSE;
  vscale->ve2_compress = FALSE;
  vscale->interleaved = FALSE;
  vscale->transferCharacteristics = FALSE;
  vscale->debug = TRUE;

  vscale->ininfo = NULL;
  vscale->outinfo = NULL;

  vscale->infeature = g_quark_from_static_string (NULL);
  vscale->outfeature = g_quark_from_static_string (NULL);

  vscale->outpool = NULL;
  vscale->drmfd =  drmOpen("realtek",NULL);
  if (drmDropMaster(vscale->drmfd) < 0) {
      GST_DEBUG_OBJECT (vscale, "drmDropMaster failed; currently not the master.");
  } else {
      GST_DEBUG_OBJECT (vscale, "drmDropMaster");
  }

}

static gboolean
plugin_init (GstPlugin * plugin)
{
  return gst_element_register (plugin, "rtkvideoscale", GST_RANK_PRIMARY,
      GST_TYPE_RTK_VIDEO_SCALE);
}

#ifndef VERSION
#define VERSION "0.0.FIXME"
#endif
#ifndef PACKAGE
#define PACKAGE "FIXME_package"
#endif
#ifndef PACKAGE_NAME
#define PACKAGE_NAME "FIXME_package_name"
#endif
#ifndef GST_PACKAGE_ORIGIN
#define GST_PACKAGE_ORIGIN "http://FIXME.org/"
#endif

GST_PLUGIN_DEFINE (GST_VERSION_MAJOR, GST_VERSION_MINOR,
    rtkvideoscale, "rtkvideoscale", plugin_init,
    VERSION, "LGPL", PACKAGE_NAME, GST_PACKAGE_ORIGIN)
