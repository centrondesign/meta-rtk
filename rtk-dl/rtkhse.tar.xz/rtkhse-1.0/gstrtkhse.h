#ifndef __GST_RTK_HSE_H__
#define __GST_RTK_HSE_H__

#include <gst/gst.h>
#include <gst/base/gstbasetransform.h>
#include <gst/video/video.h>

G_BEGIN_DECLS

#define GST_TYPE_RTK_HSE \
  (gst_rtk_hse_get_type())
#define GST_RTK_HSE(obj) \
  (G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_RTK_HSE,GstRtkHse))
#define GST_RTK_HSE_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_CAST((klass),GST_TYPE_RTK_HSE,GstRtkHseClass))
#define GST_IS_RTK_HSE(obj) \
  (G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_TYPE_RTK_HSE))
#define GST_IS_RTK_HSE_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_TYPE((klass),GST_TYPE_RTK_HSE))
#define GST_RTK_HSE_CAST(obj)       ((GstRtkHse *)(obj))

#define GST_RTK_HSE_GET_LOCK(obj) (&GST_RTK_HSE(obj)->lock)
#define GST_RTK_HSE_LOCK(obj) \
  g_mutex_lock(GST_RTK_HSE_GET_LOCK(obj))
#define GST_RTK_HSE_UNLOCK(obj) \
  g_mutex_unlock(GST_RTK_HSE_GET_LOCK(obj))

typedef enum {
  GST_VIDEO_ROTATE_METHOD_NONE,
  GST_VIDEO_ROTATE_METHOD_90R,
  GST_VIDEO_ROTATE_METHOD_180,
  GST_VIDEO_ROTATE_METHOD_90L,
  GST_VIDEO_ROTATE_METHOD_AUTO
} GstVideoRotateMethod;

typedef struct _GstRtkHse GstRtkHse;
typedef struct _GstRtkHseClass GstRtkHseClass;

struct _GstRtkHse {
  GstBaseTransform        parent;

  /// Global mutex lock.
  GMutex                  lock;

  GstVideoInfo            *ininfo;
  GstVideoInfo            *outinfo;

  // Features of the negotiated input and output caps.
  GQuark                  infeature;
  GQuark                  outfeature;

  gchar *stream_id;

  // Output buffer pool
  GstBufferPool           *outpool;
  GstVideoAlignment       out_video_align;

  gboolean                ignore_buffer_offset;
  gboolean                ignore_bit_depth;
  gboolean                bit_depth_10;
  GstVideoRectangle       scale;
  guint                   hsefd;

  GstVideoOrientationMethod rotate;
  GstVideoOrientationMethod tag_method;
  gboolean got_orientation_stream_tag;
  GstVideoOrientationMethod global_tag_method;
  GstVideoOrientationMethod configuring_method;
};

struct _GstRtkHseClass {
  GstBaseTransformClass parent;
};

G_GNUC_INTERNAL GType gst_rtk_hse_get_type (void);

G_END_DECLS

#endif // __GST_RTK_HSE_H__