#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "gstrtkhse.h"
#include <gstrtkdmaallocator.h>
#include "ext/hse.h"
#include "ext/ve_common.h"
#include "ext/rtk_heap.h"
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <sys/ioctl.h>

#define ROUNDUP(x, y)     ((x + y - 1) & ~(y - 1))
#define ROUNDUP2(x)       ROUNDUP(x, 2)
#define ROUNDUP4(x)       ROUNDUP(x, 4)
#define ROUNDUP16(x)      ROUNDUP(x, 16)
#define ROUNDUP32(x)      ROUNDUP(x, 32)
#define ROUNDUP64(x)      ROUNDUP(x, 64)

#define GST_CAT_DEFAULT gst_rtk_hse_debug
GST_DEBUG_CATEGORY_STATIC (gst_rtk_hse_debug);

#define gst_rtk_hse_parent_class parent_class
G_DEFINE_TYPE (GstRtkHse, gst_rtk_hse, GST_TYPE_BASE_TRANSFORM);

#define GST_TYPE_VIDEO_ROTATE_METHOD      (gst_rtk_video_rotate_method_get_type())

#define DEFAULT_PROP_ROTATE               GST_VIDEO_ROTATE_METHOD_NONE
#define DEFAULT_PROP_SCALE_WIDTH          0
#define DEFAULT_PROP_SCALE_HEIGHT         0
#define DEFAULT_PROP_MIN_BUFFERS          0
#define DEFAULT_PROP_MAX_BUFFERS          4
#define DEFAULT_OFFSET                    2048

#define RTK_SCALE_MASK                    (1 << 0)
#define RTK_ROTATE_MASK                   (1 << 1)
#define RTK_FORMAT_CONVERT_MASK           (1 << 2)


#define GST_SINK_VIDEO_FORMATS \
  "{ NV12, NV16, NV24, RGB }"

#define GST_SRC_VIDEO_FORMATS \
  "{ NV12, NV16, BGRA, ARGB, RGB }"

enum
{
  PROP_0,
  PROP_ROTATE,
  PROP_SCALE,
};

typedef struct _hsebuf {
	int fd;
	uint32_t va;
  uint32_t ori_width;
  uint32_t ori_height;
  uint32_t width;
  uint32_t height;
  uint32_t offset;
  uint32_t format;
} hsebuf;

int hse_device_import_dmabuf(GstRtkHse * rtkhse, int dmabuf_fd, uint32_t *hse_va) {
  struct hse_import_dmabuf args = {
      .fd = dmabuf_fd,
  };
  int ret;

  ret = ioctl(rtkhse->hsefd, HSE_IOCTL_IMPORT_DMABUF, &args);
  if (!ret)
    *hse_va = args.hse_va;
  else
     GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_IMPORT_DMABUF error dmabuf_fd %d %s", dmabuf_fd, strerror(errno));

  return ret;
}

int hse_device_release_mem(int fd, uint32_t hse_va) {
  struct hse_release_mem args = {
      .hse_va = hse_va,
  };

  return ioctl(fd, HSE_IOCTL_RELEASE_MEM, &args);
}

static GType
gst_rtk_video_rotate_method_get_type (void)
{
  static GType video_rotate_method_type = 0;
  static const GEnumValue video_rotate_methods[] = {
    {GST_VIDEO_ROTATE_METHOD_NONE, "no rotation", "none"},
    {GST_VIDEO_ROTATE_METHOD_90R,  "Rotate clockwise 90 degrees", "clockwise"},
    {GST_VIDEO_ROTATE_METHOD_180,  "Rotate 180 degrees", "rotate-180"},
    {GST_VIDEO_ROTATE_METHOD_90L,  "Rotate counter-clockwise 90 degrees", "counterclockwise"},
    {GST_VIDEO_ROTATE_METHOD_AUTO, "Select rotate method based on image-orientation tag", "automatic"},
    {0, NULL, NULL},
  };

  if (!video_rotate_method_type) {
    video_rotate_method_type = g_enum_register_static ("GstVideoRotateMethod",
        video_rotate_methods);
  }
  return video_rotate_method_type;
}

static GstCaps *
gst_rtk_hse_sink_caps (void)
{
  static GstCaps *caps = NULL;
  static gsize inited = 0;

  if (g_once_init_enter (&inited)) {
    caps = gst_caps_from_string (GST_VIDEO_CAPS_MAKE (GST_SINK_VIDEO_FORMATS));

    g_once_init_leave (&inited, 1);
  }
  return caps;
}

static GstCaps *
gst_rtk_hse_src_caps (void)
{
  static GstCaps *caps = NULL;
  static gsize inited = 0;

  if (g_once_init_enter (&inited)) {
    caps = gst_caps_from_string (GST_VIDEO_CAPS_MAKE (GST_SRC_VIDEO_FORMATS));

    g_once_init_leave (&inited, 1);
  }
  return caps;
}

static GstPadTemplate *
gst_rtk_hse_sink_template (void)
{
  return gst_pad_template_new ("sink", GST_PAD_SINK, GST_PAD_ALWAYS,
      gst_rtk_hse_sink_caps ());
}

static GstPadTemplate *
gst_rtk_hse_src_template (void)
{
  return gst_pad_template_new ("src", GST_PAD_SRC, GST_PAD_ALWAYS,
      gst_rtk_hse_src_caps ());
}

static void
gst_rtk_hse_determine_passthrough (GstRtkHse * rtkhse)
{
  gboolean passthrough = TRUE;

  // Determine whether we are going to operate in passthrough mode.
  if (rtkhse->ininfo != NULL && rtkhse->outinfo != NULL) {
    passthrough &= rtkhse->ininfo->width == rtkhse->outinfo->width &&
        rtkhse->ininfo->height == rtkhse->outinfo->height;
    passthrough &=
        rtkhse->ininfo->finfo->format == rtkhse->outinfo->finfo->format;
  } else {
    passthrough &= rtkhse->scale.w == 0 || rtkhse->scale.h == 0;
  }

  passthrough &= rtkhse->outfeature == rtkhse->infeature;
  passthrough &= rtkhse->configuring_method == (GstVideoOrientationMethod) GST_VIDEO_ROTATE_METHOD_NONE;

  GST_DEBUG_OBJECT (rtkhse, "Passthrough has been %s",
      passthrough ? "enabled" : "disabled");

  gst_base_transform_set_passthrough (GST_BASE_TRANSFORM (rtkhse), passthrough);
}

static GstBufferPool *
gst_rtk_hse_create_pool (GstRtkHse * rtkhse, GstCaps * caps)
{
  GstBufferPool *pool = NULL;
  GstStructure *config = NULL;
  GstAllocator *allocator = NULL;
  GstVideoInfo info;
  long page_size;

  if (!gst_video_info_from_caps (&info, caps)) {
    GST_ERROR_OBJECT (rtkhse, "Invalid caps %" GST_PTR_FORMAT, caps);
    return NULL;
  }
  
  GstVideoFormat format;
  GstVideoAlignment video_align;
  guint width, height,buffer_size;
  guint padding_width, padding_height;

  width = GST_VIDEO_INFO_WIDTH (&info);
  height = GST_VIDEO_INFO_HEIGHT (&info);
  format = GST_VIDEO_INFO_FORMAT (&info);

  pool = gst_video_buffer_pool_new ();
  config = gst_buffer_pool_get_config (pool);

  allocator = gst_rtk_dma_allocator_new ();
  if (allocator == NULL) {
    GST_ERROR_OBJECT (rtkhse, "Failed to create dma allocator");
    gst_clear_object (&pool);
    return NULL;
  }

  padding_width = ROUNDUP32(width);
  padding_height = ROUNDUP32(height);

  if(format == GST_VIDEO_FORMAT_NV12)
    buffer_size = padding_width * padding_height * 1.5;
  else if(format == GST_VIDEO_FORMAT_NV16)
    buffer_size = padding_width * padding_height * 2;
  else if(format == GST_VIDEO_FORMAT_NV24)
    buffer_size = padding_width * padding_height * 3;
  else if(format == GST_VIDEO_FORMAT_BGRA || format == GST_VIDEO_FORMAT_ARGB)
    buffer_size = padding_width * padding_height * 4;
  else if(format == GST_VIDEO_FORMAT_RGB)
    buffer_size = padding_width * padding_height * 3;

  page_size = sysconf (_SC_PAGESIZE);
  buffer_size = ROUNDUP(buffer_size + DEFAULT_OFFSET, page_size);

  video_align.stride_align[0]=0;
  video_align.stride_align[1]=0;
  video_align.stride_align[2]=0;
  video_align.stride_align[3]=0;
  video_align.padding_top   = 0;
  video_align.padding_left  = 0;
  video_align.padding_bottom = padding_height - height;
  video_align.padding_right = padding_width - width;
  gst_structure_set (config,
      "padding-top", G_TYPE_UINT, video_align.padding_top,
      "padding-bottom", G_TYPE_UINT, video_align.padding_bottom,
      "padding-left", G_TYPE_UINT, video_align.padding_left,
      "padding-right", G_TYPE_UINT, video_align.padding_right,
      "stride-align0", G_TYPE_UINT, video_align.stride_align[0],
      "stride-align1", G_TYPE_UINT, video_align.stride_align[1],
      "stride-align2", G_TYPE_UINT, video_align.stride_align[2],
      "stride-align3", G_TYPE_UINT, video_align.stride_align[3], NULL);

  GST_DEBUG_OBJECT (rtkhse, "padding_width %d padding_height %d",padding_width,padding_height);
  GST_DEBUG_OBJECT (rtkhse, "align.padding_bottom %d align.padding_right %d",video_align.padding_bottom,video_align.padding_right);
  gst_buffer_pool_config_set_params (config, caps, buffer_size,
      DEFAULT_PROP_MIN_BUFFERS, DEFAULT_PROP_MAX_BUFFERS);
  gst_buffer_pool_config_set_allocator (config, allocator, NULL);
  gst_buffer_pool_config_add_option (config, GST_BUFFER_POOL_OPTION_VIDEO_META);
  gst_buffer_pool_config_add_option (config, GST_BUFFER_POOL_OPTION_VIDEO_ALIGNMENT);

  if (!gst_buffer_pool_set_config (pool, config)) {
    GST_WARNING_OBJECT (rtkhse, "Failed to set pool configuration!");
    g_object_unref (pool);
    pool = NULL;
  }

  g_object_unref (allocator);

  return pool;
}

static gboolean
gst_rtk_hse_propose_allocation (GstBaseTransform * base,
    GstQuery * inquery, GstQuery * outquery)
{
  GstRtkHse *rtkhse = GST_RTK_HSE_CAST (base);

  GstCaps *caps = NULL;
  GstBufferPool *pool = NULL;
  GstVideoInfo info;
  guint size = 0;
  gboolean needpool = FALSE;

  if (NULL != inquery)
    gst_pad_peer_query (base->srcpad, outquery);

  if (!GST_BASE_TRANSFORM_CLASS (parent_class)->propose_allocation (
        base, inquery, outquery))
    return FALSE;

  // No input query, nothing to do.
  if (NULL == inquery)
    return TRUE;

  // Extract caps from the query.
  gst_query_parse_allocation (outquery, &caps, &needpool);

  if (NULL == caps) {
    GST_ERROR_OBJECT (rtkhse, "Failed to extract caps from query!");
    return FALSE;
  }

  if (!gst_video_info_from_caps (&info, caps)) {
    GST_ERROR_OBJECT (rtkhse, "Failed to get video info!");
    return FALSE;
  }

  size = GST_VIDEO_INFO_SIZE (&info);

  if (needpool) {
    GstStructure *structure = NULL;
    GstAllocator *allocator = NULL;
    pool = gst_rtk_hse_create_pool (rtkhse, caps);
    structure = gst_buffer_pool_get_config (pool);
    gst_buffer_pool_config_get_allocator (structure, &allocator, NULL);
    gst_query_add_allocation_param (outquery, allocator, NULL);
  }

  // If upstream does't have a pool requirement, set only size in query.
  gst_query_add_allocation_pool (outquery, needpool ? pool : NULL, size, 0, 0);

  if (pool != NULL)
    gst_object_unref (pool);

  gst_query_add_allocation_meta (outquery, GST_VIDEO_META_API_TYPE, NULL);
  return TRUE;
}

static gboolean
gst_rtk_hse_decide_allocation (GstBaseTransform * base,
    GstQuery * query)
{
  GstRtkHse *rtkhse = GST_RTK_HSE_CAST (base);

  GstCaps *caps = NULL;
  GstBufferPool *pool = NULL;
  GstStructure *config = NULL;
  GstAllocator *allocator = NULL;
  guint size, minbuffers, maxbuffers;
  GstAllocationParams params;

  gst_query_parse_allocation (query, &caps, NULL);
  if (!caps) {
    GST_ERROR_OBJECT (rtkhse, "Failed to parse the decide_allocation caps!");
    return FALSE;
  }

  // Invalidate the cached pool if there is an allocation_query.
  if (rtkhse->outpool) {
    gst_buffer_pool_set_active (rtkhse->outpool, FALSE);
    gst_object_unref (rtkhse->outpool);
  }

  // Create a new buffer pool.
  pool = gst_rtk_hse_create_pool (rtkhse, caps);
  rtkhse->outpool = pool;

  // Get the configured pool properties in order to set in query.
  config = gst_buffer_pool_get_config (pool);
  gst_buffer_pool_config_get_params (config, &caps, &size, &minbuffers,
      &maxbuffers);

  if (gst_buffer_pool_config_get_allocator (config, &allocator, &params))
    gst_query_add_allocation_param (query, allocator, &params);

  gst_buffer_pool_config_get_video_alignment(config,&rtkhse->out_video_align);
  gst_structure_free (config);

  // Check whether the query has pool.
  if (gst_query_get_n_allocation_pools (query) > 0)
    gst_query_set_nth_allocation_pool (query, 0, pool, size, minbuffers,
        maxbuffers);
  else
    gst_query_add_allocation_pool (query, pool, size, minbuffers,
        maxbuffers);

  gst_query_add_allocation_meta (query, GST_VIDEO_META_API_TYPE, NULL);
  return TRUE;
}

static GstFlowReturn
gst_rtk_hse_prepare_output_buffer (GstBaseTransform * base,
    GstBuffer * inbuffer, GstBuffer ** outbuffer)
{
  GstRtkHse *rtkhse = GST_RTK_HSE_CAST (base);
  GstBufferPool *pool = rtkhse->outpool;
  gboolean passthrough = FALSE, writable = TRUE;
  gsize out_size, out_offset, out_maxsize;
  GstMemory *out_mem;

  // Check whether passthrough should be true/false based on parameters.
  gst_rtk_hse_determine_passthrough (rtkhse);

  passthrough = gst_base_transform_is_passthrough (base);
  writable = gst_buffer_is_writable (inbuffer);

  // Force a copy when the buffer is not writable.
  if (passthrough && !writable) {
    GST_TRACE_OBJECT (rtkhse, "Input buffer not writable, disable passthrough");
    gst_base_transform_set_passthrough (base, FALSE);
  } else if (passthrough) {
    GST_LOG_OBJECT (rtkhse, "Passthrough, no need to do anything");
    *outbuffer = inbuffer;
    return GST_FLOW_OK;
  }

  g_return_val_if_fail (pool != NULL, GST_FLOW_ERROR);

  if (!gst_buffer_pool_is_active (pool) &&
      !gst_buffer_pool_set_active (pool, TRUE)) {
    GST_ERROR_OBJECT (rtkhse, "Failed to activate output video buffer pool!");
    return GST_FLOW_ERROR;
  }

  // Input is marked as GAP, nothing to process. Create a GAP output buffer.
  if (gst_buffer_get_size (inbuffer) == 0 &&
      GST_BUFFER_FLAG_IS_SET (inbuffer, GST_BUFFER_FLAG_GAP))
    *outbuffer = gst_buffer_new ();

  if ((*outbuffer == NULL) &&
      gst_buffer_pool_acquire_buffer (pool, outbuffer, NULL) != GST_FLOW_OK) {
    GST_ERROR_OBJECT (rtkhse, "Failed to create output video buffer!");
    return GST_FLOW_ERROR;
  }

  out_mem = gst_buffer_peek_memory (*outbuffer, 0);
  out_size = gst_memory_get_sizes (out_mem, &out_offset, &out_maxsize);

  if(out_size == out_maxsize){
    gsize buffer_size = ROUNDUP32(rtkhse->outinfo->width) * ROUNDUP32(rtkhse->outinfo->height);
    if(rtkhse->outinfo->finfo->format == GST_VIDEO_FORMAT_NV12)
      buffer_size = buffer_size * 1.5;
    else if(rtkhse->outinfo->finfo->format == GST_VIDEO_FORMAT_NV16)
      buffer_size = buffer_size * 2;
    else if(rtkhse->outinfo->finfo->format == GST_VIDEO_FORMAT_NV24)
      buffer_size = buffer_size * 3;
    else if(rtkhse->outinfo->finfo->format == GST_VIDEO_FORMAT_BGRA || rtkhse->outinfo->finfo->format == GST_VIDEO_FORMAT_ARGB)
      buffer_size = buffer_size * 4;
    else if(rtkhse->outinfo->finfo->format == GST_VIDEO_FORMAT_RGB)
      buffer_size = buffer_size * 3;
    gst_memory_resize (out_mem, 0, buffer_size);
    out_size = gst_memory_get_sizes (out_mem, &out_offset, &out_maxsize);
    GST_LOG_OBJECT (rtkhse, "out_size %zu out_maxsize %zu",out_size,out_maxsize);
  }

  // Copy the flags and timestamps from the input buffer.
  gst_buffer_copy_into (*outbuffer, inbuffer,
      GST_BUFFER_COPY_FLAGS | GST_BUFFER_COPY_TIMESTAMPS, 0, -1);

  return GST_FLOW_OK;
}

static GstCaps *
gst_rtk_hse_transform_caps (GstBaseTransform * base,
    GstPadDirection direction, GstCaps * caps, GstCaps * filter)
{
  GstRtkHse *rtkhse = GST_RTK_HSE (base);
  GstCaps *result = NULL;
  GstStructure *structure = NULL;
  GstCapsFeatures *features = NULL;
  gint idx = 0, length = 0;

  GST_DEBUG_OBJECT (rtkhse, "Transforming caps %" GST_PTR_FORMAT
      " in direction %s", caps, (direction == GST_PAD_SINK) ? "sink" : "src");
  GST_DEBUG_OBJECT (rtkhse, "Filter caps %" GST_PTR_FORMAT, filter);


  result = gst_caps_new_empty ();

  length = gst_caps_get_size (caps);

  for (idx = 0; idx < length; idx++) {
    structure = gst_caps_get_structure (caps, idx);
    features = gst_caps_get_features (caps, idx);

    // If this is already expressed by the existing caps skip this structure.
    if (idx > 0 && gst_caps_is_subset_structure_full (result, structure, features))
      continue;

    // Make a copy that will be modified.
    structure = gst_structure_copy (structure);

    // Set width and height to a range instead of fixed value.
    gst_structure_set (structure, "width", GST_TYPE_INT_RANGE, 1, G_MAXINT,
        "height", GST_TYPE_INT_RANGE, 1, G_MAXINT, NULL);

    // If pixel aspect ratio, make a range of it.
    if (gst_structure_has_field (structure, "pixel-aspect-ratio")) {
      gst_structure_set (structure, "pixel-aspect-ratio",
          GST_TYPE_FRACTION_RANGE, 1, G_MAXINT, G_MAXINT, 1, NULL);
    }

    // Remove the format/color/compression related fields.
    gst_structure_remove_fields (structure, "format", "colorimetry",
        "chroma-site", "compression", NULL);

    gst_caps_append_structure_full (result, structure,
        gst_caps_features_copy (features));
  }

  if (filter) {
    GstCaps *intersection  =
        gst_caps_intersect_full (filter, result, GST_CAPS_INTERSECT_FIRST);
    gst_caps_unref (result);
    result = intersection;
  }

  GST_DEBUG_OBJECT (rtkhse, "Returning caps: %" GST_PTR_FORMAT, result);
  return result;
}

static gboolean
gst_rtk_hse_set_caps (GstBaseTransform * base, GstCaps * incaps,
    GstCaps * outcaps)
{
  GstRtkHse *rtkhse = GST_RTK_HSE (base);
  const gchar *feature = NULL;
  GstVideoInfo ininfo, outinfo;
  gint in_dar_n, in_dar_d, out_dar_n, out_dar_d;

  if (!gst_video_info_from_caps (&ininfo, incaps)) {
    GST_ERROR_OBJECT (rtkhse, "Failed to get input video info from caps!");
    return FALSE;
  }

  if (!gst_video_info_from_caps (&outinfo, outcaps)) {
    GST_ERROR_OBJECT (rtkhse, "Failed to get output video info from caps!");
    return FALSE;
  }

  if (!gst_util_fraction_multiply (ininfo.width, ininfo.height,
          ininfo.par_n, ininfo.par_d, &in_dar_n, &in_dar_d)) {
    GST_WARNING_OBJECT (rtkhse, "Failed to calculate input DAR!");
    in_dar_n = in_dar_d = -1;
  }

  if (!gst_util_fraction_multiply (outinfo.width, outinfo.height,
          outinfo.par_n, outinfo.par_d, &out_dar_n, &out_dar_d)) {
    GST_WARNING_OBJECT (rtkhse, "Failed to calculate output DAR!");
    out_dar_n = out_dar_d = -1;
  }

  GST_DEBUG_OBJECT (rtkhse, "From %dx%d (PAR: %d/%d, DAR: %d/%d), size %"
      G_GSIZE_FORMAT " -> To %dx%d (PAR: %d/%d, DAR: %d/%d), size %"
      G_GSIZE_FORMAT, ininfo.width, ininfo.height, ininfo.par_n, ininfo.par_d,
      in_dar_n, in_dar_d, ininfo.size, outinfo.width, outinfo.height,
      outinfo.par_n, outinfo.par_d, out_dar_n, out_dar_d, outinfo.size);

  if (rtkhse->ininfo != NULL)
    gst_video_info_free (rtkhse->ininfo);

  rtkhse->ininfo = gst_video_info_copy (&ininfo);

  if (rtkhse->outinfo != NULL)
    gst_video_info_free (rtkhse->outinfo);

  rtkhse->outinfo = gst_video_info_copy (&outinfo);

  feature = NULL;
  rtkhse->infeature = g_quark_from_static_string (feature);

  feature = NULL;
  rtkhse->outfeature = g_quark_from_static_string (feature);

  // Disable passthrough in order to decide output allocation.
  gst_base_transform_set_passthrough (base, FALSE);
  return TRUE;
}

static gboolean
gst_rtk_hse_fill_pixel_aspect_ratio (GstRtkHse * rtkhse,
    GstPadDirection direction, GstStructure * input, GstStructure * output)
{
  const GValue *in_par, *out_par;

  in_par = gst_structure_get_value (input, "pixel-aspect-ratio");
  out_par = gst_structure_get_value (output, "pixel-aspect-ratio");

  switch (direction) {
    case GST_PAD_SRC:
      if ((NULL == in_par) || !gst_value_is_fixed (in_par))
        gst_structure_set (input, "pixel-aspect-ratio",
            GST_TYPE_FRACTION, 1, 1, NULL);

      if ((NULL == out_par) || !gst_value_is_fixed (out_par))
        gst_structure_set (output, "pixel-aspect-ratio",
            GST_TYPE_FRACTION, 1, 1, NULL);
      break;
    case GST_PAD_SINK:
      if ((NULL == in_par) || !gst_value_is_fixed (in_par))
        gst_structure_set (input, "pixel-aspect-ratio",
            GST_TYPE_FRACTION, 1, 1, NULL);

      if (NULL == out_par)
        gst_structure_set (output, "pixel-aspect-ratio",
            GST_TYPE_FRACTION_RANGE, 1, G_MAXINT, G_MAXINT, 1, NULL);
      break;
    case GST_PAD_UNKNOWN:
    default:
      GST_ELEMENT_ERROR (rtkhse, CORE, NEGOTIATION, (NULL),
          ("Invalid or unknown pad direction!"));
      return FALSE;
  }
  return TRUE;
}

static void
gst_rtk_hse_fixate_dimensions (GstRtkHse * rtkhse,
    GstStructure * input, GstStructure * output)
{
  gint in_par_n, in_par_d, in_dar_n, in_dar_d, in_width, in_height;
  gboolean success;

  {
    // Retrieve the PAR (pixel aspect ratio) values for the input.
    const GValue *in_par = gst_structure_get_value (input,
        "pixel-aspect-ratio");

    in_par_n = gst_value_get_fraction_numerator (in_par);
    in_par_d = gst_value_get_fraction_denominator (in_par);
  }

  // Retrieve the input width and height.
  gst_structure_get_int (input, "width", &in_width);
  gst_structure_get_int (input, "height", &in_height);

  // Calculate input DAR (display aspect ratio) from the dimensions and PAR.
  success = gst_util_fraction_multiply (in_width, in_height,
      in_par_n, in_par_d, &in_dar_n, &in_dar_d);

  if (!success) {
    GST_ELEMENT_ERROR (rtkhse, CORE, NEGOTIATION, (NULL),
        ("Error calculating the input DAR!"));
    return;
  }

  GST_DEBUG_OBJECT (rtkhse, "Input DAR is: %d/%d", in_dar_n, in_dar_d);

  {
    // Keep the dimensions as near as possible to the input and scale PAR.
    GstStructure *structure = gst_structure_copy (output);
    gint set_h, set_w, set_par_n, set_par_d, num, den, value;
    gint out_par_n, out_par_d, out_width, out_height;

    switch (rtkhse->configuring_method) {
      case GST_VIDEO_ROTATE_METHOD_90R:
      case GST_VIDEO_ROTATE_METHOD_90L:
        gst_structure_fixate_field_nearest_int (structure, "width", in_height);
        gst_structure_get_int (structure, "width", &out_width);

        gst_structure_fixate_field_nearest_int (structure, "height", in_width);
        gst_structure_get_int (structure, "height", &out_height);

        success = gst_util_fraction_multiply (in_dar_n, in_dar_d,
            out_width, out_height, &out_par_n, &out_par_d);
        break;
      case GST_VIDEO_ROTATE_METHOD_NONE:
      case GST_VIDEO_ROTATE_METHOD_180:
        gst_structure_fixate_field_nearest_int (structure, "width", in_width);
        gst_structure_get_int (structure, "width", &out_width);

        gst_structure_fixate_field_nearest_int (structure, "height", in_height);
        gst_structure_get_int (structure, "height", &out_height);

        success = gst_util_fraction_multiply (in_dar_n, in_dar_d,
            out_height, out_width, &out_par_n, &out_par_d);
        break;
      default:
        break;
    }

    if (!success) {
      GST_ELEMENT_ERROR (rtkhse, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output PAR!"));
      gst_structure_free (structure);
      return;
    }

    gst_structure_fixate_field_nearest_fraction (structure,
        "pixel-aspect-ratio", out_par_n, out_par_d);
    gst_structure_get_fraction (structure, "pixel-aspect-ratio",
        &set_par_n, &set_par_d);

    // Validate the output PAR and update the output fields.
    if (set_par_n == out_par_n && set_par_d == out_par_d) {
      gst_structure_set (output, "width", G_TYPE_INT, out_width,
          "height", G_TYPE_INT, out_height, NULL);

      gst_structure_set (output, "pixel-aspect-ratio", GST_TYPE_FRACTION,
          set_par_n, set_par_d, NULL);

      GST_DEBUG_OBJECT (rtkhse, "Output dimensions fixated to: %dx%d, and PAR"
          " fixated to: %d/%d", out_width, out_height, set_par_n, set_par_d);

      gst_structure_free (structure);
      return;
    }

    // Above failed, scale width to keep the DAR with the set PAR and height.
    success = gst_util_fraction_multiply (in_dar_n, in_dar_d, set_par_d,
        set_par_n, &num, &den);

    if (!success) {
      GST_ELEMENT_ERROR (rtkhse, CORE, NEGOTIATION, (NULL),
          ("Error calculating the output width!"));
      gst_structure_free (structure);
      return;
    }

    set_w = gst_util_uint64_scale_int (out_height, num, den);
    gst_structure_fixate_field_nearest_int (structure, "width", set_w);
    gst_structure_get_int (structure, "width", &value);

    if (set_w == value) {
      gst_structure_set (output, "width", G_TYPE_INT, set_w,
          "height", G_TYPE_INT, out_height, NULL);

      gst_structure_set (output, "pixel-aspect-ratio", GST_TYPE_FRACTION,
          set_par_n, set_par_d, NULL);

      GST_DEBUG_OBJECT (rtkhse, "Output dimensions fixated to: %dx%d, and PAR"
          " fixated to: %d/%d", out_width, out_height, set_par_n, set_par_d);

      gst_structure_free (structure);
      return;
    }

    // Above failed, scale height to keep the DAR with the set PAR and width.
    set_h = gst_util_uint64_scale_int (out_width, den, num);
    gst_structure_fixate_field_nearest_int (structure, "height", set_h);
    gst_structure_get_int (structure, "height", &value);

    gst_structure_free (structure);

    if (set_h == value) {
      gst_structure_set (output, "width", G_TYPE_INT, out_width,
          "height", G_TYPE_INT, set_h, NULL);

      gst_structure_set (output, "pixel-aspect-ratio", GST_TYPE_FRACTION,
          set_par_n, set_par_d, NULL);

      GST_DEBUG_OBJECT (rtkhse, "Output dimensions fixated to: %dx%d, and PAR"
          " fixated to: %d/%d", out_width, out_height, set_par_n, set_par_d);
      return;
    }

    // All approaches failed, take the values from the 1st iteration.
    gst_structure_set (output, "width", G_TYPE_INT, out_width,
        "height", G_TYPE_INT, out_height, NULL);
    gst_structure_set (output, "pixel-aspect-ratio", GST_TYPE_FRACTION,
        out_par_n, out_par_d, NULL);

    GST_DEBUG_OBJECT (rtkhse, "Output dimensions fixated to: %dx%d, and PAR"
        " fixated to: %d/%d", out_width, out_height, out_par_n, out_par_d);
  }

  return;
}

static void
gst_rtk_hse_fixate_width_and_height (GstRtkHse * rtkhse, GstStructure * output)
{
  switch (rtkhse->configuring_method) {
    case GST_VIDEO_ROTATE_METHOD_90R:
    case GST_VIDEO_ROTATE_METHOD_90L:
      gst_structure_set (output, "width", G_TYPE_INT, rtkhse->scale.h,
        "height", G_TYPE_INT, rtkhse->scale.w, NULL);
      break;
    case GST_VIDEO_ROTATE_METHOD_NONE:
    case GST_VIDEO_ROTATE_METHOD_180:
      gst_structure_set (output, "width", G_TYPE_INT, rtkhse->scale.w,
        "height", G_TYPE_INT, rtkhse->scale.h, NULL);
      break;
    default:
      break;
  }
  gst_structure_fixate_field_nearest_fraction (output,
          "pixel-aspect-ratio", 1, 1);
  return;
}

static void
gst_rtk_hse_fixate_format (GstRtkHse * rtkhse,
    GstStructure * input, GstStructure * output)
{
  const GstVideoFormatInfo *ininfo, *outinfo = NULL;
  const GValue *format = NULL;
  const gchar *infmt = NULL;

  infmt = gst_structure_get_string (input, "format");
  g_return_if_fail (infmt != NULL);

  GST_DEBUG_OBJECT (rtkhse, "Source format %s", infmt);

  ininfo = gst_video_format_get_info (gst_video_format_from_string (infmt));
  g_return_if_fail (ininfo != NULL);

  format = gst_structure_get_value (output, "format");
  g_return_if_fail (format != NULL);

  if (outinfo != NULL)
    gst_structure_fixate_field_string (output, "format",
        GST_VIDEO_FORMAT_INFO_NAME (outinfo));

  if (gst_structure_has_field (input, "colorimetry")) {
    const gchar *string = gst_structure_get_string (input, "colorimetry");

    if (gst_structure_has_field (output, "colorimetry"))
      gst_structure_fixate_field_string (output, "colorimetry", string);
    else
      gst_structure_set (output, "colorimetry", G_TYPE_STRING, string, NULL);
  }

  if (gst_structure_has_field (input, "chroma-site")) {
    const gchar *string = gst_structure_get_string (input, "chroma-site");

    if (gst_structure_has_field (output, "chroma-site"))
      gst_structure_fixate_field_string (output, "chroma-site", string);
    else
      gst_structure_set (output, "chroma-site", G_TYPE_STRING, string, NULL);
  }

  if (gst_structure_has_field (input, "compression")) {
    const gchar *string = gst_structure_get_string (input, "compression");

    if (gst_structure_has_field (output, "compression"))
      gst_structure_fixate_field_string (output, "compression", string);
    else
      gst_structure_set (output, "compression", G_TYPE_STRING, string, NULL);
  }
}

static GstCaps *
gst_rtk_hse_fixate_caps (GstBaseTransform * base,
    GstPadDirection direction, GstCaps * incaps, GstCaps * outcaps)
{
  GstRtkHse *rtkhse = GST_RTK_HSE (base);
  GstStructure *input, *output;

  // Truncate and make the output caps writable.
  outcaps = gst_caps_truncate (outcaps);
  outcaps = gst_caps_make_writable (outcaps);

  output = gst_caps_get_structure (outcaps, 0);

  // Take a copy of the input caps structure so we can freely modify it.
  input = gst_caps_get_structure (incaps, 0);
  input = gst_structure_copy (input);

  GST_DEBUG_OBJECT (rtkhse, "Trying to fixate output caps %" GST_PTR_FORMAT
      " based on caps %" GST_PTR_FORMAT, outcaps, incaps);

  gst_rtk_hse_fixate_format (rtkhse, input, output);
  {
    // Fill the pixel-aspect-ratio fields if they weren't set in the caps.
    gboolean success = gst_rtk_hse_fill_pixel_aspect_ratio (
        rtkhse, direction, input, output);
    g_return_val_if_fail (success, outcaps);
  }

  {
    if ((rtkhse->scale.w != 0) && (rtkhse->scale.h != 0)) {
      GST_DEBUG_OBJECT (rtkhse, "gst_rtk_hse_fixate_width_and_height");
      gst_rtk_hse_fixate_width_and_height (rtkhse, output);
    } else {
      GST_DEBUG_OBJECT (rtkhse, "gst_rtk_hse_fixate_dimensions");
      gst_rtk_hse_fixate_dimensions (rtkhse, input, output);
    }
  }

  outcaps = gst_caps_fixate (outcaps);

  // Free the local copy of the input caps structure.
  gst_structure_free (input);

  GST_DEBUG_OBJECT (rtkhse, "Fixated caps to %" GST_PTR_FORMAT, outcaps);
  return outcaps;
}

static guint
gst_rtk_hse_format (GstRtkHse *rtkhse, GstVideoFormat format)
{
  guint hse_fmt = 0;
  GST_DEBUG_OBJECT (rtkhse, "format = %d" ,format);
  switch (format) {
    case GST_VIDEO_FORMAT_NV12:
      hse_fmt = HSE_FMT_YUV420SP;
      break;
    case GST_VIDEO_FORMAT_NV16:
      hse_fmt = HSE_FMT_YUV422SP;
      break;
    case GST_VIDEO_FORMAT_NV24:
      hse_fmt = GST_VIDEO_FORMAT_NV24;
      break;
    case GST_VIDEO_FORMAT_ARGB:
      hse_fmt = HSE_FMT_ARGB;
      break;
    case GST_VIDEO_FORMAT_BGRA:
      hse_fmt = HSE_FMT_BGRA;
      break;
    case GST_VIDEO_FORMAT_RGB:
      hse_fmt = HSE_FMT_RGB888;
      break;
    default:
      hse_fmt = format;
      break;
  }
  GST_DEBUG_OBJECT (rtkhse, "hse_fmt = %d" ,hse_fmt);
  return hse_fmt;
}

static GstFlowReturn
gst_rtk_hse_scale (GstRtkHse *rtkhse, hsebuf *in_buf, hsebuf *out_buf)
{
  struct hse_cmd_stretch stretch  = {0};
  gint ret = GST_FLOW_OK;

  stretch.src_width = in_buf->ori_width;
  stretch.src_height = in_buf->ori_height;
  stretch.src_pitch = in_buf->width;
  stretch.src_va = in_buf->va;
  stretch.src_offset = in_buf->offset;
  stretch.dst_width = out_buf->ori_width;
  stretch.dst_height = out_buf->ori_height;
  stretch.dst_pitch = out_buf->width;
  stretch.dst_va = out_buf->va;
  stretch.dst_offset = out_buf->offset;
  stretch.colorSel = COLOR_SEL_Y;

  ret = ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_STRETCH, &stretch);
  if (ret < 0) {
      GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_STRETCH y fail! Error = (%s)\n", strerror(errno));
      ret = GST_FLOW_ERROR;
      goto exit;
  }

  if(in_buf->format == HSE_FMT_YUV420SP) {
    stretch.src_height = in_buf->ori_height >> 1;
    stretch.dst_height = out_buf->ori_height >> 1;
  } else if(in_buf->format == HSE_FMT_YUV422SP) {
    stretch.src_height = in_buf->ori_height;
    stretch.dst_height = out_buf->ori_height;
  }

  stretch.src_width = in_buf->ori_width >> 1;
  stretch.src_pitch = in_buf->width;
  stretch.src_va = in_buf->va;
  stretch.src_offset = in_buf->offset + in_buf->width * in_buf->height;
  stretch.dst_width = out_buf->ori_width >> 1;
  stretch.dst_pitch = out_buf->width;
  stretch.dst_va = out_buf->va;
  stretch.dst_offset = out_buf->offset + out_buf->width * out_buf->height;
  stretch.colorSel = COLOR_SEL_CBCR;

  ret = ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_STRETCH, &stretch);
  if (ret < 0) {
      GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_STRETCH uv fail! Error = (%s)\n", strerror(errno));
      ret = GST_FLOW_ERROR;
      goto exit;
  }

exit:
  return ret;
}

static GstFlowReturn
gst_rtk_hse_rotate (GstRtkHse *rtkhse, hsebuf *in_buf, hsebuf *out_buf, gint rotate_method)
{
  struct hse_cmd_rotate hse_data_y  = {0};
  struct hse_cmd_rotate hse_data_uv = {0};
  gint ret = GST_FLOW_OK;

  hse_data_y.width = in_buf->width;
  hse_data_y.height = in_buf->height;
  hse_data_y.dst_pitch = out_buf->width;
  hse_data_y.dst_va = out_buf->va;
  hse_data_y.dst_offset = out_buf->offset;
  hse_data_y.src_pitch = in_buf->width;
  hse_data_y.src_va = in_buf->va;
  hse_data_y.src_offset = in_buf->offset;
  hse_data_y.mode = rotate_method;
  hse_data_y.color_format = HSE_ROTATE_COLOR_FORMAT_Y;
  hse_data_y.flags=0;
  if (ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_ROTATE, &hse_data_y)) {
    GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_ROTATE y fail! Error = (%s)\n", strerror(errno));
    ret = GST_FLOW_ERROR;
    goto exit;
  }

  hse_data_uv.width = in_buf->width >> 1;
  hse_data_uv.height = in_buf->height >> 1;
  hse_data_uv.dst_pitch = out_buf->width;
  hse_data_uv.dst_va = out_buf->va;
  hse_data_uv.dst_offset = out_buf->offset + out_buf->width * out_buf->height;
  hse_data_uv.src_pitch = in_buf->width;
  hse_data_uv.src_va = in_buf->va;
  hse_data_uv.src_offset = in_buf->offset + in_buf->width * in_buf->height;
  hse_data_uv.mode = rotate_method;
  hse_data_uv.color_format = HSE_ROTATE_COLOR_FORMAT_CbCr;
  hse_data_uv.flags=0;
  ret = ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_ROTATE, &hse_data_uv);
  if (ret < 0) {
      GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_ROTATE uv fail! Error = (%s)\n", strerror(errno));
      ret = GST_FLOW_ERROR;
      goto exit;
  }

exit:
  return ret;
}

static GstFlowReturn
gst_rtk_hse_align_padding (GstRtkHse *rtkhse, hsebuf *in_buf, hsebuf *out_buf, gint padding_width, gint padding_height)
{
  struct hse_cmd_picture_copy hse_data_picture_copy = {0};
  struct hse_cmd_copy hse_data_copy                 = {0};
  gint ret = GST_FLOW_OK;

  if(in_buf->ori_width % 4 == 0) {
      GST_LOG_OBJECT (rtkhse, "in_buf->ori_width is 4 alignment in_buf->ori_width = %d",in_buf->ori_width);
      hse_data_picture_copy.width = in_buf->ori_width;
      hse_data_picture_copy.height = in_buf->ori_height;
      hse_data_picture_copy.dst_pitch = out_buf->width;
      hse_data_picture_copy.dst_va = out_buf->va;
      hse_data_picture_copy.dst_offset = out_buf->offset;
      hse_data_picture_copy.src_pitch = in_buf->width;
      hse_data_picture_copy.src_va = in_buf->va;
      hse_data_picture_copy.src_offset = padding_width + padding_height * in_buf->width;
      hse_data_picture_copy.flags=0;
      ret = ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_PICTURE_COPY, &hse_data_picture_copy);
      if (ret < 0) {
          GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_PICTURE_COPY y fail! Error = (%s)\n", strerror(errno));
          GST_ERROR_OBJECT (rtkhse, "hse_data_picture_copy.dst_pitch = %d",hse_data_picture_copy.dst_pitch);
          GST_ERROR_OBJECT (rtkhse, "hse_data_picture_copy.src_pitch = %d",hse_data_picture_copy.src_pitch);
          ret = GST_FLOW_ERROR;
          goto exit;
      }

      hse_data_picture_copy.width = in_buf->ori_width;
      hse_data_picture_copy.height = in_buf->ori_height >> 1;
      hse_data_picture_copy.dst_pitch = out_buf->width;
      hse_data_picture_copy.dst_va = out_buf->va;
      hse_data_picture_copy.dst_offset = out_buf->offset + out_buf->width * out_buf->height;
      hse_data_picture_copy.src_pitch = in_buf->width;
      hse_data_picture_copy.src_va = in_buf->va;
      hse_data_picture_copy.src_offset = in_buf->width * in_buf->height + padding_width + padding_height / 2 * in_buf->width;
      hse_data_picture_copy.flags=0;
      ret = ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_PICTURE_COPY, &hse_data_picture_copy);
      if (ret < 0) {
          GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_PICTURE_COPY uv fail! Error = (%s)\n", strerror(errno));
          ret = GST_FLOW_ERROR;
          goto exit;
      }
  } else {
      GST_LOG_OBJECT (rtkhse, "in_buf->ori_width not 4 alignment in_buf->ori_width = %d",in_buf->ori_width);;
      for(gint i = 0; i < out_buf->ori_height; i++) {
         hse_data_copy.size = out_buf->ori_width;
         hse_data_copy.dst_va = out_buf->va;
         hse_data_copy.dst_offset = out_buf->offset + i * out_buf->width;
         hse_data_copy.src_va = in_buf->va;
         hse_data_copy.src_offset = (i + padding_height) * in_buf->width + padding_width;
         hse_data_copy.flags=0;
         ret = ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_COPY, &hse_data_copy);
         if (ret < 0) {
           GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_COPY y i = %d fail! Error = (%s)\n", i, strerror(errno));
           ret = GST_FLOW_ERROR;
           goto exit;
         }
      }
      for(gint i = 0; i < out_buf->ori_height / 2; i++) {
         hse_data_copy.size = out_buf->ori_width;
         hse_data_copy.dst_va = out_buf->va;
         hse_data_copy.dst_offset = out_buf->offset + out_buf->width * out_buf->height + i * out_buf->width;
         hse_data_copy.src_va = in_buf->va;
         hse_data_copy.src_offset = in_buf->width * in_buf->height + (i + padding_height / 2) * in_buf->width + padding_width;
         hse_data_copy.flags=0;
         ret = ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_COPY, &hse_data_copy);
         if (ret < 0) {
           GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_COPY uv i = %d  fail! Error = (%s)\n", i, strerror(errno));
           ret = GST_FLOW_ERROR;
           goto exit;
         }
      }
  }

exit:
  return ret;
}

static GstFlowReturn
gst_rtk_hse_fmt_convert (GstRtkHse *rtkhse, hsebuf *in_buf, hsebuf *out_buf)
{
  struct hse_cmd_fmt_convert fmt_cvt = {0};
  gint ret = GST_FLOW_OK;

  fmt_cvt.width = in_buf->ori_width;
	fmt_cvt.height = in_buf->ori_height;
  fmt_cvt.src_fmt = in_buf->format;
  fmt_cvt.dst_fmt = out_buf->format;
  fmt_cvt.alpha_out = 0xFF;

  if(in_buf->format == HSE_FMT_RGB888) {
    fmt_cvt.src_pitch = in_buf->width * 3;
    fmt_cvt.src_luma_va = in_buf->va;
    fmt_cvt.src_luma_offset = in_buf->offset;
    fmt_cvt.src_chroma_va = 0;
    fmt_cvt.src_chroma_offset = 0;
  } else {
    fmt_cvt.src_pitch = in_buf->width;
    fmt_cvt.src_luma_va = in_buf->va;
    fmt_cvt.src_luma_offset = in_buf->offset;
    fmt_cvt.src_chroma_va = in_buf->va;
    fmt_cvt.src_chroma_offset = in_buf->offset + in_buf->width * in_buf->height;
  }

  if(out_buf->format == HSE_FMT_ARGB || out_buf->format == HSE_FMT_BGRA) {
    fmt_cvt.dst_pitch = out_buf->width * 4;
    fmt_cvt.dst_luma_va = out_buf->va;
    fmt_cvt.dst_luma_offset = out_buf->offset;
    fmt_cvt.dst_chroma_va = 0;
    fmt_cvt.dst_chroma_offset = 0;
  } else if(out_buf->format == HSE_FMT_RGB888) {
    fmt_cvt.dst_pitch = out_buf->width * 3;
    fmt_cvt.dst_luma_va = out_buf->va;
    fmt_cvt.dst_luma_offset = out_buf->offset;
    fmt_cvt.dst_chroma_va = 0;
    fmt_cvt.dst_chroma_offset = 0;
  } else {
    fmt_cvt.dst_pitch = out_buf->width;
    fmt_cvt.dst_luma_va = out_buf->va;
    fmt_cvt.dst_luma_offset = out_buf->offset;
    fmt_cvt.dst_chroma_va = out_buf->va;
    fmt_cvt.dst_chroma_offset = out_buf->offset + out_buf->width * out_buf->height;
  }

  if(in_buf->format == HSE_FMT_YUV422SP && out_buf->format == HSE_FMT_YUV420SP) {
    struct hse_cmd_picture_copy hse_data_copy = {0};
    struct hse_cmd_stretch stretch  = {0};

    if(in_buf->ori_width % 4 == 0) {
      GST_LOG_OBJECT (rtkhse, "fmt convert in_buf->ori_width is 4 alignment in_buf->ori_width = %d",in_buf->ori_width);
      hse_data_copy.width = in_buf->ori_width;
      hse_data_copy.height = in_buf->ori_height;
      hse_data_copy.dst_pitch = out_buf->width;
      hse_data_copy.dst_va = out_buf->va;
      hse_data_copy.dst_offset = out_buf->offset;
      hse_data_copy.src_pitch = in_buf->width;
      hse_data_copy.src_va = in_buf->va;
      hse_data_copy.src_offset = in_buf->offset;
      hse_data_copy.flags=0;
      ret = ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_PICTURE_COPY, &hse_data_copy);
      if (ret < 0) {
          GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_PICTURE_COPY fail! Error = (%s)\n", strerror(errno));
          ret = GST_FLOW_ERROR;
          goto exit;
      }

      stretch.src_width = in_buf->ori_width >> 1;
      stretch.src_height = in_buf->ori_height;
      stretch.src_pitch = in_buf->width;
      stretch.src_va = in_buf->va;
      stretch.src_offset = in_buf->offset + in_buf->width * in_buf->height;
      stretch.dst_width = out_buf->ori_width >> 1;
      stretch.dst_height = out_buf->ori_height >> 1;
      stretch.dst_pitch = out_buf->width;
      stretch.dst_va = out_buf->va;
      stretch.dst_offset = out_buf->offset + out_buf->width * out_buf->height;
      stretch.colorSel = COLOR_SEL_CBCR;

      ret = ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_STRETCH, &stretch);
      if (ret < 0) {
          GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_STRETCH fail! Error = (%s)\n", strerror(errno));
          ret = GST_FLOW_ERROR;
          goto exit;
      }
    } else {
      GST_ERROR_OBJECT (rtkhse, "fmt convert in_buf->ori_width is not 4 alignment in_buf->ori_width = %d",in_buf->ori_width);
      ret = GST_FLOW_ERROR;
    }
  }
  else if (in_buf->format == GST_VIDEO_FORMAT_NV24 && out_buf->format == HSE_FMT_YUV420SP) {
    struct hse_cmd_picture_copy hse_data_copy = {0};
    struct hse_cmd_stretch stretch  = {0};

    if(in_buf->ori_width % 4 == 0) {
      GST_LOG_OBJECT (rtkhse, "fmt convert in_buf->ori_width is 4 alignment in_buf->ori_width = %d",in_buf->ori_width);
      if(in_buf->ori_width > 2048) {
        //hw limitation
        GST_ERROR_OBJECT (rtkhse, "fmt convert NV24 overspec width %d > 2048",in_buf->ori_width);
        ret = GST_FLOW_ERROR;
      } else {
        hse_data_copy.width = in_buf->ori_width;
        hse_data_copy.height = in_buf->ori_height;
        hse_data_copy.dst_pitch = out_buf->width;
        hse_data_copy.dst_va = out_buf->va;
        hse_data_copy.dst_offset = out_buf->offset;
        hse_data_copy.src_pitch = in_buf->width;
        hse_data_copy.src_va = in_buf->va;
        hse_data_copy.src_offset = in_buf->offset;
        hse_data_copy.flags=0;
        ret = ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_PICTURE_COPY, &hse_data_copy);
        if (ret < 0) {
            GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_PICTURE_COPY fail! Error = (%s)\n", strerror(errno));
            ret = GST_FLOW_ERROR;
            goto exit;
        }

        stretch.src_width = in_buf->ori_width;
        stretch.src_height = in_buf->ori_height;
        stretch.src_pitch = in_buf->width << 1;
        stretch.src_va = in_buf->va;
        stretch.src_offset = in_buf->offset + in_buf->width * in_buf->height;
        stretch.dst_width = out_buf->ori_width >> 1;
        stretch.dst_height = out_buf->ori_height >> 1;
        stretch.dst_pitch = out_buf->width;
        stretch.dst_va = out_buf->va;
        stretch.dst_offset = out_buf->offset + out_buf->width * out_buf->height;
        stretch.colorSel = COLOR_SEL_CBCR;

        ret = ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_STRETCH, &stretch);
        if (ret < 0) {
            GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_STRETCH fail! Error = (%s)\n", strerror(errno));
            ret = GST_FLOW_ERROR;
            goto exit;
        }
      }
    } else{
      GST_ERROR_OBJECT (rtkhse, "fmt convert in_buf->ori_width is not 4 alignment in_buf->ori_width = %d",in_buf->ori_width);
      ret = GST_FLOW_ERROR;
    }
  } else {
    if(ioctl(rtkhse->hsefd, HSE_IOCTL_CMD_FMT_CONVERT, &fmt_cvt)) {
      GST_ERROR_OBJECT (rtkhse, "HSE_IOCTL_CMD_FMT_CONVERT fail! Error = (%s)\n", strerror(errno));
      ret = GST_FLOW_ERROR;
    }
  }

exit:
  return ret;
}

static GstFlowReturn
gst_rtk_hse_transform_buffer (GstRtkHse *rtkhse, hsebuf *in_buf, hsebuf *out_buf, gint transform, GstVideoMeta *in_meta, GstVideoMeta *out_meta)
{
  GstMemory *rotate_mem,*tmp_mem;
  GstAllocator *dma_allocator;
  hsebuf scale_buf = {0}, rotate_buf = {0},  tmp_buf = {0};
  gint rotate_method = 0;
  gint padding_width = 0, padding_height = 0;
  gint ret = GST_FLOW_OK;

  if(transform & RTK_ROTATE_MASK) {
    if(transform & RTK_SCALE_MASK) {
      switch (rtkhse->configuring_method) {
        case GST_VIDEO_ROTATE_METHOD_90R:
          rotate_method = 2;
          scale_buf.width = out_buf->height;
          scale_buf.height = out_buf->width;
          scale_buf.ori_width = out_buf->ori_height;
          scale_buf.ori_height = out_buf->ori_width;
          padding_width = out_buf->width - out_buf->ori_width;
          padding_height = 0;
          break;
        case GST_VIDEO_ROTATE_METHOD_90L:
          rotate_method = 0;
          scale_buf.width = out_buf->height;
          scale_buf.height = out_buf->width;
          scale_buf.ori_width = out_buf->ori_height;
          scale_buf.ori_height = out_buf->ori_width;
          padding_width = 0;
          padding_height = out_buf->height - out_buf->ori_height;
          break;
        case GST_VIDEO_ROTATE_METHOD_180:
          rotate_method = 1;
          scale_buf.width = out_buf->width;
          scale_buf.height = out_buf->height;
          scale_buf.ori_width = out_buf->ori_width;
          scale_buf.ori_height = out_buf->ori_height;
          padding_width = out_buf->width - out_buf->ori_width;
          padding_height = out_buf->height - out_buf->ori_height;
          break;
        default:
          break;
      }
      scale_buf.offset = 0;
      scale_buf.format = in_buf->format;
      rotate_buf.width = out_buf->width;
      rotate_buf.height = out_buf->height;
      rotate_buf.ori_width = out_buf->ori_width;
      rotate_buf.ori_height = out_buf->ori_height;
    } else {
      switch (rtkhse->configuring_method) {
        case GST_VIDEO_ROTATE_METHOD_90R:
          rotate_method = 2;
          rotate_buf.width = in_buf->height;
          rotate_buf.height = in_buf->width;
          rotate_buf.ori_width = in_buf->ori_height;
          rotate_buf.ori_height = in_buf->ori_width;
          padding_width = in_buf->height - in_buf->ori_height;
          padding_height = 0;
          break;
        case GST_VIDEO_ROTATE_METHOD_90L:
          rotate_method = 0;
          rotate_buf.width = in_buf->height;
          rotate_buf.height = in_buf->width;
          rotate_buf.ori_width = in_buf->ori_height;
          rotate_buf.ori_height = in_buf->ori_width;
          padding_width = 0;
          padding_height = in_buf->width - in_buf->ori_width;
          break;
        case GST_VIDEO_ROTATE_METHOD_180:
          rotate_method = 1;
          rotate_buf.width = in_buf->width;
          rotate_buf.height = in_buf->height;
          rotate_buf.ori_width = in_buf->ori_width;
          rotate_buf.ori_height = in_buf->ori_height;
          padding_width = in_buf->width - in_buf->ori_width;
          padding_height = in_buf->height - in_buf->ori_height;
          break;
        default:
          break;
      }
    }
    rotate_buf.offset = 0;
    rotate_buf.format = in_buf->format;
  }
  GST_LOG_OBJECT (rtkhse, "padding_width %d padding_height %d",padding_width,padding_height);
  if(transform == RTK_SCALE_MASK) {
    GST_LOG_OBJECT (rtkhse, "transform == RTK_SCALE_MASK");
    ret = gst_rtk_hse_scale(rtkhse, in_buf, out_buf);
  } else if(transform == RTK_ROTATE_MASK) {
    GST_LOG_OBJECT (rtkhse, "transform == RTK_ROTATE_MASK");
    dma_allocator = gst_rtk_dma_allocator_new ();
    rotate_mem = gst_allocator_alloc(dma_allocator, rotate_buf.width * rotate_buf.height * 1.5 + padding_width + padding_height * out_buf->width, NULL);
    gst_object_unref(dma_allocator);
    rotate_buf.fd = gst_dmabuf_memory_get_fd(rotate_mem);
    if (rotate_buf.fd < 0) {
      GST_ERROR_OBJECT(rtkhse, "could not obtain rotate_out DMABUF FD");
      gst_memory_unref(rotate_mem);
      ret = GST_FLOW_ERROR;
      goto exit;
    }

    hse_device_import_dmabuf(rtkhse, rotate_buf.fd, &rotate_buf.va);
    ret = gst_rtk_hse_rotate (rtkhse, in_buf, &rotate_buf, rotate_method);
    if(ret == GST_FLOW_OK)
      ret = gst_rtk_hse_align_padding (rtkhse, &rotate_buf, out_buf, padding_width, padding_height);
    hse_device_release_mem(rtkhse->hsefd, rotate_buf.va);
    gst_memory_unref(rotate_mem);
  } else if(transform == RTK_FORMAT_CONVERT_MASK) {
    GST_LOG_OBJECT (rtkhse, "transform == RTK_FORMAT_CONVERT_MASK");
    ret = gst_rtk_hse_fmt_convert(rtkhse, in_buf, out_buf);
  } else if(transform == (RTK_SCALE_MASK | RTK_ROTATE_MASK)) {
    GST_LOG_OBJECT (rtkhse, "RTK_SCALE_MASK | RTK_ROTATE_MASK");
    dma_allocator = gst_rtk_dma_allocator_new ();
    rotate_mem = gst_allocator_alloc(dma_allocator, out_buf->width * out_buf->height * 1.5 + padding_width + padding_height * out_buf->width, NULL);
    tmp_mem    = gst_allocator_alloc(dma_allocator, out_buf->width * out_buf->height * 1.5, NULL);
    gst_object_unref(dma_allocator);
    rotate_buf.fd = gst_dmabuf_memory_get_fd(rotate_mem);
    scale_buf.fd = gst_dmabuf_memory_get_fd(tmp_mem);
    if (rotate_buf.fd < 0 || scale_buf.fd < 0) {
      GST_ERROR_OBJECT(rtkhse, "could not obtain DMABUF FD");
      gst_memory_unref(rotate_mem);
      gst_memory_unref(tmp_mem);
      ret = GST_FLOW_ERROR;
      goto exit;
    }

    hse_device_import_dmabuf(rtkhse, rotate_buf.fd, &rotate_buf.va);
    hse_device_import_dmabuf(rtkhse, scale_buf.fd, &scale_buf.va);
    ret = gst_rtk_hse_scale (rtkhse, in_buf, &scale_buf);
    if(ret == GST_FLOW_OK) {
      ret = gst_rtk_hse_rotate (rtkhse, &scale_buf, &rotate_buf, rotate_method);
      if(ret == GST_FLOW_OK)
        ret = gst_rtk_hse_align_padding (rtkhse, &rotate_buf, out_buf, padding_width, padding_height);
    }
    hse_device_release_mem(rtkhse->hsefd, rotate_buf.va);
    hse_device_release_mem(rtkhse->hsefd, scale_buf.va);
    gst_memory_unref(rotate_mem);
    gst_memory_unref(tmp_mem);
  } else if(transform == (RTK_ROTATE_MASK | RTK_FORMAT_CONVERT_MASK)) {
    GST_LOG_OBJECT (rtkhse, "transform == RTK_ROTATE_MASK | RTK_FORMAT_CONVERT_MASK");
    dma_allocator = gst_rtk_dma_allocator_new ();
    rotate_mem = gst_allocator_alloc(dma_allocator, out_buf->width * out_buf->height * 1.5 + padding_width + padding_height * out_buf->width, NULL);
    tmp_mem    = gst_allocator_alloc(dma_allocator, out_buf->width * out_buf->height * 1.5, NULL);
    gst_object_unref(dma_allocator);
    rotate_buf.fd = gst_dmabuf_memory_get_fd(rotate_mem);
    tmp_buf.fd = gst_dmabuf_memory_get_fd(tmp_mem);
    tmp_buf.width = out_buf->width;
    tmp_buf.height = out_buf->height;
    tmp_buf.ori_width = out_buf->ori_width;
    tmp_buf.ori_height = out_buf->ori_height;
    tmp_buf.offset = 0;
    tmp_buf.format = rotate_buf.format;

    if (rotate_buf.fd < 0 || tmp_buf.fd < 0) {
      GST_ERROR_OBJECT(rtkhse, "could not obtain DMABUF FD");
      gst_memory_unref(rotate_mem);
      gst_memory_unref(tmp_mem);
      ret = GST_FLOW_ERROR;
      goto exit;
    }

    hse_device_import_dmabuf(rtkhse, rotate_buf.fd, &rotate_buf.va);
    hse_device_import_dmabuf(rtkhse, tmp_buf.fd, &tmp_buf.va);
    ret = gst_rtk_hse_rotate (rtkhse, in_buf, &rotate_buf, rotate_method);
    if(ret == GST_FLOW_OK) {
      gst_rtk_hse_align_padding (rtkhse, &rotate_buf, &tmp_buf, padding_width, padding_height);
      ret = gst_rtk_hse_fmt_convert(rtkhse, &tmp_buf, out_buf);
    }
    hse_device_release_mem(rtkhse->hsefd, rotate_buf.va);
    hse_device_release_mem(rtkhse->hsefd, tmp_buf.va);
    gst_memory_unref(rotate_mem);
    gst_memory_unref(tmp_mem);
  } else if(transform == (RTK_SCALE_MASK | RTK_FORMAT_CONVERT_MASK)) {
    GST_LOG_OBJECT (rtkhse, "transform == RTK_SCALE_MASK | RTK_FORMAT_CONVERT_MASK");
    dma_allocator = gst_rtk_dma_allocator_new ();
    if(in_buf->format == HSE_FMT_YUV420SP)
      tmp_mem    = gst_allocator_alloc(dma_allocator, out_buf->width * out_buf->height * 1.5, NULL);
    else if(in_buf->format == HSE_FMT_YUV422SP)
      tmp_mem    = gst_allocator_alloc(dma_allocator, out_buf->width * out_buf->height * 2, NULL);
    else {
      GST_ERROR_OBJECT(rtkhse, "unsupported input format %d",in_buf->format);
      ret = GST_FLOW_ERROR;
      goto exit;
    }

    gst_object_unref(dma_allocator);
    scale_buf.fd = gst_dmabuf_memory_get_fd(tmp_mem);
    if (scale_buf.fd < 0) {
      GST_ERROR_OBJECT(rtkhse, "could not obtain DMABUF FD");
      gst_memory_unref(tmp_mem);
      ret = GST_FLOW_ERROR;
      goto exit;
    }

    scale_buf.width = out_buf->width;
    scale_buf.height = out_buf->height;
    scale_buf.ori_width = out_buf->ori_width;
    scale_buf.ori_height = out_buf->ori_height;
    scale_buf.offset = 0;
    scale_buf.format = in_buf->format;

    hse_device_import_dmabuf(rtkhse, scale_buf.fd, &scale_buf.va);
    ret = gst_rtk_hse_scale (rtkhse, in_buf, &scale_buf);
    if(ret == GST_FLOW_OK)
      ret = gst_rtk_hse_fmt_convert(rtkhse, &scale_buf, out_buf);
    hse_device_release_mem(rtkhse->hsefd, scale_buf.va);
    gst_memory_unref(tmp_mem);
  } else if(transform == (RTK_SCALE_MASK | RTK_ROTATE_MASK | RTK_FORMAT_CONVERT_MASK)) {
    GST_LOG_OBJECT (rtkhse, "transform == RTK_SCALE_MASK | RTK_ROTATE_MASK | RTK_FORMAT_CONVERT_MASK");
    dma_allocator = gst_rtk_dma_allocator_new ();
    rotate_mem = gst_allocator_alloc(dma_allocator, out_buf->width * out_buf->height * 1.5 + padding_width + padding_height * out_buf->width, NULL);
    tmp_mem    = gst_allocator_alloc(dma_allocator, out_buf->width * out_buf->height * 1.5, NULL);
    gst_object_unref(dma_allocator);
    rotate_buf.fd = gst_dmabuf_memory_get_fd(rotate_mem);
    scale_buf.fd = gst_dmabuf_memory_get_fd(tmp_mem);
    if (rotate_buf.fd < 0 || scale_buf.fd < 0) {
      GST_ERROR_OBJECT(rtkhse, "could not obtain DMABUF FD");
      gst_memory_unref(rotate_mem);
      gst_memory_unref(tmp_mem);
      ret = GST_FLOW_ERROR;
      goto exit;
    }

    hse_device_import_dmabuf(rtkhse, rotate_buf.fd, &rotate_buf.va);
    hse_device_import_dmabuf(rtkhse, scale_buf.fd, &scale_buf.va);
    ret = gst_rtk_hse_scale (rtkhse, in_buf, &scale_buf);
    if(ret == GST_FLOW_OK) {
      ret = gst_rtk_hse_rotate (rtkhse, &scale_buf, &rotate_buf, rotate_method);
      if(ret == GST_FLOW_OK) {
        scale_buf.width = out_buf->width;
        scale_buf.height = out_buf->height;
        scale_buf.ori_width = out_buf->ori_width;
        scale_buf.ori_height = out_buf->ori_height;
        ret = gst_rtk_hse_align_padding (rtkhse, &rotate_buf, &scale_buf, padding_width, padding_height);
        if(ret == GST_FLOW_OK)
          ret = gst_rtk_hse_fmt_convert(rtkhse, &scale_buf, out_buf);
      }
    }
    hse_device_release_mem(rtkhse->hsefd, rotate_buf.va);
    hse_device_release_mem(rtkhse->hsefd, scale_buf.va);
    gst_memory_unref(rotate_mem);
    gst_memory_unref(tmp_mem);
  }

exit:
  return ret;
}

static GstFlowReturn
gst_rtk_hse_transform (GstBaseTransform * base, GstBuffer * inbuffer,
    GstBuffer * outbuffer)
{
  GstRtkHse *rtkhse = GST_RTK_HSE_CAST (base);
  GstVideoFrame inframe = { 0, }, outframe = { 0, };
  GstVideoFormat in_format, out_format;
  GstMemory *in_mem,*out_mem,*fmtcvt_mem;
  GstAllocator *dma_allocator;
  GstMapInfo mapinfo;
  struct ve_frame_info *veframe_info = NULL;
  hsebuf in_buf = {0}, out_buf = {0}, fmtcvt_buf = {0};
  gint transform = 0;
  gdouble format_size_factor = 1;
  gsize in_size, in_offset, in_maxsize;
  gsize out_size, out_offset, out_maxsize;
  gboolean is_dmabuf_mem;
  gint ret = GST_FLOW_OK;

  if(rtkhse->hsefd == -1) {
    GST_ERROR_OBJECT (rtkhse, "Failed to get hse fd");
    return GST_FLOW_ERROR;
  }

  // GAP buffer, nothing to do. Propagate output buffer downstream.
  if (gst_buffer_get_size (outbuffer) == 0 &&
      GST_BUFFER_FLAG_IS_SET (outbuffer, GST_BUFFER_FLAG_GAP))
    return GST_FLOW_OK;

  if (!gst_video_frame_map (&inframe, rtkhse->ininfo, inbuffer,
          GST_MAP_READ | GST_VIDEO_FRAME_MAP_FLAG_NO_REF)) {
    GST_ERROR_OBJECT (rtkhse, "Failed to map input buffer!");
    return GST_FLOW_OK;
  }

  if (!gst_video_frame_map (&outframe, rtkhse->outinfo, outbuffer,
          GST_MAP_READWRITE | GST_VIDEO_FRAME_MAP_FLAG_NO_REF)) {
    GST_ERROR_OBJECT (rtkhse, "Failed to map output buffer!");
    gst_video_frame_unmap (&inframe);
    return GST_FLOW_OK;
  }

  in_buf.ori_width = GST_VIDEO_FRAME_COMP_WIDTH (&inframe, 0);
  out_buf.ori_width = GST_VIDEO_FRAME_COMP_WIDTH (&outframe, 0);

  in_buf.ori_height = GST_VIDEO_FRAME_COMP_HEIGHT (&inframe, 0);
  out_buf.ori_height = GST_VIDEO_FRAME_COMP_HEIGHT (&outframe, 0);

  in_format = GST_VIDEO_FRAME_FORMAT(&inframe);
  out_format = GST_VIDEO_FRAME_FORMAT(&outframe);

  in_mem = gst_buffer_peek_memory (inbuffer, 0);
  out_mem = gst_buffer_peek_memory (outbuffer, 0);

  is_dmabuf_mem = gst_is_dmabuf_memory(in_mem);
  if (is_dmabuf_mem)
    in_buf.fd = gst_dmabuf_memory_get_fd (in_mem);
  else {
    GST_ERROR_OBJECT(rtkhse, "in_mem without DMABUF memory currently are not supported");
    ret = GST_FLOW_ERROR;
    goto exit;
  }

  is_dmabuf_mem = gst_is_dmabuf_memory(out_mem);
  if (is_dmabuf_mem)
    out_buf.fd = gst_dmabuf_memory_get_fd (out_mem);
  else {
    GST_ERROR_OBJECT(rtkhse, "out_mem without DMABUF memory currently are not supported");
    ret = GST_FLOW_ERROR;
    goto exit;
  }

  GstVideoMeta *in_meta;
  in_meta = gst_buffer_get_video_meta (inbuffer);

  if(in_meta)
  {
    in_buf.width = in_buf.ori_width + in_meta->alignment.padding_right + in_meta->alignment.padding_left;
    in_buf.height = in_buf.ori_height + in_meta->alignment.padding_top + in_meta->alignment.padding_bottom;
  }
  else
  {
    GST_INFO_OBJECT(rtkhse, "inbuffer no video meta found");
    ret = GST_FLOW_ERROR;
    goto exit;
  }

  GstVideoMeta *out_meta;
  out_meta = gst_buffer_get_video_meta (outbuffer);
  gst_video_meta_set_alignment (out_meta, rtkhse->out_video_align);
  out_buf.width = out_buf.ori_width + out_meta->alignment.padding_right + out_meta->alignment.padding_left;
  out_buf.height = out_buf.ori_height + out_meta->alignment.padding_top + out_meta->alignment.padding_bottom;

  in_size = gst_memory_get_sizes (in_mem, &in_offset, &in_maxsize);
  out_size = gst_memory_get_sizes (out_mem, &out_offset, &out_maxsize);

  in_buf.offset = (uint32_t)in_offset;
  out_buf.offset = (uint32_t)out_offset;
  in_buf.format = gst_rtk_hse_format(rtkhse,in_format);
  out_buf.format = gst_rtk_hse_format(rtkhse,out_format);

  GST_LOG_OBJECT (rtkhse, "in_buf.ori_width %u in_buf.ori_height %u",in_buf.ori_width,in_buf.ori_height);
  GST_LOG_OBJECT (rtkhse, "in_buf.width %u in_buf.height %u",in_buf.width,in_buf.height);
  GST_LOG_OBJECT (rtkhse, "out_buf.ori_width %u out_buf.ori_height %u",out_buf.ori_width,out_buf.ori_height);
  GST_LOG_OBJECT (rtkhse, "out_buf.width %u out_buf.height %u",out_buf.width,out_buf.height);
  GST_LOG_OBJECT (rtkhse, "in_size %zu in_offset %zu in_maxsize %zu",in_size,in_offset,in_maxsize);
  GST_LOG_OBJECT (rtkhse, "out_size %zu out_offset %zu out_maxsize %zu",out_size,out_offset,out_maxsize);
  GST_LOG_OBJECT (rtkhse, "in_buf.format %d out_buf.format %d",in_buf.format,out_buf.format);

  if(in_format == GST_VIDEO_FORMAT_NV12)
    format_size_factor = 1.5;
  if(in_format == GST_VIDEO_FORMAT_NV16)
    format_size_factor = 2;
  else if(in_format == GST_VIDEO_FORMAT_NV24 || in_format == GST_VIDEO_FORMAT_RGB)
    format_size_factor = 3;

  if(in_size > in_buf.width * in_buf.height * format_size_factor) {
    GST_LOG_OBJECT (rtkhse, "in_size not metch in_buf.width * in_buf.height * format_size_factor");
    if(in_size == ROUNDUP32(in_buf.width) * ROUNDUP32(in_buf.height) * format_size_factor) {
      GST_LOG_OBJECT (rtkhse, "in_size metch ROUNDUP32(in_buf.width) * ROUNDUP32(in_buf.height) * format_size_factor");
      in_buf.width = ROUNDUP32(in_buf.width);
      in_buf.height = ROUNDUP32(in_buf.height);
      GST_LOG_OBJECT (rtkhse, "update in_buf.width %d in_buf.height %d",in_buf.width,in_buf.height);
    }
  }

  if(in_maxsize - in_size >= DEFAULT_OFFSET) {
    gst_memory_resize (in_mem, 0, in_maxsize);
    gst_memory_map (in_mem, &mapinfo, GST_MAP_READ);
    veframe_info = (struct ve_frame_info *)(mapinfo.data + in_maxsize - DEFAULT_OFFSET);
    if(veframe_info->yuvs.bufBitDepth == 10){
      gst_printerr ("gstbuffers rotation with 10bit format currently are not supported\n");
      gst_memory_unmap (in_mem, &mapinfo);
      ret = GST_FLOW_ERROR;
      goto exit;
    }
    gst_memory_unmap (in_mem, &mapinfo);
    gst_memory_resize (in_mem, 0, in_size);
  }

  if(rtkhse->ininfo->width != rtkhse->outinfo->width && rtkhse->outinfo->width != rtkhse->ininfo->height){
    transform |= RTK_SCALE_MASK;
  }
  if(rtkhse->ininfo->height != rtkhse->outinfo->height && rtkhse->outinfo->height != rtkhse->ininfo->width) {
    transform |= RTK_SCALE_MASK;
  }

  if(rtkhse->configuring_method != (GstVideoOrientationMethod) GST_VIDEO_ROTATE_METHOD_NONE) {
    transform |= RTK_ROTATE_MASK;
  }

  if(rtkhse->ininfo->finfo->format != rtkhse->outinfo->finfo->format)
    transform |= RTK_FORMAT_CONVERT_MASK;

  GST_LOG_OBJECT (rtkhse, "transform %d",transform);

  hse_device_import_dmabuf(rtkhse, in_buf.fd, &in_buf.va);
  hse_device_import_dmabuf(rtkhse, out_buf.fd, &out_buf.va);

  if( ((in_buf.format == GST_VIDEO_FORMAT_NV24) && (transform & RTK_SCALE_MASK)) || ((in_buf.format == HSE_FMT_RGB888) && (transform & RTK_SCALE_MASK))
      || ((in_buf.format == HSE_FMT_RGB888) && (out_buf.format == HSE_FMT_ARGB || out_buf.format == HSE_FMT_BGRA))
      || ((in_buf.format != HSE_FMT_YUV420SP) && (transform & RTK_ROTATE_MASK)) ) {
    GST_LOG_OBJECT (rtkhse, "in_buf needs to convert nv12");
    if(out_buf.format == HSE_FMT_YUV420SP)
      transform &= ~RTK_FORMAT_CONVERT_MASK;
    dma_allocator = gst_rtk_dma_allocator_new ();
    fmtcvt_mem = gst_allocator_alloc(dma_allocator, in_buf.width  * in_buf.height  * 1.5, NULL);
    gst_object_unref(dma_allocator);

    fmtcvt_buf.fd = gst_dmabuf_memory_get_fd(fmtcvt_mem);
    fmtcvt_buf.width = in_buf.width;
    fmtcvt_buf.height = in_buf.height;
    fmtcvt_buf.ori_width = in_buf.ori_width;
    fmtcvt_buf.ori_height = in_buf.ori_height;
    fmtcvt_buf.offset = 0;
    fmtcvt_buf.format = HSE_FMT_YUV420SP;

    if (fmtcvt_buf.fd < 0) {
      GST_ERROR_OBJECT(rtkhse, "could not obtain DMABUF FD");
      gst_memory_unref(fmtcvt_mem);
      ret = GST_FLOW_ERROR;
      goto exit;
    }

    hse_device_import_dmabuf(rtkhse, fmtcvt_buf.fd, &fmtcvt_buf.va);
    ret = gst_rtk_hse_fmt_convert(rtkhse, &in_buf, &fmtcvt_buf);
    if(ret == GST_FLOW_ERROR) goto exit;
    ret = gst_rtk_hse_transform_buffer(rtkhse, &fmtcvt_buf, &out_buf, transform, in_meta, out_meta);
    hse_device_release_mem(rtkhse->hsefd, fmtcvt_buf.va);
    gst_memory_unref(fmtcvt_mem);
  } else
    ret = gst_rtk_hse_transform_buffer(rtkhse, &in_buf, &out_buf, transform, in_meta, out_meta);

  if(ret == GST_FLOW_ERROR) goto exit;

  if(out_buf.format == HSE_FMT_YUV420SP)
  {
    GST_LOG_OBJECT (rtkhse, "prepare data offset");
    struct rheap_ioc_phy_info data;
    data.handle = out_buf.fd;
    data.addr   = 0;
    data.len    = 0;
    int rtk_fd = open("/dev/rtk_heap", O_RDWR | O_CLOEXEC);
    if (ioctl(rtk_fd, RHEAP_GET_PHYINFO, &data) < 0) {
        GST_ERROR_OBJECT(rtkhse, "RHEAP_GET_PHYINFO Error = %s\n", strerror(errno));
        return GST_FLOW_ERROR;
    }

    gst_memory_map (out_mem, &mapinfo, GST_MAP_WRITE);
    veframe_info = (struct ve_frame_info *)(mapinfo.data + out_maxsize - DEFAULT_OFFSET);
    memset(veframe_info, 0, sizeof(struct ve_frame_info));

    veframe_info->yuvs.lumaOffTblAddr = 0xffffffff;
    veframe_info->yuvs.chromaOffTblAddr = 0xffffffff;
    veframe_info->yuvs.lumaOffTblAddrR = 0xffffffff;
    veframe_info->yuvs.chromaOffTblAddrR = 0xffffffff;
    veframe_info->yuvs.bufBitDepth = 8;
    veframe_info->yuvs.matrix_coefficients = 1;
    veframe_info->yuvs.tch_hdr_metadata[0] = -1;

    veframe_info->yuvs.Y_addr_Right = 0xffffffff;
    veframe_info->yuvs.U_addr_Right = 0xffffffff;
    veframe_info->yuvs.pLock_Right = 0xffffffff;
    veframe_info->rtk_meta_buf_id =  0x52544B6D; //RTKm

    veframe_info->yuvs.width = out_buf.ori_width;
    veframe_info->yuvs.height = out_buf.ori_height;
    veframe_info->yuvs.Y_addr = data.addr + out_buf.offset;
    veframe_info->yuvs.U_addr = data.addr + out_buf.offset + out_buf.width * out_buf.height;
    veframe_info->yuvs.Y_pitch = out_buf.width;
    veframe_info->yuvs.C_pitch = out_buf.width;
    veframe_info->yuvs.slice_height = out_buf.height;

    veframe_info->yuvs.mode = CONSECUTIVE_FRAME;
    close(rtk_fd);
    gst_memory_unmap (out_mem, &mapinfo);
  }

exit:
  hse_device_release_mem(rtkhse->hsefd, in_buf.va);
  hse_device_release_mem(rtkhse->hsefd, out_buf.va);
  gst_video_frame_unmap (&outframe);
  gst_video_frame_unmap (&inframe);

  return ret;
}

static void
gst_rtk_hse_set_rotate (GstRtkHse * rtkhse, GstVideoOrientationMethod method, gboolean from_tag)
{
  GST_OBJECT_LOCK (rtkhse);

  if (from_tag){
    if (method == GST_VIDEO_ORIENTATION_HORIZ || method == GST_VIDEO_ORIENTATION_VERT ||
      method == GST_VIDEO_ORIENTATION_UL_LR || method == GST_VIDEO_ORIENTATION_UR_LL) {
      GST_WARNING_OBJECT (rtkhse, "unsupported flip orientation");
      GST_OBJECT_UNLOCK (rtkhse);
      return;
    } else if (method == GST_VIDEO_ORIENTATION_CUSTOM) {
      GST_WARNING_OBJECT (rtkhse, "unsupported custom orientation");
      GST_OBJECT_UNLOCK (rtkhse);
      return;
    }
    rtkhse->tag_method = method;
  }
  else
    rtkhse->rotate = method;

  /* Get the new method */
  if (rtkhse->rotate == (GstVideoOrientationMethod) GST_VIDEO_ROTATE_METHOD_AUTO)
    method = rtkhse->tag_method;
  else
    method = rtkhse->rotate;

  if (method != rtkhse->configuring_method) {
    GEnumValue *active_method_enum, *rotate_enum;
    GstBaseTransform *base = GST_BASE_TRANSFORM (rtkhse);
    GEnumClass *enum_class =
        g_type_class_ref (GST_TYPE_VIDEO_ORIENTATION_METHOD);
    active_method_enum =
        g_enum_get_value (enum_class, rtkhse->configuring_method);
    rotate_enum = g_enum_get_value (enum_class, method);
    GST_LOG_OBJECT (rtkhse, "Changing rotate method from %s to %s",
        active_method_enum ? active_method_enum->value_nick : "(nil)",
        rotate_enum ? rotate_enum->value_nick : "(nil)");

    rtkhse->configuring_method = method;

    GST_OBJECT_UNLOCK (rtkhse);

    gst_base_transform_set_passthrough (base,
        method == (GstVideoOrientationMethod) GST_VIDEO_ROTATE_METHOD_NONE);

    gst_base_transform_reconfigure_src (base);
  } else {
    GST_OBJECT_UNLOCK (rtkhse);
  }
}

static gboolean
gst_rtk_hse_sink_event (GstBaseTransform * base, GstEvent * event)
{
  GstRtkHse *rtkhse = GST_RTK_HSE_CAST (base);
  GstTagList *taglist;
  GstVideoOrientationMethod method;
  gboolean ret;

  GST_DEBUG_OBJECT (rtkhse, "handling %s event", GST_EVENT_TYPE_NAME (event));

  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_TAG:
      gst_event_parse_tag (event, &taglist);

      if (gst_video_orientation_from_tag (taglist, &method)) {
        if (gst_tag_list_get_scope (taglist) == GST_TAG_SCOPE_STREAM) {
          rtkhse->got_orientation_stream_tag = TRUE;
        } else if (gst_tag_list_get_scope (taglist) == GST_TAG_SCOPE_GLOBAL) {
          rtkhse->global_tag_method = method;
        }

        if (gst_tag_list_get_scope (taglist) == GST_TAG_SCOPE_GLOBAL
            && rtkhse->got_orientation_stream_tag) {
          GST_DEBUG_OBJECT (rtkhse,
              "ignoring global tags as we received stream specific ones: %"
              GST_PTR_FORMAT, taglist);
        } else {
          gst_rtk_hse_set_rotate (rtkhse, method, TRUE);
        }

        if (rtkhse->rotate == GST_VIDEO_ORIENTATION_AUTO) {
          /* Update the orientation tag as we rotate the video accordingly.
           * The event (and so the tag list) can be shared so always copy both. */
          taglist = gst_tag_list_copy (taglist);

          gst_tag_list_add (taglist, GST_TAG_MERGE_REPLACE,
              "image-orientation", "rotate-0", NULL);

          gst_event_unref (event);
          event = gst_event_new_tag (taglist);
        }
      } else {
        // no orientation in tag
        if (gst_tag_list_get_scope (taglist) == GST_TAG_SCOPE_STREAM) {
          GST_DEBUG_OBJECT (rtkhse,
              "stream tag does not contain orientation, restore the global one: %d",
              rtkhse->global_tag_method);
              rtkhse->got_orientation_stream_tag = FALSE;
          gst_rtk_hse_set_rotate (rtkhse, rtkhse->global_tag_method, TRUE);
        } else if (gst_tag_list_get_scope (taglist) == GST_TAG_SCOPE_GLOBAL) {
          rtkhse->global_tag_method = GST_VIDEO_ORIENTATION_IDENTITY;

          if (!rtkhse->got_orientation_stream_tag) {
            GST_DEBUG_OBJECT (rtkhse,
                "global taglist withtout orientation, set to identity");
            gst_rtk_hse_set_rotate (rtkhse, GST_VIDEO_ORIENTATION_IDENTITY,
                TRUE);
          } else {
            // keep using the orientation from the stream tag
          }
        }
      }

      break;
    case GST_EVENT_STREAM_START:
    {
      const gchar *stream_id;

      gst_event_parse_stream_start (event, &stream_id);
      if (g_strcmp0 (stream_id, rtkhse->stream_id) != 0) {
        GST_DEBUG_OBJECT (rtkhse, "new stream, reset orientation from tags");
        rtkhse->got_orientation_stream_tag = FALSE;
        rtkhse->global_tag_method = GST_VIDEO_ORIENTATION_IDENTITY;
        gst_rtk_hse_set_rotate (rtkhse, GST_VIDEO_ORIENTATION_IDENTITY, TRUE);

        g_clear_pointer (&rtkhse->stream_id, g_free);
        rtkhse->stream_id = g_strdup (stream_id);
      }
    }
      break;
    default:
      break;
  }

  ret = GST_BASE_TRANSFORM_CLASS (parent_class)->sink_event (GST_BASE_TRANSFORM (rtkhse), event);

  return ret;
}

static void
gst_rtk_hse_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec)
{
  GstRtkHse *rtkhse = GST_RTK_HSE (object);

  GST_RTK_HSE_LOCK (rtkhse);

  switch (prop_id) {
    case PROP_ROTATE:
      gst_rtk_hse_set_rotate (rtkhse, g_value_get_enum (value), FALSE);
      break;
    case PROP_SCALE:
    {
      guint width = 0, height = 0;

      g_return_if_fail (gst_value_array_get_size (value) == 2);

      width = g_value_get_int (gst_value_array_get_value (value, 0));
      height = g_value_get_int (gst_value_array_get_value (value, 1));

      if ((width == 0) || (height == 0)) {
        GST_WARNING_OBJECT (rtkhse, "Invalid scale dimensions!");
        break;
      }

      rtkhse->scale.w = width;
      rtkhse->scale.h = height;
      break;
    }
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }

  GST_RTK_HSE_UNLOCK (rtkhse);
}

static void
gst_rtk_hse_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec)
{
  GstRtkHse *rtkhse = GST_RTK_HSE (object);

  GST_RTK_HSE_LOCK (rtkhse);

  switch (prop_id) {
    case PROP_ROTATE:
      g_value_set_enum (value, rtkhse->rotate);
      break;
    case PROP_SCALE:
    {
      GValue val = G_VALUE_INIT;
      g_value_init (&val, G_TYPE_INT);

      g_value_set_int (&val, rtkhse->scale.w);
      gst_value_array_append_value (value, &val);

      g_value_set_int (&val, rtkhse->scale.h);
      gst_value_array_append_value (value, &val);
      break;
    }
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }

  GST_RTK_HSE_UNLOCK (rtkhse);
}

static void
gst_rtk_hse_finalize (GObject * object)
{
  GstRtkHse *rtkhse = GST_RTK_HSE (object);

  g_clear_pointer (&rtkhse->stream_id, g_free);

  if (rtkhse->ininfo != NULL)
    gst_video_info_free (rtkhse->ininfo);

  if (rtkhse->outinfo != NULL)
    gst_video_info_free (rtkhse->outinfo);

  if (rtkhse->outpool != NULL)
    gst_object_unref (rtkhse->outpool);

  if(rtkhse->hsefd != -1)
    close(rtkhse->hsefd);

  g_mutex_clear (&(rtkhse)->lock);

  G_OBJECT_CLASS (parent_class)->finalize (G_OBJECT (rtkhse));
}

static GstStateChangeReturn
gst_rtk_hse_change_state (GstElement * element, GstStateChange transition)
{
  GstRtkHse *rtkhse = GST_RTK_HSE (element);
  GstStateChangeReturn result;

  result = GST_ELEMENT_CLASS (parent_class)->change_state (element, transition);

  switch (transition) {
    case GST_STATE_CHANGE_PAUSED_TO_READY:
      g_clear_pointer (&rtkhse->stream_id, g_free);
      break;
    default:
      break;
  }

  return result;
}

static void
gst_rtk_hse_class_init (GstRtkHseClass * klass)
{
  GObjectClass *gobject        = G_OBJECT_CLASS (klass);
  GstElementClass *element     = GST_ELEMENT_CLASS (klass);
  GstBaseTransformClass *base = GST_BASE_TRANSFORM_CLASS (klass);

  GST_DEBUG_CATEGORY_INIT (gst_rtk_hse_debug, "rtkhse", 0,
      "rtkhse video transform");

  gobject->set_property = GST_DEBUG_FUNCPTR (gst_rtk_hse_set_property);
  gobject->get_property = GST_DEBUG_FUNCPTR (gst_rtk_hse_get_property);
  gobject->finalize     = GST_DEBUG_FUNCPTR (gst_rtk_hse_finalize);

  g_object_class_install_property (gobject, PROP_ROTATE,
      g_param_spec_enum ("rotate", "Rotate", "Rotate method",
          GST_TYPE_VIDEO_ROTATE_METHOD, DEFAULT_PROP_ROTATE,
          G_PARAM_CONSTRUCT | G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS |
          GST_PARAM_MUTABLE_PLAYING));
  g_object_class_install_property (gobject, PROP_SCALE,
      gst_param_spec_array ("scale", "SCALE rectangle",
          "SCALE rectangle ('< WIDTH, HEIGHT >')",
          g_param_spec_int ("value", "Scale Value","One of WIDTH or HEIGHT value.",
              0, G_MAXINT, 0,
              G_PARAM_WRITABLE | G_PARAM_STATIC_STRINGS),
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS |
          GST_PARAM_MUTABLE_PLAYING));

  element->change_state = gst_rtk_hse_change_state;

  gst_element_class_set_static_metadata (element,
      "Video transformer", "Video/Scaler",
      "Resizes, colorspace converts", "RTK");

  gst_element_class_add_pad_template (element,
      gst_rtk_hse_sink_template ());
  gst_element_class_add_pad_template (element,
      gst_rtk_hse_src_template ());

  base->propose_allocation =
      GST_DEBUG_FUNCPTR (gst_rtk_hse_propose_allocation);
  base->decide_allocation =
      GST_DEBUG_FUNCPTR (gst_rtk_hse_decide_allocation);
  base->prepare_output_buffer =
      GST_DEBUG_FUNCPTR (gst_rtk_hse_prepare_output_buffer);
  base->sink_event = GST_DEBUG_FUNCPTR (gst_rtk_hse_sink_event);
  base->transform_caps =
      GST_DEBUG_FUNCPTR (gst_rtk_hse_transform_caps);
  base->fixate_caps = GST_DEBUG_FUNCPTR (gst_rtk_hse_fixate_caps);
  base->set_caps = GST_DEBUG_FUNCPTR (gst_rtk_hse_set_caps);
  base->transform = GST_DEBUG_FUNCPTR (gst_rtk_hse_transform);
}

static void
gst_rtk_hse_init (GstRtkHse * rtkhse)
{
  g_mutex_init (&(rtkhse)->lock);

  rtkhse->rotate = DEFAULT_PROP_ROTATE;
  rtkhse->configuring_method = DEFAULT_PROP_ROTATE;
  rtkhse->scale.w = DEFAULT_PROP_SCALE_WIDTH;
  rtkhse->scale.h = DEFAULT_PROP_SCALE_HEIGHT;

  rtkhse->ininfo = NULL;
  rtkhse->outinfo = NULL;

  rtkhse->infeature = g_quark_from_static_string (NULL);
  rtkhse->outfeature = g_quark_from_static_string (NULL);

  rtkhse->outpool = NULL;
  rtkhse->hsefd =  open("/dev/hse", O_RDWR);
}

static gboolean
plugin_init (GstPlugin * plugin)
{
  return gst_element_register (plugin, "rtkhse", GST_RANK_PRIMARY,
      GST_TYPE_RTK_HSE);
}

#ifndef VERSION
#define VERSION "0.0.1"
#endif
#ifndef PACKAGE
#define PACKAGE "FIXME_package"
#endif
#ifndef PACKAGE_NAME
#define PACKAGE_NAME "rtkhse"
#endif
#ifndef GST_PACKAGE_ORIGIN
#define GST_PACKAGE_ORIGIN "http://FIXME.org/"
#endif

GST_PLUGIN_DEFINE (GST_VERSION_MAJOR, GST_VERSION_MINOR,
    rtkhse, "rtkhse", plugin_init,
    VERSION, "LGPL", PACKAGE_NAME, GST_PACKAGE_ORIGIN)
