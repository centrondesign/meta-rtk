/* GStreamer DVD Sub-Picture Unit
 * Copyright (C) 2007 Fluendo S.A. <info@fluendo.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */
/**
 * SECTION:element-rtkdvdspu
 * @title: rtkdvdspu
 *
 * DVD sub picture overlay element.
 *
 * ## Example launch line
 * |[
 * FIXME: gst-launch-1.0 ...
 * ]| FIXME: description for the sample launch pipeline
 *
 */
#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

#include <glib/gi18n-lib.h>
#include <gst/video/video.h>

#include <string.h>

#include <gst/gst.h>

#include "gstdvdspu.h"
#include <gstrtkdmaallocator.h>
#include <gstrtksubtitlepool.h>
#include <stdio.h>
#include <pthread.h>
#include <time.h>

GST_DEBUG_CATEGORY (rtkdvdspu_debug);
#define GST_CAT_DEFAULT rtkdvdspu_debug

#define DEFAULT_PROP_SILENT FALSE
#define DEFAULT_PROP_USECMA FALSE
GstDVDSPUDebugFlags rtkdvdspu_debug_flags;

/* Filter signals and args */
enum
{
  /* FILL ME */
  LAST_SIGNAL
};

enum
{
  PROP_0,
  PROP_CLEAR,
  PROP_SILENT,
  PROP_USECMA,
  PROP_LAST
};

#define FORMATS "{ BGRx, RGBx, xRGB, xBGR, RGBA, BGRA, ARGB, ABGR, RGB, BGR, \
    I420, YV12, AYUV, YUY2, UYVY, v308, Y41B, Y42B, Y444, \
    NV12, NV21, A420, YUV9, YVU9, IYU1, GRAY8 }"

#define RTK_DVD_SPU_CAPS GST_VIDEO_CAPS_MAKE(FORMATS)

#define RTK_DVD_SPU_ALL_CAPS RTK_DVD_SPU_CAPS ";" \
    GST_VIDEO_CAPS_MAKE_WITH_FEATURES ("ANY", GST_VIDEO_FORMATS_ALL)

static GstStaticPadTemplate video_sink_factory =
GST_STATIC_PAD_TEMPLATE ("video_sink",
    GST_PAD_SINK,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS ("video/x-raw, " "format = (string) { I420, NV12, YV12 }, "
        "width = (int) [ 16, 4096 ], " "height = (int) [ 16, 4096 ]")
    );

static GstStaticPadTemplate video_src_factory = GST_STATIC_PAD_TEMPLATE ("video_src",
    GST_PAD_SRC,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS (RTK_DVD_SPU_ALL_CAPS)
    );

static GstStaticPadTemplate subpic_src_factory = GST_STATIC_PAD_TEMPLATE ("text_src",
    GST_PAD_SRC,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS (RTK_DVD_SPU_ALL_CAPS)
    );

static GstStaticPadTemplate subpic_sink_factory =
    GST_STATIC_PAD_TEMPLATE ("text_sink",
    GST_PAD_SINK,
    GST_PAD_ALWAYS,
//    GST_STATIC_CAPS ("subpicture/x-dvd; subpicture/x-pgs")
    GST_STATIC_CAPS ("subpicture/x-pgs")
    );

static gboolean dvd_spu_element_init (GstPlugin * plugin);

#define gst_dvd_spu_parent_class parent_class
G_DEFINE_TYPE (GstRtkDVDSpu, gst_dvd_spu, GST_TYPE_ELEMENT);
GST_ELEMENT_REGISTER_DEFINE_CUSTOM (rtkdvdspu, dvd_spu_element_init);

static void gst_dvd_spu_dispose (GObject * object);
static void gst_dvd_spu_finalize (GObject * object);
static GstStateChangeReturn gst_dvd_spu_change_state (GstElement * element,
    GstStateChange transition);

static gboolean gst_dvd_spu_video_src_event (GstPad * pad, GstObject * parent,
    GstEvent * event);
static gboolean gst_dvd_spu_video_src_query (GstPad * pad, GstObject * parent,
    GstQuery * query);
static gboolean gst_dvd_spu_subpic_src_event (GstPad * pad, GstObject * parent,
    GstEvent * event);
static gboolean gst_dvd_spu_subpic_src_query (GstPad * pad, GstObject * parent,
    GstQuery * query);

static GstCaps *gst_dvd_spu_video_proxy_getcaps (GstPad * pad,
    GstCaps * filter);
static gboolean gst_dvd_spu_video_set_caps (GstRtkDVDSpu * rtkdvdspu, GstPad * pad,
    GstCaps * caps);
static GstFlowReturn gst_dvd_spu_video_chain (GstPad * pad, GstObject * parent,
    GstBuffer * buf);
static gboolean gst_dvd_spu_video_event (GstPad * pad, GstObject * parent,
    GstEvent * event);
static gboolean gst_dvd_spu_video_query (GstPad * pad, GstObject * parent,
    GstQuery * query);
static void gst_dvd_spu_redraw_still (GstRtkDVDSpu * rtkdvdspu, gboolean force);

static void gst_dvd_spu_check_still_updates (GstRtkDVDSpu * rtkdvdspu);
static GstFlowReturn gst_dvd_spu_subpic_chain (GstPad * pad, GstObject * parent,
    GstBuffer * buf);
static gboolean gst_dvd_spu_subpic_event (GstPad * pad, GstObject * parent,
    GstEvent * event);
static gboolean gst_dvd_spu_subpic_set_caps (GstRtkDVDSpu * rtkdvdspu, GstPad * pad,
    GstCaps * caps);

static void gst_dvd_spu_clear (GstRtkDVDSpu * rtkdvdspu);
static void gst_dvd_spu_flush_spu_info (GstRtkDVDSpu * rtkdvdspu,
    gboolean process_events);
static void gst_dvd_spu_advance_spu (GstRtkDVDSpu * rtkdvdspu, GstClockTime new_ts);
static void gstspu_render (GstRtkDVDSpu * rtkdvdspu, GstBuffer * buf);
static GstFlowReturn
rtkdvdspu_handle_vid_buffer (GstRtkDVDSpu * rtkdvdspu, GstBuffer * buf);
static void gst_dvd_spu_handle_dvd_event (GstRtkDVDSpu * rtkdvdspu, GstEvent * event);
static gboolean gst_dvd_spu_spubpic_src_negotiate (GstRtkDVDSpu * rtkdvdspu);

static void gst_dvd_spu_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec)
{
  GstRtkDVDSpu *rtkdvdspu = GST_RTK_DVD_SPU (object);
  GstFlowReturn ret = GST_FLOW_OK;

  DVD_SPU_LOCK (rtkdvdspu);
  switch (prop_id) {
    case PROP_CLEAR:
      GstBuffer *clear_buffer;
      ret = gst_buffer_pool_acquire_buffer (rtkdvdspu->text_pool, &clear_buffer, NULL);
      if (ret == GST_FLOW_OK) {
        GST_BUFFER_TIMESTAMP(clear_buffer) = rtkdvdspu->last_text_timestamp;
        GST_BUFFER_DURATION(clear_buffer) = GST_CLOCK_TIME_NONE;
        gst_pad_push (rtkdvdspu->subpic_srcpad, clear_buffer);
      }
      break;
    case PROP_SILENT:
      rtkdvdspu->silent = g_value_get_boolean (value);
      if (rtkdvdspu->silent == TRUE) {
        gst_buffer_pool_set_active (rtkdvdspu->text_pool, FALSE);
        gst_rtk_subtitle_pool_reset_pool(rtkdvdspu->text_pool);
      } else
        gst_buffer_pool_set_active (rtkdvdspu->text_pool, TRUE);
      break;
    case PROP_USECMA:
      rtkdvdspu->usecma = g_value_get_boolean (value);
      break;
    default:
      break;
  }

  DVD_SPU_UNLOCK (rtkdvdspu);
}

static void
gst_dvd_spu_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec)
{
  GstRtkDVDSpu *rtkdvdspu = GST_RTK_DVD_SPU (object);

  DVD_SPU_LOCK (rtkdvdspu);
  switch (prop_id) {
    case PROP_CLEAR:
    case PROP_SILENT:
    case PROP_USECMA:
      break;
    default:
      break;
  }

  DVD_SPU_UNLOCK (rtkdvdspu);
}

static void
gst_dvd_spu_class_init (GstRtkDVDSpuClass * klass)
{
  GObjectClass *gobject_class;
  GstElementClass *gstelement_class;

  gobject_class = (GObjectClass *) klass;
  gstelement_class = (GstElementClass *) klass;

  gobject_class->set_property = gst_dvd_spu_set_property;
  gobject_class->get_property = gst_dvd_spu_get_property;
  gobject_class->dispose = (GObjectFinalizeFunc) gst_dvd_spu_dispose;
  gobject_class->finalize = (GObjectFinalizeFunc) gst_dvd_spu_finalize;

  g_object_class_install_property (gobject_class, PROP_CLEAR,
      g_param_spec_boolean ("clear", "Clear",
          "Clear rendering of subtitles", FALSE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_SILENT,
      g_param_spec_boolean ("silent", "Silent",
          "Silent rendering of subtitles", FALSE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_USECMA,
      g_param_spec_boolean ("usecma", "Usecma",
          "Use cma for subtitle buffer", FALSE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  gstelement_class->change_state = gst_dvd_spu_change_state;

  gst_element_class_add_static_pad_template (gstelement_class, &video_src_factory);
  gst_element_class_add_static_pad_template (gstelement_class, &subpic_src_factory);
  gst_element_class_add_static_pad_template (gstelement_class,
      &video_sink_factory);
  gst_element_class_add_static_pad_template (gstelement_class,
      &subpic_sink_factory);

  gst_element_class_set_static_metadata (gstelement_class,
      "Sub-picture Overlay", "Mixer/Video/Overlay/SubPicture/DVD/Bluray",
      "Parses Sub-Picture command streams and renders the SPU overlay "
      "onto the video as it passes through",
      "Jan Schmidt <thaytan@noraisin.net>");
}

void reset_window_size(GstRtkDVDSpu *rtkdvdspu)
{
  if (rtkdvdspu->info_width != rtkdvdspu->vid_width || rtkdvdspu->info_height != rtkdvdspu->vid_height)
  {
    gst_buffer_pool_set_active (rtkdvdspu->text_pool, FALSE);

    if (rtkdvdspu->text_caps) {
       gst_caps_unref(rtkdvdspu->text_caps);
       rtkdvdspu->text_caps = NULL;
    }

    gst_video_info_set_format(&rtkdvdspu->text_info, GST_VIDEO_FORMAT_BGRA, rtkdvdspu->vid_width, rtkdvdspu->vid_height);
    rtkdvdspu->text_caps  = gst_video_info_to_caps(&rtkdvdspu->text_info);

    gst_dvd_spu_spubpic_src_negotiate (rtkdvdspu);

    GstStructure *structure;
    GstAllocator *alloc;

    structure = gst_buffer_pool_get_config (rtkdvdspu->text_pool);
    gst_buffer_pool_config_set_params (structure, rtkdvdspu->text_caps, 4 * rtkdvdspu->vid_width * rtkdvdspu->vid_height, 0, SOLID_TOTAL_BUFFER_COUNT);
    gst_buffer_pool_config_add_option (structure, GST_BUFFER_POOL_OPTION_RTK_SUBTITLE_META);

    alloc = gst_rtk_dma_allocator_new ();
    if(!rtkdvdspu->usecma)
      gst_rtk_dma_allocator_set_heap(alloc, DMA_BUF_SYSTEM);
    gst_buffer_pool_config_set_allocator (structure, alloc, NULL);
    gst_buffer_pool_set_config (rtkdvdspu->text_pool, structure);

    gst_object_unref(alloc);
    gst_buffer_pool_set_active (rtkdvdspu->text_pool, TRUE);

    rtkdvdspu->info_width = rtkdvdspu->vid_width;
    rtkdvdspu->info_height = rtkdvdspu->vid_height;
    rtkdvdspu->text_info.par_n = rtkdvdspu->spu_state.info.par_n;
    rtkdvdspu->text_info.par_d = rtkdvdspu->spu_state.info.par_d;
    rtkdvdspu->text_info.fps_n = rtkdvdspu->spu_state.info.fps_n;
    rtkdvdspu->text_info.fps_d = rtkdvdspu->spu_state.info.fps_d;

    rtkdvdspu->spu_state.info = rtkdvdspu->text_info;
  }
}

#ifdef DVD_SPU_THREAD_PROCESS
void *text_process_thread(void *data){
  GstRtkDVDSpu *rtkdvdspu = (GstRtkDVDSpu *)data;
  GstFlowReturn ret = GST_FLOW_OK;
  GstBuffer *buffer;

  while(rtkdvdspu->text_thread_enable == TRUE) {
    GstClockTime *text_time = NULL;

    pthread_mutex_lock(&rtkdvdspu->text_lock);
    while (g_queue_is_empty(rtkdvdspu->pending_text_data) && rtkdvdspu->text_thread_enable == TRUE)
      pthread_cond_wait(&rtkdvdspu->text_cond, &rtkdvdspu->text_lock);

    pthread_mutex_unlock(&rtkdvdspu->text_lock);

    pthread_mutex_lock(&rtkdvdspu->text_lock);
    while (!g_queue_is_empty(rtkdvdspu->pending_text_data))
    {
       if (rtkdvdspu->text_thread_enable == FALSE)
         break;

       text_time = (GstClockTime *)g_queue_pop_head(rtkdvdspu->pending_text_data);
       pthread_mutex_unlock(&rtkdvdspu->text_lock);
       gst_dvd_spu_advance_spu (rtkdvdspu, *text_time);
       reset_window_size(rtkdvdspu);

       ret = gst_buffer_pool_acquire_buffer (rtkdvdspu->text_pool, &buffer, NULL);
       if (ret == GST_FLOW_OK) {
         rtkdvdspu->last_text_timestamp = *text_time;
         GST_BUFFER_TIMESTAMP (buffer) = *text_time;
         GST_BUFFER_DURATION (buffer) = GST_CLOCK_TIME_NONE;
         gstspu_render(rtkdvdspu, buffer);
         gst_pad_push (rtkdvdspu->subpic_srcpad, buffer);
       }
       free(text_time);
       pthread_mutex_lock(&rtkdvdspu->text_lock);
    }
    pthread_mutex_unlock(&rtkdvdspu->text_lock);
  }
  pthread_exit(NULL);
}
#endif

static void
gst_dvd_spu_init (GstRtkDVDSpu * rtkdvdspu)
{
  rtkdvdspu->videosinkpad =
      gst_pad_new_from_static_template (&video_sink_factory, "video_sink");
  gst_pad_set_chain_function (rtkdvdspu->videosinkpad, gst_dvd_spu_video_chain);
  gst_pad_set_event_function (rtkdvdspu->videosinkpad, gst_dvd_spu_video_event);
  gst_pad_set_query_function (rtkdvdspu->videosinkpad, gst_dvd_spu_video_query);

  rtkdvdspu->video_srcpad = gst_pad_new_from_static_template (&video_src_factory, "video_src");
  gst_pad_set_event_function (rtkdvdspu->video_srcpad, gst_dvd_spu_video_src_event);
  gst_pad_set_query_function (rtkdvdspu->video_srcpad, gst_dvd_spu_video_src_query);

  rtkdvdspu->subpic_srcpad = gst_pad_new_from_static_template (&subpic_src_factory, "text_src");
  gst_pad_set_event_function (rtkdvdspu->subpic_srcpad, gst_dvd_spu_subpic_src_event);
  gst_pad_set_query_function (rtkdvdspu->subpic_srcpad, gst_dvd_spu_subpic_src_query);

  rtkdvdspu->subpic_sinkpad =
      gst_pad_new_from_static_template (&subpic_sink_factory, "text_sink");
  gst_pad_set_chain_function (rtkdvdspu->subpic_sinkpad, gst_dvd_spu_subpic_chain);
  gst_pad_set_event_function (rtkdvdspu->subpic_sinkpad, gst_dvd_spu_subpic_event);

  GST_PAD_SET_PROXY_ALLOCATION (rtkdvdspu->videosinkpad);

  gst_element_add_pad (GST_ELEMENT (rtkdvdspu), rtkdvdspu->videosinkpad);
  gst_element_add_pad (GST_ELEMENT (rtkdvdspu), rtkdvdspu->subpic_sinkpad);
  gst_element_add_pad (GST_ELEMENT (rtkdvdspu), rtkdvdspu->video_srcpad);
  gst_element_add_pad (GST_ELEMENT (rtkdvdspu), rtkdvdspu->subpic_srcpad);

  g_mutex_init (&rtkdvdspu->spu_lock);
  rtkdvdspu->pending_spus = g_queue_new ();

  gst_dvd_spu_clear (rtkdvdspu);

  gst_video_info_set_format(&rtkdvdspu->text_info, GST_VIDEO_FORMAT_BGRA, SOLID_WIDTH, SOLID_HEIGHT);
  rtkdvdspu->text_caps  = gst_video_info_to_caps(&rtkdvdspu->text_info);
  rtkdvdspu->text_pool = gst_rtk_subtitle_pool_new();
  rtkdvdspu->silent = DEFAULT_PROP_SILENT;
  rtkdvdspu->usecma = DEFAULT_PROP_USECMA;
  rtkdvdspu->video_flush = FALSE;
  rtkdvdspu->text_flush = FALSE;

#ifdef DVD_SPU_THREAD_PROCESS
  pthread_cond_init(&rtkdvdspu->text_cond, NULL);
  pthread_mutex_init(&rtkdvdspu->text_lock, NULL);
  rtkdvdspu->text_thread_enable = TRUE;
  pthread_create(&rtkdvdspu->text_thread, NULL, text_process_thread, rtkdvdspu);
  rtkdvdspu->pending_text_data = g_queue_new();
#endif
  rtkdvdspu->preload_gap = 0;
  rtkdvdspu->subtitle_count = 0;
  rtkdvdspu->last_text_timestamp = GST_CLOCK_TIME_NONE;
}

static void
gst_dvd_spu_clear (GstRtkDVDSpu * rtkdvdspu)
{
  gst_dvd_spu_flush_spu_info (rtkdvdspu, FALSE);
  gst_segment_init (&rtkdvdspu->subp_seg, GST_FORMAT_UNDEFINED);

  rtkdvdspu->spu_input_type = SPU_INPUT_TYPE_NONE;

  gst_buffer_replace (&rtkdvdspu->ref_frame, NULL);
  gst_buffer_replace (&rtkdvdspu->pending_frame, NULL);

  rtkdvdspu->spu_state.info.fps_n = 25;
  rtkdvdspu->spu_state.info.fps_d = 1;

  gst_segment_init (&rtkdvdspu->video_seg, GST_FORMAT_UNDEFINED);
}

static void
gst_dvd_spu_dispose (GObject * object)
{
  GstRtkDVDSpu *rtkdvdspu = GST_RTK_DVD_SPU (object);

  /* need to hold the SPU lock in case other stuff is still running... */
  DVD_SPU_LOCK (rtkdvdspu);
  gst_dvd_spu_clear (rtkdvdspu);
  DVD_SPU_UNLOCK (rtkdvdspu);

  G_OBJECT_CLASS (parent_class)->dispose (object);
}

static void
gst_dvd_spu_finalize (GObject * object)
{
  GstRtkDVDSpu *rtkdvdspu = GST_RTK_DVD_SPU (object);
  gint i;

#ifdef DVD_SPU_THREAD_PROCESS
  rtkdvdspu->text_thread_enable = FALSE;
  pthread_cond_broadcast(&rtkdvdspu->text_cond);
  pthread_join(rtkdvdspu->text_thread, NULL);
#endif

  for (i = 0; i < 3; i++) {
    if (rtkdvdspu->spu_state.comp_bufs[i] != NULL) {
      g_free (rtkdvdspu->spu_state.comp_bufs[i]);
      rtkdvdspu->spu_state.comp_bufs[i] = NULL;
    }
  }

  if (rtkdvdspu->text_caps) {
    gst_caps_unref(rtkdvdspu->text_caps);
    rtkdvdspu->text_caps = NULL;
  }

  if (rtkdvdspu->text_pool) {
    g_object_unref(rtkdvdspu->text_pool);
    rtkdvdspu->text_pool = NULL;
  }

#ifdef DVD_SPU_THREAD_PROCESS
  pthread_mutex_lock(&rtkdvdspu->text_lock);
  while (!g_queue_is_empty(rtkdvdspu->pending_text_data))
  {
    void *item = (void *)g_queue_pop_head(rtkdvdspu->pending_text_data);
    if (item != NULL)
      free(item);
  }
  pthread_mutex_unlock(&rtkdvdspu->text_lock);

  g_queue_free (rtkdvdspu->pending_text_data);
#endif

  g_queue_free (rtkdvdspu->pending_spus);
  g_mutex_clear (&rtkdvdspu->spu_lock);

#ifdef DVD_SPU_THREAD_PROCESS
  pthread_cond_destroy(&rtkdvdspu->text_cond);
  pthread_mutex_destroy(&rtkdvdspu->text_lock);
#endif
  G_OBJECT_CLASS (parent_class)->finalize (object);
}

/* With SPU lock held, clear the queue of SPU packets */
static void
gst_dvd_spu_flush_spu_info (GstRtkDVDSpu * rtkdvdspu, gboolean keep_events)
{
  SpuPacket *packet;
  SpuState *state = &rtkdvdspu->spu_state;
  GQueue tmp_q = G_QUEUE_INIT;

  GST_INFO_OBJECT (rtkdvdspu, "Flushing SPU information");

  if (rtkdvdspu->partial_spu) {
    gst_buffer_unref (rtkdvdspu->partial_spu);
    rtkdvdspu->partial_spu = NULL;
  }

  packet = (SpuPacket *) g_queue_pop_head (rtkdvdspu->pending_spus);
  while (packet != NULL) {
    if (packet->buf) {
      gst_buffer_unref (packet->buf);
      g_assert (packet->event == NULL);
      g_free (packet);
    } else if (packet->event) {
      if (keep_events) {
        g_queue_push_tail (&tmp_q, packet);
      } else {
        gst_event_unref (packet->event);
        g_free (packet);
      }
    }
    packet = (SpuPacket *) g_queue_pop_head (rtkdvdspu->pending_spus);
  }
  /* Push anything we decided to keep back onto the pending_spus list */
  for (packet = g_queue_pop_head (&tmp_q); packet != NULL;
      packet = g_queue_pop_head (&tmp_q))
    g_queue_push_tail (rtkdvdspu->pending_spus, packet);

  state->flags &= ~(SPU_STATE_FLAGS_MASK);
  state->next_ts = GST_CLOCK_TIME_NONE;

  switch (rtkdvdspu->spu_input_type) {
    case SPU_INPUT_TYPE_VOBSUB:
      gstspu_vobsub_flush (rtkdvdspu);
      break;
    case SPU_INPUT_TYPE_PGS:
      gstspu_pgs_flush (rtkdvdspu);
      break;
    default:
      break;
  }
}

static gboolean
gst_dvd_spu_video_src_event (GstPad * pad, GstObject * parent, GstEvent * event)
{
  GstRtkDVDSpu *rtkdvdspu = GST_RTK_DVD_SPU (parent);
  GstPad *peer;
  gboolean res = TRUE;

  peer = gst_pad_get_peer (rtkdvdspu->videosinkpad);
  if (peer) {
    res = gst_pad_send_event (peer, event);
    gst_object_unref (peer);
  } else
    gst_event_unref (event);

  return res;
}

static gboolean
gst_dvd_spu_subpic_src_event (GstPad * pad, GstObject * parent, GstEvent * event)
{
  GstRtkDVDSpu *rtkdvdspu = GST_RTK_DVD_SPU (parent);
  GstPad *peer;
  gboolean res = TRUE;

  peer = gst_pad_get_peer (rtkdvdspu->subpic_sinkpad);
  if (peer) {
    res = gst_pad_send_event (peer, event);
    gst_object_unref (peer);
  } else
    gst_event_unref (event);

  return res;
}

static gboolean
gst_dvd_spu_video_src_query (GstPad * pad, GstObject * parent, GstQuery * query)
{
  gboolean res = FALSE;

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_CAPS:
    {
      GstCaps *filter, *caps;

      gst_query_parse_caps (query, &filter);
      caps = gst_dvd_spu_video_proxy_getcaps (pad, filter);
      gst_query_set_caps_result (query, caps);
      gst_caps_unref (caps);
      res = TRUE;
      break;
    }
    default:
      res = gst_pad_query_default (pad, parent, query);
      break;
  }

  return res;
}

static gboolean
gst_dvd_spu_subpic_src_query (GstPad * pad, GstObject * parent, GstQuery * query)
{
  gboolean res = FALSE;
  GstRtkDVDSpu *rtkdvdspu = GST_RTK_DVD_SPU(parent);

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_CAPS:
    {
//      GstCaps *filter, *caps;

//      gst_query_parse_caps (query, &filter);
//      caps = gst_dvd_spu_video_proxy_getcaps (pad, filter);
      gst_query_set_caps_result (query, rtkdvdspu->text_caps);
//      gst_caps_unref (caps);
      res = TRUE;
      break;
    }
    default:
      res = gst_pad_query_default (pad, parent, query);
      break;
  }

  return res;
}

static gboolean
gst_dvd_spu_video_set_caps (GstRtkDVDSpu * rtkdvdspu, GstPad * pad, GstCaps * caps)
{
  gboolean res = FALSE;
  GstVideoInfo info;
  gint i;
  SpuState *state;

  if (!gst_video_info_from_caps (&info, caps))
    goto done;

  DVD_SPU_LOCK (rtkdvdspu);

  state = &rtkdvdspu->spu_state;

  if (rtkdvdspu->text_caps) {
     gst_caps_unref(rtkdvdspu->text_caps);
     rtkdvdspu->text_caps = NULL;
  }

  gst_video_info_set_format(&rtkdvdspu->text_info, GST_VIDEO_FORMAT_BGRA, info.width, info.height);
  rtkdvdspu->text_caps  = gst_video_info_to_caps(&rtkdvdspu->text_info);

  res = gst_dvd_spu_spubpic_src_negotiate (rtkdvdspu);

  GstStructure *structure;
  GstAllocator *alloc;

  structure = gst_buffer_pool_get_config (rtkdvdspu->text_pool);
  gst_buffer_pool_config_set_params (structure, rtkdvdspu->text_caps, 4 * info.width * info.height, 0, SOLID_TOTAL_BUFFER_COUNT);
  gst_buffer_pool_config_add_option (structure, GST_BUFFER_POOL_OPTION_RTK_SUBTITLE_META);

  alloc = gst_rtk_dma_allocator_new ();
  if(!rtkdvdspu->usecma)
    gst_rtk_dma_allocator_set_heap(alloc, DMA_BUF_SYSTEM);
  gst_buffer_pool_config_set_allocator (structure, alloc, NULL);
  gst_buffer_pool_set_config (rtkdvdspu->text_pool, structure);

  gst_object_unref(alloc);
  gst_buffer_pool_set_active (rtkdvdspu->text_pool, TRUE);
  rtkdvdspu->info_width = info.width;
  rtkdvdspu->info_height = info.height;

  state->info = info;
  for (i = 0; i < 3; i++) {
    state->comp_bufs[i] = g_realloc (state->comp_bufs[i],
        sizeof (guint32) * info.width);
  }
  DVD_SPU_UNLOCK (rtkdvdspu);

  res = TRUE;
done:
  return res;
}

static GstCaps *
gst_dvd_spu_video_proxy_getcaps (GstPad * pad, GstCaps * filter)
{
  GstRtkDVDSpu *rtkdvdspu = GST_RTK_DVD_SPU (gst_pad_get_parent (pad));
  GstCaps *caps;
  GstPad *otherpad;

  /* Proxy the getcaps between videosink and the srcpad, ignoring the 
   * subpicture sink pad */
  otherpad = (pad == rtkdvdspu->video_srcpad) ? rtkdvdspu->videosinkpad : rtkdvdspu->video_srcpad;

  caps = gst_pad_peer_query_caps (otherpad, filter);
  if (caps) {
    GstCaps *temp, *templ;

    templ = gst_pad_get_pad_template_caps (otherpad);
    temp = gst_caps_intersect (caps, templ);
    gst_caps_unref (templ);
    gst_caps_unref (caps);
    caps = temp;
  } else {
    caps = gst_pad_get_pad_template_caps (pad);
  }

  gst_object_unref (rtkdvdspu);
  return caps;
}

/* With SPU lock held */
static void
update_video_to_position (GstRtkDVDSpu * rtkdvdspu, GstClockTime new_pos)
{
  SpuState *state = &rtkdvdspu->spu_state;
#if 0
  g_print ("Segment update for video. Advancing from %" GST_TIME_FORMAT
      " to %" GST_TIME_FORMAT "\n",
      GST_TIME_ARGS (rtkdvdspu->video_seg.position), GST_TIME_ARGS (start));
#endif
  while (rtkdvdspu->video_seg.position < new_pos &&
      !(state->flags & SPU_STATE_STILL_FRAME)) {
    DVD_SPU_UNLOCK (rtkdvdspu);
    if (rtkdvdspu_handle_vid_buffer (rtkdvdspu, NULL) != GST_FLOW_OK) {
      DVD_SPU_LOCK (rtkdvdspu);
      break;
    }
    DVD_SPU_LOCK (rtkdvdspu);
  }
}

static gboolean
gst_dvd_spu_video_event (GstPad * pad, GstObject * parent, GstEvent * event)
{
  GstRtkDVDSpu *rtkdvdspu = (GstRtkDVDSpu *) parent;
  SpuState *state = &rtkdvdspu->spu_state;
  gboolean res = TRUE;

  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_CAPS:
    {
      GstCaps *caps;

      gst_event_parse_caps (event, &caps);
      res = gst_dvd_spu_video_set_caps (rtkdvdspu, pad, caps);
      if (res)
        res = gst_pad_push_event (rtkdvdspu->video_srcpad, event);
      else
        gst_event_unref (event);
      break;
    }
    case GST_EVENT_CUSTOM_DOWNSTREAM:
    case GST_EVENT_CUSTOM_DOWNSTREAM_OOB:
    {
      gboolean in_still;

      if (gst_video_event_parse_still_frame (event, &in_still)) {
        GstBuffer *to_push = NULL;

        /* Forward the event before handling */
//        res = gst_pad_event_default (pad, parent, event);
        res = gst_pad_push_event(rtkdvdspu->video_srcpad, event);
        GST_DEBUG_OBJECT (rtkdvdspu,
            "Still frame event on video pad: in-still = %d", in_still);

        DVD_SPU_LOCK (rtkdvdspu);
        if (in_still) {
          state->flags |= SPU_STATE_STILL_FRAME;
          /* Entering still. Advance the SPU to make sure the state is 
           * up to date */
          gst_dvd_spu_check_still_updates (rtkdvdspu);
          /* And re-draw the still frame to make sure it appears on
           * screen, otherwise the last frame  might have been discarded 
           * by QoS */
          gst_dvd_spu_redraw_still (rtkdvdspu, TRUE);
          to_push = rtkdvdspu->pending_frame;
          rtkdvdspu->pending_frame = NULL;
        } else {
          state->flags &= ~(SPU_STATE_STILL_FRAME);
        }
        DVD_SPU_UNLOCK (rtkdvdspu);
        if (to_push)
          gst_pad_push (rtkdvdspu->video_srcpad, to_push);
      } else {
        GST_DEBUG_OBJECT (rtkdvdspu,
            "Custom event %" GST_PTR_FORMAT " on video pad", event);
//        res = gst_pad_event_default (pad, parent, event);
        res = gst_pad_push_event(rtkdvdspu->video_srcpad, event);
      }
      break;
    }
    case GST_EVENT_SEGMENT:
    {
      GstSegment seg;

      gst_event_copy_segment (event, &seg);

      if (seg.format != GST_FORMAT_TIME) {
        gst_event_unref (event);
        return FALSE;
      }

      /* Only print updates if they have an end time (don't print start_time
       * updates */
      GST_DEBUG_OBJECT (rtkdvdspu, "video pad Segment: %" GST_SEGMENT_FORMAT,
          &seg);

      DVD_SPU_LOCK (rtkdvdspu);

//      if (seg.start > rtkdvdspu->video_seg.position) {
//        update_video_to_position (rtkdvdspu, seg.start);
//      }

      rtkdvdspu->video_seg = seg;
      DVD_SPU_UNLOCK (rtkdvdspu);

//      res = gst_pad_event_default (pad, parent, event);
      res = gst_pad_push_event(rtkdvdspu->video_srcpad, event);
      break;
    }
    case GST_EVENT_GAP:
    {
      GstClockTime timestamp, duration;
      gst_event_parse_gap (event, &timestamp, &duration);
      if (GST_CLOCK_TIME_IS_VALID (duration))
        timestamp += duration;

      DVD_SPU_LOCK (rtkdvdspu);
      GST_LOG_OBJECT (rtkdvdspu, "Received GAP. Advancing to %" GST_TIME_FORMAT,
          GST_TIME_ARGS (timestamp));
//      update_video_to_position (rtkdvdspu, timestamp);
      DVD_SPU_UNLOCK (rtkdvdspu);

      gst_event_unref (event);
      break;
    }
    case GST_EVENT_FLUSH_START:
//      res = gst_pad_event_default (pad, parent, event);
      res = gst_pad_push_event(rtkdvdspu->video_srcpad, event);
      goto done;
    case GST_EVENT_FLUSH_STOP:
//      res = gst_pad_event_default (pad, parent, event);
      res = gst_pad_push_event(rtkdvdspu->video_srcpad, event);
      DVD_SPU_LOCK (rtkdvdspu);
      gst_segment_init (&rtkdvdspu->video_seg, GST_FORMAT_UNDEFINED);
      gst_buffer_replace (&rtkdvdspu->ref_frame, NULL);
      gst_buffer_replace (&rtkdvdspu->pending_frame, NULL);

      DVD_SPU_UNLOCK (rtkdvdspu);
      goto done;
    default:
      res = gst_pad_event_default (pad, parent, event);
      break;
  }

done:
  return res;
#if 0
error:
  gst_event_unref (event);
  return FALSE;
#endif
}

static gboolean
gst_dvd_spu_video_query (GstPad * pad, GstObject * parent, GstQuery * query)
{
  gboolean res = FALSE;

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_CAPS:
    {
      GstCaps *filter, *caps;

      gst_query_parse_caps (query, &filter);
      caps = gst_dvd_spu_video_proxy_getcaps (pad, filter);
      gst_query_set_caps_result (query, caps);
      gst_caps_unref (caps);
      res = TRUE;
      break;
    }
    default:
      res = gst_pad_query_default (pad, parent, query);
      break;
  }

  return res;
}

static GstFlowReturn
gst_dvd_spu_video_chain (GstPad * pad, GstObject * parent, GstBuffer * buf)
{
  GstRtkDVDSpu *rtkdvdspu = (GstRtkDVDSpu *) parent;
  GstFlowReturn ret;
  g_return_val_if_fail (rtkdvdspu != NULL, GST_FLOW_ERROR);

  GST_LOG_OBJECT (rtkdvdspu, "video buffer %p with TS %" GST_TIME_FORMAT,
      buf, GST_TIME_ARGS (GST_BUFFER_TIMESTAMP (buf)));

  ret = rtkdvdspu_handle_vid_buffer (rtkdvdspu, buf);

  return ret;
}

static GstFlowReturn
rtkdvdspu_handle_vid_buffer (GstRtkDVDSpu * rtkdvdspu, GstBuffer * buf)
{
//  GstClockTime new_ts;
  GstFlowReturn ret;
  gboolean using_ref = FALSE;

  DVD_SPU_LOCK (rtkdvdspu);

  if (rtkdvdspu->silent == TRUE) {
    gst_buffer_unref(buf);
    DVD_SPU_UNLOCK (rtkdvdspu);
    return GST_FLOW_OK;
  }

  if (rtkdvdspu->video_flush)
  {
     gst_buffer_unref(buf);
     DVD_SPU_UNLOCK (rtkdvdspu);
     return GST_FLOW_OK;
  }

  if (buf == NULL) {
    DVD_SPU_UNLOCK (rtkdvdspu);
    printf("%s video queue null buffer\n", __func__);
    return GST_FLOW_OK;
#if 0
    GstClockTime next_ts = rtkdvdspu->video_seg.position;

    next_ts += gst_util_uint64_scale_int (GST_SECOND,
        rtkdvdspu->spu_state.info.fps_d, rtkdvdspu->spu_state.info.fps_n);

    /* NULL buffer was passed - use the reference frame and update the timestamp,
     * or else there's nothing to draw, and just return GST_FLOW_OK */
    if (rtkdvdspu->ref_frame == NULL) {
      rtkdvdspu->video_seg.position = next_ts;
      goto no_ref_frame;
    }

    buf = gst_buffer_copy (rtkdvdspu->ref_frame);

#if 0
    g_print ("Duping frame %" GST_TIME_FORMAT " with new TS %" GST_TIME_FORMAT
        "\n", GST_TIME_ARGS (GST_BUFFER_TIMESTAMP (buf)),
        GST_TIME_ARGS (next_ts));
#endif

    GST_BUFFER_TIMESTAMP (buf) = next_ts;
    using_ref = TRUE;
#endif
  }

  if (GST_BUFFER_TIMESTAMP_IS_VALID (buf)) {
    rtkdvdspu->video_seg.position = GST_BUFFER_TIMESTAMP (buf);
  }

//  new_ts = gst_segment_to_running_time (&rtkdvdspu->video_seg, GST_FORMAT_TIME,
//      rtkdvdspu->video_seg.position);

#if 0
  g_print ("TS %" GST_TIME_FORMAT " running: %" GST_TIME_FORMAT "\n",
      GST_TIME_ARGS (rtkdvdspu->video_seg.position), GST_TIME_ARGS (new_ts));
#endif

//  gst_dvd_spu_advance_spu (rtkdvdspu, new_ts);
#if 0
  /* If we have an active SPU command set, we store a copy of the frame in case
   * we hit a still and need to draw on it. Otherwise, a reference is
   * sufficient in case we later encounter a still */
  if ((rtkdvdspu->spu_state.flags & SPU_STATE_FORCED_DSP) ||
      ((rtkdvdspu->spu_state.flags & SPU_STATE_FORCED_ONLY) == 0 &&
          (rtkdvdspu->spu_state.flags & SPU_STATE_DISPLAY))) {
    if (using_ref == FALSE) {
      GstBuffer *copy;

      /* Take a copy in case we hit a still frame and need the pristine 
       * frame around */
      copy = gst_buffer_copy (buf);
      gst_buffer_replace (&rtkdvdspu->ref_frame, copy);
      gst_buffer_unref (copy);
    }

    /* Render the SPU overlay onto the buffer */
//    buf = gst_buffer_make_writable (buf);
  } else {
    if (using_ref == FALSE) {
      /* Not going to draw anything on this frame, just store a reference
       * in case we hit a still frame and need it */
      gst_buffer_replace (&rtkdvdspu->ref_frame, buf);
    }
  }
#endif
  if (rtkdvdspu->spu_state.flags & SPU_STATE_STILL_FRAME) {
    GST_DEBUG_OBJECT (rtkdvdspu, "Outputting buffer with TS %" GST_TIME_FORMAT
        "from chain while in still",
        GST_TIME_ARGS (GST_BUFFER_TIMESTAMP (buf)));
  }
  DVD_SPU_UNLOCK (rtkdvdspu);

  /* just push out the incoming buffer without touching it */

  rtkdvdspu->last_video_timestamp = GST_BUFFER_TIMESTAMP(buf);
  rtkdvdspu->last_video_duration = GST_BUFFER_DURATION(buf);
  if (rtkdvdspu->usecma) {
    if(rtkdvdspu->subtitle_count)
      rtkdvdspu->subtitle_count--;
    else if(!GST_CLOCK_TIME_IS_VALID (rtkdvdspu->last_text_timestamp) || rtkdvdspu->last_video_timestamp > rtkdvdspu->last_text_timestamp) {
      GstEvent *gap_event = gst_event_new_gap(rtkdvdspu->last_video_timestamp, rtkdvdspu->last_video_duration);
      gst_pad_push_event(rtkdvdspu->subpic_srcpad, gap_event);
    }
  }
  else if (rtkdvdspu->preload_gap < 3) {
    GstEvent *gap_event = gst_event_new_gap(rtkdvdspu->last_video_timestamp, rtkdvdspu->last_video_duration);
    rtkdvdspu->preload_gap++;
    gst_pad_push_event(rtkdvdspu->subpic_srcpad, gap_event);
  }

#ifdef DVD_SPU_THREAD_PROCESS
  if (!g_queue_is_empty(rtkdvdspu->pending_text_data)) {
    pthread_mutex_lock(&rtkdvdspu->text_lock);
    GstClockTime *text_time = g_queue_peek_head(rtkdvdspu->pending_text_data);
    pthread_mutex_unlock(&rtkdvdspu->text_lock);
    if (*text_time < rtkdvdspu->last_video_timestamp)
       pthread_cond_broadcast(&rtkdvdspu->text_cond);
  }
#endif
  ret = gst_pad_push (rtkdvdspu->video_srcpad, buf);
  return ret;
#if 0
no_ref_frame:

  DVD_SPU_UNLOCK (rtkdvdspu);

  return GST_FLOW_OK;
#endif
}


static void
gstspu_render (GstRtkDVDSpu * rtkdvdspu, GstBuffer * buf)
{
  GstVideoFrame frame;

  if (!gst_video_frame_map (&frame, &rtkdvdspu->text_info, buf,
          GST_MAP_READWRITE))
    return;

  switch (rtkdvdspu->spu_input_type) {
    case SPU_INPUT_TYPE_VOBSUB:
      gstspu_vobsub_render (rtkdvdspu, &frame);
      break;
    case SPU_INPUT_TYPE_PGS:
      gstspu_pgs_render (rtkdvdspu, &frame);
      break;
    default:
      break;
  }
  gst_video_frame_unmap (&frame);
}

/* With SPU LOCK */
static void
gst_dvd_spu_redraw_still (GstRtkDVDSpu * rtkdvdspu, gboolean force)
{
  /* If we have an active SPU command set and a reference frame, copy the
   * frame, redraw the SPU and store it as the pending frame for output */
  if (rtkdvdspu->ref_frame) {
    gboolean redraw = (rtkdvdspu->spu_state.flags & SPU_STATE_FORCED_DSP);
    redraw |= (rtkdvdspu->spu_state.flags & SPU_STATE_FORCED_ONLY) == 0 &&
        (rtkdvdspu->spu_state.flags & SPU_STATE_DISPLAY);

    if (redraw) {
      GstBuffer *buf = gst_buffer_ref (rtkdvdspu->ref_frame);

      buf = gst_buffer_make_writable (buf);

      GST_LOG_OBJECT (rtkdvdspu, "Redraw due to Still Frame with ref %p",
          rtkdvdspu->ref_frame);
      GST_BUFFER_FLAG_SET (buf, GST_BUFFER_FLAG_DISCONT);
      GST_BUFFER_TIMESTAMP (buf) = GST_CLOCK_TIME_NONE;
      GST_BUFFER_DURATION (buf) = GST_CLOCK_TIME_NONE;

      /* Render the SPU overlay onto the buffer */
      //gstspu_render (rtkdvdspu, buf);
      gst_buffer_replace (&rtkdvdspu->pending_frame, buf);
      gst_buffer_unref (buf);
    } else if (force) {
      /* Simply output the reference frame */
      GstBuffer *buf = gst_buffer_ref (rtkdvdspu->ref_frame);
      buf = gst_buffer_make_writable (buf);
      GST_BUFFER_FLAG_SET (buf, GST_BUFFER_FLAG_DISCONT);
      GST_BUFFER_TIMESTAMP (buf) = GST_CLOCK_TIME_NONE;
      GST_BUFFER_DURATION (buf) = GST_CLOCK_TIME_NONE;

      GST_DEBUG_OBJECT (rtkdvdspu, "Pushing reference frame at start of still");

      gst_buffer_replace (&rtkdvdspu->pending_frame, buf);
      gst_buffer_unref (buf);
    } else {
      GST_LOG_OBJECT (rtkdvdspu, "Redraw due to Still Frame skipped");
    }
  } else {
    GST_LOG_OBJECT (rtkdvdspu, "Not redrawing still frame - no ref frame");
  }
}

static void
gst_dvd_spu_handle_dvd_event (GstRtkDVDSpu * rtkdvdspu, GstEvent * event)
{
  gboolean hl_change = FALSE;

  GST_INFO_OBJECT (rtkdvdspu, "DVD event of type %s on subp pad OOB=%d",
      gst_structure_get_string (gst_event_get_structure (event), "event"),
      (GST_EVENT_TYPE (event) == GST_EVENT_CUSTOM_DOWNSTREAM_OOB));

  switch (rtkdvdspu->spu_input_type) {
    case SPU_INPUT_TYPE_VOBSUB:
      hl_change = gstspu_vobsub_handle_dvd_event (rtkdvdspu, event);
      break;
    case SPU_INPUT_TYPE_PGS:
      hl_change = gstspu_pgs_handle_dvd_event (rtkdvdspu, event);
      break;
    default:
      break;
  }

  if (hl_change && (rtkdvdspu->spu_state.flags & SPU_STATE_STILL_FRAME)) {
    gst_dvd_spu_redraw_still (rtkdvdspu, FALSE);
  }
}

static gboolean
gstspu_execute_event (GstRtkDVDSpu * rtkdvdspu)
{
  switch (rtkdvdspu->spu_input_type) {
    case SPU_INPUT_TYPE_VOBSUB:
      return gstspu_vobsub_execute_event (rtkdvdspu);
      break;
    case SPU_INPUT_TYPE_PGS:
      return gstspu_pgs_execute_event (rtkdvdspu);
      break;
    default:
      g_assert_not_reached ();
      break;
  }
  return FALSE;
}

/* Advance the SPU packet/command queue to a time. new_ts is in running time */
static void
gst_dvd_spu_advance_spu (GstRtkDVDSpu * rtkdvdspu, GstClockTime new_ts)
{
  SpuState *state = &rtkdvdspu->spu_state;

  if (G_UNLIKELY (rtkdvdspu->spu_input_type == SPU_INPUT_TYPE_NONE))
    return;

  while (state->next_ts == GST_CLOCK_TIME_NONE || state->next_ts <= new_ts) {
    GST_DEBUG_OBJECT (rtkdvdspu,
        "Advancing SPU from TS %" GST_TIME_FORMAT " to %" GST_TIME_FORMAT,
        GST_TIME_ARGS (state->next_ts), GST_TIME_ARGS (new_ts));

    if (!gstspu_execute_event (rtkdvdspu)) {
      /* No current command buffer, try and get one */
      SpuPacket *packet = (SpuPacket *) g_queue_pop_head (rtkdvdspu->pending_spus);

      if (packet == NULL)
        return;                 /* No SPU packets available */

      GST_LOG_OBJECT (rtkdvdspu,
          "Popped new SPU packet with TS %" GST_TIME_FORMAT
          ". Video position=%" GST_TIME_FORMAT " (%" GST_TIME_FORMAT
          ") type %s",
          GST_TIME_ARGS (packet->event_ts),
          GST_TIME_ARGS (gst_segment_to_running_time (&rtkdvdspu->video_seg,
                  GST_FORMAT_TIME, rtkdvdspu->video_seg.position)),
          GST_TIME_ARGS (rtkdvdspu->video_seg.position),
          packet->buf ? "buffer" : "event");

      if (packet->buf) {
        switch (rtkdvdspu->spu_input_type) {
          case SPU_INPUT_TYPE_VOBSUB:
            gstspu_vobsub_handle_new_buf (rtkdvdspu, packet->event_ts,
                packet->buf);
            break;
          case SPU_INPUT_TYPE_PGS:
            gstspu_pgs_handle_new_buf (rtkdvdspu, packet->event_ts, packet->buf);
            break;
          default:
            g_assert_not_reached ();
            break;
        }
        g_assert (packet->event == NULL);
      } else if (packet->event)
        gst_dvd_spu_handle_dvd_event (rtkdvdspu, packet->event);

      g_free (packet);
      continue;
    }
  }
}

static void
gst_dvd_spu_check_still_updates (GstRtkDVDSpu * rtkdvdspu)
{
  GstClockTime sub_ts;
  GstClockTime vid_ts;

  if (rtkdvdspu->spu_state.flags & SPU_STATE_STILL_FRAME) {

    if (rtkdvdspu->video_seg.format != GST_FORMAT_TIME)
      return;                   /* No video segment or frames yet */

    vid_ts = gst_segment_to_running_time (&rtkdvdspu->video_seg,
        GST_FORMAT_TIME, rtkdvdspu->video_seg.position);
    sub_ts = gst_segment_to_running_time (&rtkdvdspu->subp_seg,
        GST_FORMAT_TIME, rtkdvdspu->subp_seg.position);

    vid_ts = MAX (vid_ts, sub_ts);

    GST_DEBUG_OBJECT (rtkdvdspu,
        "In still frame - advancing TS to %" GST_TIME_FORMAT
        " to process SPU buffer", GST_TIME_ARGS (vid_ts));
//    gst_dvd_spu_advance_spu (rtkdvdspu, vid_ts);
  }
}

static void
submit_new_spu_packet (GstRtkDVDSpu * rtkdvdspu, GstBuffer * buf)
{
  SpuPacket *spu_packet;
  GstClockTime ts;
  GstClockTime run_ts = GST_CLOCK_TIME_NONE;

  GST_DEBUG_OBJECT (rtkdvdspu,
      "Complete subpicture buffer of %" G_GSIZE_FORMAT " bytes with TS %"
      GST_TIME_FORMAT, gst_buffer_get_size (buf),
      GST_TIME_ARGS (GST_BUFFER_TIMESTAMP (buf)));

  /* Decide whether to pass this buffer through to the rendering code */
  ts = GST_BUFFER_TIMESTAMP (buf);
  if (GST_CLOCK_TIME_IS_VALID (ts)) {
    if (ts < (GstClockTime) rtkdvdspu->subp_seg.start) {
      GstClockTimeDiff diff = rtkdvdspu->subp_seg.start - ts;

      /* Buffer starts before segment, see if we can calculate a running time */
      run_ts =
          gst_segment_to_running_time (&rtkdvdspu->subp_seg, GST_FORMAT_TIME,
          rtkdvdspu->subp_seg.start);
      if (run_ts >= (GstClockTime) diff)
        run_ts -= diff;
      else
        run_ts = GST_CLOCK_TIME_NONE;   /* No running time possible for this subpic */
    } else {
      /* TS within segment, convert to running time */
      run_ts =
          gst_segment_to_running_time (&rtkdvdspu->subp_seg, GST_FORMAT_TIME, ts);
    }
  }

  if (GST_CLOCK_TIME_IS_VALID (run_ts)) {
    /* Complete SPU packet, push it onto the queue for processing when
     * video packets come past */
    spu_packet = g_new0 (SpuPacket, 1);
    spu_packet->buf = buf;

    /* Store the activation time of this buffer in running time */
    spu_packet->event_ts = run_ts;
    GST_INFO_OBJECT (rtkdvdspu,
        "Pushing SPU buf with TS %" GST_TIME_FORMAT " running time %"
        GST_TIME_FORMAT, GST_TIME_ARGS (ts),
        GST_TIME_ARGS (spu_packet->event_ts));

    g_queue_push_tail (rtkdvdspu->pending_spus, spu_packet);

    /* In a still frame condition, advance the SPU to make sure the state is 
     * up to date */
    gst_dvd_spu_check_still_updates (rtkdvdspu);
  } else {
    gst_buffer_unref (buf);
  }
}

static GstFlowReturn
gst_dvd_spu_subpic_chain (GstPad * pad, GstObject * parent, GstBuffer * buf)
{
  GstRtkDVDSpu *rtkdvdspu = (GstRtkDVDSpu *) parent;
  GstFlowReturn ret = GST_FLOW_OK;
  gsize size;
  g_return_val_if_fail (rtkdvdspu != NULL, GST_FLOW_ERROR);

  GST_INFO_OBJECT (rtkdvdspu, "Have subpicture buffer with timestamp %"
      GST_TIME_FORMAT " and size %" G_GSIZE_FORMAT,
      GST_TIME_ARGS (GST_BUFFER_TIMESTAMP (buf)), gst_buffer_get_size (buf));

  DVD_SPU_LOCK (rtkdvdspu);

  if (rtkdvdspu->silent == TRUE)
  {
    gst_buffer_unref(buf);
    DVD_SPU_UNLOCK (rtkdvdspu);
    return GST_FLOW_OK;
  }

  if (rtkdvdspu->text_flush) {
     gst_buffer_unref(buf);
     DVD_SPU_UNLOCK (rtkdvdspu);
     return GST_FLOW_OK;
  }


  if (GST_BUFFER_TIMESTAMP_IS_VALID (buf)) {
    rtkdvdspu->subp_seg.position = GST_BUFFER_TIMESTAMP (buf);
  }

  if (GST_BUFFER_IS_DISCONT (buf) && rtkdvdspu->partial_spu) {
    gst_buffer_unref (rtkdvdspu->partial_spu);
    rtkdvdspu->partial_spu = NULL;
  }

  if (rtkdvdspu->partial_spu != NULL) {
    if (GST_BUFFER_TIMESTAMP_IS_VALID (buf))
      GST_WARNING_OBJECT (rtkdvdspu,
          "Joining subpicture buffer with timestamp to previous");
    rtkdvdspu->partial_spu = gst_buffer_append (rtkdvdspu->partial_spu, buf);
  } else {
    /* If we don't yet have a buffer, wait for one with a timestamp,
     * since that will avoid collecting the 2nd half of a partial buf */
    if (GST_BUFFER_TIMESTAMP_IS_VALID (buf))
      rtkdvdspu->partial_spu = buf;
    else
      gst_buffer_unref (buf);
  }

  if (rtkdvdspu->partial_spu == NULL)
    goto done;

  size = gst_buffer_get_size (rtkdvdspu->partial_spu);

  switch (rtkdvdspu->spu_input_type) {
    case SPU_INPUT_TYPE_VOBSUB:
      if (size >= 2) {
        guint8 header[2];
        guint16 packet_size;

        gst_buffer_extract (rtkdvdspu->partial_spu, 0, header, 2);
        packet_size = GST_READ_UINT16_BE (header);
        if (packet_size == size) {
          submit_new_spu_packet (rtkdvdspu, rtkdvdspu->partial_spu);
          rtkdvdspu->partial_spu = NULL;
        } else if (packet_size == 0) {
          GST_LOG_OBJECT (rtkdvdspu, "Discarding empty SPU buffer");
          gst_buffer_unref (rtkdvdspu->partial_spu);
          rtkdvdspu->partial_spu = NULL;
        } else if (packet_size < size) {
          /* Somehow we collected too much - something is wrong. Drop the
           * packet entirely and wait for a new one */
          GST_DEBUG_OBJECT (rtkdvdspu,
              "Discarding invalid SPU buffer of size %" G_GSIZE_FORMAT, size);

          gst_buffer_unref (rtkdvdspu->partial_spu);
          rtkdvdspu->partial_spu = NULL;
        } else {
          GST_LOG_OBJECT (rtkdvdspu,
              "SPU buffer claims to be of size %u. Collected %" G_GSIZE_FORMAT
              " so far.", packet_size, size);
        }
      }
      break;
    case SPU_INPUT_TYPE_PGS:{
      /* Collect until we have a command buffer that ends exactly at the size
       * we've collected */
      guint8 packet_type;
      guint16 packet_size;
      GstMapInfo map;
      guint8 *ptr, *end;
      gboolean invalid = FALSE;

      gst_buffer_map (rtkdvdspu->partial_spu, &map, GST_MAP_READ);

      ptr = map.data;
      end = ptr + map.size;

      /* FIXME: There's no need to walk the command set each time. We can set a
       * marker and resume where we left off next time */
      /* FIXME: Move the packet parsing and sanity checking into the format-specific modules */
      while (ptr != end) {
        if (ptr + 3 > end)
          break;
        packet_type = *ptr++;
        packet_size = GST_READ_UINT16_BE (ptr);
        ptr += 2;
        if (ptr + packet_size > end)
          break;
        ptr += packet_size;
        /* 0x80 is the END command for PGS packets */
        if (packet_type == 0x80 && ptr != end) {
          /* Extra cruft on the end of the packet -> assume invalid */
          invalid = TRUE;
          break;
        }
      }
      gst_buffer_unmap (rtkdvdspu->partial_spu, &map);

      if (invalid) {
        gst_buffer_unref (rtkdvdspu->partial_spu);
        rtkdvdspu->partial_spu = NULL;
      } else if (ptr == end) {
        GST_DEBUG_OBJECT (rtkdvdspu,
            "Have complete PGS packet of size %" G_GSIZE_FORMAT ". Enqueueing.",
            map.size);
        GstClockTime ts = GST_BUFFER_TIMESTAMP(rtkdvdspu->partial_spu);
        submit_new_spu_packet (rtkdvdspu, rtkdvdspu->partial_spu);
#ifdef DVD_SPU_THREAD_PROCESS
        GstClockTime *text_time = (GstClockTime *)malloc(sizeof(GstClockTime));
        *text_time = ts;
        pthread_mutex_lock(&rtkdvdspu->text_lock);
        g_queue_push_tail(rtkdvdspu->pending_text_data, text_time);
        pthread_mutex_unlock(&rtkdvdspu->text_lock);
        pthread_cond_broadcast(&rtkdvdspu->text_cond);
#else
        GstBuffer *buffer;
        gst_dvd_spu_advance_spu (rtkdvdspu, GST_BUFFER_TIMESTAMP(rtkdvdspu->partial_spu));
        reset_window_size(rtkdvdspu);
        rtkdvdspu->subtitle_count++;
        ret = gst_buffer_pool_acquire_buffer (rtkdvdspu->text_pool, &buffer, NULL);
        GST_BUFFER_TIMESTAMP (buffer) = ts;
        GST_BUFFER_DURATION (buffer) = GST_CLOCK_TIME_NONE;
        gstspu_render(rtkdvdspu, buffer);
        gst_pad_push (rtkdvdspu->subpic_srcpad, buffer);
#endif
        rtkdvdspu->partial_spu = NULL;
      }
      break;
    }
    default:
      GST_ERROR_OBJECT (rtkdvdspu, "Input type not configured before SPU passing");
      goto caps_not_set;
  }

done:
  DVD_SPU_UNLOCK (rtkdvdspu);

  return ret;

  /* ERRORS */
caps_not_set:
  {
    GST_ELEMENT_ERROR (rtkdvdspu, RESOURCE, NO_SPACE_LEFT,
        (_("Subpicture format was not configured before data flow")), (NULL));
    ret = GST_FLOW_ERROR;
    goto done;
  }
}

static gboolean
gst_dvd_spu_subpic_event (GstPad * pad, GstObject * parent, GstEvent * event)
{
  GstRtkDVDSpu *rtkdvdspu = (GstRtkDVDSpu *) parent;
  gboolean res = TRUE;

  /* Some events on the subpicture sink pad just get ignored, like 
   * FLUSH_START */
  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_CAPS:
    {
      GstCaps *caps;

      gst_event_parse_caps (event, &caps);
      res = gst_dvd_spu_subpic_set_caps (rtkdvdspu, pad, caps);
      gst_event_unref (event);
      break;
    }
    case GST_EVENT_CUSTOM_DOWNSTREAM:
    case GST_EVENT_CUSTOM_DOWNSTREAM_STICKY:
    case GST_EVENT_CUSTOM_DOWNSTREAM_OOB:
    {
      const GstStructure *structure = gst_event_get_structure (event);
      const gchar *name = gst_structure_get_name (structure);
      gboolean need_push;

      if (!g_str_has_prefix (name, "application/x-gst-dvd")) {
//        res = gst_pad_event_default (pad, parent, event);
        res = gst_pad_push_event(rtkdvdspu->subpic_srcpad, event);
        break;
      }

      DVD_SPU_LOCK (rtkdvdspu);
      if (GST_EVENT_IS_SERIALIZED (event)) {
        SpuPacket *spu_packet = g_new0 (SpuPacket, 1);
        GST_DEBUG_OBJECT (rtkdvdspu,
            "Enqueueing DVD event on subpicture pad for later");
        spu_packet->event = event;
        g_queue_push_tail (rtkdvdspu->pending_spus, spu_packet);
      } else {
        gst_dvd_spu_handle_dvd_event (rtkdvdspu, event);
      }

      /* If the handle_dvd_event generated a pending frame, we
       * need to synchronise with the video pad's stream lock and push it.
       * This requires some dancing to preserve locking order and handle
       * flushes correctly */
      need_push = (rtkdvdspu->pending_frame != NULL);
      DVD_SPU_UNLOCK (rtkdvdspu);
      if (need_push) {
        GstBuffer *to_push = NULL;
        gboolean flushing;

        GST_LOG_OBJECT (rtkdvdspu, "Going for stream lock");
        GST_PAD_STREAM_LOCK (rtkdvdspu->videosinkpad);
        GST_LOG_OBJECT (rtkdvdspu, "Got stream lock");
        GST_OBJECT_LOCK (rtkdvdspu->videosinkpad);
        flushing = GST_PAD_IS_FLUSHING (rtkdvdspu->videosinkpad);
        GST_OBJECT_UNLOCK (rtkdvdspu->videosinkpad);

        DVD_SPU_LOCK (rtkdvdspu);
        if (rtkdvdspu->pending_frame == NULL || flushing) {
          /* Got flushed while waiting for the stream lock */
          DVD_SPU_UNLOCK (rtkdvdspu);
        } else {
          to_push = rtkdvdspu->pending_frame;
          rtkdvdspu->pending_frame = NULL;

          DVD_SPU_UNLOCK (rtkdvdspu);
          gst_pad_push (rtkdvdspu->subpic_srcpad, to_push);
        }
        GST_LOG_OBJECT (rtkdvdspu, "Dropping stream lock");
        GST_PAD_STREAM_UNLOCK (rtkdvdspu->videosinkpad);
      }

      break;
    }
    case GST_EVENT_SEGMENT:
    {
      GstSegment seg;

      gst_event_copy_segment (event, &seg);

      /* Only print updates if they have an end time (don't print start_time
       * updates */
      GST_DEBUG_OBJECT (rtkdvdspu, "subpic pad Segment: %" GST_SEGMENT_FORMAT,
          &seg);

      DVD_SPU_LOCK (rtkdvdspu);

      rtkdvdspu->subp_seg = seg;
      GST_LOG_OBJECT (rtkdvdspu, "Subpicture segment now: %" GST_SEGMENT_FORMAT,
          &rtkdvdspu->subp_seg);
      DVD_SPU_UNLOCK (rtkdvdspu);

//      gst_event_unref (event);
      res = gst_pad_push_event(rtkdvdspu->subpic_srcpad, event);
      break;
    }
    case GST_EVENT_GAP:
    {
      GstClockTime timestamp, duration;
      gst_event_parse_gap (event, &timestamp, &duration);
      if (GST_CLOCK_TIME_IS_VALID (duration))
        timestamp += duration;

      DVD_SPU_LOCK (rtkdvdspu);
      rtkdvdspu->subp_seg.position = timestamp;
      GST_LOG_OBJECT (rtkdvdspu, "Received GAP. Segment now: %" GST_SEGMENT_FORMAT,
          &rtkdvdspu->subp_seg);
      DVD_SPU_UNLOCK (rtkdvdspu);

      gst_event_unref (event);

      break;
    }
    case GST_EVENT_FLUSH_START:
      //gst_event_unref (event);
      rtkdvdspu->preload_gap = 0;

#ifdef DVD_SPU_THREAD_PROCESS
      pthread_mutex_lock(&rtkdvdspu->text_lock);
      while (!g_queue_is_empty(rtkdvdspu->pending_text_data))
      {
        void *item = (void *)g_queue_pop_head(rtkdvdspu->pending_text_data);
        if (item != NULL)
          free(item);
      }
      pthread_mutex_unlock(&rtkdvdspu->text_lock);
#endif

      res = gst_pad_push_event(rtkdvdspu->subpic_srcpad, event);
      goto done;
    case GST_EVENT_FLUSH_STOP:
      GST_DEBUG_OBJECT (rtkdvdspu, "Have flush-stop event on SPU pad");
      DVD_SPU_LOCK (rtkdvdspu);
      gst_segment_init (&rtkdvdspu->subp_seg, GST_FORMAT_UNDEFINED);
      gst_dvd_spu_flush_spu_info (rtkdvdspu, TRUE);
      DVD_SPU_UNLOCK (rtkdvdspu);

      /* We don't forward flushes on the spu pad */
      //gst_event_unref (event);
      res = gst_pad_push_event(rtkdvdspu->subpic_srcpad, event);
      goto done;
    case GST_EVENT_EOS:
      /* drop EOS on the subtitle pad, it means there are no more subtitles,
       * video might still continue, though */
      //gst_event_unref (event);
      res = gst_pad_push_event(rtkdvdspu->subpic_srcpad, event);
      goto done;
    default:
      res = gst_pad_event_default (pad, parent, event);
      break;
  }

done:

  return res;
}

static gboolean
gst_dvd_spu_spubpic_src_negotiate (GstRtkDVDSpu * rtkdvdspu)
{
  gboolean ret = TRUE;

  GST_DEBUG_OBJECT (rtkdvdspu, "performing negotiation");

  gst_pad_check_reconfigure (rtkdvdspu->subpic_srcpad);

  if (!rtkdvdspu->text_caps || gst_caps_is_empty (rtkdvdspu->text_caps))
    goto no_format;

//  gst_rtkass_render_update_render_size (render);

//  ret = gst_rtkass_render_can_handle_caps (render->text_caps);

  if (ret) {
    GST_DEBUG_OBJECT (rtkdvdspu, "Using caps %" GST_PTR_FORMAT, rtkdvdspu->text_caps);
    ret = gst_pad_set_caps (rtkdvdspu->subpic_srcpad, rtkdvdspu->text_caps);
  }

  if (!ret) {
    GST_DEBUG_OBJECT (rtkdvdspu, "negotiation failed, schedule reconfigure");
    gst_pad_mark_reconfigure (rtkdvdspu->subpic_srcpad);
  }

  return ret;

no_format:
  {
    gst_pad_mark_reconfigure (rtkdvdspu->subpic_srcpad);
    return FALSE;
  }
}

static gboolean
gst_dvd_spu_subpic_set_caps (GstRtkDVDSpu * rtkdvdspu, GstPad * pad, GstCaps * caps)
{
  gboolean res = FALSE;
  GstStructure *s;
  SpuInputType input_type;

  res = gst_dvd_spu_spubpic_src_negotiate (rtkdvdspu);

  s = gst_caps_get_structure (caps, 0);

  if (gst_structure_has_name (s, "subpicture/x-dvd")) {
    input_type = SPU_INPUT_TYPE_VOBSUB;
  } else if (gst_structure_has_name (s, "subpicture/x-pgs")) {
    input_type = SPU_INPUT_TYPE_PGS;
  } else {
    goto done;
  }

  DVD_SPU_LOCK (rtkdvdspu);
  if (rtkdvdspu->spu_input_type != input_type) {
    GST_INFO_OBJECT (rtkdvdspu, "Incoming SPU packet type changed to %u",
        input_type);
    rtkdvdspu->spu_input_type = input_type;
    gst_dvd_spu_flush_spu_info (rtkdvdspu, TRUE);
  }

  DVD_SPU_UNLOCK (rtkdvdspu);
  res = TRUE;
done:
  return res;
}

static GstStateChangeReturn
gst_dvd_spu_change_state (GstElement * element, GstStateChange transition)
{
  GstRtkDVDSpu *rtkdvdspu = (GstRtkDVDSpu *) element;
  GstStateChangeReturn ret;

  switch (transition) {
     case GST_STATE_CHANGE_PAUSED_TO_READY:
       DVD_SPU_LOCK (rtkdvdspu);
       rtkdvdspu->video_flush = TRUE;
       rtkdvdspu->text_flush = TRUE;
       gst_dvd_spu_clear (rtkdvdspu);
       DVD_SPU_UNLOCK (rtkdvdspu);
       break;
     case GST_STATE_CHANGE_PLAYING_TO_PAUSED:
     case GST_STATE_CHANGE_PAUSED_TO_PLAYING:
      if (!rtkdvdspu->usecma) {
        rtkdvdspu->preload_gap = 0;
        GstEvent *event = gst_event_new_gap(rtkdvdspu->last_video_timestamp, rtkdvdspu->last_video_duration);
        gst_pad_push_event(rtkdvdspu->subpic_srcpad, event);
      }
       break;
     default:
       break;
  }

  ret = GST_ELEMENT_CLASS (parent_class)->change_state (element, transition);

  switch (transition) {
    case GST_STATE_CHANGE_READY_TO_PAUSED:
      DVD_SPU_LOCK (rtkdvdspu);
      rtkdvdspu->video_flush = FALSE;
      rtkdvdspu->text_flush = FALSE;
      DVD_SPU_UNLOCK (rtkdvdspu);
      break;
    default:
      break;
  }

  return ret;
}

static gboolean
dvd_spu_element_init (GstPlugin * plugin)
{
  const gchar *env;

  GST_DEBUG_CATEGORY_INIT (rtkdvdspu_debug, "gstspu",
      0, "Sub-picture Overlay decoder/renderer");

  env = g_getenv ("GST_RTK_DVD_SPU_DEBUG");

  rtkdvdspu_debug_flags = 0;
  if (env != NULL) {
    if (strstr (env, "render-rectangle") != NULL)
      rtkdvdspu_debug_flags |= GST_RTK_DVD_SPU_DEBUG_RENDER_RECTANGLE;
    if (strstr (env, "highlight-rectangle") != NULL)
      rtkdvdspu_debug_flags |= GST_RTK_DVD_SPU_DEBUG_HIGHLIGHT_RECTANGLE;
  }
  GST_INFO ("debug flags : 0x%02x", rtkdvdspu_debug_flags);

  return gst_element_register (plugin, "rtkdvdspu",
      GST_RANK_PRIMARY, GST_TYPE_RTK_DVD_SPU);
}

static gboolean
gst_dvd_spu_plugin_init (GstPlugin * plugin)
{
  return GST_ELEMENT_REGISTER (rtkdvdspu, plugin);
}

GST_PLUGIN_DEFINE (GST_VERSION_MAJOR,
    GST_VERSION_MINOR,
    rtkdvdspu,
    "DVD Sub-picture Overlay element",
    gst_dvd_spu_plugin_init,
    VERSION, GST_LICENSE, GST_PACKAGE_NAME, GST_PACKAGE_ORIGIN)
