#ifndef __MALI_KBASE_CONFIG_REALTEK_H
#define __MALI_KBASE_CONFIG_REALTEK_H

#include <mali_kbase_config.h>

struct rtk_gpu_platform_data {
	struct device *dev;
	unsigned int spm_suspended;
	unsigned int power;
};

static inline void kbdev_enable_clocks(struct kbase_device *kbdev)
{
	int i;

	for (i = 0; i < kbdev->nr_clocks; i++)
		clk_prepare_enable(kbdev->clocks[i]);
}

static inline void kbdev_disable_clocks(struct kbase_device *kbdev)
{
	int i;

	for (i = 0; i < kbdev->nr_clocks; i++)
		clk_disable_unprepare(kbdev->clocks[i]);
}

#endif
