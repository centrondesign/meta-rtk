// SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note

#include <linux/proc_fs.h>
#include <linux/time64.h>
#include <mali_kbase.h>
#include <device/mali_kbase_device.h>
#include <mali_kbase_gpu_load_procfs.h>

static int kbasep_gpu_load_seq_show(struct seq_file *sfile, void *data)
{
	struct list_head *entry;
	const struct list_head *kbdev_list;

	kbdev_list = kbase_device_get_list();
	list_for_each(entry, kbdev_list) {
		struct kbase_device *kbdev = NULL;
		u64 time_busy, time_idle;

		kbdev = list_entry(entry, struct kbase_device, entry);
		time_busy = kbdev->pm.backend.metrics.values.time_busy / NSEC_PER_USEC;
		time_idle = kbdev->pm.backend.metrics.values.time_idle / NSEC_PER_USEC;
		seq_printf(sfile, "%s: %llu %llu\n", kbdev->devname, time_busy, time_idle);
	}
	kbase_device_put_list(kbdev_list);
	return 0;
}

/*
 *  File operations related to debugfs entry for gpu_load
 */
static int kbasep_gpu_load_procfs_open(struct inode *in, struct file *file)
{
	return single_open(file, kbasep_gpu_load_seq_show, NULL);
}

#if (KERNEL_VERSION(5, 6, 0) <= LINUX_VERSION_CODE)
static const struct proc_ops kbasep_gpu_load_procfs_fops = {
	.proc_open = kbasep_gpu_load_procfs_open,
	.proc_read = seq_read,
	.proc_lseek = seq_lseek,
	.proc_release = single_release,
};
#else
static const struct file_operations kbasep_gpu_load_procfs_fops = {
	.owner = THIS_MODULE,
	.open = kbasep_gpu_load_procfs_open,
	.read = seq_read,
	.llseek = seq_lseek,
	.release = single_release,
};
#endif

static struct proc_dir_entry *mali_procfs_gpuload;

void kbase_gpu_load_procfs_init(void)
{
	if (mali_procfs_gpuload)
		return;

	mali_procfs_gpuload = proc_create_data("gpu_load", 0444, NULL, &kbasep_gpu_load_procfs_fops, NULL);
	if (!mali_procfs_gpuload)
		pr_warn("%s: failed to create /proc/gpu_load\n", __func__);
	return;
}

void kbase_gpu_load_procfs_term(void)
{
	if (mali_procfs_gpuload)
		proc_remove(mali_procfs_gpuload);
	mali_procfs_gpuload = NULL;
}
