// SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note

#include <linux/proc_fs.h>
#include <mali_kbase.h>
#include <device/mali_kbase_device.h>
#include "mali_kbase_gpu_memory_procfs.h"

static int kbasep_gpu_memory_seq_show(struct seq_file *sfile, void *data)
{
	struct list_head *entry;
	const struct list_head *kbdev_list;

	kbdev_list = kbase_device_get_list();
	list_for_each(entry, kbdev_list) {
		struct kbase_device *kbdev = NULL;
		struct kbase_context *kctx;

		kbdev = list_entry(entry, struct kbase_device, entry);
		/* output the total memory usage and cap for this device */
		seq_printf(sfile, "%-16s  %10u\n",
				kbdev->devname,
				atomic_read(&(kbdev->memdev.used_pages)));
		seq_printf(sfile, "  TGID        PID       PAGE_NUM\n");
		mutex_lock(&kbdev->kctx_list_lock);
		list_for_each_entry(kctx, &kbdev->kctx_list, kctx_list_link) {
			/* output the memory usage and cap for each kctx
			 * opened on this device
			 */
			seq_printf(sfile, "%10u %10u %10u\n",
				kctx->tgid, kctx->pid,
				atomic_read(&(kctx->used_pages)));
		}
		mutex_unlock(&kbdev->kctx_list_lock);
	}
	kbase_device_put_list(kbdev_list);
	return 0;
}

/*
 *  File operations related to debugfs entry for gpu_memory
 */
static int kbasep_gpu_memory_procfs_open(struct inode *in, struct file *file)
{
	return single_open(file, kbasep_gpu_memory_seq_show, NULL);
}

#if (KERNEL_VERSION(5, 6, 0) <= LINUX_VERSION_CODE)
static const struct proc_ops kbasep_gpu_memory_procfs_fops = {
	.proc_open = kbasep_gpu_memory_procfs_open,
	.proc_read = seq_read,
	.proc_lseek = seq_lseek,
	.proc_release = single_release,
};
#else
static const struct file_operations kbasep_gpu_memory_procfs_fops = {
	.owner = THIS_MODULE,
	.open = kbasep_gpu_memory_procfs_open,
	.read = seq_read,
	.llseek = seq_lseek,
	.release = single_release,
};
#endif

static struct proc_dir_entry *mali_procfs_gpumemory;

void kbase_gpu_memory_procfs_init(void)
{
	if (mali_procfs_gpumemory)
		return;

	mali_procfs_gpumemory = proc_create_data("gpu_memory", 0444, NULL, &kbasep_gpu_memory_procfs_fops, NULL);
	if (!mali_procfs_gpumemory)
		pr_warn("%s: failed to create /proc/gpu_memory\n", __func__);
	return;
}

void kbase_gpu_memory_procfs_term(void)
{
	if (mali_procfs_gpumemory)
		proc_remove(mali_procfs_gpumemory);
	mali_procfs_gpumemory = NULL;
}
