/**
 * @file config.cpp
 * @author Realtek Semiconductor Corp.
 * @date Aug 2017
 * @brief The config value for GUI or system
 */

#include <QSettings>
#include <QFile>
#include <QHostAddress>
#include "config.h"
#include "gui/mainwidget.h"

SYSTEM_S Config::sys_def = {
    0x0,            // dbgFlag
    true,           // isWayland
    false,          // restartWeston
    true,           // logMsg
    false,          // aiApplication
    false,          // enableScreenShot
    ".mp4 .mkv .mov .avi .flv .m2ts .ts .wmv .mpg .3gp .ps .tp .divx .f4v .m4v .mpeg .mts .ogv .vod .webm .iso", // videoFileFilter
    _STR_WAYLANDSINK_,  // videoSink
    _STR_WAYLANDSINK_,  // textSink
    CHANNEL_MAX,    // ipcChannelMax
    1,              // fileChannelMax
    1920,           // width                    1920                3840
    1080,           // height                   1080                2160
    32,             // widthBase
    18,             // heightBase
    384,            // playbackX                384 /480 /368 /464  384
    1536,           // playbackWidth            1536/1440/1536/1440 3456
    864,            // playbackHeight           864 /810 /864 /810  1944
    0,              // playbackTopDownBorder    0   /0   /8   /8    0
    0,              // playbackLeftRightBorder  0   /0   /16  /16   0
    1,              // frameBufferSizeIndex
    0.5,            // rationOSD
    1,              // ratioFB
    true,           // autoLogin
    true,           // bootupIpcConnect
    100,            // setBlankTime
    1000,           // setPlayerConnectTime
    200,            // viewProcessPoolingTime
    true,           // monitorProcessEnable
    200,            // monitorProcessPoolingTime
    1000,           // monitorProcessQueryTime
    10000,          // monitorProcessNoFrameTimeout
    30000,          // monitorProcessReconnectTime
    3600000,        // monitorProcessReconnectMaxTime
    30000,          // monitorProcessRepingTime
    3000,           // getSourcePollingTime
    2000,           // setSpeedPollingTime
    300,            // recSegmentPollingTime
    200,            // setRtspLatency
    500,            // terminateDelay
    1000,           // playbackQueryTime
    1000,           // playbackPlayDelayTime
    true,           // playbackBlankEnable
    300,            // playbackBlankTime
    SOUND_VALUE_DEF,// playbackSound
    10,             // hlsDuration
    false,          // seamless
    false,          // onvifEnable
    20000,          // onvifPollingTime
    false,          // faceDetectEnable
    false,          // testEnable
    251,            // testInterval
    13579,          // cmdServerPort
};
SYSTEM_S Config::sys;

STYLE_S Config::style = {
    9,              // ipcGridNum
    1,              // fileGridNum
    4,              // ipcBorderSize
    2,              // fileBorderSize
    _RGBA_COLOR_BLACK_,     // borderColor
    "rgba(191,255,57,255)", // borderDragColor
    "rgba(191,255,57,255)",  // borderZoomColor
    "rgba(255,255,255,255)",// tagFontColor
    _RGBA_COLOR_BLACK_, // tagBgColor
    "rgba(191,255,57,50)",   // maskZoomColor
    2,              // tagAlignment
};

SETTING_S Config::setting = {
    60,                 // segmentTime
    35790,              // segmentTimeMax, 35790: max value of type int for QTimer::interval()
    SLIDESHOW_INTERVAL_DEF, // slideshowInterval
    0,                  // dateFormat
    0,                  // timeFormat
    IMAGE_VALUE_DEF,    // brightness
    IMAGE_VALUE_DEF,    // contrast
    IMAGE_VALUE_DEF,    // hue
    IMAGE_VALUE_DEF,    // saturation
    SHARPNESS_VALUE_DEF,// sharpness
    0x0,                // bgColorR
    0x0,                // bgColorG
    0x0,                // bgColorB
    0xFF,               // bgColorA
    // HDMI_1080P_60,      // hdmiMode
    // DP_NONE,            // dpMode
};

AIPATH_S Config::aipath = {
    "/demo/yolo/yolov5uint8.so",                 // yolov5 case code
    "/demo/yolo/network_binary.nb",              // yolov5 nbg file
    "/demo/yolo/coco.txt", // yolov5 label
    "/root/ai-demo/pose-estimation/sample/posenet/poseuint8.so", // posenet case code
    "/root/ai-demo/pose-estimation/sample/posenet/network_binary_posenet.nb", // posenet nbg file
    "/root/ai-demo/pose-estimation/sample/posenet/point_labels.txt", // posenet label
    "/root/ai-demo/object-detection/sample/ssdmobilenet/ssdmobilenetv2cocouint8.so", // ssd_mobilenet case code
    "/root/ai-demo/object-detection/sample/ssdmobilenet/network_binary_ssdmobilenet.nb", // ssd_mobilenet nbg file
    "/root/ai-demo/object-detection/sample/ssdmobilenet/box_priors.txt", // ssd_mobilenet label box_priors
    "/root/ai-demo/object-detection/sample/ssdmobilenet/coco_labels_list.txt", // ssd_mobilenet label coco_labels_list
    "/root/ai-demo/face-processing/face-recogniton/example_face_recognition_tflite.py", // face_recognition script file
};


/*
美國us: MM/dd/yyyy HH:mm:ss,
義大利it: dd/MM/yy HH.mm.ss,
英國uk: dd/MM/yyyy HH:mm:ss,
台灣tw: yyyy/MM/dd HH:mm:ss,
中國cn: yyyy-MM-dd HH:mm:ss
*/
QList<QString> Config::listDateFormat = {"yyyy/MM/dd", "yyyy-MM-dd", "MM/dd/yyyy", "dd/MM/yyyy"};
QList<QString> Config::listTimeFormat = {"HH:mm:ss", "HH.mm.ss"};
QList<QString> Config::listOvertimeFormat = {"%02d:%02d:%02d", "%02d.%02d.%02d"};   // same number as listTimeFormat
QString Config::applicationDirPath;
QString Config::absoluteHlsDirPath; // ex: /mnt/sda/hls/
//QString Config::profileName = _CFG_PROFILE_INI_;

bool Config::init(QString absolutePath)
{
#if 0
    applicationDirPath = QCoreApplication::applicationDirPath()+"/";
#else
    applicationDirPath = absolutePath + ((absolutePath.endsWith("/")) ? "" : "/");
#endif
    absoluteHlsDirPath = Config::applicationDirPath+_CFG_HLS_DIR_;

    loadConfig();
    printInfo();

//    if (QDir().mkpath(absoluteHlsDirPath) != true)
//    {
//        qDebug() << QString("Fail to create dir path %1").arg(absoluteHlsDirPath);
//    }
    return true;
}

Config::Config()
{
}

Config::~Config()
{
}

QString Config::getAbsDirPath(QString dirPath)
{
    QDir dir;
    QString absDirPath;
    dir.setPath(dirPath);
    absDirPath = dir.absolutePath();
    return absDirPath;
}




#define END             settings.endArray()
#define ARRAY(I)        settings.setArrayIndex(I);
#define BEGIN(S)        settings.beginReadArray(S)
#define GET_BOOL(S,V)   V=settings.value(S,V).toBool()
#define GET_INT(S,V)    V=settings.value(S,V).toInt()
#define GET_HEX(S,V)    V=settings.value(S,QString().asprintf("%x", V)).toString().toUInt(NULL, 16)
#define GET_UINT(S,V)   V=settings.value(S,V).toUInt()
#define GET_STR(S,V)    V=settings.value(S,V).toString()
#define GET_IP(S,V)     V=QHostAddress(settings.value(S, QHostAddress(V).toString()).toString()).toIPv4Address()
#define GET_IDX(S,V,L)  V=(L.indexOf(settings.value(S).toString()) < 0) ? V : L.indexOf(settings.value(S).toString())
#define GET_DOUBLE(S,V) V=settings.value(S,V).toDouble()
#define SET_VAL(S,V)    settings.setValue(S,V)
#define SET_IP(S,V)     settings.setValue(S,QHostAddress(V).toString())
#define SET_IDX(S,V,L)  settings.setValue(S,L.at(V))


void Config::loadConfig()
{
    QString absFilePath = applicationDirPath+_CFG_CONFIG_INI_;
    memcpy(&sys, &sys_def, sizeof(sys));

    if (!QFile(absFilePath).exists())
    {
        qDebug() << QString("%1 does not exist !").arg(absFilePath);
        return;
    }
    qDebug() << __func__;
    QSettings settings(absFilePath, QSettings::IniFormat);
    Q_UNUSED(settings)

    BEGIN("SYSTEM");
        GET_HEX("dbgFlag", sys.dbgFlag);
        GET_BOOL("isWayland", sys.isWayland);
        GET_BOOL("restartWeston", sys.restartWeston);
        GET_BOOL("logMsg", sys.logMsg);
        GET_BOOL("aiApplication", sys.aiApplication);
        GET_BOOL("enableScreenShot", sys.enableScreenShot);
        GET_STR("videoFileFilter", sys.videoFileFilter);
        GET_STR("videoSink", sys.videoSink);
        GET_STR("textSink", sys.textSink);
        GET_INT("ipcChannelMax", sys.ipcChannelMax);
        GET_INT("fileChannelMax", sys.fileChannelMax);
        GET_INT("width", sys.width);
        GET_INT("height", sys.height);
        GET_INT("widthBase", sys.widthBase);
        GET_INT("heightBase", sys.heightBase);
        GET_INT("playbackX", sys.playbackX);
        GET_INT("playbackWidth", sys.playbackWidth);
        GET_INT("playbackHeight", sys.playbackHeight);
        GET_INT("playbackTopDownBorder", sys.playbackTopDownBorder);
        GET_INT("playbackLeftRightBorder", sys.playbackLeftRightBorder);
        GET_UINT("setBlankTime", sys.setBlankTime);
        GET_UINT("setPlayerConnectTime", sys.setPlayerConnectTime);
        GET_UINT("viewProcessPoolingTime", sys.viewProcessPoolingTime);
        GET_BOOL("monitorProcessEnable", sys.monitorProcessEnable);
        GET_UINT("monitorProcessPoolingTime", sys.monitorProcessPoolingTime);
        GET_UINT("monitorProcessQueryTime", sys.monitorProcessQueryTime);
        GET_UINT("monitorProcessNoFrameTimeout", sys.monitorProcessNoFrameTimeout);
        GET_UINT("monitorProcessReconnectTime", sys.monitorProcessReconnectTime);
        GET_UINT("monitorProcessReconnectMaxTime", sys.monitorProcessReconnectMaxTime);
        GET_UINT("monitorProcessRepingTime", sys.monitorProcessRepingTime);
        GET_UINT("getSourcePollingTime", sys.getSourcePollingTime);
        GET_UINT("setSpeedPollingTime", sys.setSpeedPollingTime);
        GET_UINT("recSegmentPollingTime", sys.recSegmentPollingTime);
        GET_UINT("setRtspLatency", sys.setRtspLatency);
        GET_UINT("terminateDelay", sys.terminateDelay);
        GET_UINT("playbackQueryTime", sys.playbackQueryTime);
        GET_UINT("playbackPlayDelayTime", sys.playbackPlayDelayTime);
        GET_BOOL("playbackBlankEnable", sys.playbackBlankEnable);
        GET_UINT("playbackBlankTime", sys.playbackBlankTime);
        GET_UINT("hlsDuration", sys.hlsDuration);
        GET_BOOL("seamless", sys.seamless);
        GET_BOOL("onvifEnable", sys.onvifEnable);
        GET_UINT("onvifPollingTime", sys.onvifPollingTime);
        GET_BOOL("faceDetectEnable", sys.faceDetectEnable);
        GET_BOOL("testEnable", sys.testEnable);
        GET_UINT("testInterval", sys.testInterval);
        GET_UINT("cmdServerPort", sys.cmdServerPort);
    END;
    if (sys.width <= 0)         sys.width = sys_def.width;
    if (sys.height <= 0)        sys.height = sys_def.height;
    if (sys.widthBase <= 0)     sys.widthBase = sys_def.widthBase;
    if (sys.heightBase <= 0)    sys.heightBase = sys_def.heightBase;
    if (sys.playbackWidth <= 0) sys.playbackWidth = sys_def.playbackWidth;
    if (sys.playbackHeight <= 0)sys.playbackHeight = sys_def.playbackHeight;
    if (sys.playbackLeftRightBorder <= 0)sys.playbackLeftRightBorder = 0;
    if (sys.ipcChannelMax <= 0 || sys.ipcChannelMax > CHANNEL_MAX)    sys.ipcChannelMax = sys_def.ipcChannelMax;
    if (sys.fileChannelMax <= 0 || sys.fileChannelMax > CHANNEL_MAX)    sys.fileChannelMax = sys_def.fileChannelMax;
    if (sys.width <= 1920)
    {
        sys.ratioOSD = 0.5;
    }
    else if (sys.width <= 3840)
    {
        sys.ratioOSD = 1;
    }
    BEGIN("STYLE");
        GET_UINT("ipcBorderSize", style.ipcBorderSize);
        GET_UINT("fileBorderSize", style.fileBorderSize);
        GET_STR("borderColor", style.borderColor);
        GET_STR("borderDragColor", style.borderDragColor);
        GET_STR("borderZoomColor", style.borderZoomColor);
        GET_STR("tagFontColor", style.tagFontColor);
        GET_STR("tagBgColor", style.tagBgColor);
        GET_STR("maskZoomColor", style.maskZoomColor);
    END;

    BEGIN("SETTING");
    END;

    BEGIN("AIPATH");
        GET_STR("yoloCaseCode", aipath.yoloCaseCode);
        GET_STR("yoloNbg", aipath.yoloNbg);
        GET_STR("yoloCoco", aipath.yoloCoco);
        GET_STR("poseCaseCode", aipath.poseCaseCode);
        GET_STR("poseNbg", aipath.poseNbg);
        GET_STR("poseCoco", aipath.poseCoco);
        GET_STR("mobilenetCaseCode", aipath.mobilenetCaseCode);
        GET_STR("mobilenetNbg", aipath.mobilenetNbg);
        GET_STR("mobilenetBoxPri", aipath.mobilenetBoxPri);
        GET_STR("mobilenetCoco", aipath.mobilenetCoco);
        GET_STR("facerecogScript", aipath.facerecogScript);
    END;
}

void Config::setFrameBufferSizeIndex(int frameBufferSizeIndex)
{
    sys.frameBufferSizeIndex = frameBufferSizeIndex;

    if (frameBufferSizeIndex <= 0 || frameBufferSizeIndex > 1)
    {
        // FRAME_BUFFER_1920x1088
        sys.frameBufferSizeIndex = 0;
        sys.ratioVFB = 0.5;
    }
    else
    {
        // FRAME_BUFFER_3840x2160
        sys.frameBufferSizeIndex = frameBufferSizeIndex;
        sys.ratioVFB = 1;
    }
}

void Config::updateBorderColorByBgColor()
{
    style.borderColor = QString("rgba(%1,%2,%3,%4)")
                                .arg(Config::setting.bgColorR)
                                .arg(Config::setting.bgColorG)
                                .arg(Config::setting.bgColorB)
                                .arg(Config::setting.bgColorA);
}

void Config::printInfo()
{
    qDebug() << QString().asprintf("0x%08x",_DBG_RTKGST_) << "_DBG_RTKGST_" << (DBG(_DBG_RTKGST_) > 0);
    qDebug() << QString().asprintf("0x%08x",_DBG_ALARM_) << "_DBG_ALARM_" << (DBG(_DBG_ALARM_) > 0);
    qDebug() << QString().asprintf("0x%08x",_DBG_PLAYBACK_) << "_DBG_PLAYBACK_" << (DBG(_DBG_PLAYBACK_) > 0);
    qDebug() << QString().asprintf("0x%08x",_DBG_MONITOR_) << "_DBG_MONITOR_" << (DBG(_DBG_MONITOR_) > 0);
    qDebug() << QString().asprintf("0x%08x",_DBG_HLS_PARSER_) << "_DBG_HLS_PARSER_" << (DBG(_DBG_HLS_PARSER_) > 0);
    qDebug() << QString().asprintf("0x%08x",_DBG_ONVIF_) << "_DBG_ONVIF_" << (DBG(_DBG_ONVIF_) > 0);
    qDebug() << "dbgFlag" << QString().asprintf("%08x", sys.dbgFlag);
    qDebug() << "logMsg" << sys.logMsg;
    qDebug() << "autoLogin" << sys.autoLogin;
    qDebug() << "bootupIpcConnect" << sys.bootupIpcConnect;
    qDebug() << "setBlankTime" << sys.setBlankTime;
    qDebug() << "videoSink" << sys.videoSink;
    qDebug() << "textSink" << sys.textSink;
}

QString Config::strQDateFormat()
{
    return listDateFormat.at(setting.dateFormat);
}

QString Config::strQTimeFormat()
{
    return listTimeFormat.at(setting.timeFormat);
}

QString Config::strTimeFormat()
{
    return listOvertimeFormat.at(setting.timeFormat);
}

QString Config::strTime(int secs)
{
    QString str;
    if(secs > 80000)
    {
        qint64 diffT = (qint64)secs;
        int h, m, s;
        s = diffT % 60;
        m = diffT / 60;
        h = m / 60;
        m = m % 60;
        str = QString().asprintf(Config::strTimeFormat().toStdString().c_str(), h, m, s);
    }
    else
    {
        QTime t(0, 0, 0);
        t = t.addMSecs((int)(secs * 1000.0)); // only in 24 hours
        str = t.toString(Config::strQTimeFormat());
    }
    return str;
}

QString Config::strQDateTime(QDateTime datetime)
{
    return (datetime.toString(listDateFormat.at(setting.dateFormat) + " " +
            listTimeFormat.at(setting.timeFormat)));
}
