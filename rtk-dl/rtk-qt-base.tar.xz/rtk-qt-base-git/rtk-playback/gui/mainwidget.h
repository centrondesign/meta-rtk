/**
 * @file mainwidget.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The main background widget page of GUI
 */

#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QComboBox>
#include "define.h"
#include "config.h"
#include "keypad.h"
#include "keyboard.h"
#include "rcheckbox.h"
#include "rdialog.h"
#include "playback.h"
#include "selectvideo.h"
#include "setting.h"
#include "system.h"
#include "test.h"

namespace Ui {
class MainWidget;
}

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    QTimer *bootTimer;

    explicit MainWidget(QWidget *parent = 0);
    ~MainWidget();

    bool setup();
    void finalize();
    void repaintBackground();

private:
    Ui::MainWidget *ui;
    QList<QWidget *>widgetList;
    QLineEdit *faceRecogEdit;
    QTimer *faceRecogEditTimer;

    void showIdxWidgetOnly(QWidget *idxWidget);
    void setComponentStyleSheet();

private slots:
    void power_selected(bool);

protected:
    void mouseMoveEvent(QMouseEvent *);
    void mousePressEvent(QMouseEvent *);
    void keyPressEvent(QKeyEvent *);
    QWidget* getVisibleWidget(QMouseEvent *);
    QWidget* getClickedWidget(QMouseEvent *);
};

extern MainWidget *mainWidget;
extern Playback *playback;
extern SelectVideo *selectVideo;
extern Setting *setting;
extern System *setSystem;
extern Test *setTest;
extern Keypad *keypad;
extern Keyboard *keyboard;
extern RDialog *dialog;

extern QList<QLabel*> *labelList;
extern QList<QLineEdit*> *editList;
extern QList<QLineEdit*> *readOnlyList;
extern QList<RCheckBox*> *checkList;
extern QList<QToolButton*> *actionList;
#endif // MAINWIDGET_H
