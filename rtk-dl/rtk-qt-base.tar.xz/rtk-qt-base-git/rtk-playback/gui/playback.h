/**
 * @file playback.h
 * @author Realtek Semiconductor Corp.
 * @date Oct 2017
 * @brief The widget page to do playback operation
 */

#ifndef PLAYBACK_H
#define PLAYBACK_H

#include <QWidget>
#include <QTimer>
#include <QToolButton>
#include <QList>
#include <QLabel>
#include <QFrame>
#include <QMutex>
#include <QDateTime>

namespace Ui {
class Playback;
}

class Playback : public QWidget
{
    Q_OBJECT

public:
    explicit Playback(QWidget *parent = 0);
    ~Playback();

    void setupButtons();
    void stylesheetUnmute();
    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setBlankDisabled();
    void updateShuffleIndexList();
    void checkIfUpdateShuffleIndexList(bool listChanged);
    void updateProgress();
    void startProgress();
    void stopProgress();
    void seekToPositionByOffset(long long offset);
    void seekToPositionByRate(double rate);
    QString formatTime(qint64 timeNano);
    void returnFromFullscreen();
    int getIdxOfListForSpecificVideo(QString filePath);
    bool selectSpecificVideoInList(QString filePath);
    void setMute();
    void setUnmute();
    void setVolume(int volume);
    bool setPlayPaused();
    bool setPlayResumed();
    bool isPlayable(const QString filePath, bool ifDialog, bool ifMsg);
    void setPlayPauseButton(bool play);
    void setPlayStopButton();
    void setPlayRotate();
    void setPlaySpeed(double speed);
    double getSpeedByRandomIdx(int randIdx);
    bool isPlayFullscreen();
    void setPlayFullscreenButton();
    void setPlayFullscreen(bool bFullscreen);
    void face_recog_keyboard_input(QString);
    bool is_face_recog_running();

private:
    Ui::Playback *ui;
    QList<int> shuffleIndexList;
    QLabel *speedLabel;
    double playspeed;  // stores the current playback speed
    bool playSpeedChanged;
    bool playIfFullscreen;
    const QVector<double> speedLevels = {0.25, 0.5, 1, 2, 4};  // 0.25x, 0.5x, 1x, 2x, 4x
    QTimer *progressTimer;
    QTimer *blankTimer;
    QMutex mutexShuffle;

    QString getSourceString(int source);
    void play(const QString filepath, QWidget *gst_window, bool bFullscreen);
    void playAi(const QString filepath, QString selectedMode, bool bFullscreen);
    void setPlayInfo(QString header, QString filePath);

protected:
    bool eventFilter(QObject *o, QEvent *e);

signals:
    void requestStartProgress();
    void requestStopProgress();
    void requestReturnFromFullscreen();

private slots:
    void mute_changed(bool);
    void volume_changed(int);
    void playCtrl_action();
    void playCtrl_stop();
    void playCtrl_next();
    void playCtrl_prev();
    void btnPlaySeekBack_clicked();
    void btnPlaySeekFront_clicked();

    void btnPlayCtrl_clicked();
    void btnPlayRotation_clicked();
    void btnSlowDown_clicked();
    void btnSpeedUp_clicked();
    void resetPlaySpeed();
    void btnSettings_clicked();
    void btnSelectVideo_clicked();
    void updateSpeedLabel();
    void seekToPosition(int value);
    void btnPlayPrev_clicked();
    void btnPlayNext_clicked();
    void btnPlayShuffle_clicked();
    void btnPlayScreenshot_clicked();
    void btnPlayFullScreen_clicked();
    void btnPlayAi_clicked();
    void btnPlayCameraAi_clicked();
    void listWidgetFileName_changed();

public slots:
    void power_clicked();
    void btnPlayStop_clicked();
};

#endif // PLAYBACK_H
