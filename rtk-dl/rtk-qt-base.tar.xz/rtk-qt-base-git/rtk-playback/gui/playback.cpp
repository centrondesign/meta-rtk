/**
 * @file playback.cpp
 * @author Realtek Semiconductor Corp.
 * @date Oct 2017
 * @brief The widget page to do playback operation
 */

#include <QGraphicsDropShadowEffect>
#include "playback.h"
#include "ui_playback.h"
#include "mainwidget.h"
#include "rtkgst.h"

#include <QSplitter>
#include <QMenu>
#include <QAction>
#include <QPoint>
#include <regex>

#define QNAME(var) QStringLiteral(#var)
#define UPDATE_INTERVAL_MS 200  // Update progress every 200ms
#define WIDTH_SIDEBARWIDGET 350 // sidebarWidget default width

extern int g_pipefd[2];

Playback::Playback(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Playback)
{
    ui->setupUi(this);

#if 0
    ui->lTitle->setStyleSheet(STYLESHEET_TITLE_1);
#else
    ui->lTitle->setStyleSheet("background-color: rgb(25, 32, 36);"
                              "color: rgb(179, 179, 179);"
                              "font: bold 28px \"Arial\";");
#endif

    speedLabel = ui->speedLabel;
    playSpeed = 1;
    playSeekRate = 0;
    playSpeedChanged = false;
    playSeekRateChanged = false;
    playIfFullscreen = false;

    setupButtons();
    stylesheetUnmute();

    ui->progressBar->setStyleSheet(R"(
        QSlider::groove:horizontal {
            background: #333;
            height: 8px;
            border-radius: 4px;
        }
        QSlider::handle:horizontal {
            background: #fff;
            width: 14px;
            border-radius: 7px;
        }
        QSlider::sub-page:horizontal {
            background: #ffcc00;
            border-radius: 4px;
        }
    )");

    ui->speedLabel->setStyleSheet("color: white; font-size: 32px; font-weight: bold;");
    ui->totalTime->setStyleSheet("color: white; font-size: 16px; font-weight: bold;");
    ui->currentTime->setStyleSheet("color: white; font-size: 16px; font-weight: bold;");
    ui->volumeLabel->setStyleSheet("color: white; font-size: 16px; font-weight: bold;");

    ui->progressLayout->setContentsMargins(50, 100, 20, 0);// left, top, right, bottom
    ui->infoLayout->setContentsMargins(50, 0, 10, 20);// left, top, right, bottom

    // Use QSplitter to proportionally adjust sidebarWidget and videoWidget
    QSplitter *splitter = new QSplitter(Qt::Horizontal, this);
    splitter->addWidget(ui->sidebarWidget);
    splitter->addWidget(ui->videoWidget);
    splitter->setStretchFactor(0, 1);  // Sidebar gets a lower weight
    splitter->setStretchFactor(1, 3);  // Video area gets a higher weight
    splitter->setHandleWidth(0);
    ui->mainLayout->addWidget(splitter);
    ui->mainLayout->setContentsMargins(0, 0, 0, 0); // Remove all borders

    // Set sidebarWidget width for different screen resolution, default 350
    int sidebarWidth = std::min(WIDTH_SIDEBARWIDGET, Config::sys.width - Config::sys.playbackWidth);
    ui->sidebarWidget->setMaximumWidth(sidebarWidth);
    ui->sidebarWidget->setMinimumWidth(sidebarWidth);

    // Set layout stretch factors inside videoWidget
    ui->videoLayout->setStretch(0, 4);  // videoDisplay (video area) takes 4 parts
    ui->videoLayout->setStretch(1, 1);  // controlWidget (control area) takes 1 part

    // Ensure sidebarWidget can adapt to screen size
    ui->sidebarWidget->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Expanding);

    // Set background colors
    ui->sidebarWidget->setStyleSheet("background-color: rgb(25, 32, 36);");
    ui->lFileName->setStyleSheet("background-color: rgb(179, 179, 179)");
    ui->controlWidget->setStyleSheet("background-color: rgb(25, 32, 36);");

    ui->wTop->setStyleSheet("background-color: rgb(0, 0, 64);");
    ui->wBottom->setStyleSheet("background-color: rgb(0, 0, 64);");
    ui->wLeft->setStyleSheet("background-color: rgb(0, 0, 64);");
    ui->wRight->setStyleSheet("background-color: rgb(0, 0, 64);");
    ui->wBlank->setStyleSheet("background-color: rgb(0, 0, 64);");

    ui->lFileName->setSelectionMode(QAbstractItemView::SingleSelection);
    connect(ui->lFileName, &QListWidget::currentItemChanged, this, &Playback::listWidgetFileName_changed);

    // Set full screen mode
    this->showFullScreen();

    // Allow UI elements to resize automatically
    ui->wMain->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    ui->wMain->layout()->setSizeConstraint(QLayout::SetNoConstraint);
    ui->wMain->raise();

    QFont font;
    font.setPointSize(16);
    ui->lFileName->setFont(font);
    ui->lFileName->setStyleSheet("background: transparent; color: white;");
    ui->lFileName->setWordWrap(true);
    ui->lFileName->setTextElideMode(Qt::ElideNone); // Disable text eliding to ensure wrapping

    ui->lInfo->setFont(font);
    ui->lInfo->setStyleSheet("background: transparent; color: white;");
    ui->lInfo->setAlignment(Qt::AlignCenter);
    ui->lInfo->clear();

    ui->controlLayout->setAlignment(Qt::AlignLeft);

    progressTimer = new QTimer(this);
    connect(progressTimer, &QTimer::timeout, this, &Playback::updateProgress);
    connect(this, &Playback::requestStartProgress, this, &Playback::startProgress, Qt::QueuedConnection);
    connect(this, &Playback::requestStopProgress, this, &Playback::stopProgress, Qt::QueuedConnection);
    // Listen for progress bar slider moved events
    connect(ui->progressBar, &QSlider::sliderMoved, this, &Playback::seekToPosition);
    // Install eventFilter to capture click events on the slider
    ui->progressBar->installEventFilter(this);

    ui->volumeSlider->setMaximum(VOLUME_MAX);
    ui->volumeSlider->setValue(VOLUME_DEF);
    ui->volumeLabel->setText(QString().sprintf("%d", VOLUME_DEF));
    // Listen for volume slider moved events
    connect(ui->volumeSlider, &QSlider::valueChanged, this, &Playback::volume_changed);

    // Initialize default selection
    ui->screenshotButton->setVisible(Config::sys.enableScreenShot);
    ui->aiButton->setVisible(Config::sys.aiApplication);
    ui->cameraAIButton->setVisible(Config::sys.aiApplication);

    blankTimer = new QTimer(this);
    blankTimer->setSingleShot(true);
    blankTimer->setInterval(Config::sys.playbackBlankTime);
    connect(blankTimer, &QTimer::timeout, this, &Playback::setBlankDisabled);
}

Playback::~Playback()
{
    playCtrl_stop ();
    delete blankTimer;
    delete progressTimer;
    delete ui;
}

void Playback::setupButtons()
{
    connect(ui->selectVideoButton, &QPushButton::clicked, this, &Playback::btnSelectVideo_clicked);
    connect(ui->settingsButton, &QPushButton::clicked, this, &Playback::btnSettings_clicked);
    connect(ui->quitButton, &QPushButton::clicked, this, &Playback::power_clicked);

    QPushButton *btn;
    QList <QPushButton *> btnList = {ui->selectVideoButton, ui->settingsButton, ui->quitButton};
    foreach (btn, btnList)
    {
        btn->setStyleSheet(QString(
                                "QPushButton{"
                                    "border:0px;"    // transparent for Linux
                                    "background: transparent;"
                                    "color:#737373;"
                                    "%1"
                                    "}"
                                "QPushButton:hover{"
                                    "border:0px;"    // transparent for Linux
                                    "background: transparent;"
                                    "color: rgb(224, 255, 24);"
                                    "%1"
                                    "}")
                           .arg("font: bold 24px \"Arial Black\";")
                           );
    }

    ui->shuffleButton->setIcons(QIcon(":/images/playback_random_turnoff_normal.png"),
                            QIcon(":/images/playback_random_turnon_normal.png"),
                            QIcon(":/images/playback_random_turnon_normal.png"),
                            QIcon(":/images/playback_random_turnoff_normal.png"),
                            true);
    connect(ui->shuffleButton, SIGNAL(clicked(bool)), this, SLOT(btnPlayShuffle_clicked()));

    ui->aiButton->setIcons(QIcon(":/images/playback_ai_normal.png"),
                            QIcon(":/images/playback_ai_hover.png"),
                            QIcon(":/images/playback_ai_hover.png"),
                            QIcon(":/images/playback_ai_normal.png"),
                            true);
    connect(ui->aiButton, SIGNAL(clicked(bool)), this, SLOT(btnPlayAi_clicked()));

    ui->repeatButton->setIcons(QIcon(":/images/playback_replay_normal.png"),
                            QIcon(":/images/playback_replay_hover.png"),
                            QIcon(":/images/playback_replay_hover.png"),
                            QIcon(":/images/playback_replay_normal.png"),
                            true);

    ui->muteButton->setIcons(QIcon(":/images/soundoff_normal.png"),
                            QIcon(":/images/soundoff_hover.png"),
                            QIcon(":/images/soundon_normal.png"),
                            QIcon(":/images/soundon_hover.png"),
                            true);
    connect(ui->muteButton, SIGNAL(clicked(bool)), this, SLOT(mute_changed(bool)));

    ui->cameraAIButton->setIcons(QIcon(":/images/playback_aiCamera_normal.png"),
                            QIcon(":/images/playback_aiCamera_hover.png"),
                            QIcon(":/images/playback_aiCamera_hover.png"),
                            QIcon(":/images/playback_aiCamera_normal.png"),
                            true);
    connect(ui->cameraAIButton, SIGNAL(clicked(bool)), this, SLOT(btnPlayCameraAi_clicked()));

    ui->slowDownButton->setIcons(QIcon(":/images/playback_prev_normal.png"),
                            QIcon(":/images/playback_prev_hover.png"),
                            QIcon(":/images/playback_prev_normal.png"),
                            QIcon(":/images/playback_prev_hover.png"),
                            false);
    connect(ui->slowDownButton, SIGNAL(clicked(bool)), this, SLOT(btnSlowDown_clicked()));

    ui->speedUpButton->setIcons(QIcon(":/images/playback_next_normal.png"),
                            QIcon(":/images/playback_next_hover.png"),
                            QIcon(":/images/playback_next_normal.png"),
                            QIcon(":/images/playback_next_hover.png"),
                            false);
    connect(ui->speedUpButton, SIGNAL(clicked(bool)), this, SLOT(btnSpeedUp_clicked()));

    ui->rewindButton->setIcons(QIcon(":/images/playback_backward10Sec_normal.png"),
                            QIcon(":/images/playback_backward10Sec_hover.png"),
                            QIcon(":/images/playback_backward10Sec_normal.png"),
                            QIcon(":/images/playback_backward10Sec_hover.png"),
                            false);
    connect(ui->rewindButton, SIGNAL(clicked(bool)), this, SLOT(btnPlaySeekBack_clicked()));

    ui->prevButton->setIcons(QIcon(":/images/playback_seek_back_normal.png"),
                            QIcon(":/images/playback_seek_back_hover.png"),
                            QIcon(":/images/playback_seek_back_normal.png"),
                            QIcon(":/images/playback_seek_back_hover.png"),
                            false);
    connect(ui->prevButton, SIGNAL(clicked(bool)), this, SLOT(btnPlayPrev_clicked()));

    ui->playPauseButton->setIcons(QIcon(":/images/playback_play_normal.png"),
                            QIcon(":/images/playback_play_hover.png"),
                            QIcon(":/images/playback_pause_normal.png"),
                            QIcon(":/images/playback_pause_hover.png"),
                            true);
    connect(ui->playPauseButton, SIGNAL(clicked(bool)), this, SLOT(btnPlayCtrl_clicked()));

    ui->stopButton->setIcons(QIcon(":/images/playback_stop_normal.png"),
                            QIcon(":/images/playback_stop_hover.png"),
                            QIcon(":/images/playback_stop_normal.png"),
                            QIcon(":/images/playback_stop_hover.png"),
                            false);
    connect(ui->stopButton, SIGNAL(clicked(bool)), this, SLOT(btnPlayStop_clicked()));

    ui->nextButton->setIcons(QIcon(":/images/playback_seek_front_normal.png"),
                            QIcon(":/images/playback_seek_front_hover.png"),
                            QIcon(":/images/playback_seek_front_normal.png"),
                            QIcon(":/images/playback_seek_front_hover.png"),
                            false);
    connect(ui->nextButton, SIGNAL(clicked(bool)), this, SLOT(btnPlayNext_clicked()));

    ui->forwardButton->setIcons(QIcon(":/images/playback_forward10Sec_normal.png"),
                            QIcon(":/images/playback_forward10Sec_hover.png"),
                            QIcon(":/images/playback_forward10Sec_normal.png"),
                            QIcon(":/images/playback_forward10Sec_hover.png"),
                            false);
    connect(ui->forwardButton, SIGNAL(clicked(bool)), this, SLOT(btnPlaySeekFront_clicked()));

    ui->rotateButton->setIcons(QIcon(":/images/playback_rotation_normal.png"),
                            QIcon(":/images/playback_rotation_hover.png"),
                            QIcon(":/images/playback_rotation_normal.png"),
                            QIcon(":/images/playback_rotation_hover.png"),
                            false);
    connect(ui->rotateButton, SIGNAL(clicked(bool)), this, SLOT(btnPlayRotation_clicked()));

    ui->fullscreenButton->setIcons(QIcon(":/images/playback_fullScreen_normal.png"),
                            QIcon(":/images/playback_fullScreen_hover.png"),
                            QIcon(":/images/playback_fullScreen_normal.png"),
                            QIcon(":/images/playback_fullScreen_hover.png"),
                            false);
    connect(ui->fullscreenButton, SIGNAL(clicked(bool)), this, SLOT(btnPlayFullScreen_clicked()));
    connect(this, &Playback::requestReturnFromFullscreen, this, &Playback::returnFromFullscreen, Qt::QueuedConnection);

    ui->screenshotButton->setIcons(QIcon(":/images/playback_screenshot_normal.png"),
                            QIcon(":/images/playback_screenshot_hover.png"),
                            QIcon(":/images/playback_screenshot_normal.png"),
                            QIcon(":/images/playback_screenshot_hover.png"),
                            false);
    connect(ui->screenshotButton, SIGNAL(clicked(bool)), this, SLOT(btnPlayScreenshot_clicked()));
}

void Playback::stylesheetUnmute()
{
    ui->muteButton->setActive(false, false);
    ui->volumeSlider->setEnabled(true);
    ui->volumeSlider->setStyleSheet(R"(
        QSlider::groove:horizontal {
            background: #444;  /* adjust background color */
            height: 6px;
            border-radius: 3px;
        }
        QSlider::handle:horizontal {
            background: #ddd;  /* adjust slider handle color */
            width: 12px;
            border-radius: 6px;
        }
        QSlider::sub-page:horizontal {
            background: #1DB954;  /* adjust progress bar fill color */
            border-radius: 3px;
        }
    )");
}

void Playback::setup()
{
    selectVideo->setFileNameList(ui->lFileName);
    setTest->setFileNameList(ui->lFileName);
}

void Playback::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);
    // qDebug() << __func__ << rect.x() << rect.y() << rect.width() << rect.height();

    ui->wTop->setGeometry(0, 0, rect.width(), 0);
    ui->wBottom->setGeometry(0, Config::sys.playbackHeight, rect.width(), qMax(rect.height()-Config::sys.playbackHeight, 0));
    ui->wLeft->setGeometry(9, 0, Config::sys.playbackX, rect.height());
    ui->wRight->setGeometry(Config::sys.playbackX+Config::sys.playbackWidth, 0, 
                            qMax(rect.width()-(Config::sys.playbackX+Config::sys.playbackWidth), 0), rect.height());
    ui->wBlank->setGeometry(Config::sys.playbackX, 0, Config::sys.playbackWidth, Config::sys.playbackHeight);

    ui->wBlank->setVisible(Config::sys.playbackBlankEnable);

    ui->wMain->setGeometry(rect.x(), rect.y(), rect.width(), rect.height());
}

void Playback::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void Playback::setBlankDisabled()
{
    ui->wBlank->setVisible(false);
    ui->wBlank->repaint();
    if (rtkGst->if_platform_wayland && rtkGst->if_wayland_bg_color_transparency &&
        Config::sys.videoSink.startsWith("rtk") && Config::sys.videoSink.endsWith("sink"))
    {
        // repaint transparenct bg again to show video layer automatically
        mainWidget->repaintBackground();
    }
}

void Playback::btnSelectVideo_clicked()
{
    setting->setVisible(false);
    selectVideo->setVisible(true);
    selectVideo->raise();
}

bool Playback::eventFilter(QObject *o, QEvent *e)
{
    //qDebug() << __func__ << o << e;
    if (o == ui->progressBar) {
        QSlider *slider = ui->progressBar;
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(e);

        if (e->type() == QEvent::MouseButtonPress && mouseEvent->button() == Qt::LeftButton) {
            // Calculate the new value based on the click position
            int newValue = QStyle::sliderValueFromPosition(
                slider->minimum(), slider->maximum(),
                mouseEvent->pos().x(), slider->width()
            );
            slider->setValue(newValue);
            return true; // Handle the click event
        }
        else if (e->type() == QEvent::MouseMove && (mouseEvent->buttons() & Qt::LeftButton)) {
            // Update the slider position during dragging
            int newValue = QStyle::sliderValueFromPosition(
                slider->minimum(), slider->maximum(),
                mouseEvent->pos().x(), slider->width()
            );
            slider->setValue(newValue);
            return true; // Handle the drag event
        }
        else if (e->type() == QEvent::MouseButtonRelease && mouseEvent->button() == Qt::LeftButton) {
            // Ensure the final position is correct upon release
            int newValue = QStyle::sliderValueFromPosition(
                slider->minimum(), slider->maximum(),
                mouseEvent->pos().x(), slider->width()
            );
            slider->setValue(newValue);
            seekToPosition(newValue);
            return true; // Handle the release event
        }
    }
    return QObject::eventFilter(o, e);
}

void Playback::power_clicked()
{
    // TBD，confirm to stop playing
    mainWidget->close();
}

void Playback::setMute()
{
    if(ui->cameraAIButton->getActived()){
        qDebug () << QString().asprintf("%s:%d function only support video mode.", __FUNCTION__, __LINE__);
        return;
    }

    int volume = 0;
    qDebug () << QString().asprintf("%s:%d volume %d", __FUNCTION__, __LINE__, volume);
    rtkGst->rtk_gst_setVolume(volume);
    ui->muteButton->setActive(true, false);
    ui->volumeSlider->setEnabled(false);
    ui->volumeSlider->setStyleSheet("QSlider::sub-page:horizontal { background: gray; }");
}

void Playback::setUnmute()
{
    if(ui->cameraAIButton->getActived()){
        qDebug () << QString().asprintf("%s:%d function only support video mode.", __FUNCTION__, __LINE__);
        return;
    }

    int volume = (int)ui->volumeSlider->value();
    qDebug () << QString().asprintf("%s:%d volume %d", __FUNCTION__, __LINE__, volume);
    rtkGst->rtk_gst_setVolume(volume);
    stylesheetUnmute();
}

void Playback::mute_changed(bool)
{
    if(ui->muteButton->getActived())
        setMute();
    else
        setUnmute();
}

void Playback::setVolume(int volume)
{
    qDebug () << QString().asprintf("%s:%d volume %d", __FUNCTION__, __LINE__, volume);
    if (ui->volumeSlider->value() != volume && ui->muteButton->getActived())
    {
        ui->volumeSlider->setValue(volume);
        stylesheetUnmute();
    }
    else if (ui->volumeSlider->value() != volume)
    {
        ui->volumeSlider->setValue(volume);
    }
    else if (ui->muteButton->getActived())
    {
        setUnmute();
    }
}

void Playback::volume_changed(int value)
{
    if(ui->cameraAIButton->getActived()){
        qDebug() << "The volume_changed function only support video mode.";
        return;
    }

    qDebug () << QString().asprintf("%s:%d volume %d", __FUNCTION__, __LINE__, value);
    rtkGst->rtk_gst_setVolume(value);
    ui->volumeLabel->setText(QString::number(value));
}

void Playback::btnPlayCtrl_clicked()
{
    if(ui->cameraAIButton->getActived()){
        qDebug() << "The playCtrl function only support video mode.";
        ui->playPauseButton->setActive(!ui->playPauseButton->getActived(), false); // recover the icon
        return;
    }

    if(ui->shuffleButton->getActived())
        updateShuffleIndexList();

    playCtrl_action();
}

void Playback::playCtrl_action()
{
    // Toggle the playback state
    if (ui->playPauseButton->getActived()) {
        // Logic for playing video
        QListWidgetItem *currentItem = ui->lFileName->currentItem();
        if(currentItem) {
            QString filePath = currentItem->text();
            if (isPlayable(filePath, true, true) != true)
            {
                ui->playPauseButton->setActive(false, false);
                return;
            }
            if(ui->aiButton->getActived())
                playAi(filePath, setSystem->strAiMode, playIfFullscreen);
            else
                play(filePath, ui->videoDisplay, playIfFullscreen);
            setPlayInfo(QString("%1 / %2 => ")
                            .arg(ui->lFileName->currentRow()+1)
                            .arg(ui->lFileName->count()), filePath);
            if (isSpeedChangeable() && playSpeed != 1)
                playSpeedChanged = true;
        }

        emit requestStartProgress();    // progressTimer->start(UPDATE_INTERVAL_MS);

    } else {
        // pausing video
        rtkGst->rtk_gst_pause();
        emit requestStopProgress();    // progressTimer->stop();
    }
}

bool Playback::setPlayPaused()
{
    if(ui->cameraAIButton->getActived()){
        qDebug() << "The playCtrl function only support video mode.";
        ui->playPauseButton->setActive(true, false);
        return false;
    }
    bool result = rtkGst->rtk_gst_pause();
    if (result)
        emit requestStopProgress();     // progressTimer->stop();
    ui->playPauseButton->setActive(!result, false);
    return result;
}

bool Playback::setPlayResumed()
{
    if(ui->cameraAIButton->getActived()){
        qDebug() << "The playCtrl function only support video mode.";
        ui->playPauseButton->setActive(true, false);
        return false;
    }
    bool result = rtkGst->rtk_gst_resume();
    if (result)
        emit requestStartProgress();    // progressTimer->start(UPDATE_INTERVAL_MS);
    ui->playPauseButton->setActive(result, false);
    return result;
}

void Playback::setPlayPauseButton(bool play)
{
    ui->playPauseButton->setActive(!play, false);
    ui->playPauseButton->clicked(play);
}

void Playback::setPlayStopButton()
{
    ui->stopButton->clicked(true);
}

void Playback::setPlayInfo(QString header, QString filePath)
{
    const int max_char_len = 125;
    QString filePath_abbrv;
    if (header.toUtf8().size() + filePath.toUtf8().size() < max_char_len)
        filePath_abbrv = filePath;
    else
    {
        QFileInfo fileInfo(filePath);
        QString fileName = fileInfo.fileName();
        QString path = fileInfo.path();
        int remainingLength = max_char_len - header.toUtf8().size() - fileName.toUtf8().size() - 5; /// 5 for ".../"
        if (remainingLength > 0)
        {
            QString abbreviatePath = path.left(remainingLength / 2) + "..." +
                                    path.right(remainingLength / 2);
            filePath_abbrv = abbreviatePath + "/" + fileName;
        }
        else
            filePath_abbrv = "..." + fileName.right(max_char_len - header.toUtf8().size() -3);
    }
    ui->lInfo->setText(QString("%1%2").arg(header).arg(filePath_abbrv));
}

QString Playback::getSourceString(int source)
{
    QString strSource;
    switch (source)
    {
    case SOURCE_VIDEO_FILE:   strSource = "file"; break;
    default:    strSource = "unknown";
    }
    return strSource;
}

bool Playback::isPlayable(const QString filePath, bool ifDialog, bool ifMsg)
{
#if GET_INFO_FROM_FRAMEWORK == 1
    MediaInfo *info = rtkGst->get_media_info_from_framework(filePath.toStdString());
    if (info->has_video) {
        if (info->decodable_v_count <= 0) {
            if (ifMsg)
                qDebug () << QString().asprintf("%s:%d File %s is over spec! Unable to play it !", 
                                    __FUNCTION__, __LINE__, filePath.toStdString().c_str());
            if (ifDialog)
                dialog->showError(QString().sprintf("File %s is over spec! Unable to play it !", filePath.toStdString().c_str()));
            return false;
        }
    }
#endif
    return true;
}

void Playback::play(const QString filepath, QWidget *gst_window, bool bFullscreen)
{
#if GET_INFO_FROM_FRAMEWORK == 1
    MediaInfo *info = rtkGst->get_media_info_from_framework(filepath.toStdString());
#else
    MediaInfo *info = rtkGst->get_media_info (filepath.toStdString());
#endif
    int x=0, y=0, width=0, height=0;
    if (bFullscreen)
    {
        x = y = 0;
        width = Config::sys.width;
        height = Config::sys.height;
    }
    else
    {
        x = Config::sys.playbackX;
        y = 0;
        width = Config::sys.playbackWidth;
        height = Config::sys.playbackHeight;
    }
    if(Config::sys.videoSink.startsWith("rtk") && Config::sys.videoSink.endsWith("sink"))
    {
        QString strSource = getSourceString(SOURCE_VIDEO_FILE);
        rtkGst->rtk_gst_play_multi(strSource, 0, filepath, gst_window, bFullscreen, x, y, width, height, true);

        if(rtkGst->if_platform_wayland == true &&
           rtkGst->if_wayland_bg_color_transparency == false)
            qDebug () << QString().asprintf("Error: Cannot display video for weston background is not transparent !!!", 
                                            Config::sys.videoSink.toStdString().c_str());
        else if(info->subtitle_format != "NONE")
            qDebug () << QString().asprintf("%s:%d Unsupport subtitle for %s !", 
                                __FUNCTION__, __LINE__, Config::sys.videoSink.toStdString().c_str());
    }
    else
        rtkGst->rtk_gst_play_new(filepath, gst_window, bFullscreen, x, y, width, height, true);

    if(Config::sys.playbackBlankEnable)
    {
        if (info->has_video)
            blankTimer->start();
    }

    // apply volume
    mute_changed(ui->muteButton->getActived());
}

void Playback::playAi(const QString filepath, QString selectedMode, bool bFullscreen)
{
#if GET_INFO_FROM_FRAMEWORK == 1
    MediaInfo *info = rtkGst->get_media_info_from_framework(filepath.toStdString());
#else
    MediaInfo *info = rtkGst->get_media_info (filepath.toStdString());
#endif
    AiParam param;
    param.yoloCaseCode = Config::aipath.yoloCaseCode;
    param.yoloNbg = Config::aipath.yoloNbg;
    param.yoloCoco = Config::aipath.yoloCoco;
    param.poseCaseCode = Config::aipath.poseCaseCode;
    param.poseNbg = Config::aipath.poseNbg;
    param.poseCoco = Config::aipath.poseCoco;
    param.mobilenetCaseCode = Config::aipath.mobilenetCaseCode;
    param.mobilenetNbg = Config::aipath.mobilenetNbg;
    param.mobilenetBoxPri = Config::aipath.mobilenetBoxPri;
    param.mobilenetCoco = Config::aipath.mobilenetCoco;
    param.facerecogScript = Config::aipath.facerecogScript;

    QStringList lstPath, lstName;
    QFile file;
    if (selectedMode == "yolov5") {
        lstPath << param.yoloCaseCode << param.yoloNbg << param.yoloCoco;
        lstName << QNAME(param.yoloCaseCode) << QNAME(param.yoloNbg) << QNAME(param.yoloCoco);
    } else if (selectedMode == "ssd_mobilenet") {
        lstPath << param.poseCaseCode << param.poseNbg << param.poseCoco;
        lstName << QNAME(param.poseCaseCode) << QNAME(param.poseNbg) << QNAME(param.poseCoco);
    } else if (selectedMode == "posenet") {
        lstPath << param.mobilenetCaseCode << param.mobilenetNbg << param.mobilenetBoxPri << param.mobilenetCoco;
        lstName << QNAME(param.mobilenetCaseCode) << QNAME(param.mobilenetNbg) << QNAME(param.mobilenetBoxPri) << QNAME(param.mobilenetCoco);
    } else if (selectedMode == "face_recognition") {
        lstPath << param.facerecogScript;
        lstName << QNAME(param.facerecogScript);
    } else {

    }
    bool param_ok = true;
    for(int i=0; i<lstPath.count() && i<lstName.count(); i++)
    {
        file.setFileName(lstPath.at(i));
        if(!file.exists())
        {
            qDebug() << QString("Error: The file %1 for %2 does not exist !")
                        .arg(lstName.at(i)).arg(lstPath.at(i));
            param_ok = false;
        }
    }
    if (param_ok != true)
        return;

    int x=0, y=0, width=0, height=0;
    if (bFullscreen)
    {
        x = y = 0;
        width = Config::sys.width;
        height = Config::sys.height;
    }
    else
    {
        x = Config::sys.playbackX;
        y = 0;
        width = Config::sys.playbackWidth;
        height = Config::sys.playbackHeight;
    }
    rtkGst->rtk_gst_play_ai(filepath, selectedMode, bFullscreen, x, y, width, height, &param, true);

    if(Config::sys.playbackBlankEnable)
    {
        if (info->has_video)
            blankTimer->start();
    }
}

void Playback::playCtrl_stop()
{
    if (Config::sys.playbackBlankEnable)
    {
        ui->wBlank->setVisible(true);
        ui->wBlank->repaint();
    }

    rtkGst->rtk_gst_play_free();
    ui->playPauseButton->setActive(false, false);

    progressTimer->stop();
    ui->progressBar->setValue(0);
    ui->currentTime->setText("00:00:00");
    ui->totalTime->setText("00:00:00");
    ui->lInfo->clear();
    playSpeedChanged = false;
    resetPlaySpeed();
}

void Playback::seekToPositionByRate(double rate) {
    if(ui->cameraAIButton->getActived())
    {
        qDebug () << QString().asprintf("%s:%d function only support video mode.", __FUNCTION__, __LINE__);
        return;
    }

    qDebug () << QString().asprintf("%s:%d rate: %lf", __FUNCTION__, __LINE__, rate);
    rtkGst->rtk_gst_seek_by_slider(rate);
    if (isSpeedChangeable() && playSpeed != 1)
        playSpeedChanged = true;
    else
        resetPlaySpeed();
}

// Seek by dragging the progress bar
void Playback::seekToPosition(int value) {
    double rate = value / 100.0;
    seekToPositionByRate (rate);
}

void Playback::seekToPositionByOffset(long long offset)
{
    if(ui->cameraAIButton->getActived()){
        qDebug () << QString().asprintf("%s:%d function only support video mode.", __FUNCTION__, __LINE__);
        return;
    }

    rtkGst->rtk_gst_seek_with_offset(offset);
    if (isSpeedChangeable() && playSpeed != 1)
        playSpeedChanged = true;
    else
        resetPlaySpeed();
}

void Playback::btnPlaySeekBack_clicked()
{
    seekToPositionByOffset(-10);
}

void Playback::btnPlaySeekFront_clicked()
{
    seekToPositionByOffset(10);
}

void Playback::btnPlayStop_clicked()
{
    if(ui->cameraAIButton->getActived()){
        qDebug() << "The Stop function only support video mode.";
        return;
    }

    playCtrl_stop();
}

void Playback::btnPlayRotation_clicked()
{
    if(ui->cameraAIButton->getActived() || ui->aiButton->getActived()){
        qDebug() << "The PlayRotation function only support video mode.";
        return;
    }

    rtkGst->rtk_gst_rotation();
}

void Playback::setPlayRotate()
{
    if (ui->rotateButton->isVisible() && ui->rotateButton->isEnabled())
        btnPlayRotation_clicked();
    else
        qDebug () << QString().asprintf("%s:%d Rotate is forbidden", __FUNCTION__, __LINE__); 
}

void Playback::btnPlayScreenshot_clicked()
{
    if(ui->cameraAIButton->getActived() || ui->aiButton->getActived()){
        qDebug() << "The PlayScreenshot function only support video mode.";
        return;
    }

    QString filePath;
    QListWidgetItem *currentItem = ui->lFileName->currentItem();
    if(currentItem) {
        filePath = currentItem->text();
    }
    auto [position, duration] = rtkGst->rtk_gst_getPlaybackPositionDuration();
    qDebug() << "btnPlayScreenshot_clicked(): " << position << " / " << formatTime(position) << " / " << formatTime(duration);
    if(!filePath.isEmpty() && position >= 0) {
        rtkGst->rtk_gst_screenshot(filePath ,position);
    }
}

void Playback::btnSlowDown_clicked()
{
    if(ui->cameraAIButton->getActived() || ui->aiButton->getActived()){
        qDebug() << "The SlowDown function only support video mode.";
        return;
    }

    double playSpeed_org = playSpeed;
    int index = speedLevels.indexOf(playSpeed);
    if (index > 0) {
        playSpeed = speedLevels[index - 1];
        updateSpeedLabel();
    }

    qDebug () << QString().asprintf("%s:%d speed: %0.2lf -> %0.2lf",
                                __FUNCTION__, __LINE__, playSpeed_org, playSpeed);
    rtkGst->rtk_gst_speedchange(playSpeed);
    playSpeedChanged = false;
}

void Playback::btnSpeedUp_clicked()
{
    if(ui->cameraAIButton->getActived() || ui->aiButton->getActived()){
        qDebug() << "The SpeedUp function only support video mode.";
        return;
    }

    double playSpeed_org = playSpeed;
    int index = speedLevels.indexOf(playSpeed);
    if (index < speedLevels.size() - 1) {
        playSpeed = speedLevels[index + 1];
        updateSpeedLabel();
    }

    qDebug () << QString().asprintf("%s:%d speed: %0.2lf -> %0.2lf",
                                __FUNCTION__, __LINE__, playSpeed_org, playSpeed);
    rtkGst->rtk_gst_speedchange(playSpeed);
    playSpeedChanged = false;
}

bool Playback::isSpeedChangeable()
{
    if (speedLevels.count() < 0)
        return false;
    if (ui->cameraAIButton->getActived() || ui->aiButton->getActived() ||
        !ui->slowDownButton->isEnabled() || !ui->speedUpButton->isEnabled())
        return false;
    return true;
}

void Playback::setPlaySpeed(double speed)
{
    double speed_candidate = playSpeed;
    if (isSpeedChangeable() != true)
    {
        qDebug () << QString().asprintf("%s:%d speed setting is forbidden", __FUNCTION__, __LINE__); 
        return;
    }
    double speed_min = speedLevels.at(0);
    double speed_max = speedLevels.at(speedLevels.count()-1);
    if (speed <= speed_min)
        speed_candidate = speed_min;
    else if (speed >= speed_max)
        speed_candidate = speed_max;
    else
    {
        speed_candidate = speed_min;
        for (int i=1; i<speedLevels.count(); i++)
        {
            if (speed == speedLevels[i])
            {
                speed_candidate = speedLevels[i];
                break;
            }
            else if (speed > speedLevels[i])
                speed_candidate = speedLevels[i];
            else
            {
                // find the nearest speed
                double speed_diff1 = speed - speedLevels[i-1];
                double speed_diff2 = speedLevels[i] - speed;
                speed_candidate = (speed_diff1 < speed_diff2) ? speedLevels[i-1] : speedLevels[i];
                break;
            }
        }
    }

    if (speed != speed_candidate)
        qDebug () << QString().asprintf("%s:%d speed: %0.2lf -> set %0.2lf -> %0.2lf",
                                    __FUNCTION__, __LINE__, playSpeed, speed, speed_candidate);
    else
        qDebug () << QString().asprintf("%s:%d speed: %0.2lf -> %0.2lf",
                                    __FUNCTION__, __LINE__, playSpeed, speed_candidate);
    if (playSpeed != speed_candidate)
    {
        playSpeed = speed_candidate;
        updateSpeedLabel();
    }
    rtkGst->rtk_gst_speedchange(playSpeed);
    playSpeedChanged = false;
}

double Playback::getSpeedByRandomIdx(int randIdx)
{
    int idx;
    if (randIdx < 0)
    {
        srand(time(NULL));
        randIdx = rand();
    }

    idx = randIdx % speedLevels.count();
    return speedLevels[idx];
}

void Playback::btnSettings_clicked()
{
    selectVideo->setVisible(false);
    setting->setVisible(true);
    setting->raise();
}

void Playback::updateSpeedLabel() {
    QString speedText;
    // If playSpeed is an integer, remove the decimal point
    if (playSpeed == static_cast<int>(playSpeed)) {
        speedText = QString::number(static_cast<int>(playSpeed)) + "x";
    } else {
        speedText = QString::number(playSpeed, 'f', 2) + "x"; // Keep 2 decimal places
    }
    speedLabel->setText(speedText);
    //qDebug() << "Speed changed to:" << speedText;
}

// Query the current playback position and duration from GStreamer
void Playback::updateProgress() {
    auto [position, duration] = rtkGst->rtk_gst_getPlaybackPositionDuration();

    if (duration > 0) {
        int progressValue = static_cast<int>((position * 100) / duration);
        ui->progressBar->setValue(progressValue);

        if (playSeekRateChanged)
        {
            rtkGst->rtk_gst_seek_by_slider(playSeekRate);
            playSeekRateChanged = false;
        }
        else // for timing issue, we can only set seek rate or speed individually in different round
        if (playSpeedChanged)
        {
            rtkGst->rtk_gst_speedchange(playSpeed);
            updateSpeedLabel();
            playSpeedChanged = false;
        }
    }

    // Convert the time format and update the UI
    ui->currentTime->setText(formatTime(position));
    ui->totalTime->setText(formatTime(duration));

    char buffer[100];
    int bytesRead;
    if ((bytesRead = read(g_pipefd[0], buffer, sizeof(buffer) - 1)) != -1) {
        if (bytesRead > 0) {
            buffer[bytesRead] = '\0';
            qDebug() << "pipe read: " << buffer;

            if (strcmp(buffer, "GST_MESSAGE_EOS") == 0) {
                playCtrl_stop();
                playCtrl_next();
            }
        }
    }
}

void Playback::startProgress() {
    // qDebug() << QString().sprintf("%s:%d", __FUNCTION__, __LINE__);
    progressTimer->start(UPDATE_INTERVAL_MS);
}

void Playback::stopProgress() {
    // qDebug() << QString().sprintf("%s:%d", __FUNCTION__, __LINE__);
    progressTimer->stop();
}

// Reset playSpeed
void Playback::resetPlaySpeed() {
    playSpeed = 1;
    updateSpeedLabel();
}

// Convert nanoseconds to HH:MM:SS format
QString Playback::formatTime(qint64 timeNano) {
    if (timeNano <= 0) {
        return "00:00:00";
    }

    // Convert to milliseconds (1 nanosecond = 1/1,000,000 milliseconds)
    qint64 totalMilliseconds = timeNano / 1000000;

    // Calculate hours, minutes, and seconds
    int totalSeconds = static_cast<int>(totalMilliseconds / 1000);
    int hours = totalSeconds / 3600;
    int minutes = (totalSeconds % 3600) / 60;
    int seconds = totalSeconds % 60;

    return QString("%1:%2:%3")
        .arg(hours, 2, 10, QChar('0'))
        .arg(minutes, 2, 10, QChar('0'))
        .arg(seconds, 2, 10, QChar('0'));

}

void Playback::btnPlayPrev_clicked()
{
    if(ui->cameraAIButton->getActived()){
        qDebug() << "The PlayPrev function only support video mode.";
        return;
    }

    playCtrl_stop();
    playCtrl_prev();
}

void Playback::btnPlayNext_clicked()
{
    if(ui->cameraAIButton->getActived()){
        qDebug() << "The PlayNext function only support video mode.";
        return;
    }

    playCtrl_stop();
    playCtrl_next();
}

void Playback::btnPlayShuffle_clicked()
{
    //qDebug() << "btnPlayShuffle_clicked: " << ui->shuffleButton->getActived();
    if(ui->cameraAIButton->getActived()){
        qDebug() << "The PlayShuffle function only support video mode.";
        return;
    }

    if(ui->shuffleButton->getActived())
    {
        updateShuffleIndexList();
    }
    else
    {
        mutexShuffle.lock();
        shuffleIndexList.clear();
        mutexShuffle.unlock();
        qDebug() << "shuffleIndexList cleared" << shuffleIndexList;
    }
}


void Playback::playCtrl_next()
{
    int currentIndex = ui->lFileName->currentRow();

    if(ui->shuffleButton->getActived())
    {
        int shuffleIndex = -1;
        mutexShuffle.lock();
        shuffleIndexList.removeOne(currentIndex);
        if(!shuffleIndexList.isEmpty()) {
            shuffleIndex = shuffleIndexList.takeFirst();
        }
        mutexShuffle.unlock();
        if (shuffleIndex >= 0)
        {
            qDebug() << "pop shuffle Index: " << shuffleIndex;

            if(shuffleIndex <  ui->lFileName->count())
            {
                ui->lFileName->setCurrentRow(shuffleIndex);
                ui->playPauseButton->setActive(true, false);
                playCtrl_action();
            }
        }
    }
    else if(currentIndex <  ui->lFileName->count() - 1)
    {
        ui->lFileName->setCurrentRow(currentIndex + 1);
        ui->playPauseButton->setActive(true, false);
        playCtrl_action();
    }
    else if(ui->repeatButton->getActived()) //Check if repeat button actived
    {
        ui->lFileName->setCurrentRow(0);
        ui->playPauseButton->setActive(true, false);
        playCtrl_action();
    }
}

void Playback::playCtrl_prev()
{
    int currentIndex = ui->lFileName->currentRow();

    if(currentIndex > 0)
    {
        ui->lFileName->setCurrentRow(currentIndex - 1);

        ui->playPauseButton->setActive(true, false);
        playCtrl_action();
    }
}

void Playback::updateShuffleIndexList()
{
    mutexShuffle.lock();
    shuffleIndexList.clear();

    for(int i=0; i<ui->lFileName->count(); i++)
        shuffleIndexList.append(i);

    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(shuffleIndexList.begin(), shuffleIndexList.end(), g);

    mutexShuffle.unlock();
    qDebug() << "shuffleIndexList" << shuffleIndexList;
}

void Playback::checkIfUpdateShuffleIndexList(bool listChanged)
{
    if (listChanged != true)
        return;
    if (ui->shuffleButton->getActived() && ui->playPauseButton->getActived())
    {
        updateShuffleIndexList();
    }
}

void Playback::btnPlayFullScreen_clicked()
{
    setPlayFullscreen (true);
}

void Playback::returnFromFullscreen()
{
    setPlayFullscreen (false);
}

bool Playback::isPlayFullscreen()
{
    return playIfFullscreen;
}

void Playback::setPlayFullscreenButton()
{
    ui->fullscreenButton->click();
}

void Playback::setPlayFullscreen(bool bFullscreen)
{
    QString videoDevice = rtkGst->rtk_gst_findVideoUnderMedia();
    double seekRate = 0;
    double playSpeed_org = playSpeed;
    auto [position, duration] = rtkGst->rtk_gst_getPlaybackPositionDuration();
    if (duration > 0) {
        seekRate = static_cast<double>(position) / duration;
    }

    playCtrl_stop();

    // Logic for playing video
    QListWidgetItem *currentItem = ui->lFileName->currentItem();
    if(ui->cameraAIButton->getActived()) {
        //run show camera AI
        if (videoDevice.isEmpty())
            return;

        playAi(videoDevice, setSystem->strAiMode, bFullscreen);
        ui->playPauseButton->setActive(true, false);
    } else if(currentItem) {
        QString filePath = currentItem->text();
        qDebug() << QString().sprintf("%s:%d filePath: %s", __FUNCTION__, __LINE__, filePath.toStdString().c_str());
        if (isPlayable(filePath, true, true) != true)
            return;
        if(ui->aiButton->getActived())
            playAi(filePath, setSystem->strAiMode, bFullscreen);
        else
            play(filePath, ui->videoDisplay, bFullscreen);
        if(this->isVisible() != true)
            ui->playPauseButton->setActive(true, false);
        setPlayInfo(QString("%1 / %2 => ")
                        .arg(ui->lFileName->currentRow()+1)
                        .arg(ui->lFileName->count()), filePath);
        if (seekRate > 0) {
            playSeekRate = seekRate;
            playSeekRateChanged = true;
        }
        if (isSpeedChangeable() && playSpeed_org != 1)
        {
            playSpeed = playSpeed_org;
            playSpeedChanged = true;
        }
        else
            resetPlaySpeed();
    }

    if (setSystem->strAiMode != "face_recognition")
        emit requestStartProgress();    // progressTimer->start(UPDATE_INTERVAL_MS);

    this->setVisible(!bFullscreen);
    playIfFullscreen = bFullscreen;
}

void Playback::btnPlayAi_clicked()
{
    if(ui->cameraAIButton->getActived()){
        qDebug() << "The PlayAi function only support video mode.";
        ui->aiButton->setActive(false, false);
        return;
    }
    if (Config::sys.videoSink != _STR_WAYLANDSINK_)
    {
        qDebug() << QString().sprintf("Error: The PlayAi function only support %s, not support %s !",
                                      _STR_WAYLANDSINK_, Config::sys.videoSink.toStdString().c_str());
        ui->aiButton->setActive(false, false);
        return;
    }
    QListWidgetItem *currentItem = ui->lFileName->currentItem();

    double seekRate = 0;
    double playSpeed_org = playSpeed;
    auto [position, duration] = rtkGst->rtk_gst_getPlaybackPositionDuration();
    qDebug() << QString().sprintf("%s:%d position: %ld, duration: %ld", __FUNCTION__, __LINE__, position, duration);
    if (duration > 0)
        seekRate = static_cast<double>(position) / duration;
    else
    {
        if (ui->playPauseButton->getActived() != true && playSpeed != 1)
            resetPlaySpeed();
        return;
    }

    playCtrl_stop();

    // Logic for playing video
    if(currentItem) {
        QString filePath = currentItem->text();
        qDebug() << QString().sprintf("%s:%d filePath: %s", __FUNCTION__, __LINE__, filePath.toStdString().c_str());
        if (isPlayable(filePath, true, true) != true)
            return;
        if(ui->aiButton->getActived())
            playAi(filePath, setSystem->strAiMode, playIfFullscreen);
        else
            play(filePath, ui->videoDisplay, playIfFullscreen);
        ui->playPauseButton->setActive(true, false);
        setPlayInfo(QString("%1 / %2 => ")
                        .arg(ui->lFileName->currentRow()+1)
                        .arg(ui->lFileName->count()), filePath);
        if (seekRate > 0) {
            playSeekRate = seekRate;
            playSeekRateChanged = true;
        }
        if (isSpeedChangeable() && playSpeed_org != 1)
        {
            playSpeed = playSpeed_org;
            playSpeedChanged = true;
        }
        else
            resetPlaySpeed();
        emit requestStartProgress();    // progressTimer->start(UPDATE_INTERVAL_MS);
    }
}

void Playback::btnPlayCameraAi_clicked()
{
    if(ui->cameraAIButton->getActived()){
        QString videoDevice = rtkGst->rtk_gst_findVideoUnderMedia();
        //run show camera AI
        if (videoDevice.isEmpty())
            return;

        playAi(videoDevice, setSystem->strAiMode, playIfFullscreen);
        ui->playPauseButton->setActive(true, playIfFullscreen);

        if (setSystem->strAiMode != "face_recognition")
            emit requestStartProgress();    // progressTimer->start(UPDATE_INTERVAL_MS);
    }
    else {
        //stop show camera AI
        playCtrl_stop();
    }
}

void Playback::listWidgetFileName_changed()
{
    QListWidgetItem *currentItem = ui->lFileName->currentItem();

    playCtrl_stop();

    if(currentItem)
    {
        string filePath = currentItem->text().toStdString();
#if GET_INFO_FROM_FRAMEWORK == 1
        MediaInfo *info = rtkGst->get_media_info_from_framework(filePath);
#else
        MediaInfo *info = rtkGst->get_media_info (filePath);
#endif
        if (!info->already_get_info || info->file_path != filePath)
            qDebug () << QString().asprintf("%s:%d get media info fail !", __FUNCTION__, __LINE__);

        if (info->enable_video_speed_change)
        {
            ui->slowDownButton->setEnabled(false);
            ui->speedUpButton->setEnabled(false);
        } else {
            ui->slowDownButton->setEnabled(true);
            ui->speedUpButton->setEnabled(true);
        }

        if (info->enable_video_rotate)
        {
            ui->rotateButton->setVisible(true);
        } else {
            ui->rotateButton->setVisible(false);
        }
    }
#if GET_INFO_FROM_FRAMEWORK == 1
    if (setSystem->isVisible())
    {
        QShowEvent *event = new QShowEvent();
        QApplication::postEvent(setSystem, event);
    }
#endif
}

int Playback::getIdxOfListForSpecificVideo(QString filePath)
{
    QListWidgetItem *item;
    for (int i=0; i<ui->lFileName->count(); i++)
    {
        item = ui->lFileName->item(i);
        if(item->text() == filePath)
        {
            return i;
        }
    }
    return -1;
}

bool Playback::selectSpecificVideoInList(QString filePath)
{
    QListWidgetItem *item;
    for (int i=0; i<ui->lFileName->count(); i++)
    {
        item = ui->lFileName->item(i);
        if(item->text() == filePath)
        {
            ui->lFileName->setCurrentRow(i);
            return true;
        }
    }
    return false;
}

void Playback::face_recog_keyboard_input(QString input)
{
    rtkGst->rtk_gst_face_recog_keyboard_input(input);
}

bool Playback::is_face_recog_running()
{
    return rtkGst->rtk_gst_is_face_recog_running();
}