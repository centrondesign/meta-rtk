/**
 * @file test.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2025
 * @brief The widget page to do testing
 */

#include "test.h"
#include "ui_test.h"
#include "mainwidget.h"
#include "rtkgst.h"
#include <regex>

#define STR_PAUSE_RESUME    "Pause / Resume"
#define STR_ROTATE          "Rotate"
#define STR_SEEK            "Seek"
#define STR_SPEED           "Speed"
#define STR_FULLSCREEN      "Fullscreen"
#define STR_MUTE_UNMTE      "Mute / Unmute"
#define STR_VOLUME          "Volume"

#define STEP                100

/**************/
/* class TestThread
/**************/
TestThread::TestThread()
{
    bRun = false;
}

TestThread::~TestThread()
{
    bRun = false;
}

void TestThread::setStart()
{
    setStop();
    this->start();
}

void TestThread::setStop()
{
    bRun = false;
    for (int i=0; i<Config::sys.testInterval; i+=STEP)
    {
        if (this->isRunning())
            this->msleep(STEP);
        else
            break;
    }
}

void TestThread::run()
{
    QDateTime dateTime;
    bRun = true;

    playback->setPlayStopButton();
    this->msleep(STEP);

    // start current play
    playback->setPlayPauseButton(true);
    this->msleep(STEP);

    while(bRun)
    {
        setTest->updateSelectedItemList();
        if (setTest->selectedItemList.count() <= 0)
        {
            this->msleep(STEP);
            continue;
        }
        dateTime = QDateTime::currentDateTime();
        int ms = dateTime.toMSecsSinceEpoch() % 1000;
        srand(time(NULL));
        int random = rand() + ms;
        int idx = random % setTest->selectedItemList.count();
        QString strItem = setTest->selectedItemList.at(idx);

        if (strItem == STR_PAUSE_RESUME)
        {
            if (random % 2 == 0)
                playback->setPlayPaused();
            else
                playback->setPlayResumed();
        }
        else if (strItem == STR_ROTATE)
        {
            playback->setPlayRotate();
        }
        else if (strItem == STR_SEEK)
        {
            double rate = ((double)(random % 90))/100.0;
            playback->seekToPositionByRate(rate);
        }
        else if (strItem == STR_SPEED)
        {
            double speed = playback->getSpeedByRandomIdx(random);
            playback->setPlaySpeed(speed);
        }
        else if (strItem == STR_FULLSCREEN)
        {
            if (playback->isPlayFullscreen())
            {
                emit playback->requestReturnFromFullscreen();
            }
            else
            {
                playback->setPlayFullscreenButton();
            }
        }
        else if (strItem == STR_MUTE_UNMTE)
        {
            if (random % 2 == 0)
                playback->setMute();
            else
                playback->setUnmute();
        }
        else if (strItem == STR_VOLUME)
        {
            playback->setVolume(random % 100);
        }

        int step = STEP;
        for (int i=0; i<Config::sys.testInterval; i+=STEP)
        {
            if (!bRun)
                break;
            if (i + STEP >= Config::sys.testInterval)
                step = (Config::sys.testInterval - i);
            else
                step = STEP;

            this->msleep (step);
        }
    }

    playback->setPlayStopButton();
    this->msleep(STEP);
}

void TestThread::finalize()
{
    bRun = false;
    while (this->isRunning())
    {
        this->msleep(STEP);
    }
}

/**************/
/* class Test
/**************/
Test::Test(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Test)
{
    ui->setupUi(this);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;

    ui->lTest->setStyleSheet(STYLESHEET_TITLE_2);

    ui->gpbTestItems->setStyleSheet("color: rgb(69, 77, 77);"
                                    "font: bold 20px \"Arial Black\";");

    // QList<QComboBox*> optionList = {ui->cbAiMode};
    // foreach(QComboBox *cb, optionList)
    // {
    //     cb->setStyleSheet(STYLESHEET_COMBOBOX);
    // }
    lFileName = NULL;
    bSelectChanged = false;
    // videoDisplay = NULL;

    connect(ui->tbSelectAll, SIGNAL(clicked(bool)), this, SLOT(test_select_all_clicked(bool)));
    connect(ui->tbClearAll, SIGNAL(clicked(bool)), this, SLOT(test_clear_all_clicked(bool)));
    connect(ui->tbStart, SIGNAL(clicked(bool)), this, SLOT(test_start_clicked(bool)));
    connect(ui->tbStop, SIGNAL(clicked(bool)), this, SLOT(test_stop_clicked(bool)));
    connect(ui->tbHide, SIGNAL(clicked(bool)), this, SLOT(test_hide_clicked(bool)));
}

Test::~Test()
{
    delete ui;
}

void Test::setup()
{
    ui->chkPauseResume->setText(STR_PAUSE_RESUME);
    ui->chkRotate->setText(STR_ROTATE);
    ui->chkSeek->setText(STR_SEEK);
    ui->chkSpeed->setText(STR_SPEED);
    ui->chkFullscreen->setText(STR_FULLSCREEN);
    ui->chkMuteUnmute->setText(STR_MUTE_UNMTE);
    ui->chkVolume->setText(STR_VOLUME);
    labelList->append({ui->lTestInterval, ui->lTestIntervalUnit});
    editList->append(ui->leTestInterval);
    itemList.append({ui->chkPauseResume, ui->chkRotate, ui->chkSeek, ui->chkSpeed, ui->chkFullscreen,
                    ui->chkMuteUnmute, ui->chkVolume});
    actionList->append({ui->tbSelectAll, ui->tbClearAll, ui->tbStart, ui->tbStop, ui->tbHide});
    checkList->append(itemList);

    ui->leTestInterval->setValueRange(ui->lTestInterval, 0, 60000, 0);
    connect(ui->leTestInterval, SIGNAL(editingFinished()), this, SLOT(test_interval_changed()));

    foreach(RCheckBox *chk, itemList)
    {
        connect(chk, SIGNAL(clicked(bool)), this, SLOT(test_select_changed(bool)));
    }
}

void Test::initValue(bool fromStatus)
{
    // qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);
    ui->leTestInterval->setText(Config::sys.testInterval);
}

void Test::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);
}

void Test::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void Test::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void Test::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    QList<RLineEdit *>keyboardList = {};
    QList<RLineEdit *>keybadList = {ui->leTestInterval};
    RLineEdit *le;
    foreach(le, keyboardList)
    {
        le->installEventFilter(keyboard);
    }
    foreach(le, keybadList)
    {
        le->installEventFilter(keypad);
    }
}

void Test::showEvent(QShowEvent *)
{
    initValue(true);
}

// bool Test::eventFilter(QObject *o, QEvent *e)
// {
//     if(e->type() == QEvent::Show)
//     {
//         if(o==ui->pgCurrent ||
//            o==ui->pgFormat ||
//            o==ui->pgImage ||
//            o==ui->pgBg ||
//            o==ui->pgFb ||
//            o==ui->pgOutput ||
//            o==ui->pgAdmin)
//         {
//             initValue(true);
//         }
//     }
//     return QObject::eventFilter(o, e);
// }

void Test::setFileNameList(QListWidget *list)
{
    lFileName = list;
}

#if 0
void Test::setVideoDisplay(QWidget *widget)
{
    videoDisplay = widget;
}
#endif

void Test::updateSelectedItemList()
{
    if (bSelectChanged != true)
        return;
    mutexChange.lock();
    selectedItemList.clear();
    foreach(RCheckBox *chk, itemList)
    {
        if (chk->isChecked())
            selectedItemList.append(chk->getText());
    }
    bSelectChanged = false;
    // qDebug() << selectedItemList;
    mutexChange.unlock();
}

void Test::selectAllItems(bool selected)
{
    foreach(RCheckBox *chk, itemList)
    {
        chk->setChecked(selected);
    }
    mutexChange.lock();
    bSelectChanged = true;
    mutexChange.unlock();
}

void Test::test_select_all_clicked(bool)
{
    selectAllItems(true);
}

void Test::test_clear_all_clicked(bool)
{
    selectAllItems(false);
}

void Test::test_select_changed(bool)
{
    mutexChange.lock();
    bSelectChanged = true;
    mutexChange.unlock();
}

void Test::test_start_clicked(bool)
{
    bool ifFileExist = false;

    QString filePath = "";
    QListWidgetItem *currentItem = lFileName->currentItem();
    if(currentItem)
    {
        filePath = currentItem->text();
        QFileInfo fileInfo(filePath);
        if (fileInfo.exists() && fileInfo.isFile())
        {
            ifFileExist = true;
        }
    }

    if (ifFileExist != true)
    {
        qDebug () << QString().asprintf("%s:%d Fail to Load File %s !", 
                            __FUNCTION__, __LINE__, 
                            filePath.toStdString().c_str());
        dialog->showError(QString().sprintf("Fail to Load File %s !", filePath.toStdString().c_str()));
        return;
    }
    testThrad.setStart();
}

void Test::test_stop_clicked(bool)
{
    testThrad.setStop();
}

void Test::test_hide_clicked(bool)
{
    setting->setVisible(false);
}

void Test::test_interval_changed()
{
    Config::sys.testInterval = ui->leTestInterval->getValue();
}
