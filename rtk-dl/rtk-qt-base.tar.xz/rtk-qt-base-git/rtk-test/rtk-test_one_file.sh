#!/bin/bash
# @author Realtek Semiconductor Corp.
# @date Sep 2025
# @brief The script to do automation test of rtk player
# @input: video file path
# @output: console output

PLAYER_NAME="rtk-playback"
# VIDEO_LIST_TMP="/usr/bin/$PLAYER_NAME/video_list.tmp"
# LOG_DIR="/usr/bin/rtk-test/logs"
# CURRENT_TIME=$(date '+%Y_%m%d_%H%M%S')
# VIDEO_LIST="${LOG_DIR}/${CURRENT_TIME}_video_list.log"
# PASS_LIST="${LOG_DIR}/${CURRENT_TIME}_pass_list.log"
# FAIL_LIST="${LOG_DIR}/${CURRENT_TIME}_fail_list.log"
# FAIL_RECORDS="${LOG_DIR}/${CURRENT_TIME}_fail_records.log"
TEST_CMD="/usr/bin/rtk-test/rtk-test"
# mkdir -p "$LOG_DIR"
# rm -fr "$VIDEO_LIST"
# rm -fr "$PASS_LIST"
# rm -fr "$FAIL_LIST"

# get script name as header
HEADER="$(basename "$0") :"
HEADER_Error="$(basename "$0") Error:"
HEADER_Fail="$(basename "$0") Fail:" # header for test fail

# flags for the usage of different process, we need to clear the flags first
FLAG_REQ_FINALIZE="/tmp/rtk_test.req_finalized.flag"
FLAG_REQ_RESTART="/tmp/rtk_test.req_restart.flag"
FLAG_PLAYER_READY="/tmp/rtk_test.player_ready.flag"
FLAG_GET_EOS="/tmp/rtk_test.get_eos.flag"
FLAG_GET_ROTATE_FORBIDDEN="/tmp/rtk_test.get_rotate_forbidden.flag"
FLAG_GET_SPEED_FORBIDDEN="/tmp/rtk_test.get_speed_forbidden.flag"
FLAG_RESULT_FAIL="/tmp/rtk_test.result_fail.flag"
REC_RESULT_FAIL="/tmp/rtk_test.result_fail.rec"
rm -fr "$FLAG_REQ_FINALIZE"
rm -fr "$FLAG_REQ_RESTART"
rm -fr "$FLAG_PLAYER_READY"
rm -fr "$FLAG_GET_EOS"
rm -fr "$FLAG_GET_ROTATE_FORBIDDEN"
rm -fr "$FLAG_GET_SPEED_FORBIDDEN"
rm -fr "$FLAG_RESULT_FAIL"
rm -fr "$REC_RESULT_FAIL"

# timeout
TIMEOUT_PLAYER_STARTTIME=30

player_pid=0
is_player_alive=0

#==================================================================
# Please modify /usr/bin/rtk-playback/config.ini to set
# 1. videoFileFilter to filter valid files
#==================================================================

#==================================================================
# Check the input parameter
#==================================================================
# if [ ! -d "$1" ] && [ ! -f "$1" ]; then
#     echo "$HEADER_Error $1 should be directory path or file path for the list of video paths inside ..."
#     exit 1
# fi
if [ ! -f "$1" ]; then
    echo "$HEADER_Error $1 should be the video file !"
    exit 1
fi


#==================================================================
# Init rtk player
#==================================================================
endPlayer() {
    local i=0
    touch "$FLAG_REQ_FINALIZE"
    local pid=$(pgrep $PLAYER_NAME | head -n 1)
    if [ -n "$pid" ]; then
        # use command to end player normally
        $TEST_CMD "--EndServer"

        # wait for memory release and weston restart
        i=0
        while [ "$i" -lt 5 ]; do
            i=$((i + 1))
            echo "$HEADER end $PLAYER_NAME, wait $i"
            sleep 1
        done
    fi
    pid=$(pgrep $PLAYER_NAME | head -n 1)
    if [ -n "$pid" ]; then
        echo "$HEADER kill $PLAYER_NAME pid $id"
        # delete old pid by sorting with large to samll
        pids=$(pgrep $PLAYER_NAME | sort -nr)
        kill $pids

        # wait for memory release and weston restart
        i=0
        while [ "$i" -lt 5 ]; do
            i=$((i + 1))
            echo "$HEADER kill $PLAYER_NAME, wait $i"
            sleep 1
        done
    fi
    sleep 1
    rm -fr "$FLAG_REQ_FINALIZE"
}

startAndMonitorRtkPlayer() {
    local i=0
    local playback_pid=65535

    # start new player and parsing
    echo "$HEADER /usr/bin/$PLAYER_NAME/$PLAYER_NAME --platform wayland &"
    /usr/bin/$PLAYER_NAME/$PLAYER_NAME --platform wayland 2>&1 | while read -r line; do
        echo "$line"
        if [[ "$line" == *"CmdSrv:"*"started"*"Listening on port"* ]]; then
            # commandserver.cpp log
            echo "$HEADER $PLAYER_NAME is ready"
            touch "$FLAG_PLAYER_READY"
        elif [[ "$line" == *"Resource not found"* ]]; then
            # gstreamer log
            echo "$HEADER_Fail Resource not found"
            echo "Resource not found" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
        elif [[ "$line" == *"can't find space for allocating"* ]]; then
            # dma log: dma_rheap_alloc can't find space for allocating
            echo "$HEADER_Fail can't find space for allocating"
            echo "can't find space for allocating" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
        elif echo "$line" | grep -Eiq 'Failed to allocate'; then
            # gstreamer log: ERROR Failed to allocate required memory. for
            # system log: failed to allocate buf_obj buffer
            # [VDEC]  *ERROR* allocate body fail, No Memory
            echo "$HEADER_Fail Failed to allocate"
            echo "Failed to allocate" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
        elif [[ "$line" == *"streaming stopped, reason error (-5)"* ]]; then
            # gstreamer log
            echo "$HEADER_Fail found \"streaming stopped, reason error (-5)\""
            echo "streaming stopped, reason error (-5)" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
        elif [[ "$line" == *"Internal data stream error"* ]]; then
            # gstreamer log
            echo "$HEADER_Fail found \"Internal data stream error\""
            echo "Internal data stream error" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
        elif [[ "$line" == *"Audio ROS Unexpected interrupt error"* ]]; then
            # log: FATAL: Audio ROS Unexpected interrupt error!!
            echo "$HEADER_Fail Audio ROS Unexpected interrupt error"
            echo "Audio ROS Unexpected interrupt error" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
        elif [[ "$line" == *"AudioVersion"* ]]; then
            # AFW log: AudioVersion:8e7d24c191a292777cf355d8189255ff89049ddd
            echo "$HEADER_Fail AudioVersion"
            echo "AudioVersion" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
        # elif [[ "$line" == *"Too old frames, bug in decoder"* ]]; then
        #     # decoder log: Too old frames, bug in decoder - please file a bug
        #     echo "$HEADER_Fail found \"Too old frames, bug in decoder\""
        #     echo "Too old frames, bug in decoder" >> $REC_RESULT_FAIL
        #     touch "$FLAG_RESULT_FAIL"
        elif [[ "$line" == *"Failed to retrieve current position"* ]]; then
            # rtkgst.cpp log
            echo "$HEADER_Fail Failed to retrieve current position"
            echo "Failed to retrieve current position" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
        elif [[ "$line" == *"CmdSrv"*"File over spec"* ]]; then
            # commandserver.cpp log
            echo "$HEADER_Fail File over spec"
            echo "File over spec" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
        elif [[ "$line" == *"CmdSrv"*"File does not exist"* ]] || \
             [[ "$line" == *"CmdSrv"*"Fail to select file in list"* ]]; then
            # commandserver.cpp log
            echo "$HEADER_Fail File does not exist"
            echo "File does not exist" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
        elif [[ "$line" == *"CmdSrv"*"Unknown cmd"* ]]; then
            # commandserver.cpp log
            echo "$HEADER_Fail Unknown cmd"
            echo "Unknown cmd" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
        elif [[ "$line" == *"CmdSrv"*"insufficient parameters"* ]]; then
            # commandserver.cpp log
            echo "$HEADER_Fail insufficient parameters"
            echo "insufficient parameters" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
        elif [[ "$line" == *"GST_MESSAGE_EOS"* ]]; then
            # rtkgst.cpp log, stream already finished normally
            echo "$HEADER GST_MESSAGE_EOS"
            touch "$FLAG_GET_EOS"
        elif [[ "$line" == *"End of stream reached"* ]]; then
            # rtkgst.cpp log, stream already finished normally
            echo "$HEADER End of stream reached"
            touch "$FLAG_GET_EOS"
        elif echo "$line" | grep -Eiq 'is forbidden'; then
            # playback.cpp log, stream already finished normally
            if echo "$line" | grep -Eiq 'Rotate'; then
                echo "$HEADER found rotate forbidden"
                touch "$FLAG_GET_ROTATE_FORBIDDEN"
            elif echo "$line" | grep -Eiq 'speed'; then
                echo "$HEADER found speed forbidden"
                touch "$FLAG_GET_SPEED_FORBIDDEN"
            fi
        fi
        if [ -f "$FLAG_REQ_FINALIZE" ]; then
            echo "$HEADER finalize $PLAYER_NAME output"
            break;
        fi
    done &

    # clear the flag as FLAG_REQ_RESTART=0
    rm -f "$FLAG_REQ_RESTART"

    # Sometimes we meet "The Wayland connection broke. Did the Wayland compositor die?"
    # just after 15 seconds when Rtk Player fail to start
    while [ ! -f "$FLAG_PLAYER_READY" ] && [ "$i" -lt "$TIMEOUT_PLAYER_STARTTIME" ]; do
        i=$((i + 1))
        echo "$HEADER wait $PLAYER_NAME ready $i"
        sleep 1
    done

    if [ ! -f "$FLAG_PLAYER_READY" ]; then
        echo "$HEADER_Error $PLAYER_NAME is not ready !!!"
    else    # $! get the prior background pid, but may not correctly playback pid in multi process
        # player_pid=$!
        player_pid=$(pgrep $PLAYER_NAME | head -n 1)
        echo "$HEADER $PLAYER_NAME pid: $player_pid"
    fi
}

restartRtkPlayer() {
    rm -fr "$FLAG_PLAYER_READY"
    endPlayer
    startAndMonitorRtkPlayer
}

# And then run player
restartRtkPlayer

#============================================================================================
# Run rtk test and check restart Rtk player first
#============================================================================================
checkRtkPlayerAlive() {
    if [ "$player_pid" -gt 0 ]; then
        if kill -0 "$player_pid" 2>/dev/null; then
            is_player_alive=1
        else
            echo "$HEADER_Error $PLAYER_NAME pid $player_pid is not alive => restart $PLAYER_NAME"
            is_player_alive=0
        fi
    else
        is_player_alive=0
    fi
}

runTest() {
    local cmd="$1"
    local sec="$2"
    local i=0

    i=0
    checkRtkPlayerAlive
    while [ -f "$FLAG_REQ_RESTART" ] || [ ! -f "$FLAG_PLAYER_READY" ] || [ "$is_player_alive" -le 0 ]; do
        restartRtkPlayer
        checkRtkPlayerAlive
        if [ "$i" -lt "$TIMEOUT_PLAYER_STARTTIME" ]; then
            i=$((i + 1))
        fi
        sleep "$i"
    done

    $TEST_CMD $cmd 2>&1 | while read -r line; do
        echo "$line"
        if echo "$line" | grep -Eq 'No response from server'; then
            echo "$HEADER_Fail No response from server"
            echo "No response from server" >> $REC_RESULT_FAIL
            #touch "$FLAG_REQ_RESTART"
            touch "$FLAG_RESULT_FAIL"
            break;
        elif echo "$line" | grep -Eq 'Cannot connect to server'; then
            echo "$HEADER_Fail Cannot connect to server"
            echo "Cannot connect to server" >> $REC_RESULT_FAIL
            #touch "$FLAG_REQ_RESTART"
            touch "$FLAG_RESULT_FAIL"
            break;
        elif echo "$line" | grep -Eq 'Directory does not exist'; then
            echo "$HEADER_Fail Directory does not exist"
            echo "Directory does not exist" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
            break;
        elif echo "$line" | grep -Eq 'File does not exist'; then
            echo "$HEADER_Fail File does not exist"
            echo "File does not exist" >> $REC_RESULT_FAIL
            touch "$FLAG_RESULT_FAIL"
            break;
        fi
    done

    # sleep seconds
    i=0
    while [ "$sec" -gt "$i" ] && [ ! -f "$FLAG_RESULT_FAIL" ] && [ ! -f "$FLAG_GET_EOS" ]; do
        sleep 1
        # echo "$HEADER $i / $sec"
        i=$((i + 1))
    done
}


#============================================================================================
# Get multimedia files
#============================================================================================
# if [ -d "$1" ]; then
#     # If the parameter is a directory
#     DIR="$1"

#     # clear video list in GUI
#     $TEST_CMD -c

#     echo "$HEADER Scanning directory: $DIR"

#     # to read all valid video files in the specific dir and save as a list in $VIDEO_LIST_TMP
#     $TEST_CMD -d "$DIR"

#     if [ ! -f "$VIDEO_LIST_TMP" ]; then
#         echo "$HEADER_Error $VIDEO_LIST_TMP does not exist."
#         endPlayer
#         wait
#         exit 1
#     fi

#     cp "${VIDEO_LIST_TMP}" "${VIDEO_LIST}"
# elif [ -f "$1" ]; then

    # clear video list in GUI
    $TEST_CMD -c

#     echo "$HEADER Read file to get video list: $1"

#     # to read all valid video files in the specific dir and save as a list in $VIDEO_LIST_TMP
#     $TEST_CMD -l "$1"

#     cp "$1" "${VIDEO_LIST}"
# fi

# if [ ! -f "$VIDEO_LIST" ]; then
#     echo "$HEADER_Error $VIDEO_LIST does not exist."
#     endPlayer
#     wait
#     exit 1
# fi

#============================================================================================
# Line-by-line processing $VIDEO_LIST to do all kinds test
#============================================================================================
cnt_total=0
cnt_pass=0
cnt_fail=0
# while IFS= read -r line; do
line="$1"

    handle_ctrl_c() {
        echo "$HEADER Ctrl+C detected!"
        endPlayer
        echo "$HEADER Executing pgrep for rtk-test..."
        pids=$(pgrep rtk-test)
        kill $pids
        exit
    }
    trap handle_ctrl_c SIGINT

    echo "$HEADER No. $((cnt_total + 1)) line=\"${line}\""
    rm -fr "$FLAG_GET_EOS"
    rm -fr "$FLAG_GET_ROTATE_FORBIDDEN"
    rm -fr "$FLAG_GET_SPEED_FORBIDDEN"
    rm -fr "$FLAG_RESULT_FAIL"
    rm -fr "$REC_RESULT_FAIL"

    if [ -f "$line" ]; then

        # start to play video
        # runTest "-pl \"$line\"" 8

        while [ ! -f "$FLAG_RESULT_FAIL" ]; do

        # start to play video
        runTest "-pl \"$line\"" 8

        # rotate from 0% to 90%
        #if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ] && [ ! -f "$FLAG_GET_ROTATE_FORBIDDEN" ]; then
        #    runTest "-rt" 4
        #fi

        # rotate from 90% to 180%
        #if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ] && [ ! -f "$FLAG_GET_ROTATE_FORBIDDEN" ]; then
        #    runTest "-rt" 4
        #fi

        # rotate from 180% to 270%
        #if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ] && [ ! -f "$FLAG_GET_ROTATE_FORBIDDEN" ]; then
        #    runTest "-rt" 4
        #fi

        # rotate from 270% to 0%
        #if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ] && [ ! -f "$FLAG_GET_ROTATE_FORBIDDEN" ]; then
        #    runTest "-rt" 4
        #fi

        # seek to rate min-max %
        if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ]; then
            min=50
            max=70
            random_num=$(( ($RANDOM % (max - min + 1)) + min ))
            runTest "-sr $random_num" 8
        fi

        # pause
        if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ]; then
            runTest "-ps" 3
        fi

        # resume
        if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ]; then
            runTest "-rs" 3
        fi

        # seek to rate min-max %
        if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ]; then
            min=0
            max=20
            random_num=$(( ($RANDOM % (max - min + 1)) + min ))
            runTest "-sr $random_num" 8
        fi

        # change speed to 2x
        if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ] && [ ! -f "$FLAG_GET_SPEED_FORBIDDEN" ]; then
            runTest "-sp 2" 6
        fi

        # pause
        if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ]; then
            runTest "-ps" 3
        fi

        # resume
        if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ]; then
            runTest "-rs" 3
        fi

        # seek to rate min-max %
        if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ]; then
            min=60
            max=70
            random_num=$(( ($RANDOM % (max - min + 1)) + min ))
            runTest "-sr $random_num" 8
        fi

        # change speed to 0.5x
        if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ] && [ ! -f "$FLAG_GET_SPEED_FORBIDDEN" ]; then
            runTest "-sp 0.5" 6
        fi

        # pause
        if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ]; then
            runTest "-ps" 3
        fi

        # resume
        if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ]; then
            runTest "-rs" 3
        fi

        # seek to rate
        if [ ! -f "$FLAG_GET_EOS" ] && [ ! -f "$FLAG_RESULT_FAIL" ]; then
            min=5
            max=15
            random_num=$(( ($RANDOM % (max - min + 1)) + min ))
            runTest "-sr $random_num" 8
        fi

        # stop playing
        runTest "-st" 2

        done

        # stop playing
        #runTest "-st" 2

    else
        echo "$HEADER_Fail video file $line does not exist."
        touch "$FLAG_RESULT_FAIL"
    fi

#    cnt_total=$((cnt_total + 1))
#    if [ ! -f "$FLAG_RESULT_FAIL" ]; then
#        # add file path to pass list
#        echo "$line" >> "$PASS_LIST"
#        cnt_pass=$((cnt_pass + 1))
#    else
#        # add file path to fail list
#        echo "$line" >> "$FAIL_LIST"
#        # record the fail reason and file path
#        if [ ! -f "$FAIL_RECORDS" ]; then
#            # print title
#            printf "%-40s %-6s %-8s %s\n" "#Main_fail_record" "#Idx" "#Time" "#File_path" > "$FAIL_RECORDS"
#        fi
#        main_rec=$(cat "$REC_RESULT_FAIL" | head -n 1)
#        log_time=$(date '+%H:%M:%S')
#        printf "%-40s %-6s %s\n" "$main_rec" "$cnt_total" "$log_time" "$line" >> "$FAIL_RECORDS"
#        cnt_fail=$((cnt_fail + 1))
#    fi

# done < $VIDEO_LIST
# echo "$HEADER Total test files: ${cnt_total}, PASS: $cnt_pass, FAIL: $cnt_fail."

endPlayer
wait
