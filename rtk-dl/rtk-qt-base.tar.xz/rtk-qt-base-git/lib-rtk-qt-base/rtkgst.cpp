/**
 * @file rtkgst.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The interface/api to use Realtek library
 */

#include <QImage>
#include <QUrl>
#include <QDebug>
#include "rtkgst.h"
#include <gst/video/videooverlay.h>
#include <fstream>
#include <sstream>
#include <string>
#include <chrono>
#include <iomanip>
#include <QProcess>
#include <QFile>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <regex>
#include <QMutex>

#if GET_INFO_FROM_FRAMEWORK == 1
#include <gst/audio/streamvolume.h>
#define container_of(ptr, type, member) \
        ((type *)((char *)ptr - offsetof(type, member)))
#endif

#define DEBUG_GSTREAMER 0
#define DEBUG_FRAMEWORK 0
#define DEBUG_RETRIEVE_TAG_INFO 0
#define RELEASE_RETRY_COUNT 10

/* playbin flags */
typedef enum {
  GST_PLAY_FLAG_VIDEO         = (1 << 0), /* We want video output */
  GST_PLAY_FLAG_AUDIO         = (1 << 1), /* We want audio output */
  GST_PLAY_FLAG_TEXT          = (1 << 2)  /* We want subtitle output */
} GstPlayFlags;

extern int g_pipefd[2];

#define DEFAULT_BUFFER_BYTES 41943040     // 40 MB
gboolean play_bus_msg (GstBus * bus, GstMessage * msg, gpointer data);
static pthread_t thread_id_bus = 0;
static bool bus_monitor_running = false;
MediaInfo mediaInfo;
GstPlay *g_play = NULL;

RtkGst *rtkGst = NULL;
QProcess g_face_recognition_process;
static int device_fd = -1;

#if GET_INFO_FROM_FRAMEWORK == 1
static pthread_t thread_id_main_loop = 0;
rtk_media_info rtkMediaInfo;
rtk_cap_instance inst_video;
rtk_cap_instance inst_audio;
rtk_cap_instance inst_subtitle;
#endif

string generateTimestampedFilename() {
    auto now = chrono::system_clock::now();
    auto in_time_t = chrono::system_clock::to_time_t(now);

    stringstream ss;
    ss << put_time(localtime(&in_time_t), "%Y%m%d_%H%M%S");
    return "snapshot_" + ss.str() + ".jpg";
}

void init_media_info(MediaInfo *info)
{
    if (info == nullptr)
        return;
    info->file_path = "";
    info->already_get_info = false;
    info->has_video = false;
    info->has_audio = false;
#if GET_INFO_FROM_FRAMEWORK == 1
    for (int i=0; i<STREAM_MAX; i++)
    {
        StreamInfo *stream = &info->stream[i];
        stream->type = RTK_UNKNOWN_TYPE;
        stream->type_name = "";
        stream->id = -1;
        stream->decodable = false;
        stream->language = "";
        stream->title = "";
        stream->video_width = 0;
        stream->video_height = 0;
        stream->video_bit_depth = 8;
        stream->mpegversion = 0;
        stream->wmvversion = 0;
        stream->subtitle_format = "";
    }
    info->stream_count = 0;
    info->vect_v.clear();
    info->vect_a.clear();
    info->vect_s.clear();
    info->vect_idx_v = -1;
    info->vect_idx_a = -1;
    info->vect_idx_s = -1;
    info->decodable_v_count = 0;
    info->decodable_a_count = 0;
    info->decodable_s_count = 0;
#else
    info->video_width = 0;
    info->video_height = 0;
    info->video_bit_depth = 8;
#endif
    info->video_codec_desc = "NONE";
    info->subtitle_format = "NONE";
    info->is_video_4k = false;
    info->is_video_less_than_4k = false;
    info->is_video_10_bits = false;
    info->enable_video_speed_change = false;
    info->enable_video_rotate = false;
}

#if GET_INFO_FROM_FRAMEWORK == 1
bool get_check_video_info_from_framework(rtk_stream_info *stream_info, StreamInfo *stream)
{
    bool decodable = false;

    if (stream_info == nullptr || stream == nullptr)
        return false;

    video_info *v_info = &stream_info->v_info;
    char *mime = stream_info->mime_type;

    /* 1. fill media info to qury form */
    rtk_video_cap cap_video;    // for query
    rtk_video_cap *cap = &cap_video;
    memset (cap, 0x0, sizeof(rtk_video_cap));
    strcpy(&cap->mime_type[0], mime);
    cap->max_width = v_info->width;
    cap->max_height = v_info->height;
    cap->mpegversion = v_info->mpegversion;
    strcpy(cap->profile[0], v_info->profile);
    if (v_info->profile[0] != 0) {
        cap->profile_count = 1;
    }
    strcpy(cap->level[0], v_info->level);
    if (v_info->level[0] != 0) {
        cap->level_count = 1;
    }
    cap->wmvversion = v_info->wmvversion;
    cap->max_bit_depth = v_info->bit_depth;
    // cap->input_format
    // cap->output_format

    /* 2. check decode capability */
#if DEBUG_FRAMEWORK == 1
    qDebug() << QString().sprintf("%s:%d list_video_cap_info()", __FUNCTION__, __LINE__);
    list_video_cap_info (cap);
#endif
    decodable = (rtk_video_cap_check(&inst_video, cap) == 0);

    /* 3. get video info */
    stream->video_width = v_info->width;
    stream->video_height = v_info->height;
    stream->mpegversion = v_info->mpegversion;
    stream->wmvversion = v_info->wmvversion;
    stream->video_bit_depth = v_info->bit_depth;
    stream->decodable = decodable;

    return decodable;
}

bool get_check_subtitle_info_from_framework(rtk_stream_info *stream_info, StreamInfo *stream)
{
    bool decodable = false;

    if (stream_info == nullptr || stream == nullptr)
        return false;

    subtitle_info *s_info = &stream_info->s_info;
    char *mime = stream_info->mime_type;

    /* 1. fill media info to qury form */
    rtk_subtitle_cap cap_subtitle;  // for query
    rtk_subtitle_cap *cap = &cap_subtitle;
    memset (cap, 0x0, sizeof(rtk_subtitle_cap));
    strcpy(cap->mime_type, mime);

    /* 2. check decode capability */
#if DEBUG_FRAMEWORK == 1
    qDebug() << QString().sprintf("%s:%d list_subtitle_cap_info()", __FUNCTION__, __LINE__);
    list_subtitle_cap_info (cap);
#endif
    decodable = (rtk_subtitle_cap_check(&inst_subtitle, cap) == 0);

    /* 3. get video info */
    stream->decodable = decodable;

    return decodable;
}

bool get_check_audio_info_from_framework(rtk_stream_info *stream_info, StreamInfo *stream)
{
    if (stream_info == nullptr || stream == nullptr)
        return false;

    audio_info *a_info = &stream_info->a_info;
    stream->decodable = true;
    return stream->decodable;
}

MediaInfo* RtkGst::get_media_info_from_framework(const string& video_file)
{
    static QMutex mutex;
    MediaInfo *info = &mediaInfo;
    rtk_media_info *rtk = &rtkMediaInfo;

    mutex.lock();
    if (info->file_path == video_file && info->already_get_info)
    {
        mutex.unlock();
        // already get media info before, therefore recturn directly
        return info;
    }

    std::string s(video_file.c_str());
    char *filepath = s.data();
    qDebug () << QString().asprintf("%s:%d filepath=%s", __FUNCTION__, __LINE__, filepath);

    init_media_info(info);
    get_media_info (filepath, rtk, false);
#if DEBUG_FRAMEWORK == 1
    qDebug() << QString().sprintf("%s:%d list_media_info()", __FUNCTION__, __LINE__);
    list_media_info (rtk);
#else
    qDebug() << QString("mime_type total: %1").arg(rtk->info_count);
#endif

    for (int i = 0; i < rtk->info_count; i++)
    {
        rtk_stream_info *stream_info = &rtk->stream_info[i];
        StreamInfo *stream = &info->stream[i];

        stream->type = stream_info->stream_type;
        stream->type_name = stream_info->stream_type_name;
        stream->mime = stream_info->mime_type;
        stream->id = stream_info->stream_type_id;
        stream->language = stream_info->language;
        stream->title = stream_info->title;
#if DEBUG_FRAMEWORK == 1
#else
    qDebug() << QString().sprintf("%12s #%-3d %s", stream->type_name.c_str(), stream->id, stream->mime.c_str());
#endif
        switch(stream_info->stream_type)
        {
        case RTK_VIDEO_TYPE:
            get_check_video_info_from_framework(stream_info, stream);
            info->has_video = true;
            info->vect_v.push_back(i);
            if (stream->decodable)
            {
                if (info->decodable_v_count <= 0)
                    info->vect_idx_v = info->vect_v.size()-1;
                info->decodable_v_count++;
            }
            else {
                qDebug() << QString().sprintf("%s:%d warning: %s is not decodable", __FUNCTION__, __LINE__, stream->mime.c_str());
            }
            break;
        case RTK_AUDIO_TYPE:
            get_check_audio_info_from_framework(stream_info, stream);
            info->has_audio = true;
            info->vect_a.push_back(i);
            if (stream->decodable)
            {
                if (info->decodable_a_count <= 0)
                    info->vect_idx_a = info->vect_a.size()-1;
                info->decodable_a_count++;
            }
            else {
                qDebug() << QString().sprintf("%s:%d warning: %s is not decodable", __FUNCTION__, __LINE__, stream->mime.c_str());
            }
            break;
        case RTK_SUBTITLE_TYPE:
            get_check_subtitle_info_from_framework(stream_info, stream);
            info->vect_s.push_back(i);
            if (stream->decodable)
            {
                if (info->decodable_s_count <= 0)
                    info->vect_idx_s = info->vect_s.size()-1;
                info->decodable_s_count++;
            }
            else {
                qDebug() << QString().sprintf("%s:%d warning: %s is not decodable", __FUNCTION__, __LINE__, stream->mime.c_str());
            }
            break;
        default:
            break;
        }
    }

    if (info->vect_idx_v >= 0)
    {
        int idx = info->vect_v[info->vect_idx_v];
        StreamInfo *stream = &info->stream[idx];
        info->is_video_4k = (stream->video_width >= 3840 && stream->video_height >= 2160);
        info->is_video_less_than_4k = (stream->video_width > 0 && stream->video_width < 3840 &&
                                      stream->video_height > 0 && stream->video_height < 2160);
        info->is_video_10_bits = (stream->video_bit_depth >= 10);
        info->enable_video_speed_change = (info->is_video_4k ||
                                          // 10 bits for 2K/4K or more, sometimes we cannot parse width/height without proper plugin
                                          (info->is_video_10_bits && !info->is_video_less_than_4k));
        info->enable_video_rotate = (info->decodable_s_count <= 0) &&
#if 1
                                    info->is_video_less_than_4k;
#else
                                    // for 4096 pixels, we need to scale it first
                                    (info->is_video_10_bits == false || (info->is_video_10_bits && info->is_video_less_than_4k));
#endif
        if (strstr(stream->mime.c_str(), "h264"))       // ex:video/x-h264
            info->video_codec_desc = "264";
        else if (strstr(stream->mime.c_str(), "h265"))  // ex:video/x-h265
            info->video_codec_desc = "265";

        qDebug() << "video resolution: " << stream->video_width << "x" << stream->video_height;
        qDebug() << "video bits depth: " << stream->video_bit_depth;
    }
    if (info->vect_idx_s >= 0)
    {
        int idx = info->vect_s[info->vect_idx_s];
        StreamInfo *stream = &info->stream[idx];
        qDebug() << QString().sprintf("%s:%d", __FUNCTION__, __LINE__);
        // subtitle format
        if (strstr(stream->mime.c_str(), "subrip") || 
            strstr(stream->mime.c_str(), "srt") || 
            strstr(stream->mime.c_str(), "pgs") ||  // ex: subpicture/x-pgs
            strstr(stream->mime.c_str(), "PGS"))
            info->subtitle_format = "SRT";
        else if (strstr(stream->mime.c_str(), "ssa") || 
            strstr(stream->mime.c_str(), "ass") || 
            strstr(stream->mime.c_str(), "Advanced"))
            info->subtitle_format = "ASS";
        else
            info->subtitle_format = "Others";
    }

    qDebug() << "video decodable: " << info->decodable_v_count;
    qDebug() << "audio decodable: " << info->decodable_a_count;
    qDebug() << "subtitle decodable: " << info->decodable_s_count;
    qDebug() << "codec_desc format: " << QString::fromStdString(info->video_codec_desc);
    qDebug() << "subtitle format: " << QString::fromStdString(info->subtitle_format);
    if (info->has_video && (info->decodable_v_count <= 0))
    {
        qDebug () << QString().asprintf("Video format is over spec! Unable to play it !");
    }

    info->stream_count = rtk->info_count;
    info->file_path = video_file;
    info->already_get_info = true;

    mutex.unlock();
    return info;
}

void RtkGst::rtk_gst_play_get_info(GstPlay **play_p, MediaInfo **info_p)
{
    if (play_p != nullptr)
        *play_p = g_play;
    if (info_p != nullptr)
        *info_p = &mediaInfo;
}

#else
// Generate the rank of all v4l2 elements to 0.
string rtk_gst_generate_plugin_rank()
{
    std::string command = "gst-inspect-1.0";
    std::vector<std::string> plugins;
    char buffer[128];
    std::string result;

    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        std::cerr << "Failed to execute gst-inspect-1.0" << std::endl;
        return "";
    }

    // read the output of gst-inspect-1.0
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        result += buffer;
    }
    pclose(pipe);

    // Get 'video4linux2:' and 'v4l2.*dec'
    std::regex v4l2_dec_regex("video4linux2:[ \\t]+(v4l2.*dec)");
    std::smatch match;
    std::istringstream iss(result);
    std::string line;

    while (std::getline(iss, line)) {
        if (std::regex_search(line, match, v4l2_dec_regex)) {
            std::string plugin_name = match[1].str();
            plugin_name.erase(0, plugin_name.find_first_not_of(" \t"));
            plugins.push_back(plugin_name + ":0");
        }
    }

    // Format the plugin to: <name>:0,<name>:0,...
    std::string gst_rank;
    for (size_t i = 0; i < plugins.size(); ++i) {
        gst_rank += plugins[i];
        if (i < plugins.size() - 1) {
            gst_rank += ",";
        }
    }

    return gst_rank;
}

MediaInfo* RtkGst::get_media_info(const string& video_file)
{
    MediaInfo *info = &mediaInfo;

    if (info->file_path == video_file && info->already_get_info)
        // already get media info before, therefore recturn directly
        return info;

    init_media_info(info);

    string command = "gst-discoverer-1.0 \"" + video_file + "\" 2>/dev/null";

    string gst_plugin_rank = rtk_gst_generate_plugin_rank();
    if (gst_plugin_rank != "")
        command = "GST_PLUGIN_FEATURE_RANK=" + gst_plugin_rank + " " + command;

    qDebug () << QString().asprintf("%s:%d %s", __FUNCTION__, __LINE__, command.c_str());

    // Execute command and capture output
    array<char, 512> buffer;
    string output;
    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe)
    {
        qDebug () << QString().asprintf("%s:%d Failed to run gst-discoverer-1.0", __FUNCTION__, __LINE__);
        return info;
    }

    while (fgets(buffer.data(), buffer.size(), pipe)) {
        output += buffer.data();
    }
    pclose(pipe);

    // Parse resolution, bits depth
    regex width_regex(R"(Width\s*:\s*(\d+))");
    regex height_regex(R"(Height\s*:\s*(\d+))");
    regex profile_regex(R"(Main\s+(\d+)\s+Profile)");
    smatch match;

    int width = 0, height = 0, profile = 8;
    if (regex_search(output, match, width_regex)) {
        width = stoi(match[1]);
    }
    if (regex_search(output, match, height_regex)) {
        height = stoi(match[1]);
    }
    if (regex_search(output, match, profile_regex)) {
        profile = stoi(match[1]);
    }
    info->video_width = width;
    info->video_height = height;
    info->video_bit_depth = profile;

    // info->subtitle_format = "NONE";
    // info->video_codec_desc = "NONE";
    QStringList resultList = QString::fromStdString(output).split("\n");
    for (int i=0; i<resultList.count(); i++)
    {
        QString result = resultList.at(i);
        // Parse output to find subtitle format
        if (result.indexOf("subtitle", Qt::CaseInsensitive) >= 0)
        {
            // Check for common subtitle formats
            if (result.indexOf("subrip") >= 0 ||
                result.indexOf("srt") >= 0 ||
                result.indexOf("PGS") >= 0)
                info->subtitle_format = "SRT";
            else if (result.indexOf("ssa") >= 0 ||
                     result.indexOf("ass") >= 0 ||
                     result.indexOf("Advanced SubStation") >= 0)
                info->subtitle_format = "ASS";
            else
                info->subtitle_format = "Others";
        }
        // Parse output to find subtitle format
        if (result.indexOf("video", Qt::CaseInsensitive) >= 0)
        {
            info->has_video = true;
            // Check for common video formats
            if (result.indexOf("264") >= 0)
                info->video_codec_desc = "264";
            else if (result.indexOf("265") >= 0)
                info->video_codec_desc = "265";
        }
        if (result.indexOf("audio", Qt::CaseInsensitive) >= 0)
        {
            info->has_audio = true;
        }
    }


    info->is_video_4k = (info->video_width >= 3840 && info->video_height >= 2160);
    info->is_video_less_than_4k = (info->video_width > 0 && info->video_width < 3840 &&
                                  info->video_height > 0 && info->video_height < 2160);
    info->is_video_10_bits = (info->video_bit_depth >= 10);
    info->enable_video_speed_change = (info->is_video_4k ||
                                      // 10 bits for 2K/4K or more, sometimes we cannot parse width/height without proper plugin
                                      (info->is_video_10_bits && !info->is_video_less_than_4k));
    info->enable_video_rotate = (info->subtitle_format == "NONE") &&
#if 1
                                info->is_video_less_than_4k;
#else
                                // for 4096 pixels, we need to scale it first
                                (info->is_video_10_bits == false || (info->is_video_10_bits && info->is_video_less_than_4k));
#endif

    qDebug() << "video resolution: " << info->video_width << "x" << info->video_height;
    qDebug() << "video bits depth: " << info->video_bit_depth;
    qDebug() << "subtitle format: " << QString::fromStdString(info->subtitle_format);
    qDebug() << "codec_desc format: " << QString::fromStdString(info->video_codec_desc);

    info->file_path = video_file;
    info->already_get_info = true;
    return info;
}
#endif

RtkGst::RtkGst()
{
    rtkGst = this;
    if_platform_wayland = false;
    if_wayland_bg_color_transparency = false;
    if_debug = false;
    video_sink_str = "waylandsink";
    text_sink_str = "waylandsink";
#if GET_INFO_FROM_FRAMEWORK == 1
    rtk_media_cap_init(&inst_video, RTK_VIDEO_CAP);
    rtk_media_cap_init(&inst_audio, RTK_AUDIO_CAP);
    rtk_media_cap_init(&inst_subtitle, RTK_SUBTITLE_CAP);
#if DEBUG_FRAMEWORK == 1
    list_cap_instance_info(&inst_video);
    list_cap_instance_info(&inst_subtitle);
#endif
#endif
}

RtkGst::~RtkGst()
{
#if GET_INFO_FROM_FRAMEWORK == 1
    rtk_media_cap_uninit(&inst_video);
    rtk_media_cap_uninit(&inst_subtitle);
#endif
}

QString RtkGst::getPlatformName(int argc, char *argv[])
{
    QString strPlatform = "";
    QString strQpaVariable = "QT_QPA_PLATFORM=";
    for (int i=0; i< argc; ++i)
    {
        QString strArgv = QString(argv[i]);
        // qDebug() << i << " " << strArgv;

        if (i+1 <argc &&
            (strArgv == "-platform" ||
             strArgv == "--platform"))
        {
            strPlatform = argv[i+1];
            qDebug () << QString().asprintf("%s:%d %s %s", __FUNCTION__, __LINE__,
                            strArgv.toStdString().c_str(),
                            strPlatform.toStdString().c_str());
        }
        else if (strArgv.startsWith(strQpaVariable))
        {
            // ex: QT_QPA_PLATFORM=linuxfb:fb=/dev/fb1
            // but this setting must be placed after the executable filename to be readble
            strPlatform  = strArgv.split(strQpaVariable).last().split(":").at(0);
            qDebug () << QString().asprintf("%s:%d %s %s", __FUNCTION__, __LINE__,
                            strArgv.toStdString().c_str(),
                            strPlatform.toStdString().c_str());
        }
    }
    if_platform_wayland = (strPlatform == _STR_WAYLAND_);
    return strPlatform;
}

void RtkGst::modifyWestonIni(WestonMode mode)
{
    const std::string iniPath = "/etc/xdg/weston/weston.ini"; // Weston config file
    std::ifstream iniFileIn(iniPath);
    if (!iniFileIn) {
        std::cerr << "Cannot open file: " << iniPath << "\n";
        return;
    }

    std::ostringstream buffer;
    std::string line;
    bool inShellSection = false;

    // Read file and modify based on mode
    while (std::getline(iniFileIn, line)) {
        if (line == "[shell]") {
            inShellSection = true;
            buffer << line << "\n";
            continue;
        }

        if (inShellSection) {
            if (line.find("background-type=") == 0) {
                if (mode == WestonMode::Update) {
                    buffer << "background-type=solid\n"; // Update mode modification
                } else if (mode == WestonMode::Reset) {
                    buffer << "background-type=scale\nbackground-image=/etc/xdg/weston/logo_banner.jpg\n"; // Reset mode modification
                }
                continue;
            }
            if (mode == WestonMode::Update && line.find("background-image=") == 0) {
                continue; // Remove background-image in update mode
            }
            if (line.find("background-color=") == 0) {
                if (mode == WestonMode::Update) {
                    buffer << "background-color=0x00ff0000\n"; // Update by transparency to showing video layer
                } else if (mode == WestonMode::Reset) {
                    buffer << "background-color=0xff000000\n"; // Reset mode modification
                }
                continue;
            }
        }

        buffer << line << "\n";
    }

    iniFileIn.close();

    // Write back weston.ini
    std::ofstream iniFileOut(iniPath);
    if (!iniFileOut) {
        std::cerr << "Cannot open file: " << iniPath << "\n";
        return;
    }

    iniFileOut << buffer.str();
    iniFileOut.close();

    std::cout << "Update Weston.ini success!\n";

    // Restart Weston
    int result = system("systemctl restart weston");
    if (result == 0) {
        std::cout << "Restart Weston success!\n";
    } else {
        std::cerr << "Restart Weston failed!\n";
    }
}

void RtkGst::parsePlatformSetting()
{
    const QString iniPath = "/etc/xdg/weston/weston.ini"; // Weston config file
    QString bg_color;

    if (if_platform_wayland != true)
    {
        if_wayland_bg_color_transparency = false;
        return;
    }

    QFile file(iniPath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty())
            continue;
        if (line.startsWith('#') || line.startsWith(';'))
            continue;
        if (line.startsWith("background-image"))
        {
            // assuem the image is not transparent image
            if_wayland_bg_color_transparency = false;
            return;
        }
        if (line.startsWith("background-color"))
        {
            QStringList parts = line.split('=', Qt::SkipEmptyParts);
            if (parts.size() == 2)
            {
                bg_color = parts[1].trimmed();
                if (bg_color.compare("0x00FF0000", Qt::CaseInsensitive) == 0 ||
                    bg_color.compare("0x0000FF00", Qt::CaseInsensitive) == 0 ||
                    bg_color.compare("0x000000FF", Qt::CaseInsensitive) == 0)
                    if_wayland_bg_color_transparency = true;
                continue;
            }
        }
    }
}

void RtkGst::set_debug (bool bDebug)
{
    if_debug = bDebug;
}

void RtkGst::set_sink (QString videosink, QString textsink)
{
    video_sink_str = videosink;
    text_sink_str = textsink;
}

void RtkGst::get_sink (QString *vsink, QString *tsink)
{
    if (vsink)
        *vsink = video_sink_str;
    if (tsink)
        *tsink = text_sink_str;
}

bool RtkGst::rtk_gst_set_element_state(GstPlay *play, GstElement *element, GstState state)
{
    if(play == NULL || play->pipeline == NULL || element == NULL)
        return false;
    bool if_pipeline = (play->pipeline == element);
    GstState state_old, state_new;
    gst_element_get_state(element, &state_old, NULL, GST_CLOCK_TIME_NONE);
    gst_element_set_state(element, state);
    for (int i=0; i < RELEASE_RETRY_COUNT; i++)
    {
        gst_element_get_state(element, &state_new, NULL, GST_CLOCK_TIME_NONE);
        if(state == state_new)
            break;
        else {
            if (if_debug && if_pipeline)
                qDebug () << QString().asprintf("%s:%d wait gst state to %s",
                        __FUNCTION__, __LINE__, gst_element_state_get_name(state));
            usleep(50000);
        }
    }
    if (if_debug && if_pipeline)
    {
        qDebug () << QString().asprintf("%s:%d play %p, change state to %s, then %s -> %s",
                    __FUNCTION__, __LINE__, play,
                    gst_element_state_get_name(state),
                    gst_element_state_get_name(state_old),
                    gst_element_state_get_name(state_new));
    }

    if (if_pipeline)
        g_print("Change state %s -> %s\n", gst_element_state_get_name(state_old),
                gst_element_state_get_name(state_new));
    return (state == state_new);
}

void RtkGst::rtk_gst_set_element_state_no_check(GstPlay *play, GstElement *element, GstState state)
{
    if(play == NULL || play->pipeline == NULL || element == NULL)
        return;
    bool if_pipeline = (play->pipeline == element);
    gst_element_set_state(element, state);
    if (if_debug && if_pipeline)
    {
        qDebug () << QString().asprintf("%s:%d play %p, set state to %s",
                    __FUNCTION__, __LINE__, play,
                    gst_element_state_get_name(state));
    }
    if (if_pipeline)
        g_print("Set state to %s\n", gst_element_state_get_name(state));
}

void RtkGst::rtk_gst_unref_element(GstElement *element)
{
    for (int i = 0; i < RELEASE_RETRY_COUNT; i++)
    {
        int ref_count = 0;
        ref_count = GST_OBJECT_REFCOUNT(element);
        if (ref_count <= 0) {
            if (ref_count < 0) {
                qDebug () << QString().asprintf("%s:%d %s with invalid ref_count %d !", 
                                __FUNCTION__, __LINE__, gst_element_get_name(element), ref_count);
            }
            break;
        } else {
            // if (if_debug) {
            //     qDebug () << QString().asprintf("%s:%d unref %s until ref_count %d to 0 !", 
            //                     __FUNCTION__, __LINE__, gst_element_get_name(element), ref_count);
            // }
            gst_object_unref (element);
            usleep(50000);
        }
    }
}

QString formatTime(gint64 time) {
    if (time == -1) {
        return "Unknown";
    }
    return QString("%1:%2:%3")
        .arg((time / GST_SECOND) / 3600, 2, 10, QChar('0'))   // hour
        .arg(((time / GST_SECOND) % 3600) / 60, 2, 10, QChar('0')) // minute
        .arg((time / GST_SECOND) % 60, 2, 10, QChar('0'));    // second
}

pair<gint64, gint64> RtkGst::rtk_gst_getPlaybackPositionDuration(GstPlay *play)
{
    gint64 position = 0;
    gint64 duration = 0;

    if (play == NULL || play->pipeline == NULL)
        return {0, 0};

    // current position
    gboolean posAvailable = gst_element_query_position(play->pipeline, GST_FORMAT_TIME, &position);

    // duration
    gboolean durAvailable = gst_element_query_duration(play->pipeline, GST_FORMAT_TIME, &duration);

    if (posAvailable && durAvailable)
    {
        // if (if_debug)
        //     qDebug () << QString().asprintf("position %ld duration %ld", position, duration);
        return {position, duration};
    }
    else
        return {0, 0};
}

pair<gint64, gint64> RtkGst::rtk_gst_getPlaybackPositionDuration()
{
    return rtk_gst_getPlaybackPositionDuration(g_play);
}

bool RtkGst::rtk_gst_setVolume(GstPlay *play, int volume)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d volume %d", __FUNCTION__, __LINE__, volume);
    if(play == NULL || play->pipeline == NULL)
        return false;

    if(volume < 0 || volume > 100)
        return false;

#if GET_INFO_FROM_FRAMEWORK == 1
    play->volume_value = volume;
    play->volume_applied = false;
#endif

    /* the volume range is usually 0.0~10.0, and 0.0~1.0 is generally recommended,
       exceeding 1.0 will amplify the sound and cause distortion or even popping */
    gdouble vol = (gdouble)((gdouble)volume / VOLUME_MAX);

    GstElement *element = NULL;
    // qDebug () << QString().asprintf("%s:%d GST_ELEMENT_NAME(play->pipeline) %s", __FUNCTION__, __LINE__, GST_ELEMENT_NAME(play->pipeline));
    if (strcmp(GST_ELEMENT_NAME(play->pipeline), "playbin") == 0)
    {
        element = play->pipeline;
    }
#if GET_INFO_FROM_FRAMEWORK == 1
    else if(strcmp(GST_ELEMENT_NAME(play->pipeline), play->player_name.c_str()) == 0)
    {
        if (play->audio_count <= 0 ||
            play->video_index >= play->video_count ||
            play->video_index >= MAX_VIDEO_COUNT)
            return false;
        RTK_VIDEO_BIN *video = &play->video_bin[play->video_index];
        if (video->volume == nullptr)
        {
            qDebug () << QString().asprintf("%s:%d Cannot find volume object !", __FUNCTION__, __LINE__);
            return false;
        }
        element = video->volume;
    }
#endif
    else
    {
        GstElement *gst_volume = gst_bin_get_by_name(GST_BIN(play->pipeline), "gst_volume");
        if (gst_volume != NULL)
            element = gst_volume;
        else
        {
#if GET_INFO_FROM_FRAMEWORK == 1
            gst_volume = gst_bin_get_by_interface(GST_BIN(play->pipeline), gst_stream_volume_get_type());
            if (gst_volume != NULL)
                element = gst_volume;
            else
#endif
            {
                qDebug () << QString().asprintf("%s:%d Cannot find volume object !", __FUNCTION__, __LINE__);
                return false;
            }
        }
    }
    g_print("Playback volume set to %.2f \n", vol);
    g_object_set(element, "volume", vol, NULL);
#if GET_INFO_FROM_FRAMEWORK == 1
    play->volume_applied = true;
#endif
    return true;
}

bool RtkGst::rtk_gst_setVolume(int volume)
{
    return rtk_gst_setVolume (g_play, volume);
}

#if GET_INFO_FROM_FRAMEWORK == 1
#if DEBUG_RETRIEVE_TAG_INFO == 1
static void get_language_from_tag_list(GstTagList *tag_list, const gchar *source)
{
    if (tag_list == NULL)
        return;

    const gchar *language_tags[] = {
        "language",
        "Language", 
        "LANGUAGE",
        "audio-language",
        "Audio-language",
        "subtitle-language",
        "subtitle-language",
        "lang",
        "Lang",
        NULL
    };

    for (int i = 0; language_tags[i] != NULL; i++) {
        gchar *lang = NULL;
        if (gst_tag_list_get_string(tag_list, language_tags[i], &lang) && lang) {
            qDebug() << QString().asprintf("%s:%d [%s] Found language (%s): %s", 
            __FUNCTION__, __LINE__, source, language_tags[i], lang);
            g_free(lang);
            return;
        }
    }

    // try to get title
    gchar *title = NULL;
    if (gst_tag_list_get_string(tag_list, GST_TAG_TITLE, &title) && title) {
        qDebug() << QString().asprintf("%s:%d [%s] Title: %s", __FUNCTION__, __LINE__, source, title);
        g_free(title);
    }

    // try to get artist
    gchar *artist = NULL;
    if (gst_tag_list_get_string(tag_list, GST_TAG_ARTIST, &artist) && artist) {
        qDebug() << QString().asprintf("%s:%d [%s] Artist: %s", __FUNCTION__, __LINE__, source, artist);
        g_free(artist);
    }
}

static void print_all_tags(GstTagList *tag_list, const gchar *tag_source)
{
    if (tag_list == NULL) {
        qDebug() << QString().asprintf("%s:%d tag_list is NULL", __FUNCTION__, __LINE__);
        return;
    }

    guint num_tags = gst_tag_list_n_tags(tag_list);
    qDebug() << QString().asprintf("%s:%d ====== %u tags found from %s ======", __FUNCTION__, __LINE__, num_tags, tag_source);

    for (guint i = 0; i < num_tags; i++) {
        const gchar *tag_name = gst_tag_list_nth_tag_name(tag_list, i);
        
        GType tag_type = gst_tag_get_type(tag_name);
        
        if (tag_type == G_TYPE_STRING) {
            gchar *str_value = NULL;
            if (gst_tag_list_get_string(tag_list, tag_name, &str_value) && str_value) {
                qDebug() << QString().asprintf("%s:%d   [%s] %s: %s", __FUNCTION__, __LINE__, tag_source, tag_name, str_value);
                g_free(str_value);
            }
        } 
        else if (tag_type == G_TYPE_UINT) {
            guint uint_value = 0;
            if (gst_tag_list_get_uint(tag_list, tag_name, &uint_value)) {
                qDebug() << QString().asprintf("%s:%d   [%s] %s: %u", __FUNCTION__, __LINE__, tag_source, tag_name, uint_value);
            }
        }
        else if (tag_type == G_TYPE_UINT64) {
            guint64 uint64_value = 0;
            if (gst_tag_list_get_uint64(tag_list, tag_name, &uint64_value)) {
                qDebug() << QString().asprintf("%s:%d   [%s] %s: %llu", __FUNCTION__, __LINE__, tag_source, tag_name, (unsigned long long)uint64_value);
            }
        }
        else if (tag_type == G_TYPE_INT) {
            gint int_value = 0;
            if (gst_tag_list_get_int(tag_list, tag_name, &int_value)) {
                qDebug() << QString().asprintf("%s:%d   [%s] %s: %d", __FUNCTION__, __LINE__, tag_source, tag_name, int_value);
            }
        }
        else if (tag_type == G_TYPE_DOUBLE) {
            gdouble double_value = 0;
            if (gst_tag_list_get_double(tag_list, tag_name, &double_value)) {
                qDebug() << QString().asprintf("%s:%d   [%s] %s: %.2f", __FUNCTION__, __LINE__, tag_source, tag_name, double_value);
            }
        }
        else if (tag_type == G_TYPE_BOOLEAN) {
            gboolean bool_value = FALSE;
            if (gst_tag_list_get_boolean(tag_list, tag_name, &bool_value)) {
                qDebug() << QString().asprintf("%s:%d   [%s] %s: %s", __FUNCTION__, __LINE__, tag_source, tag_name, bool_value ? "TRUE" : "FALSE");
            }
        }
        else if (tag_type == GST_TYPE_BUFFER) {
            const GValue *buffer_val = gst_tag_list_get_value_index(tag_list, tag_name, 0);
            if (buffer_val && GST_VALUE_HOLDS_BUFFER(buffer_val)) {
                GstBuffer *buffer = gst_value_get_buffer(buffer_val);
                qDebug() << QString().asprintf("%s:%d   [%s] %s: <buffer, size=%u>", __FUNCTION__, __LINE__, tag_source, tag_name, gst_buffer_get_size(buffer));
            }
        }
        else {
            qDebug() << QString().asprintf("%s:%d   [%s] %s: <type: %s>", __FUNCTION__, __LINE__, tag_source, tag_name, g_type_name(tag_type));
        }
    }
    qDebug() << QString().asprintf("%s:%d =========================================", __FUNCTION__, __LINE__);
}

static void on_dmx_tag_found(GstElement *demux, GstTagList *tag_list, gpointer user_data)
{
    GstPlay *play = (GstPlay *)user_data;
    
    qDebug() << QString().asprintf("%s:%d tag-found signal received", __FUNCTION__, __LINE__);
    
    // print all tags
    print_all_tags(tag_list, "demux");
    
    get_language_from_tag_list (tag_list, "demux");
}
#endif
#endif

void *bus_monitor(void *param)
{
    GstPlay *play = (GstPlay *)param;

    GstMessage * msg;
    while( bus_monitor_running ) {
        if( (msg = gst_bus_pop(play->bus)) ) {
            // Call your bus message handler
            play_bus_msg (play->bus, msg, play);
            gst_message_unref (msg);
        }
        usleep(1000);
    }

    return NULL;
}

gboolean play_bus_msg (GstBus * bus, GstMessage * msg, gpointer user_data)
{
    GstPlay *play = (GstPlay *)user_data;
    // GstObject *src = GST_MESSAGE_SRC (msg);

    switch (GST_MESSAGE_TYPE (msg)) {
        case GST_MESSAGE_EOS:
            //sendCommand(CMD_NEXT_FILE);
            g_print("End of stream reached.\n");
            if(play != NULL)
            {
                write(g_pipefd[1], "GST_MESSAGE_EOS", 15);
            }
            break;
        case GST_MESSAGE_ERROR:
            GError *err;
            gchar *dbg;

            gst_message_parse_error (msg, &err, &dbg);
            g_printerr ("ERROR %s for %s\n", err->message, "");
            if (dbg != NULL)
                g_printerr ("ERROR debug information: %s\n", dbg);
            g_error_free (err);
            g_free (dbg);
            break;
#if GET_INFO_FROM_FRAMEWORK == 1
#if DEBUG_RETRIEVE_TAG_INFO == 1
        case GST_MESSAGE_TAG:
        {
            GstTagList *tag_list = NULL;
            gst_message_parse_tag(msg, &tag_list);
            
            qDebug() << QString().asprintf("%s:%d GST_MESSAGE_TAG", __FUNCTION__, __LINE__);
            if (tag_list) {
                GstObject *src = GST_MESSAGE_SRC(msg);
                const gchar *src_name = src ? GST_OBJECT_NAME(src) : "unknown";
                
                qDebug() << QString().asprintf("%s:%d Bus: tag message from %s", __FUNCTION__, __LINE__, src_name);
                print_all_tags(tag_list, "bus");
                
                gst_tag_list_unref(tag_list);
            }
            break;
        }
#endif
#endif
    }
    return true;
}

void RtkGst::rtk_gst_remove_audio_flag(GstPlay *play)
{
    if (play == NULL || play->pipeline == NULL)
        return;

    uint flags, flags_new;
    g_object_get(play->pipeline, "flags", &flags, NULL);
    flags_new = flags & (~GST_PLAY_FLAG_AUDIO);
    g_object_set(play->pipeline, "flags", flags_new, NULL);
    // qDebug () << QString().asprintf("%s:%d flags %p -> %p", __FUNCTION__, __LINE__, flags, flags_new);
}

#if GET_INFO_FROM_FRAMEWORK == 1
void *main_loop(void *param)
{
    GstPlay *play = (GstPlay *)param;

    g_main_loop_run(play->loop);
    return NULL;
}

static GstElement *choose_subtitle_plugin(RTK_SUBTITLE_BIN *subtitle)
{
    qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);
    switch (subtitle->kind) {
        case RTK_DVDSPU:
            subtitle->subtitle = gst_element_factory_make("rtkdvdspu", NULL);
            break;
        case RTK_SRT:
            subtitle->subtitle = gst_element_factory_make("rtksrtrender", NULL);
            break;
        case RTK_ASS:
            subtitle->subtitle = gst_element_factory_make("rtkassrender", NULL);
            break;
        default:
            qDebug () << QString().asprintf("%s:%d unknown subtitle type:%d", __FUNCTION__, __LINE__, subtitle->kind);
            break;
    }
    return subtitle->subtitle;
}

static void on_vdec_pad_added(GstElement *element, GstPad *new_pad, gpointer user_data)
{
    GstPlay *play = (GstPlay *)user_data;
    RTK_VIDEO_BIN *video = &play->video_bin[play->video_index];
    GstPad *sinkpad = nullptr;
    MediaInfo *info = &mediaInfo;
    sinkpad = gst_element_get_static_pad (video->queue2, "sink");

    if (gst_pad_is_linked(sinkpad))
        qDebug () << QString().asprintf("%s:%d gst_pad_is_linked(sinkpad)", __FUNCTION__, __LINE__);
    else if (gst_pad_link(new_pad, sinkpad) != GST_PAD_LINK_OK)
        qDebug () << QString().asprintf("%s:%d gst_pad_link(new_pad, sinkpad) fail", __FUNCTION__, __LINE__);
    // g_object_unref(sinkpad);

    qDebug () << QString().asprintf("%s:%d x=%d, y=%d, width=%d, height=%d", 
                                    __FUNCTION__, __LINE__, play->x, play->y, play->width, play->height);
    GValue location = G_VALUE_INIT;
    GValue tmp = G_VALUE_INIT;
    g_value_init (&location, GST_TYPE_ARRAY);
    g_value_init (&tmp, G_TYPE_INT);
    g_value_set_int (&tmp, play->x);
    gst_value_array_append_value (&location, &tmp);
    g_value_set_int (&tmp, play->y);
    gst_value_array_append_value (&location, &tmp);
    g_value_set_int (&tmp, play->width);
    gst_value_array_append_value (&location, &tmp);
    g_value_set_int (&tmp, play->height);
    gst_value_array_append_value (&location, &tmp);

    if (play->subtitle_count > 0) {
        g_object_set_property (G_OBJECT (video->vsink), "render-rectangle", &location);
        g_object_set_property (G_OBJECT (video->ssink), "render-rectangle", &location);
    } else {
        g_object_set_property (G_OBJECT (video->vsink), "render-rectangle", &location);
    }

    if (play->audio_count <= 0) {
        rtkGst->rtk_gst_set_element_state_no_check (play, play->pipeline, GST_STATE_PLAYING);
        // play->start_playing = TRUE;
#if DEBUG_GSTREAMER == 1
        GST_DEBUG_BIN_TO_DOT_FILE(GST_BIN(play->pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "pipeline_PAUSED_PLAYING");
#endif
    }
    g_value_unset(&location);
    g_value_unset(&tmp);
}

static void on_adec_pad_added(GstElement *element, GstPad *new_pad, gpointer user_data)
{
    qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);
    RTK_AUDIO_BIN *audio = (RTK_AUDIO_BIN *)user_data;
    GstPlay *play = container_of(audio - (sizeof(RTK_AUDIO_BIN) * audio->audio_active_id), GstPlay, audio_bin);
    GstPad *sinkpad = gst_element_get_static_pad (audio->queue2, "sink");

    if (gst_pad_link(new_pad, sinkpad) != GST_PAD_LINK_OK)
        qDebug () << QString().asprintf("%s:%d gst_pad_link(new_pad, sinkpad) fail", __FUNCTION__, __LINE__);
    g_object_unref(sinkpad);
    rtkGst->rtk_gst_set_element_state_no_check (play, play->pipeline, GST_STATE_PLAYING);
    // play->start_playing = TRUE;
#if DEBUG_GSTREAMER == 1
    GST_DEBUG_BIN_TO_DOT_FILE(GST_BIN(play->pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "pipeline_PAUSED_PLAYING");
#endif
}

#if DEBUG_RETRIEVE_TAG_INFO == 1
static void on_pad_caps_changed(GstElement *pad, GParamSpec *pspec,  gpointer user_data)
{

    static const gchar *possible_lanuage_fields[] = {
        "language",
        "lang",
        "audio-language",
        "subtitle-language",
        NULL
    };

    GstCaps *caps = gst_pad_get_current_caps((GstPad *)pad);
    if (!caps)  // caps is not appear, wait for the next time information
        return;
    GstStructure *structure = gst_caps_get_structure (caps, 0);
    qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);
    if (structure == NULL)
        return;

    const gchar *mime = gst_structure_get_name(structure);
    GstPlay *play = (GstPlay *)user_data;
    gchar *caps_str = gst_caps_to_string(caps);
    const gchar *language = NULL;
    for (int i=0; i<play->video_count; i++)
    {
        if (play->video_bin[i].pad == (GstPad *)pad)
        {
            qDebug () << QString().asprintf("%s:%d:video_bin[%d], cap_str=%s", __FUNCTION__, __LINE__, i, caps_str);
            for (int j=0; possible_lanuage_fields[j] != NULL; j++)
            {
                language = gst_structure_get_string(structure, possible_lanuage_fields[j]);
                if (language)
                    break;
            }
            qDebug() << QString().asprintf("%s:%d v language %s", __FUNCTION__, __LINE__, language);
            if (caps)
                gst_caps_unref(caps);
            if (caps_str)
                g_free(caps_str);
            return;
        }
    }
    for (int i=0; i<play->subtitle_count; i++)
    {
        if (play->subtitle_bin[i].pad == (GstPad *)pad)
        {
            qDebug () << QString().asprintf("%s:%d:subtitle_bin[%d], cap_str=%s", __FUNCTION__, __LINE__, i, caps_str);
            for (int j=0; possible_lanuage_fields[j] != NULL; j++)
            {
                language = gst_structure_get_string(structure, possible_lanuage_fields[j]);
                if (language)
                    break;
            }
            qDebug() << QString().asprintf("%s:%d s language %s", __FUNCTION__, __LINE__, language);
            if (caps)
                gst_caps_unref(caps);
            if (caps_str)
                g_free(caps_str);
            return;
        }
    }
    for (int i=0; i<play->audio_count; i++)
    {
        if (play->audio_bin[i].pad == (GstPad *)pad)
        {
            qDebug () << QString().asprintf("%s:%d:audio_bin[%d], cap_str=%s", __FUNCTION__, __LINE__, i, caps_str);
            for (int j=0; possible_lanuage_fields[j] != NULL; j++)
            {
                language = gst_structure_get_string(structure, possible_lanuage_fields[j]);
                if (language)
                    break;
            }
            qDebug() << QString().asprintf("%s:%d a language %s", __FUNCTION__, __LINE__, language);
            if (caps)
                gst_caps_unref(caps);
            if (caps_str)
                g_free(caps_str);
            return;
        }
    }
}
#endif

static GstPadProbeReturn on_first_subtitle_frame(GstPad *pad, GstPadProbeInfo *info, gpointer user_data)
{
    GstPlay *play = (GstPlay *)user_data;
    if (play->video_first_frame == TRUE)
        return GST_PAD_PROBE_REMOVE;
    else
        return GST_PAD_PROBE_DROP;
}

static GstPadProbeReturn on_first_video_frame(GstPad *pad, GstPadProbeInfo *info, gpointer user_data)
{
    GstPlay *play = (GstPlay *)user_data;
    play->video_first_frame = TRUE;
    return GST_PAD_PROBE_REMOVE;
}

static GstPadProbeReturn on_vdec_caps_probe(GstPad *pad, GstPadProbeInfo *info, gpointer user_data)
{
    GstCaps *caps = gst_pad_get_current_caps(pad);
    GstStructure *structure = NULL;
    int width = -1, height = -1;
    RTK_VIDEO_BIN *video = NULL;

    qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);
    if (caps == NULL)
        return GST_PAD_PROBE_OK;

    structure = gst_caps_get_structure (caps, 0);
    if (structure == NULL)
        return GST_PAD_PROBE_OK;

    gst_structure_get_int(structure, "height", &height);
    gst_structure_get_int(structure, "width", &width);

    video = (RTK_VIDEO_BIN *)user_data;
    if (width * height >= 2560 * 1440) {
        g_object_set(video->queue1, "max-size-time", 0, NULL);
        g_object_set(video->queue1, "max-size-bytes", 50 * 1024 * 1024, NULL);
    }

    if (caps)
        gst_caps_unref(caps);

    return GST_PAD_PROBE_REMOVE;
}

static void on_vdec_parsebin_added(GstElement *element, GstPad *new_pad, gpointer user_data)
{
    gst_pad_add_probe(new_pad, GST_PAD_PROBE_TYPE_EVENT_DOWNSTREAM, (GstPadProbeCallback)on_vdec_caps_probe, user_data, NULL);
}

static void on_vdec_element_added(GstBin *bin, GstElement *child, gpointer user_data)
{
    qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);
    const gchar *type_name = G_OBJECT_TYPE_NAME(child);
    GstElementFactory *f = gst_element_get_factory(child);
    const gchar *factory_name = f ? gst_plugin_feature_get_name(GST_PLUGIN_FEATURE(f)) : NULL;

    if ((factory_name && g_strcmp0(factory_name, "parsebin") == 0) || g_str_has_prefix(type_name, "GstParseBin"))
    {
        g_signal_connect(child, "pad-added", G_CALLBACK(on_vdec_parsebin_added), user_data);
    }
}

static void no_dmx_more_pads (GstElement *element, gpointer user_data)
{
    GstPlay *play = (GstPlay *)user_data;
    RTK_VIDEO_BIN *video = NULL;
    RTK_AUDIO_BIN *audio = NULL;
    MediaInfo *info = &mediaInfo;

    qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);

    // GstIterator *pads = gst_element_iterate_pads(element);
    // gboolean done = false;
    // while (!done)
    // {
    //     GValue pad_value = G_VALUE_INIT;
    //     GstIteratorResult res = gst_iterator_next(pads, &pad_value);
    //     switch (res)
    //     {
    //     case GST_ITERATOR_OK:
    //         {
    //             GstPad *pad = GST_PAD(g_value_get_object(&pad_value));
    //             if (!GST_PAD_IS_SRC(pad)){
    //                 gst_object_unref(pad);
    //                 g_value_unset(&pad_value);
    //                 break;
    //             }
    //             GstPadTemplate *templ = gst_pad_get_pad_template (pad);
    //             if (templ) {
    //                 g_signal_connect (pad, "notify::caps", G_CALLBACK(on_pad_caps_changed), play);
    //                 gst_object_unref(templ);
    //             }
    //             gst_object_unref(pad);
    //             g_value_unset(&pad_value);
    //         }
    //         break;
    //     case GST_ITERATOR_RESYNC:
    //         gst_iterator_resync(pads);
    //         break;
    //     case GST_ITERATOR_ERROR:
    //     case GST_ITERATOR_DONE:
    //         done = true;
    //         break;
    //     }
    // }
    // gst_iterator_free (pads);

    qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);
    if (play->video_count > 0) {
        GstPad *sinkpad = NULL;

        play->video_index = 0;
        if (info->vect_idx_v >= 0 && info->vect_idx_v < play->video_count)
        {
            play->video_index = info->vect_idx_v;
        }
        video = &play->video_bin[play->video_index];
        video->queue1 = gst_element_factory_make("rtkhookqueue", NULL);
//      g_object_set(video->queue1, "max-size-time", 0, NULL);
//      g_object_set(video->queue1, "max-size-bytes", 50 * 1024 * 1024, NULL);
        video->dec = gst_element_factory_make("decodebin3", NULL);
        video->queue2 = gst_element_factory_make("rtkhookqueue", NULL);

        QString vsink_str;
        rtkGst->get_sink(&vsink_str, nullptr);
        video->vsink = gst_element_factory_make(vsink_str.toStdString().c_str(), "video-output");

        if (info->enable_video_rotate)
        {
            video->vscale = gst_element_factory_make("rtkvideoscale", "scale");
            video->vhse = gst_element_factory_make("rtkhse", "videoflip");

            g_object_set(G_OBJECT(video->vscale), "force-passthrough", info->is_video_10_bits, NULL);
            g_object_set(G_OBJECT(video->vhse), "rotate", play->rotation_method, NULL);
            gst_bin_add_many(GST_BIN(play->pipeline), video->queue1, video->dec, video->queue2, video->vscale, video->vhse, video->vsink, NULL);
        }
        else
        {
            gst_bin_add_many(GST_BIN(play->pipeline), video->queue1, video->dec, video->queue2, video->vsink, NULL);
        }
        gst_bin_sync_children_states(GST_BIN(play->pipeline));

        // demuxer -> queue1
        sinkpad = gst_element_get_static_pad (video->queue1, "sink");
        if (gst_pad_link(video->pad, sinkpad) != GST_PAD_LINK_OK)
            qDebug () << QString().asprintf("%s:%d gst_pad_link(video->pad, sinkpad) fail", __FUNCTION__, __LINE__);
        g_object_unref(sinkpad);

        // queue1 -> dec
        if (!gst_element_link(video->queue1, video->dec))
            qDebug () << QString().asprintf("%s:%d gst_element_link(video->queue1, video->dec)) fail", __FUNCTION__, __LINE__);

        if (info->enable_video_rotate) {
            if (gst_element_link_many(video->queue2, video->vscale, video->vhse, video->vsink, NULL) != TRUE)
                qDebug () << QString().asprintf("%s:%d gst_element_link_many fail", __FUNCTION__, __LINE__);
        }
        g_signal_connect(video->dec, "element-added", G_CALLBACK(on_vdec_element_added), video);
        g_signal_connect(video->dec, "pad-added", G_CALLBACK(on_vdec_pad_added), play);
#if DEBUG_RETRIEVE_TAG_INFO == 1
        if (video->pad != NULL && GST_PAD_IS_SRC (video->pad))
        {
            qDebug () << QString().asprintf("%s:%d signal video->pad", __FUNCTION__, __LINE__);
            g_signal_connect (video->pad, "notify::caps", G_CALLBACK(on_pad_caps_changed), play);
        }
#endif

        if (play->subtitle_count > 0)
        {
            video->vqueue = gst_element_factory_make("rtkhookqueue", NULL);
            video->squeue = gst_element_factory_make("rtkhookqueue", NULL);
            video->ssink = gst_element_factory_make("waylandsink", NULL);

            play->subtitle_index = 0;
            if (info->vect_idx_s >= 0 && info->vect_idx_s < play->subtitle_count)
            {
                play->subtitle_index = info->vect_idx_s;
            }
            RTK_SUBTITLE_BIN *subtitle = &play->subtitle_bin[play->subtitle_index];
            subtitle->queue1 = gst_element_factory_make("rtkhookqueue", NULL);
            subtitle->subtitle = choose_subtitle_plugin(subtitle);
            gst_bin_add_many(GST_BIN(play->pipeline), subtitle->queue1, subtitle->subtitle, video->vqueue, video->squeue, video->ssink, NULL);
            gst_bin_sync_children_states(GST_BIN(play->pipeline));

            sinkpad = gst_element_get_static_pad (subtitle->queue1, "sink");
            if (gst_pad_link(subtitle->pad, sinkpad) != GST_PAD_LINK_OK)
                qDebug () << QString().asprintf("%s:%d gst_pad_link(subtitle->pad, sinkpad) fail", __FUNCTION__, __LINE__);
            g_object_unref(sinkpad);

            gst_element_link(video->queue2, subtitle->subtitle);
            gst_element_link(subtitle->queue1, subtitle->subtitle);
            gst_element_link(subtitle->subtitle, video->vqueue);
            gst_element_link(subtitle->subtitle, video->squeue);

            GstPad *ssink_pad = gst_element_get_static_pad(video->ssink, "sink");
            GstPad *vsink_pad = gst_element_get_static_pad(video->vsink, "sink");
            gst_pad_add_probe(ssink_pad, (GstPadProbeType)(GST_PAD_PROBE_TYPE_BLOCK | GST_PAD_PROBE_TYPE_BUFFER), (GstPadProbeCallback)on_first_subtitle_frame, play, NULL);
            gst_pad_add_probe(vsink_pad, (GstPadProbeType)(GST_PAD_PROBE_TYPE_BLOCK | GST_PAD_PROBE_TYPE_BUFFER), (GstPadProbeCallback)on_first_video_frame, play, NULL);
            g_object_unref(ssink_pad);
            g_object_unref(vsink_pad);

            gst_element_link(video->vqueue, video->vsink);
            gst_element_link(video->squeue, video->ssink);
#if DEBUG_RETRIEVE_TAG_INFO == 1
            if (subtitle->pad != NULL && GST_PAD_IS_SRC (subtitle->pad))
            {
                qDebug () << QString().asprintf("%s:%d signal subtitle->pad", __FUNCTION__, __LINE__);
                g_signal_connect (subtitle->pad, "notify::caps", G_CALLBACK(on_pad_caps_changed), play);
            }
#endif
        }
    }


    if (play->audio_count > 0) {
        play->audio_index = 0;
        video->asink = gst_element_factory_make("alsasink", NULL);
        video->selector = gst_element_factory_make("input-selector", NULL);
        video->convert = gst_element_factory_make("audioconvert", NULL);
        video->resample = gst_element_factory_make("audioresample", NULL);
        video->capsfilter = gst_element_factory_make("capsfilter", NULL);
        GstCaps *caps = gst_caps_from_string("audio/x-raw,rate=48000,channels=2");
        g_object_set(video->capsfilter, "caps", caps, NULL);
        gst_caps_unref(caps);
        video->volume = gst_element_factory_make("volume", NULL);
        gst_bin_add_many(GST_BIN(play->pipeline), video->selector, video->convert, video->resample, video->capsfilter, video->volume, video->asink, NULL);
        gst_bin_sync_children_states(GST_BIN(play->pipeline));
        if (gst_element_link_many(video->selector, video->convert, video->resample, video->capsfilter, video->volume, video->asink, NULL) != TRUE)
            qDebug () << QString().asprintf("%s:%d gst_element_link_many fail", __FUNCTION__, __LINE__);

        /* the volume range is usually 0.0~10.0, and 0.0~1.0 is generally recommended,
            exceeding 1.0 will amplify the sound and cause distortion or even popping */
        gdouble vol = (gdouble)((gdouble)play->volume_value / VOLUME_MAX);
        g_object_set(video->volume, "volume", vol, NULL);
        play->volume_applied = true;
        qDebug () << QString().asprintf("%s:%d Set volume %d", __FUNCTION__, __LINE__, play->volume_value);

        for (int i = 0; i < play->audio_count; i++) {
            RTK_AUDIO_BIN *audio = &play->audio_bin[i];
            GstPad *sinkpad;
            GstPad *srcpad;

            audio->queue1 = gst_element_factory_make("rtkhookqueue", NULL);
            g_object_set(audio->queue1, "max-size-time", 0, NULL);
            audio->dec = gst_element_factory_make("decodebin3", NULL);
            audio->queue2 = gst_element_factory_make("rtkhookqueue", NULL);
            g_object_set(audio->queue2, "max-size-time", 0, NULL);
            gst_bin_add_many(GST_BIN(play->pipeline), audio->queue1, audio->dec, audio->queue2, NULL);
            gst_bin_sync_children_states(GST_BIN(play->pipeline));

            sinkpad = gst_element_get_static_pad (audio->queue1, "sink");
            if (gst_pad_link(audio->pad, sinkpad) != GST_PAD_LINK_OK)
            {
                qDebug () << QString().asprintf("%s:%d gst_pad_link(audio->pad, sinkpad) fail", __FUNCTION__, __LINE__);
            }
            g_object_unref(sinkpad);
            gst_element_link(audio->queue1, audio->dec);
            srcpad = gst_element_get_static_pad (audio->queue2, "src");
            sinkpad = gst_element_get_request_pad (video->selector, "sink_%u");
            if (gst_pad_link(srcpad, sinkpad) != GST_PAD_LINK_OK)
            {
                qDebug () << QString().asprintf("%s:%d gst_pad_link(srcpad, sinkpad) fail", __FUNCTION__, __LINE__);
            }
            g_object_unref(srcpad);
            g_object_unref(sinkpad);
            audio->audio_active_id = i;
            g_signal_connect(audio->dec, "pad-added", G_CALLBACK(on_adec_pad_added), audio);
#if DEBUG_RETRIEVE_TAG_INFO == 1
            if (audio->pad != NULL && GST_PAD_IS_SRC (audio->pad))
            {
                qDebug () << QString().asprintf("%s:%d signal audio->pad", __FUNCTION__, __LINE__);
                g_signal_connect (audio->pad, "notify::caps", G_CALLBACK(on_pad_caps_changed), play);
            }
#endif
        }
    }
}

#if DEBUG_RETRIEVE_TAG_INFO == 1
static void get_language_from_pad(GstPad *pad, const gchar *pad_name, GstPlay *play)
{
    if (pad == nullptr || play == nullptr)
        return;
        
    GstCaps *caps = gst_pad_get_current_caps(pad);
    if (!caps) {
        qDebug() << QString().asprintf("%s:%d %s pad has no caps yet", __FUNCTION__, __LINE__, pad_name);
        return;
    }

    GstStructure *structure = gst_caps_get_structure(caps, 0);
    if (!structure) {
        gst_caps_unref(caps);
        return;
    }

    const gchar *language = NULL;
    static const gchar *possible_language_fields[] = {
        "language",
        "lang", 
        "audio-language",
        "subtitle-language",
        NULL
    };

    for (int i = 0; possible_language_fields[i] != NULL; i++) {
        language = gst_structure_get_string(structure, possible_language_fields[i]);
        if (language)
            break;
    }

    if (language) {
        qDebug() << QString().asprintf("%s:%d %s language: %s", __FUNCTION__, __LINE__, pad_name, language);
    } else {
        // 嘗試從 streamheader 中解析
        const GValue *streamheader = gst_structure_get_value(structure, "streamheader");
        if (streamheader && GST_VALUE_HOLDS_ARRAY(streamheader)) {
            qDebug() << QString().asprintf("%s:%d %s has streamheader but no language field", __FUNCTION__, __LINE__, pad_name);
        } else {
            qDebug() << QString().asprintf("%s:%d %s language not found in caps", __FUNCTION__, __LINE__, pad_name);
        }
    }

    gst_caps_unref(caps);
}
#endif

static void on_dmx_pad_added (GstElement *element, GstPad *new_pad, gpointer user_data)
{
    GstPlay *play = (GstPlay *)user_data;
    const gchar *mime = NULL;
    GstStructure *structure = NULL;
    GstCaps *caps = gst_pad_get_current_caps(new_pad);
    gchar *caps_str = NULL;
#if DEBUG_RETRIEVE_TAG_INFO == 1
    int v_count = play->video_count;
    int a_count = play->audio_count;
    int s_count = play->subtitle_count;
#endif

    structure = gst_caps_get_structure (caps, 0);
    if (structure == NULL)
        goto finish_pad_add;
    mime = gst_structure_get_name(structure);
    caps_str = gst_caps_to_string(caps);

    qDebug () << QString().asprintf("%s:%d, mime:%s, caps:%s", __FUNCTION__, __LINE__, mime, caps_str);
    if (play->video_count >= MAX_VIDEO_COUNT)
    {
        qDebug () << QString().asprintf("%s:%d exceed video count:%d mine_type:%s", __FUNCTION__, __LINE__, play->video_count, mime);
        goto finish_pad_add;
    }

    if (play->subtitle_count >= MAX_SUBTITLE_COUNT)
    {
        qDebug () << QString().asprintf("%s:%d exceed subtitle count:%d mine_type:%s", __FUNCTION__, __LINE__, play->subtitle_count, mime);
        goto finish_pad_add;
    }

    if (play->audio_count >= MAX_AUDIO_COUNT)
    {
        qDebug () << QString().asprintf("%s:%d exceed audio count:%d mine_type:%s", __FUNCTION__, __LINE__, play->audio_count, mime);
        goto finish_pad_add;
    }

    if (gst_structure_has_name (structure, "video/x-h264")) { // video codec start
        play->video_bin[play->video_count].kind = RTK_H264_VIDEO;
        play->video_bin[play->video_count].pad = new_pad;
        play->video_count++;
    } else if (gst_structure_has_name (structure, "video/x-h265")) {
        play->video_bin[play->video_count].kind = RTK_H265_VIDEO;
        play->video_bin[play->video_count].pad = new_pad;
        play->video_count++;
    } else if (gst_structure_has_name (structure, "video/x-av1")) {
        play->video_bin[play->video_count].kind = RTK_AV1_VIDEO;
        play->video_bin[play->video_count].pad = new_pad;
        play->video_count++;
    } else if (gst_structure_has_name (structure, "video/x-vp8")) {
        play->video_bin[play->video_count].kind = RTK_VP8_VIDEO;
        play->video_bin[play->video_count].pad = new_pad;
        play->video_count++;
    } else if (gst_structure_has_name (structure, "video/x-vp9")) {
        play->video_bin[play->video_count].kind = RTK_VP9_VIDEO;
        play->video_bin[play->video_count].pad = new_pad;
        play->video_count++;
    } else if (gst_structure_has_name (structure, "video/mpeg")) {
        int mpegversion = -1;
        gst_structure_get_int(structure, "mpegversion", &mpegversion);
        if (mpegversion == 1)
            play->video_bin[play->video_count].kind = RTK_MPEG1_VIDEO;
        else if (mpegversion == 2)
            play->video_bin[play->video_count].kind = RTK_MPEG2_VIDEO;
        else if (mpegversion == 4)
            play->video_bin[play->video_count].kind = RTK_MPEG4_VIDEO;
        else
            goto finish_pad_add;

        play->video_bin[play->video_count].pad = new_pad;
        play->video_count++;
    } else if (gst_structure_has_name (structure, "video/x-wmv")) {
        play->video_bin[play->video_count].kind = RTK_WMV_VIDEO;
        play->video_bin[play->video_count].pad = new_pad;
        play->video_count++;
    } else if (gst_structure_has_name (structure, "subpicture/x-pgs")) { // subtitle codec start
        play->subtitle_bin[play->subtitle_count].kind = RTK_DVDSPU;
        play->subtitle_bin[play->subtitle_count].pad = new_pad;
        play->subtitle_count++;
    } else if (gst_structure_has_name (structure, "text/x-raw")) {
        play->subtitle_bin[play->subtitle_count].kind = RTK_SRT;
        play->subtitle_bin[play->subtitle_count].pad = new_pad;
        play->subtitle_count++;
    } else if (gst_structure_has_name (structure, "application/x-ass") || gst_structure_has_name (structure, "application/x-ssa")) {
        play->subtitle_bin[play->subtitle_count].kind = RTK_ASS;
        play->subtitle_bin[play->subtitle_count].pad = new_pad;
        play->subtitle_count++;
    } else if (gst_structure_has_name (structure, "audio/x-ac3")) { // audio codec start
        play->audio_bin[play->audio_count].kind = RTK_AC3_AUDIO;
        play->audio_bin[play->audio_count].pad = new_pad;
        play->audio_count++;
    } else if (gst_structure_has_name (structure, "audio/x-eac3")) {
        play->audio_bin[play->audio_count].kind = RTK_EAC3_AUDIO;
        play->audio_bin[play->audio_count].pad = new_pad;
        play->audio_count++;
    } else if (gst_structure_has_name (structure, "audio/mpeg")) {
        int mpegversion = -1;
        gst_structure_get_int(structure, "mpegversion", &mpegversion);
        if (mpegversion == 1) {
            int layer = -1;
            gst_structure_get_int(structure, "layer", &layer);
            if (layer == 1)
                play->audio_bin[play->audio_count].kind = RTK_MP1_AUDIO;
            else if (layer == 2)
                play->audio_bin[play->audio_count].kind = RTK_MP2_AUDIO;
            else if (layer == 3)
                play->audio_bin[play->audio_count].kind = RTK_MP3_AUDIO;
            else
                goto finish_pad_add;
        } else if (mpegversion == 4)
            play->audio_bin[play->audio_count].kind = RTK_AAC_AUDIO;

        play->audio_bin[play->audio_count].pad = new_pad;
        play->audio_count++;
    } else if (gst_structure_has_name (structure, "audio/x-opus")) {
        play->audio_bin[play->audio_count].kind = RTK_OPUS_AUDIO;
        play->audio_bin[play->audio_count].pad = new_pad;
        play->audio_count++;
    } else if (gst_structure_has_name (structure, "audio/x-vorbis")) {
        play->audio_bin[play->audio_count].kind = RTK_VORBIS_AUDIO;
        play->audio_bin[play->audio_count].pad = new_pad;
        play->audio_count++;
    } else if (gst_structure_has_name (structure, "audio/x-dts")) {
        play->audio_bin[play->audio_count].kind = RTK_DTS_AUDIO;
        play->audio_bin[play->audio_count].pad = new_pad;
        play->audio_count++;
    } else {
        qDebug () << QString().asprintf("%s:%d unsupported codec format:%s", __FUNCTION__, __LINE__, caps_str);
    }

#if DEBUG_RETRIEVE_TAG_INFO == 1
    if (v_count < play->video_count)
    {
        get_language_from_pad(new_pad, "video", play);
    }
    if (a_count < play->audio_count)
    {
        get_language_from_pad(new_pad, "audio", play);
    }
    if (s_count < play->subtitle_count)
    {
        get_language_from_pad(new_pad, "subtitle", play);
    }
#endif

finish_pad_add:
    if (caps)
        gst_caps_unref(caps);

    if (caps_str)
        g_free(caps_str);
}

static void typefound_cb(GstElement *typefind, guint probability, GstCaps *caps, gpointer user_data)
{
    GstPlay *play = (GstPlay *)user_data;
    const gchar *mime = NULL;
    mime = gst_structure_get_name(gst_caps_get_structure(caps, 0));
    qDebug () << QString().asprintf("%s:%d container mime:%s", __FUNCTION__, __LINE__, mime);
    if (g_str_has_prefix(mime, "video/quicktime") || g_str_has_prefix(mime, "video/mp4")) {
        play->container_kind = RTK_MP4_CONTAINER;
    } else if (g_str_has_prefix(mime, "video/x-matroska") || g_str_has_prefix(mime, "video/webm")) {
        play->container_kind = RTK_MKV_CONTAINER;
    } else if (g_str_has_prefix(mime, "video/mpegts")) {
        play->container_kind = RTK_TS_CONTAINER;
    } else if (g_str_has_prefix(mime, "video/x-ms-asf")) {
        play->container_kind = RTK_ASF_CONTAINER;
    } else if (g_str_has_prefix(mime, "video/mpeg")) {
        play->container_kind = RTK_PS_CONTAINER;
    } else if (g_str_has_prefix(mime, "video/x-msvideo")) {
        play->container_kind = RTK_AVI_CONTAINER;
    } else {
        qDebug () << QString().asprintf("%s:%d unsupported container format:%s", __FUNCTION__, __LINE__, mime);
        play->container_kind = RTK_UNKNOWN_CONTAINER;
    }
#if 0
    if (play->container_kind != RTK_UNKNOWN_CONTAINER) {
        gst_bin_add(GST_BIN(play->pipeline), play->demux);
        gst_bin_sync_children_states(GST_BIN(play->pipeline));
        gst_element_link(play->typefind, play->demux);
        g_signal_connect (play->demux, "pad-added", G_CALLBACK (on_dmx_pad_added), play);
        g_signal_connect (play->demux, "no-more-pads", G_CALLBACK (no_dmx_more_pads), play);
    }
#endif
    g_main_loop_quit (play->loop);
}

void RtkGst::rtk_gst_switch_audio (GstPlay *play, int index)
{
    gchar active_pad[32] = {0};
    GstPad *pad = NULL;
    RTK_VIDEO_BIN *video = NULL;

    if (index < 0 ||
        index >= play->audio_count ||
        play->audio_count <= 0 ||
        play->audio_index == index)
    {
        if (if_debug)
            qDebug () << QString().asprintf("%s:%d play %p, index=%d => no switch", __FUNCTION__, __LINE__, play, index);
        return;
    }

    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p, index:%d->%d", __FUNCTION__, __LINE__, play, play->audio_index, index);

    video = &play->video_bin[play->video_index];
    GstPad *test;
    g_object_get(video->selector, "active-pad", &test, NULL);
    gst_object_unref(test);

    sprintf(active_pad, "sink_%u", index);
    qDebug () << QString().asprintf("%s:%d audio active_pad:%s", __FUNCTION__, __LINE__, active_pad);
    pad = gst_element_get_static_pad(video->selector, active_pad);
    g_object_set(video->selector, "active-pad", pad, NULL);
    gst_object_unref(pad);
    play->audio_index = index;
    rtk_gst_set_element_state_no_check (play, play->pipeline, GST_STATE_PLAYING);
}

void RtkGst::rtk_gst_switch_subtitle (GstPlay *play, int index)
{
    GstPad *sinkpad = NULL;
    RTK_VIDEO_BIN *video = &play->video_bin[play->video_index];
    RTK_SUBTITLE_BIN *subtitle_current = NULL;
    RTK_SUBTITLE_BIN *subtitle_new = NULL;

    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p, index=%lf",
                    __FUNCTION__, __LINE__, play, index);

    if (index < 0 ||
        index >= play->subtitle_count ||
        play->subtitle_count <= 0 ||
        play->subtitle_index == index)
    {
        if (if_debug)
            qDebug () << QString().asprintf("%s:%d play %p, index=%d => no switch", __FUNCTION__, __LINE__, play, index);
        return;
    }

    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p, index:%d->%d", __FUNCTION__, __LINE__, play, play->subtitle_index, index);


    subtitle_current = &play->subtitle_bin[play->subtitle_index];
    subtitle_new = &play->subtitle_bin[index];

    g_object_set(G_OBJECT(subtitle_current->subtitle), "silent", TRUE, NULL);
    g_object_set(G_OBJECT(video->ssink), "silent", TRUE, NULL);
    g_object_set(G_OBJECT(video->ssink), "clear", TRUE, NULL);
// flush previous subtitle frame
    gst_element_send_event(video->squeue, gst_event_new_flush_start());
    gst_element_send_event(video->squeue, gst_event_new_flush_stop(FALSE));
    gint64 current_position = 0;
    gst_element_query_position(play->pipeline, GST_FORMAT_TIME, &current_position);
    gst_element_send_event(video->squeue, gst_event_new_gap(current_position, 0));

    rtk_gst_set_element_state(play, play->pipeline, GST_STATE_PAUSED);
    gst_element_unlink(video->queue2, subtitle_current->subtitle);

    sinkpad = gst_element_get_static_pad (subtitle_current->queue1, "sink");
    gst_pad_unlink(subtitle_current->pad, sinkpad);
    g_object_unref(sinkpad);

    gst_element_unlink(subtitle_current->subtitle, video->vqueue);
    gst_element_unlink(subtitle_current->subtitle, video->squeue);
    gst_element_unlink(subtitle_current->queue1, subtitle_current->subtitle);
    rtk_gst_set_element_state(play, subtitle_current->queue1, GST_STATE_NULL);
    rtk_gst_set_element_state(play, subtitle_current->subtitle, GST_STATE_NULL);
    gst_bin_remove(GST_BIN(play->pipeline), subtitle_current->queue1);
    gst_bin_remove(GST_BIN(play->pipeline), subtitle_current->subtitle);

    subtitle_new->queue1 = gst_element_factory_make("rtkhookqueue", NULL);
    subtitle_new->subtitle = choose_subtitle_plugin(subtitle_new);

    gst_bin_add_many(GST_BIN(play->pipeline), subtitle_new->queue1, subtitle_new->subtitle, NULL);
    gst_bin_sync_children_states(GST_BIN(play->pipeline));
    sinkpad = gst_element_get_static_pad (subtitle_new->queue1, "sink");
    if (gst_pad_link(subtitle_new->pad, sinkpad) != GST_PAD_LINK_OK)
    {
        qDebug () << QString().asprintf("%s:%d gst_pad_link(subtitle_new->pad, sinkpad) fail", __FUNCTION__, __LINE__);
    }
    g_object_unref(sinkpad);
    gst_element_link(video->queue2, subtitle_new->subtitle);
    gst_element_link(subtitle_new->queue1, subtitle_new->subtitle);
    gst_element_link(subtitle_new->subtitle, video->vqueue);
    gst_element_link(subtitle_new->subtitle, video->squeue);
    g_object_set(G_OBJECT(video->ssink), "silent", FALSE, NULL);

    play->subtitle_index = index;
    rtk_gst_set_element_state_no_check (play, play->pipeline, GST_STATE_PLAYING);
}

bool RtkGst::rtk_gst_play_new(GstPlay **play_p, const QString filepath, QWidget *gst_window,
                                  bool bFullscreen,
                                  int x, int y, int width, int height,
                                  bool bAudio)
{
    if (play_p == NULL)
        return false;

    // Convert QString to std::string, then to const char*
    string filepath_str = filepath.toStdString();
    const char* filepath_cstr = filepath_str.c_str();

    GstPlay *play_org = *play_p;
    //pause case
    if (play_org!= NULL)
    {
        if (if_debug)
            qDebug () << QString().asprintf("%s:%d play_p %p play %p resume",
                        __FUNCTION__, __LINE__, play_p, play_org);
        rtk_gst_resume (play_org);
        return true;
    }

    GstPlay *play;

    //Get video info, subtitle format, video codec description by executing the command
    MediaInfo *info = get_media_info_from_framework(filepath_str);

    if (info == NULL || !info->already_get_info || info->file_path != filepath_str)
    {
        qDebug () << QString().asprintf("%s:%d get media info fail !", __FUNCTION__, __LINE__);
    }
    else if (info->decodable_v_count <= 0 && info->decodable_a_count <= 0)
    {
        qDebug () << QString().asprintf("%s:%d filepath=%s undecodable ! return fail !", __FUNCTION__, __LINE__, filepath_cstr);
        return false;
    }

    play = g_new0 (GstPlay, 1);
    *play_p = play;
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play_p %p play %p filepath=%s bFullscreen=%d x=%d y=%d w=%d h=%d, bAudio=%d",
                    __FUNCTION__, __LINE__, play_p, play,
                    filepath_cstr, bFullscreen, x, y, width, height, bAudio);

    play->player_name = "player1";
    for (int i=0; i<MAX_VIDEO_COUNT; i++)
    {
        play->video_bin[i].kind = RTK_UNKNOWN_VIDEO;
    }
    play->video_index = -1;
    play->video_count = 0;
    for (int i=0; i<MAX_SUBTITLE_COUNT; i++)
    {
        play->subtitle_bin[i].kind = RTK_UNKNOWN_SUBTITLE;
    }
    play->subtitle_index = -1;
    play->subtitle_count = 0;
    for (int i=0; i<MAX_AUDIO_COUNT; i++)
    {
        play->audio_bin[i].kind = RTK_UNKNOWN_AUDIO;
    }
    play->audio_index = -1;
    play->audio_count = 0;
    // play->pipeline_already_quit = FALSE;
    // play->start_playing = FALSE;
    // play->rate = 1.0;
    play->x = x;
    play->y = y;
    play->width = width;
    play->height = height;
    // copy_media_info(&(play->info), info);
    play->volume_value = VOLUME_DEF;
    play->volume_applied = false;
    play->video_first_frame = false;
    play->loop = g_main_loop_new (NULL, FALSE);
    play->rotation_method = 0;

    gst_init(NULL, NULL);
    play->pipeline = gst_pipeline_new(play->player_name.c_str());
    play->src = gst_element_factory_make("filesrc", NULL);
    play->typefind = gst_element_factory_make("typefind", NULL);

    g_object_set(G_OBJECT(play->src), "location", filepath_cstr, NULL);
    gst_bin_add_many(GST_BIN(play->pipeline), play->src, play->typefind, NULL);
    if (!gst_element_link(play->src, play->typefind))
        qDebug () << QString().asprintf("%s:%d gst_element_link(play->src, play->typefind) fail", __FUNCTION__, __LINE__);

    play->bus = gst_pipeline_get_bus (GST_PIPELINE (play->pipeline));
    bus_monitor_running = true;
    pthread_create(&thread_id_bus, NULL, bus_monitor, (void *)play);

    g_signal_connect(play->typefind, "have-type", G_CALLBACK(typefound_cb), play);
    rtk_gst_set_element_state(play, play->pipeline, GST_STATE_PAUSED);
    g_main_loop_run(play->loop);

    /* already found container format */
    rtk_gst_set_element_state(play, play->pipeline, GST_STATE_NULL);
    rtk_gst_unref_element(play->pipeline);

    bus_monitor_running = false;
    if (thread_id_bus)
    {
        pthread_cancel(thread_id_bus);
        pthread_join(thread_id_bus, 0);
        thread_id_bus = 0;
    }
    if (play->bus)
        gst_object_unref(play->bus);

    if (play->loop)
        g_main_loop_unref(play->loop);

    /* check container format */
    QString container_str;
    switch (play->container_kind)
    {
    case RTK_MP4_CONTAINER:
        container_str = "qtdemux";
        break;
    case RTK_MKV_CONTAINER:
        container_str = "matroskademux";
        break;
    case RTK_TS_CONTAINER:
        container_str = "tsdemux";
        break;
    case RTK_ASF_CONTAINER:
        container_str = "asfdemux";
        break;
    case RTK_PS_CONTAINER:
        container_str = "mpegpsdemux";
        break;
    case RTK_AVI_CONTAINER:
        container_str = "avidemux";
        break;
    default:
        qDebug () << QString().asprintf("%s:%d unknown container:%s, return fail !",
                    __FUNCTION__, __LINE__, container_str.toStdString().c_str());
        return false;
    }
    play->demux = gst_element_factory_make(container_str.toStdString().c_str(), NULL);
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d container:%s",
                    __FUNCTION__, __LINE__, container_str.toStdString().c_str());

    play->loop = g_main_loop_new (NULL, FALSE);
    play->pipeline = gst_pipeline_new(play->player_name.c_str());
    play->src = gst_element_factory_make("filesrc", NULL);
    g_object_set(G_OBJECT(play->src), "location", filepath_cstr, NULL);

    gst_bin_add_many(GST_BIN(play->pipeline), play->src, play->demux, NULL);
    if (!gst_element_link(play->src, play->demux))
        qDebug () << QString().asprintf("%s:%d gst_element_link(play->src, play->demux) fail", __FUNCTION__, __LINE__);

    play->bus = gst_pipeline_get_bus (GST_PIPELINE (play->pipeline));
    bus_monitor_running = true;
    pthread_create(&thread_id_bus, NULL, bus_monitor, (void *)play);

    g_signal_connect (play->demux, "pad-added", G_CALLBACK (on_dmx_pad_added), play);
    g_signal_connect (play->demux, "no-more-pads", G_CALLBACK (no_dmx_more_pads), play);
#if DEBUG_RETRIEVE_TAG_INFO == 1
    g_signal_connect (play->demux, "tag-found", G_CALLBACK (on_dmx_tag_found), play);
#endif

    rtk_gst_set_element_state(play, play->pipeline, GST_STATE_PAUSED);
    pthread_create(&thread_id_main_loop, NULL, main_loop, (void *)play);

    return true;
}
#else
bool RtkGst::rtk_gst_play_new(GstPlay **play_p, const QString filepath, QWidget *gst_window,
                                  bool bFullscreen,
                                  int x, int y, int width, int height,
                                  bool bAudio)
{
    if (play_p == NULL)
        return false;

    // Convert QString to std::string, then to const char*
    string filepath_str = filepath.toStdString();
    const char* filepath_cstr = filepath_str.c_str();

    GstPlay *play_org = *play_p;
    //pause case
    if (play_org!= NULL)
    {
        if (if_debug)
            qDebug () << QString().asprintf("%s:%d play_p %p play %p resume",
                        __FUNCTION__, __LINE__, play_p, play_org);
        rtk_gst_resume (play_org);
        return true;
    }

    GstElement *videosink;
    GstElement *video_bin;
    GstPlay *play;

    //Get video info, subtitle format, video codec description by executing the command
    MediaInfo *info = get_media_info(filepath_str);

    if (info == NULL || !info->already_get_info || info->file_path != filepath_str)
    {
        qDebug () << QString().asprintf("%s:%d get media info fail !", __FUNCTION__, __LINE__);
    }

    play = g_new0 (GstPlay, 1);
    *play_p = play;
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play_p %p play %p filepath=%s bFullscreen=%d x=%d y=%d w=%d h=%d, bAudio=%d",
                    __FUNCTION__, __LINE__, play_p, play,
                    filepath_cstr, bFullscreen, x, y, width, height, bAudio);

    gst_init(NULL, NULL);

    if(info->subtitle_format == "NONE") {
        play->pipeline = gst_element_factory_make ("playbin", "playbin");
        videosink = gst_element_factory_make(video_sink_str.toStdString().c_str(), "video-output");

        play->rtkvideoscale = gst_element_factory_make("rtkvideoscale", "scale");
        g_object_set(G_OBJECT(play->rtkvideoscale), "force-passthrough", info->is_video_10_bits, NULL);

        // Create video_bin, include videoflip and videosink
        video_bin = gst_bin_new("video_bin");
        play->rtkvideoflip = gst_element_factory_make("rtkhse", "videoflip");

        // Set rotation
        play->rotation_method = 0;
        g_object_set(G_OBJECT(play->rtkvideoflip), "rotate", play->rotation_method, NULL);

        // Add video_bin
        gst_bin_add_many(GST_BIN(video_bin), play->rtkvideoscale, play->rtkvideoflip, videosink, NULL);
        gst_element_link_many(play->rtkvideoscale, play->rtkvideoflip, videosink);

        // Set ghost pad, let playbin use bin to do video-sink
        GstPad *pad = gst_element_get_static_pad(play->rtkvideoscale, "sink");
        GstPad *ghost_pad = gst_ghost_pad_new("sink", pad);
        gst_pad_set_active(ghost_pad, TRUE);
        gst_element_add_pad(video_bin, ghost_pad);
        gst_object_unref(pad);

        // Set video-sink of playbin
        g_object_set(play->pipeline, "video-sink", video_bin, NULL);

        GstVideoOverlay *overlay = GST_VIDEO_OVERLAY(videosink);
        if(overlay != NULL) {
            gst_video_overlay_set_render_rectangle(overlay, x, y, width, height);

            WId winid = 0;
            if (gst_window != NULL)
                winid = gst_window->winId();
            gst_video_overlay_set_window_handle(overlay, winid);
        }

        if(!filepath.isEmpty()) {
            qDebug() << "Play filepath:" << filepath;
            QUrl fileUri = QUrl::fromLocalFile(filepath);
            QString gstreamerUri = fileUri.toString();
            qDebug() << "Play Uri:" << gstreamerUri;
            g_object_set(play->pipeline, "uri", gstreamerUri.toUtf8().constData(), NULL);
        }

        if(bAudio != true)
            rtk_gst_remove_audio_flag (play);
        else
            g_object_set(play->pipeline, "current-audio", 0, NULL);

        play->bus = GST_ELEMENT_BUS (play->pipeline);

        rtk_gst_set_element_state_no_check (play, play->pipeline, GST_STATE_PLAYING);
    }
    else { //Subtitle with SRT, PGS, ASS
        char pipeline_str[1024]; // Define pipeline string buffer
        char rectangle[32]; // Sufficient size for "<x,y,width,height>"

        // Create the rectangle string
        snprintf(rectangle, sizeof(rectangle), "<%d,%d,%d,%d>", x, y, width, height);
        string rectangle_str = rectangle;

        if (info->video_codec_desc == "265") { // H.265
            snprintf(pipeline_str, sizeof(pipeline_str),
                "rtksubtitlebin name=r "
                "filesrc location=\"%s\" ! parsebin name=d "
                "d. ! r.subtitle_sink r.subtitle_src ! rtkhookqueue ! %s render-rectangle=\"%s\" "
                "d. ! rtkhookqueue ! h265parse ! v4l2h265dec ! r.video_sink r.video_src ! "
                "rtkhookqueue ! %s render-rectangle=\"%s\" ",
                filepath_cstr,
                text_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str()
            );
        } else { // H.264 and others
            snprintf(pipeline_str, sizeof(pipeline_str),
                "rtksubtitlebin name=r "
                "filesrc location=\"%s\" ! parsebin name=d "
                "d. ! r.subtitle_sink r.subtitle_src ! rtkhookqueue ! %s render-rectangle=\"%s\" "
                "d. ! rtkhookqueue ! h264parse ! v4l2h264dec ! r.video_sink r.video_src ! "
                "rtkhookqueue ! %s render-rectangle=\"%s\" ",
                filepath_cstr,
                text_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str()
            );
        }

        if(bAudio == true)
        {
            int start_idx = strlen(pipeline_str);
            snprintf(&pipeline_str[start_idx], sizeof(pipeline_str) - start_idx,
                "d. ! queue ! decodebin ! audioconvert ! audioresample ! volume name=gst_volume ! autoaudiosink ");
        }

        qDebug() << pipeline_str;
        play->pipeline = gst_parse_launch(pipeline_str, nullptr);

        play->bus = GST_ELEMENT_BUS (play->pipeline);

        rtk_gst_set_element_state_no_check (play, play->pipeline, GST_STATE_PLAYING);
    }
#if DEBUG_GSTREAMER == 1
    GST_DEBUG_BIN_TO_DOT_FILE(GST_BIN(play->pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "pipeline_PAUSED_PLAYING");
#endif

    bus_monitor_running = true;
    pthread_create(&thread_id_bus, NULL, bus_monitor, (void *)play);
    return true;
}
#endif

bool RtkGst::rtk_gst_play_new(const QString filepath, QWidget *gst_window,
                                  bool bFullscreen,
                                  int x, int y, int width, int height,
                                  bool bAudio)
{
    return rtk_gst_play_new (&g_play, filepath,  gst_window, bFullscreen, x, y, width, height, bAudio);
}

void RtkGst::rtk_gst_play_free(GstPlay **play_p)
{
    if(play_p == NULL || *play_p == NULL)
        return;
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play_p %p", __FUNCTION__, __LINE__, play_p);

    if (g_face_recognition_process.state() == QProcess::Running)
    {
        g_face_recognition_process.terminate();
        g_face_recognition_process.waitForFinished(5000);
        qDebug() << "Face recognition process terminated.";
    }

    GstPlay *play = *play_p;

    bus_monitor_running = false;

    if (thread_id_bus)
    {
        pthread_cancel(thread_id_bus);
        pthread_join(thread_id_bus, 0);
        thread_id_bus = 0;
    }

#if GET_INFO_FROM_FRAMEWORK == 1
#if 0
    if (play->loop && play->pipeline_already_quit == FALSE) {
        play->start_playing = FALSE;
        g_main_loop_quit(play->loop);
    }
#else
    if (play->loop)
    {
        g_main_loop_quit(play->loop);
        pthread_join(thread_id_main_loop, 0);
        thread_id_main_loop = 0;
    }
#endif

#endif

    // if(play->channel_list)
    //     free(play->channel_list);
    // if(play->demux && GST_OBJECT_REFCOUNT(play->demux) != 0)
    //     gst_object_unref (play->demux);

    if (play->pipeline)
    {
        rtk_gst_set_element_state (play, play->pipeline, GST_STATE_NULL);

        /*
        Due to the issue in both YOLO and SSD MobileNet modes where stopping and then playing a video
        causes nnstreamer to have resource cleanup problems, a workaround is to try adding this line,
        which has the effect of cleaning up resources.
        */
        GstIterator *it = gst_bin_iterate_elements(GST_BIN(play->pipeline)); // This will increment GST_OBJECT_REFCOUNT(play->pipeline)

        rtk_gst_unref_element(play->pipeline);
        play->pipeline = NULL;
    }

#if GET_INFO_FROM_FRAMEWORK == 1
    if (play->bus)
    {
        gst_object_unref(play->bus);
        play->bus = NULL;
    }

    if (play->loop)
    {
        g_main_loop_unref(play->loop);
        play->loop = NULL;
    }
#endif

    g_free (play);
    *play_p = NULL;
}

void RtkGst::rtk_gst_play_free() {
    rtk_gst_play_free(&g_play);
}

bool RtkGst::rtk_gst_seek_by_slider(GstPlay *play, gdouble rate)
{
    gint64 duration = 0;

    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p, rate=%lf",
                    __FUNCTION__, __LINE__, play, rate);
    if(play == NULL || play->pipeline == NULL)
        return false;

    GstState state;
    gst_element_get_state(play->pipeline, &state, NULL, GST_CLOCK_TIME_NONE);
    if (!gst_element_query_duration(play->pipeline, GST_FORMAT_TIME, &duration)) {
        g_printerr("Failed to query duration.\n");
        return false;
    }

    //GstSeekFlags seekFlags = static_cast<GstSeekFlags>(0);  // No flags
    GstSeekFlags seekFlags = static_cast<GstSeekFlags>(GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_ACCURATE);
    if (!gst_element_seek_simple(play->pipeline, GST_FORMAT_TIME, seekFlags, duration*rate)) {
        g_printerr("Seek failed to position %" GST_TIME_FORMAT "\n", GST_TIME_ARGS(duration*rate));
        return false;
    }

    return true;
}

bool RtkGst::rtk_gst_seek_by_slider(gdouble rate)
{
    return rtk_gst_seek_by_slider(g_play, rate);
}

bool RtkGst::rtk_gst_seek_with_offset(GstPlay *play, gint64 offset)
{
    gint64 current_position = 0;

    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p, offset=%ld",
                    __FUNCTION__, __LINE__, play, offset);
    if(play == NULL || play->pipeline == NULL)
        return false;

    GstState state;
    gst_element_get_state(play->pipeline, &state, NULL, GST_CLOCK_TIME_NONE);
    if (!gst_element_query_position(play->pipeline, GST_FORMAT_TIME, &current_position)) {
        g_printerr("Failed to query current position.\n");
        return false;
    }

    gint64 new_position = current_position + offset*GST_SECOND;
    new_position = new_position < 0 ? 0 : new_position;

    //GstSeekFlags seekFlags = static_cast<GstSeekFlags>(0);  // No flags
    GstSeekFlags seekFlags = static_cast<GstSeekFlags>(GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_ACCURATE);
    if (!gst_element_seek_simple(play->pipeline, GST_FORMAT_TIME, seekFlags, new_position)) {
        g_printerr("Seek failed to position %" GST_TIME_FORMAT "\n", GST_TIME_ARGS(new_position));
        return false;
    }

    return true;
}

bool RtkGst::rtk_gst_seek_with_offset(gint64 offset)
{
    return rtk_gst_seek_with_offset(g_play, offset);
}

void RtkGst::rtk_gst_speedchange(GstPlay *play, gdouble rate)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p, rate=%lf",
                    __FUNCTION__, __LINE__, play, rate);
    if(play == NULL || play->pipeline == NULL)
        return;

    //get position
    gint64 position = GST_CLOCK_TIME_NONE;
    if (!gst_element_query_position(play->pipeline, GST_FORMAT_TIME, &position)) {
        g_printerr("Failed to retrieve current position\n");
        return;
    }

    GstState state;
    GstSeekFlags flags = static_cast<GstSeekFlags>(0);  // No flags
    gst_element_get_state(play->pipeline, &state, NULL, GST_CLOCK_TIME_NONE);
    if (state == GST_STATE_PLAYING || state == GST_STATE_PAUSED)
    {
        if (state == GST_STATE_PAUSED)
            // change speed should on playing state, otherwise thread will be locked on preroll() behavior
            rtk_gst_set_element_state (play, play->pipeline, GST_STATE_PLAYING);
        if (!gst_element_seek(play->pipeline, rate, GST_FORMAT_TIME,
                              flags,
                              GST_SEEK_TYPE_SET, position,
                              GST_SEEK_TYPE_NONE, GST_CLOCK_TIME_NONE)) {
            g_printerr("Failed to set playback speed to %.2fx\n", rate);
        } else {
            g_print("Playback speed set to %.2fx\n", rate);
        }
        if (state == GST_STATE_PAUSED)
            rtk_gst_set_element_state (play, play->pipeline, GST_STATE_PAUSED);
    }
    else
        g_printerr("Failed to set playback speed to %.2fx for inappropriate state %s\n", rate,
                    gst_element_state_get_name(state));
}

void RtkGst::rtk_gst_speedchange(gdouble rate)
{
    rtk_gst_speedchange (g_play, rate);
}

bool RtkGst::rtk_gst_pause(GstPlay *play)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p", __FUNCTION__, __LINE__, play);
    if(play == NULL || play->pipeline == NULL)
        return false;

    bool result = rtk_gst_set_element_state (play, play->pipeline, GST_STATE_PAUSED);
#if DEBUG_GSTREAMER == 1
    GST_DEBUG_BIN_TO_DOT_FILE(GST_BIN(play->pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "pipeline_PLAYING_PAUSED");
#endif
    return result;
}

bool RtkGst::rtk_gst_pause()
{
    return rtk_gst_pause(g_play);
}

bool RtkGst::rtk_gst_resume(GstPlay *play)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p", __FUNCTION__, __LINE__, play);
    if(play == NULL)
        return false;

    bool result = rtk_gst_set_element_state (play, play->pipeline, GST_STATE_PLAYING);
    return result;
}

bool RtkGst::rtk_gst_resume()
{
    return rtk_gst_resume(g_play);
}

void RtkGst::rtk_gst_rotation(GstPlay *play)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p", __FUNCTION__, __LINE__, play);
#if GET_INFO_FROM_FRAMEWORK == 1
    RTK_VIDEO_BIN *bin = NULL;
    if(play == NULL)
        return;
    if (play->rtkvideoflip == NULL)
    {
        if (play->video_index >= MAX_VIDEO_COUNT || play->video_index >= play->video_count)
            return;
        bin = &play->video_bin[play->video_index];
        if (bin == NULL || bin->vhse == NULL)
            return;
    }
#else
    if(play == NULL || play->rtkvideoflip == NULL)
        return;
#endif

    if(play->rotation_method < 3){
        play->rotation_method++;
    }
    else{
        play->rotation_method = 0;
    }
#if GET_INFO_FROM_FRAMEWORK == 1
    if (play->rtkvideoflip != NULL)
        g_object_set(G_OBJECT(play->rtkvideoflip), "rotate", play->rotation_method, NULL);
    else
        g_object_set(G_OBJECT(bin->vhse), "rotate", play->rotation_method, NULL);
#else
    g_object_set(G_OBJECT(play->rtkvideoflip), "rotate", play->rotation_method, NULL);
#endif
}

void RtkGst::rtk_gst_rotation()
{
    rtk_gst_rotation (g_play);
}

void RtkGst::rtk_gst_play_ai(GstPlay **play_p, const QString filepath, QString selectedMode,
                            bool bFullscreen, int x, int y, int width, int height,
                            AiParam *param, bool bAudio)
{
    if (play_p == NULL)
        return;

    // Convert QString to std::string, then to const char*
    string filepath_str = filepath.toStdString();
    const char* filepath_cstr = filepath_str.c_str();

    GstPlay *play_org = *play_p;
    //pause case
    if (play_org!= NULL)
    {
        if (if_debug)
            qDebug () << QString().asprintf("%s:%d play_p %p play %p resume",
                        __FUNCTION__, __LINE__, play_p, play_org);
        rtk_gst_resume (play_org);
        return;
    }

    char pipeline_str[2048]; // Define pipeline string buffer
    char video_size[32]; //Sufficient size for "width=x,height=y"
    char rectangle[32]; // Sufficient size for "<x,y,width,height>"
    char option_size[16]; // Sufficient size for "width:height"

    GstPlay *play;

    play = g_new0 (GstPlay, 1);
    *play_p = play;
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play_p %p play %p filepath=%s selectedMode=%s bFullscreen=%d x=%d y=%d w=%d h=%d, bAudio=%d",
                    __FUNCTION__, __LINE__, play_p, play,
                    filepath_cstr, selectedMode.toStdString().c_str(),
                    bFullscreen, x, y, width, height, bAudio);

    gst_init(NULL, NULL);

    // Create the rectangle string and option4 string
    snprintf(video_size, sizeof(video_size), "width=%d,height=%d", width, height);
    snprintf(rectangle, sizeof(rectangle), "<%d,%d,%d,%d>", x, y, width, height);
    snprintf(option_size, sizeof(option_size), "%d:%d", width, height);
    string video_size_str = video_size;
    string rectangle_str = rectangle;
    string option_size_str = option_size;

    if (filepath_str.rfind("/dev", 0) == 0) // for usb camera
    {
        if (selectedMode == "posenet"){
            //pose
            snprintf(pipeline_str, sizeof(pipeline_str),
                    "v4l2src device=\"%s\" ! videoconvert ! video/x-raw,format=RGB,width=640,height=360 ! tee name=t \
                    t. ! queue ! videoconvert ! videoscale ! video/x-raw,width=257,height=257,format=RGB \
                    ! tensor_converter ! tensor_transform mode=typecast option=uint8 \
                    ! tensor_filter framework=vivante model=\"%s,%s \" \
                    ! tensor_decoder mode=pose_estimation option1=640:360 option2=257:257 \
                    option3=%s option4=heatmap-offset ! compositor name=mix sink_0::zorder=1 sink_1::zorder=0 ! \
                    %s render-rectangle=\"%s\" \
                    t. ! queue ! mix.",
                    filepath_cstr,
                    param->poseNbg.toStdString().c_str(),
                    param->poseCaseCode.toStdString().c_str(),
                    param->poseCoco.toStdString().c_str(),
                    video_sink_str.toStdString().c_str(), rectangle_str.c_str()
                );
            }
        else if (selectedMode == "ssd_mobilenet"){
            //ssd_mobilenet
            snprintf(pipeline_str, sizeof(pipeline_str),
                    "v4l2src device=\"%s\" ! videoconvert ! video/x-raw,format=RGB,width=640,height=360 ! tee name=t \
                    t. ! queue ! compositor name=mix sink_0::zorder=1 sink_1::zorder=2 ! %s render-rectangle=\"%s\" \
                    t. ! queue ! videoconvert ! videoscale ! video/x-raw,width=300,height=300,format=RGB ! tensor_converter ! \
                    tensor_transform mode=typecast option=uint8 ! tensor_filter framework=vivante \
                    model=\"%s,%s \" ! queue ! tensor_decoder mode=bounding_boxes option1=mobilenet-ssd \
                    option2=%s option3=%s option4=640:360 option5=300:300 ! mix.",
                    filepath_cstr,
                    video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                    param->mobilenetNbg.toStdString().c_str(),
                    param->mobilenetCaseCode.toStdString().c_str(),
                    param->mobilenetCoco.toStdString().c_str(),
                    param->mobilenetBoxPri.toStdString().c_str()
            );
        }
        else if (selectedMode == "face_recognition"){
            //face_recognition
            snprintf(pipeline_str, sizeof(pipeline_str),
                    "python3 %s --camera_device=\"%s\" --resolution=1920,1080 --fps=30 --position=%d,%d --window=%d,%d",
                    param->facerecogScript.toStdString().c_str(),
                    filepath_cstr,
                    x,
                    y,
                    width,
                    height
            );
            qDebug() << pipeline_str;
            g_face_recognition_process.start(pipeline_str);
            if (!g_face_recognition_process.waitForStarted())
            {
                qDebug() << "start face recognition process failed.";
            }
            return;
        }
        else if (selectedMode == "yolov5"){
            //yolov5
            snprintf(pipeline_str, sizeof(pipeline_str),
                    "v4l2src device=\"%s\" ! video/x-raw,width=640,height=360, ! tee name=t "
                    "t. ! queue leaky=2 max-size-buffers=10 ! compositor name=mix sink_0::zorder=1 sink_1::zorder=2 ! "
                    "%s sync=true render-rectangle=\"%s\" "
                    "t. ! queue leaky=2 max-size-buffers=2 ! videoconvert ! videoscale ! video/x-raw,width=320,height=320,format=RGB ! "
                    "tensor_converter ! tensor_transform mode=typecast option=uint8 ! "
                    "tensor_filter framework=vivante model=\"%s,%s \" ! "
                    "queue ! tensor_transform mode=arithmetic option=typecast:float32,add:-1,mul:0.00390963489189744 ! "
                    "tensor_decoder mode=bounding_boxes option1=yolov5 option2=%s option3=0 "
                    "option4=640:360 option5=320:320 ! mix.",
                    filepath_cstr,
                    video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                    param->yoloNbg.toStdString().c_str(),
                    param->yoloCaseCode.toStdString().c_str(),
                    param->yoloCoco.toStdString().c_str()
            );
        }
        else {
            qDebug () << QString().asprintf("%s:%d Unknown slectedMode %s !",
                                            __FUNCTION__, __LINE__, selectedMode.toStdString().c_str());
            return;
        }
    }
    else if (selectedMode == "posenet") {
#if 1
        snprintf(pipeline_str, sizeof(pipeline_str),
                "%s location=\"%s\" ! decodebin name=dec ! tee name=t "
                "t. ! queue ! %s render-rectangle=\"%s\" "
                "t. ! queue leaky=2 max-size-buffers=2 ! "
                "v4l2convert output-io-mode=5 extra-controls=\"controls,npp_single_rgb_plane=1\" ! "
                "video/x-raw ! queue ! videoscale ! video/x-raw,width=257,height=257,format=RGB ! "
                "tensor_converter ! tensor_transform mode=typecast option=uint8 ! "
                "tensor_filter framework=vivante model=\"%s,%s\" ! "
                "tensor_decoder mode=pose_estimation option1=%s option2=257:257 option3=%s option4=heatmap-offset ! "
                "%s render-rectangle=\"%s\"",
                filepath.startsWith("rtsp") ? "rtspsrc" : "filesrc",
                filepath_cstr,
                video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                param->poseNbg.toStdString().c_str(),
                param->poseCaseCode.toStdString().c_str(),
                option_size_str.c_str(),
                param->poseCoco.toStdString().c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str()
        );
#else
        // h264 only
        snprintf(pipeline_str, sizeof(pipeline_str),
                "filesrc location=\"%s\" ! qtdemux ! h264parse ! v4l2h264dec ! videoconvert  ! videoscale ! "
                "video/x-raw,%s,format=RGB ! tee name=t  "
                "t. ! queue ! videoscale ! video/x-raw,width=257,height=257,format=RGB ! "
                "tensor_converter ! tensor_transform mode=typecast option=uint8 ! tensor_filter framework=vivante model=\"%s,%s \" ! "
                "tensor_decoder mode=pose_estimation option1=%s option2=257:257 option3=%s option4=heatmap-offset ! "
                "compositor name=mix sink_0::zorder=1 sink_1::zorder=0 ! %s render-rectangle=\"%s\" "
                "t. ! queue ! mix.",
                filepath_cstr,
                video_size_str.c_str(),
                param->poseNbg.toStdString().c_str(),
                param->poseCaseCode.toStdString().c_str(),
                option_size_str.c_str(),
                param->poseCoco.toStdString().c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str()
        );
#endif
    }
    else if (selectedMode == "ssd_mobilenet") {
#if 1
        snprintf(pipeline_str, sizeof(pipeline_str),
                "%s location=\"%s\" ! decodebin name=dec ! tee name=t "
                "t. ! queue ! %s render-rectangle=\"%s\" "
                "t. ! queue leaky=2 max-size-buffers=2 ! "
                "v4l2convert output-io-mode=5 extra-controls=\"controls,npp_single_rgb_plane=1\" ! "
                "video/x-raw ! queue ! videoscale ! video/x-raw,width=300,height=300,format=RGB ! "
                "tensor_converter ! tensor_transform mode=typecast option=uint8 ! "
                "tensor_filter framework=vivante model=\"%s,%s\" ! "
                "queue ! tensor_decoder mode=bounding_boxes option1=mobilenet-ssd option2=%s option3=%s "
                "option4=%s option5=300:300 ! %s render-rectangle=\"%s\"",
                filepath.startsWith("rtsp") ? "rtspsrc" : "filesrc",
                filepath_cstr,
                video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                param->mobilenetNbg.toStdString().c_str(),
                param->mobilenetCaseCode.toStdString().c_str(),
                param->mobilenetCoco.toStdString().c_str(),
                param->mobilenetBoxPri.toStdString().c_str(),
                option_size_str.c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str()
        );
#else
        // h264 only
        snprintf(pipeline_str, sizeof(pipeline_str),
                "filesrc location=\"%s\" ! qtdemux ! h264parse ! v4l2h264dec ! videoconvert  ! videoscale ! "
                "video/x-raw,format=RGB,%s ! tee name=t "
                "t. ! queue ! compositor name=mix sink_0::zorder=1 sink_1::zorder=2 ! "
                "%s render-rectangle=\"%s\" "
                "t. ! queue ! videoscale ! video/x-raw,width=300,height=300,format=RGB ! "
                "tensor_converter ! tensor_transform mode=typecast option=uint8 ! "
                "tensor_filter framework=vivante model=\"%s,%s \" ! "
                "queue ! tensor_decoder mode=bounding_boxes option1=mobilenet-ssd option2=%s option3=%s "
                "option4=%s option5=300:300 ! mix.",
                filepath_cstr,
                video_size_str.c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                param->mobilenetNbg.toStdString().c_str(),
                param->mobilenetCaseCode.toStdString().c_str(),
                param->mobilenetCoco.toStdString().c_str(),
                param->mobilenetBoxPri.toStdString().c_str(),
                option_size_str.c_str()
        );
#endif
    }
    else if (selectedMode == "yolov5") {
#if 1
        snprintf(pipeline_str, sizeof(pipeline_str),
                "%s location=\"%s\" ! decodebin name=dec ! tee name=t "
                "t. ! queue ! %s render-rectangle=\"%s\" "
                "t. ! queue leaky=2 max-size-buffers=2 ! "
                "v4l2convert output-io-mode=5 extra-controls=\"controls,npp_single_rgb_plane=1\" ! "
                "video/x-raw ! queue ! videoscale ! video/x-raw,width=320,height=320,format=RGB ! "
                "tensor_converter ! tensor_transform mode=typecast option=uint8 ! "
                "tensor_filter framework=vivante model=\"%s,%s \" ! "
                "queue ! tensor_transform mode=arithmetic option=typecast:float32,add:-1,mul:0.00390963489189744 ! "
                "tensor_decoder mode=bounding_boxes option1=yolov5 option2=%s option3=0  "
                "option4=%s option5=320:320 ! %s render-rectangle=\"%s\"",
                filepath.startsWith("rtsp") ? "rtspsrc" : "filesrc",
                filepath_cstr,
                video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                param->yoloNbg.toStdString().c_str(),
                param->yoloCaseCode.toStdString().c_str(),
                param->yoloCoco.toStdString().c_str(),
                option_size_str.c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str()
        );
#else
        // h264 only
        snprintf(pipeline_str, sizeof(pipeline_str),
                "filesrc location=\"%s\" ! qtdemux ! h264parse ! v4l2h264dec ! videoconvert  ! videoscale ! "
                "video/x-raw,format=RGB,%s ! tee name=t "
                "t. ! queue leaky=2 max-size-buffers=10 ! "
                "compositor name=mix sink_0::zorder=1 sink_1::zorder=2 ! %s sync=false render-rectangle=\"%s\" "
                "t. ! queue leaky=2 max-size-buffers=2 ! "
                "videoscale ! video/x-raw,width=320,height=320,format=RGB ! tensor_converter ! tensor_transform mode=typecast option=uint8 ! "
                "tensor_filter framework=vivante model=\"%s,%s \" ! "
                "queue ! tensor_transform mode=arithmetic option=typecast:float32,add:-1,mul:0.00390963489189744 ! "
                "tensor_decoder mode=bounding_boxes option1=yolov5 option2=%s option3=0  "
                "option4=%s option5=320:320 ! mix.",
                filepath_cstr,
                video_size_str.c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                param->yoloNbg.toStdString().c_str(),
                param->yoloCaseCode.toStdString().c_str(),
                param->yoloCoco.toStdString().c_str(),
                option_size_str.c_str()
        );
#endif
    }
    else if (selectedMode == "face_recognition") {
        qDebug () << QString().asprintf("%s:%d Unsupported filepath %s",
                                        __FUNCTION__, __LINE__, filepath_cstr);
        qDebug () << QString().asprintf("%s:%d Please use USB camera as device. IP camera and video file are unsupported now !",
                                        __FUNCTION__, __LINE__);
        return;
    }
    else {
        qDebug () << QString().asprintf("%s:%d Unknown slectedMode %s !",
                                        __FUNCTION__, __LINE__, selectedMode.toStdString().c_str());
        return;
    }

    qDebug() << pipeline_str;
    GError *error = NULL;
    play->pipeline = gst_parse_launch(pipeline_str, &error);
    if (!play->pipeline || error) {
        g_printerr("Pipeline creation failed: %s\n", error ? error->message : "Unknown error");
        if (error) g_error_free(error);
        return;
    }
    if(bAudio != true)
        rtk_gst_remove_audio_flag (play);

    play->bus = GST_ELEMENT_BUS (play->pipeline);

    rtk_gst_set_element_state_no_check (play, play->pipeline, GST_STATE_PLAYING);

#if DEBUG_GSTREAMER == 1
    GST_DEBUG_BIN_TO_DOT_FILE(GST_BIN(play->pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "pipeline_PAUSED_PLAYING");
#endif

    bus_monitor_running = true;
    pthread_create(&thread_id_bus, NULL, bus_monitor, (void *)play);

}

void RtkGst::rtk_gst_play_ai(const QString filepath, QString selectedMode,
                            bool bFullscreen, int x, int y, int width, int height,
                            AiParam *param, bool bAudio)
{
    rtk_gst_play_ai(&g_play , filepath, selectedMode,
                    bFullscreen, x, y, width, height,
                    param, bAudio);
}

bool RtkGst::rtk_gst_play_multi(QString strSource, int ch, GstPlay **play_p,
                                const QString srcpath, QWidget *gst_window,
                                bool bFullscreen,
                                int x, int y, int width, int height,
                                bool bAudio)
{
    if (play_p == NULL)
        return false;

    // Convert QString to std::string, then to const char*
    string srcpath_str = srcpath.toStdString();
    const char* srcpath_cstr = srcpath_str.c_str();

    GstPlay *play_org = *play_p;
    //pause case
    if (play_org!= NULL)
    {
        if (if_debug)
            qDebug () << QString().asprintf("%s:%d %s ch play_p %p play %p resume",
                        __FUNCTION__, __LINE__, strSource.toStdString().c_str(),
                        ch, play_p, play_org);
        rtk_gst_resume (play_org);
        return true;
    }

    GstElement *videosink;
    GstElement *video_bin;
    GstPlay *play;

    //Get video info, subtitle format, video codec description by executing the command
#if GET_INFO_FROM_FRAMEWORK == 1
    MediaInfo *info = get_media_info_from_framework(srcpath_str);
#else
    MediaInfo *info = get_media_info(srcpath_str);
#endif
    if (info == NULL || !info->already_get_info || info->file_path != srcpath_str)
    {
        qDebug () << QString().asprintf("%s:%d get media info fail !", __FUNCTION__, __LINE__);
    }


    play = g_new0 (GstPlay, 1);
    *play_p = play;
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d play_p %p play %p srcpath=%s bFullscreen=%d x=%d y=%d w=%d h=%d, bAudio=%d",
                    __FUNCTION__, __LINE__, strSource.toStdString().c_str(),
                    ch, play_p, play, srcpath_cstr, bFullscreen, x, y, width, height, bAudio);

    gst_init(NULL, NULL);

    if(video_sink_str.startsWith("rtk") && video_sink_str.endsWith("sink")) {

        play->pipeline = gst_element_factory_make ("playbin", "playbin");
        videosink = gst_element_factory_make(video_sink_str.toStdString().c_str(), "video-output");


        // Set video-sink of playbin
        g_object_set(play->pipeline, "video-sink", videosink, NULL);

        if(device_fd != -1){
            qDebug() << "reused fd:" << device_fd;
            g_object_set(videosink, "x", x,  "y", y, "w", width, "h", height, "chid", ch, "fd", device_fd, NULL);
        }
        else
            g_object_set(videosink, "x", x,  "y", y, "w", width, "h", height, "chid", ch, NULL);

        if(!srcpath.isEmpty()) {
            qDebug() << "Play srcpath:" << srcpath;
            if(srcpath.startsWith("rtsp") ){
                qDebug() << "Play rtsp:" << srcpath;
                g_object_set(play->pipeline, "uri", srcpath.toUtf8().constData(), NULL);
            }
            else{
                QUrl fileUri = QUrl::fromLocalFile(srcpath);
                QString gstreamerUri = fileUri.toString();
                qDebug() << "Play Uri:" << gstreamerUri;
                g_object_set(play->pipeline, "uri", gstreamerUri.toUtf8().constData(), NULL);
            }
        }

        if(bAudio != true)
            rtk_gst_remove_audio_flag (play);
        else
            g_object_set(play->pipeline, "current-audio", 0, NULL);

        play->bus = GST_ELEMENT_BUS (play->pipeline);

        rtk_gst_set_element_state_no_check(play, play->pipeline, GST_STATE_PLAYING);

        if(device_fd == -1){
            g_object_get(videosink, "fd", &device_fd, NULL);
            qDebug() << "fd:" << device_fd;
        }
    }
    else if(info->subtitle_format == "NONE") {
        play->pipeline = gst_element_factory_make ("playbin", "playbin");
        videosink = gst_element_factory_make(video_sink_str.toStdString().c_str(), "video-output");

        play->rtkvideoscale = gst_element_factory_make("rtkvideoscale", "scale");
        g_object_set(G_OBJECT(play->rtkvideoscale), "force-passthrough", info->is_video_10_bits, NULL);

        // Create video_bin, include videoflip and videosink
        video_bin = gst_bin_new("video_bin");
        play->rtkvideoflip = gst_element_factory_make("rtkhse", "videoflip");

        // Set rotation
        play->rotation_method = 0;
        g_object_set(G_OBJECT(play->rtkvideoflip), "rotate", play->rotation_method, NULL);

        // Add video_bin
        gst_bin_add_many(GST_BIN(video_bin), play->rtkvideoscale, play->rtkvideoflip, videosink, NULL);
        gst_element_link_many(play->rtkvideoscale, play->rtkvideoflip, videosink);

        // Set ghost pad, let playbin use bin to do video-sink
        GstPad *pad = gst_element_get_static_pad(play->rtkvideoscale, "sink");
        GstPad *ghost_pad = gst_ghost_pad_new("sink", pad);
        gst_pad_set_active(ghost_pad, TRUE);
        gst_element_add_pad(video_bin, ghost_pad);
        gst_object_unref(pad);

        // Set video-sink of playbin
        g_object_set(play->pipeline, "video-sink", video_bin, NULL);

        GstVideoOverlay *overlay = GST_VIDEO_OVERLAY(videosink);
        if(overlay != NULL) {
            gst_video_overlay_set_render_rectangle(overlay, x, y, width, height);

            WId winid = gst_window->winId();
            gst_video_overlay_set_window_handle(overlay, winid);
        }

        if(!srcpath.isEmpty()) {
            qDebug() << "Play srcpath:" << srcpath;
            if(srcpath.startsWith("rtsp") ){
                qDebug() << "Play rtsp_:" << srcpath;
                g_object_set(play->pipeline, "uri", srcpath.toUtf8().constData(), NULL);
            }
            else{
                QUrl fileUri = QUrl::fromLocalFile(srcpath);
                QString gstreamerUri = fileUri.toString();
                qDebug() << "Play Uri_:" << gstreamerUri;
                g_object_set(play->pipeline, "uri", gstreamerUri.toUtf8().constData(), NULL);
            }
        }

        if(bAudio != true)
            rtk_gst_remove_audio_flag (play);
        else
            g_object_set(play->pipeline, "current-audio", 0, NULL);

        play->bus = GST_ELEMENT_BUS (play->pipeline);

        rtk_gst_set_element_state_no_check(play, play->pipeline, GST_STATE_PLAYING);
    }
    else{
       qDebug() << "Not supperted!!" ;
    }
#if DEBUG_GSTREAMER == 1
    GST_DEBUG_BIN_TO_DOT_FILE(GST_BIN(play->pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "pipeline_PAUSED_PLAYING");
#endif

    bus_monitor_running = true;
    pthread_create(&thread_id_bus, NULL, bus_monitor, (void *)play);

    return true;
}

bool RtkGst::rtk_gst_play_multi(QString strSource, int ch,
                                const QString filepath, QWidget *gst_window,
                                bool bFullscreen,
                                int x, int y, int width, int height,
                                bool bAudio)
{
    return rtk_gst_play_multi (strSource, ch, &g_play, filepath,  gst_window, bFullscreen, x, y, width, height, bAudio);
}

QString RtkGst::rtk_gst_findVideoUnderMedia()
{
    QProcess process;
    process.start("v4l2-ctl --list-devices");
    process.waitForFinished();

    QString result = process.readAllStandardOutput();
    QTextStream stream(&result);

    QString line;
    QString firstVideoDevice;
    bool isTargetBlock = false;

    while (stream.readLineInto(&line)) {
        line = line.trimmed();

        if (line.isEmpty()) continue;

        if (!line.startsWith("/dev/")) {
            // clean states when entering new device block
            firstVideoDevice.clear();
            isTargetBlock = false;
            continue;
        }

        if (line.contains("/dev/video") && firstVideoDevice.isEmpty()) {
            firstVideoDevice = line;  // store the first /dev/video in the block
        }

        if (line.contains("/dev/media0")) {
            isTargetBlock = true;
        }

        // If /dev/media0 exists, return the first /dev/video in the block
        if (isTargetBlock && !firstVideoDevice.isEmpty()) {
            return firstVideoDevice;
        }
    }
    return "";  // No devices found
}

void RtkGst::rtk_gst_screenshot(QString videoStr, gint64 position)
{
    gst_init(NULL, NULL);

    qDebug() << videoStr << " / " << position;

    string pipelineStr =
        "filesrc location=\"" + videoStr.toStdString() +
        "\" ! decodebin ! videoconvert ! videoscale ! video/x-raw ! jpegenc ! multifilesink max-files=1 location=" + generateTimestampedFilename();

    GstElement *pipeline = gst_parse_launch(pipelineStr.c_str(), NULL);
    if (!pipeline) {
        qDebug() << "Failed to create GStreamer pipeline";
        return;
    }

    // Set PAUSED to Seek
    GstStateChangeReturn ret = gst_element_set_state(pipeline, GST_STATE_PAUSED);
    if (ret == GST_STATE_CHANGE_FAILURE) {
        qDebug() << "Failed to set pipeline to PAUSED";
        gst_object_unref(pipeline);
        return;
    }

    // Check pause success
    GstState state;
    GstState pending;
    if (gst_element_get_state(pipeline, &state, &pending, GST_CLOCK_TIME_NONE) != GST_STATE_CHANGE_SUCCESS) {
        qDebug() << "Pipeline did not reach PAUSED state";
        gst_object_unref(pipeline);
        return;
    }

    // Set seek position
    //position = 5000000000;
    GstSeekFlags seekFlags = static_cast<GstSeekFlags>(GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_ACCURATE);
    if (!gst_element_seek_simple(pipeline, GST_FORMAT_TIME, seekFlags, position)) {
        qDebug() << "Seek failed";
    }

    // Set PLAYING to get one picture
    gst_element_set_state(pipeline, GST_STATE_PLAYING);

    gst_element_get_state (pipeline, NULL, NULL, GST_CLOCK_TIME_NONE);

    // Stop Pipeline
    gst_element_set_state(pipeline, GST_STATE_NULL);
    gst_object_unref(pipeline);
}

void RtkGst::rtk_gst_face_recog_keyboard_input(QString input)
{
    //qDebug() << "write face name: " << input;
    if (g_face_recognition_process.state() == QProcess::Running)
    {
        g_face_recognition_process.write(input.toUtf8());
        g_face_recognition_process.waitForBytesWritten();
    }
}

bool RtkGst::rtk_gst_is_face_recog_running()
{
    return (g_face_recognition_process.state() == QProcess::Running) ? true : false;
}