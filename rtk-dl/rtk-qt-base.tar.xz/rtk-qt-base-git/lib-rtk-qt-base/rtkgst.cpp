/**
 * @file rtkgst.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The interface/api to use Realtek library
 */

#include <QImage>
#include <QUrl>
#include <QDebug>
#include "rtkgst.h"
#include <gst/video/videooverlay.h>
#include <fstream>
#include <sstream>
#include <string>
#include <chrono>
#include <iomanip>
#include <QProcess>
#include <QFile>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <regex>
#include <QMutex>
#if GET_INFO_FROM_FRAMEWORK == 1
#include <rtk_media_info.h>
#include <rtk_media_cap.h>
#endif

#define DEBUG_GSTREAMER 0
#define DEBUG_FRAMEWORK 0
#define RELEASE_RETRY_COUNT 10

/* playbin flags */
typedef enum {
  GST_PLAY_FLAG_VIDEO         = (1 << 0), /* We want video output */
  GST_PLAY_FLAG_AUDIO         = (1 << 1), /* We want audio output */
  GST_PLAY_FLAG_TEXT          = (1 << 2)  /* We want subtitle output */
} GstPlayFlags;

extern int g_pipefd[2];

#define DEFAULT_BUFFER_BYTES 41943040     // 40 MB
gboolean play_bus_msg (GstBus * bus, GstMessage * msg, gpointer data);
static pthread_t thread_id_bus = 0;
static bool bus_monitor_running = false;
MediaInfo mediaInfo;
GstPlay *g_play = NULL;

RtkGst *rtkGst = NULL;
QProcess g_face_recognition_process;
static int device_fd = -1;

#if GET_INFO_FROM_FRAMEWORK == 1
rtk_media_info rtkMediaInfo;
rtk_cap_instance inst_video;
rtk_cap_instance inst_audio;
rtk_cap_instance inst_subtitle;
#endif

string generateTimestampedFilename() {
    auto now = chrono::system_clock::now();
    auto in_time_t = chrono::system_clock::to_time_t(now);

    stringstream ss;
    ss << put_time(localtime(&in_time_t), "%Y%m%d_%H%M%S");
    return "snapshot_" + ss.str() + ".jpg";
}

void init_media_info(MediaInfo *info)
{
    if (info == nullptr)
        return;
    info->already_get_info = false;
    info->has_video = false;
    info->has_audio = false;
    info->has_subtitle = false;
#if GET_INFO_FROM_FRAMEWORK == 1
    info->decodable_video = false;
    info->decodable_audio = false;
    info->decodable_subtitle = false;
    info->video_bit_depth = 8;
#endif
    info->is_video_4k = false;
    info->is_video_less_than_4k = false;
    info->is_video_10_bits = false;
    info->enable_video_speed_change = false;
    info->enable_video_rotate = false;
    info->video_width = 0;
    info->video_height = 0;
    info->file_path = "";
    info->subtitle_format = "NONE";
    info->video_codec_desc = "NONE";
}

#if GET_INFO_FROM_FRAMEWORK == 1
bool RtkGst::get_check_video_info_from_framework(int stream_idx)
{
    bool decodable = false;

    if (stream_idx < 0 || stream_idx >= STREAM_INFO_LEN)
        return false;

    video_info *v_info = &rtkMediaInfo.stream_info[stream_idx].v_info;
    char *mime = rtkMediaInfo.stream_info[stream_idx].mime_type;

    /* 1. fill media info to qury form */
    rtk_video_cap cap_video;    // for query
    rtk_video_cap *cap = &cap_video;
    memset (cap, 0x0, sizeof(rtk_video_cap));
    strcpy(&cap->mime_type[0], mime);
    cap->max_width = v_info->width;
    cap->max_height = v_info->height;
    cap->mpegversion = v_info->mpegversion;
    strcpy(cap->profile[0], v_info->profile);
    if (v_info->profile[0] != 0) {
        cap->profile_count = 1;
    }
    strcpy(cap->level[0], v_info->level);
    if (v_info->level[0] != 0) {
        cap->level_count = 1;
    }
    cap->wmvversion = v_info->wmvversion;
    cap->max_bit_depth = v_info->bit_depth;
    // cap->input_format
    // cap->output_format

    /* 2. check decode capability */
#if DEBUG_FRAMEWORK == 1
    qDebug() << QString().sprintf("%s:%d list_video_cap_info()", __FUNCTION__, __LINE__);
    list_video_cap_info (cap);
#endif
    decodable = (rtk_video_cap_check(&inst_video, cap) == 0);

    /* 3. get video info */
    MediaInfo *info = &mediaInfo;
    info->video_width = v_info->width;
    info->video_height = v_info->height;
    info->mpegversion = v_info->mpegversion;
    info->wmvversion = v_info->wmvversion;
    info->video_bit_depth = v_info->bit_depth;
    if (strstr(mime, "h264"))       // ex:video/x-h264
        info->video_codec_desc = "264";
    else if (strstr(mime, "h265"))  // ex:video/x-h265
        info->video_codec_desc = "265";

    info->has_video = true;
    info->decodable_video = decodable;

    return decodable;
}

bool RtkGst::get_check_subtitle_info_from_framework(int stream_idx)
{
    bool decodable = false;

    if (stream_idx < 0 || stream_idx >= STREAM_INFO_LEN)
        return false;

    subtitle_info *s_info = &rtkMediaInfo.stream_info[stream_idx].s_info;
    char *mime = rtkMediaInfo.stream_info[stream_idx].mime_type;

    /* 1. fill media info to qury form */
    rtk_subtitle_cap cap_subtitle;  // for query
    rtk_subtitle_cap *cap = &cap_subtitle;
    memset (cap, 0x0, sizeof(rtk_subtitle_cap));
    strcpy(cap->mime_type, mime);

    /* 2. check decode capability */
#if DEBUG_FRAMEWORK == 1
    qDebug() << QString().sprintf("%s:%d list_subtitle_cap_info()", __FUNCTION__, __LINE__);
    list_subtitle_cap_info (cap);
#endif
    decodable = (rtk_subtitle_cap_check(&inst_subtitle, cap) == 0);

    /* 3. get video info */
    MediaInfo *info = &mediaInfo;
    // subtitle format
    if (strstr(mime, "subrip") || 
        strstr(mime, "srt") || 
        strstr(mime, "pgs") ||  // ex: subpicture/x-pgs
        strstr(mime, "PGS"))
        info->subtitle_format = "SRT";
    else if (strstr(mime, "ssa") || 
        strstr(mime, "ass") || 
        strstr(mime, "Advanced"))
        info->subtitle_format = "ASS";
    else
        info->subtitle_format = "Others";

    info->has_subtitle = true;
    info->decodable_subtitle = decodable;

    return decodable;
}

MediaInfo* RtkGst::get_media_info_from_framework(const string& video_file)
{
    static QMutex mutex;
    MediaInfo *info = &mediaInfo;
    rtk_media_info *rtk = &rtkMediaInfo;

    mutex.lock();
    if (info->file_path == video_file && info->already_get_info)
    {
        mutex.unlock();
        // already get media info before, therefore recturn directly
        return info;
    }

    std::string s(video_file.c_str());
    char *filepath = s.data();
    qDebug () << QString().asprintf("%s:%d filepath=%s", __FUNCTION__, __LINE__, filepath);

    init_media_info(info);
    get_media_info (filepath, rtk, false);
#if DEBUG_FRAMEWORK == 1
    qDebug() << QString().sprintf("%s:%d list_media_info()", __FUNCTION__, __LINE__);
    list_media_info (rtk);
#else
    QStringList mime_list;
    for (int i = 0; i < rtk->info_count; i++) {
        mime_list.append(QString(rtk->stream_info[i].mime_type));
    }
    qDebug() << QString("mime_type total %1: %2").arg(mime_list.count()).arg(mime_list.join(", "));
#endif

    for (int i = 0; i < rtk->info_count; i++)
    {
        rtk_stream_info *stream_info = &rtk->stream_info[i];
        switch(stream_info->stream_type)
        {
        case RTK_VIDEO_TYPE:
            if (! info->has_video) {
                get_check_video_info_from_framework(i);
            }
            else {
                qDebug() << QString().sprintf("%s:%d warning: video already exists ...", __FUNCTION__, __LINE__);
            }
            break;
        case RTK_AUDIO_TYPE:
            info->has_audio = true;
            // TBD: get all audio infor for selection
            break;
        case RTK_SUBTITLE_TYPE:
            if (! info->has_subtitle) {
                get_check_subtitle_info_from_framework(i);
            }
            else {
                // TBD: check all subtitle for selection
            }
            break;
        default:
            break;
        }
    }

    info->is_video_4k = (info->video_width >= 3840 && info->video_height >= 2160);
    info->is_video_less_than_4k = (info->video_width > 0 && info->video_width < 3840 &&
                                  info->video_height > 0 && info->video_height < 2160);
    info->is_video_10_bits = (info->video_bit_depth >= 10);
    info->enable_video_speed_change = (info->is_video_4k ||
                                      // 10 bits for 2K/4K or more, sometimes we cannot parse width/height without proper plugin
                                      (info->is_video_10_bits && !info->is_video_less_than_4k));
    info->enable_video_rotate = (info->subtitle_format == "NONE") &&
#if 1
                                info->is_video_less_than_4k;
#else
                                // for 4096 pixels, we need to scale it first
                                (info->is_video_10_bits == false || (info->is_video_10_bits && info->is_video_less_than_4k));
#endif

    qDebug() << "video resolution: " << info->video_width << "x" << info->video_height;
    qDebug() << "video bits depth: " << info->video_bit_depth;
    qDebug() << "video decodable: " << info->decodable_video;
    qDebug() << "subtitle format: " << QString::fromStdString(info->subtitle_format);
    qDebug() << "subtitle decodable: " << info->decodable_subtitle;
    qDebug() << "codec_desc format: " << QString::fromStdString(info->video_codec_desc);
    if (info->has_video && (info->decodable_video != true))
    {
        qDebug () << QString().asprintf("Video format is over spec! Unable to play it !");
    }
    info->file_path = video_file;
    info->already_get_info = true;

    mutex.unlock();
    return info;
}

#else
// Generate the rank of all v4l2 elements to 0.
string rtk_gst_generate_plugin_rank()
{
    std::string command = "gst-inspect-1.0";
    std::vector<std::string> plugins;
    char buffer[128];
    std::string result;

    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        std::cerr << "Failed to execute gst-inspect-1.0" << std::endl;
        return "";
    }

    // read the output of gst-inspect-1.0
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        result += buffer;
    }
    pclose(pipe);

    // Get 'video4linux2:' and 'v4l2.*dec'
    std::regex v4l2_dec_regex("video4linux2:[ \\t]+(v4l2.*dec)");
    std::smatch match;
    std::istringstream iss(result);
    std::string line;

    while (std::getline(iss, line)) {
        if (std::regex_search(line, match, v4l2_dec_regex)) {
            std::string plugin_name = match[1].str();
            plugin_name.erase(0, plugin_name.find_first_not_of(" \t"));
            plugins.push_back(plugin_name + ":0");
        }
    }

    // Format the plugin to: <name>:0,<name>:0,...
    std::string gst_rank;
    for (size_t i = 0; i < plugins.size(); ++i) {
        gst_rank += plugins[i];
        if (i < plugins.size() - 1) {
            gst_rank += ",";
        }
    }

    return gst_rank;
}

MediaInfo* RtkGst::get_media_info(const string& video_file)
{
    MediaInfo *info = &mediaInfo;

    if (info->file_path == video_file && info->already_get_info)
        // already get media info before, therefore recturn directly
        return info;

    init_media_info(info);

    string command = "gst-discoverer-1.0 \"" + video_file + "\" 2>/dev/null";

    string gst_plugin_rank = rtk_gst_generate_plugin_rank();
    if (gst_plugin_rank != "")
        command = "GST_PLUGIN_FEATURE_RANK=" + gst_plugin_rank + " " + command;

    qDebug () << QString().asprintf("%s:%d %s", __FUNCTION__, __LINE__, command.c_str());

    // Execute command and capture output
    array<char, 512> buffer;
    string output;
    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe)
    {
        qDebug () << QString().asprintf("%s:%d Failed to run gst-discoverer-1.0", __FUNCTION__, __LINE__);
        return info;
    }

    while (fgets(buffer.data(), buffer.size(), pipe)) {
        output += buffer.data();
    }
    pclose(pipe);

    // Parse resolution, bits depth
    regex width_regex(R"(Width\s*:\s*(\d+))");
    regex height_regex(R"(Height\s*:\s*(\d+))");
    regex profile_regex(R"(Main\s+(\d+)\s+Profile)");
    smatch match;

    int width = 0, height = 0, profile = 8;
    if (regex_search(output, match, width_regex)) {
        width = stoi(match[1]);
    }
    if (regex_search(output, match, height_regex)) {
        height = stoi(match[1]);
    }
    if (regex_search(output, match, profile_regex)) {
        profile = stoi(match[1]);
    }
    info->video_width = width;
    info->video_height = height;
    info->video_bit_depth = profile;

    // info->subtitle_format = "NONE";
    // info->video_codec_desc = "NONE";
    QStringList resultList = QString::fromStdString(output).split("\n");
    for (int i=0; i<resultList.count(); i++)
    {
        QString result = resultList.at(i);
        // Parse output to find subtitle format
        if (result.indexOf("subtitle", Qt::CaseInsensitive) >= 0)
        {
            // Check for common subtitle formats
            if (result.indexOf("subrip") >= 0 ||
                result.indexOf("srt") >= 0 ||
                result.indexOf("PGS") >= 0)
                info->subtitle_format = "SRT";
            else if (result.indexOf("ssa") >= 0 ||
                     result.indexOf("ass") >= 0 ||
                     result.indexOf("Advanced SubStation") >= 0)
                info->subtitle_format = "ASS";
            else
                info->subtitle_format = "Others";
        }
        // Parse output to find subtitle format
        if (result.indexOf("video", Qt::CaseInsensitive) >= 0)
        {
            info->has_video = true;
            // Check for common video formats
            if (result.indexOf("264") >= 0)
                info->video_codec_desc = "264";
            else if (result.indexOf("265") >= 0)
                info->video_codec_desc = "265";
        }
        if (result.indexOf("audio", Qt::CaseInsensitive) >= 0)
        {
            info->has_audio = true;
        }
    }


    info->is_video_4k = (info->video_width >= 3840 && info->video_height >= 2160);
    info->is_video_less_than_4k = (info->video_width > 0 && info->video_width < 3840 &&
                                  info->video_height > 0 && info->video_height < 2160);
    info->is_video_10_bits = (info->video_bit_depth >= 10);
    info->enable_video_speed_change = (info->is_video_4k ||
                                      // 10 bits for 2K/4K or more, sometimes we cannot parse width/height without proper plugin
                                      (info->is_video_10_bits && !info->is_video_less_than_4k));
    info->enable_video_rotate = (info->subtitle_format == "NONE") &&
#if 1
                                info->is_video_less_than_4k;
#else
                                // for 4096 pixels, we need to scale it first
                                (info->is_video_10_bits == false || (info->is_video_10_bits && info->is_video_less_than_4k));
#endif

    qDebug() << "video resolution: " << info->video_width << "x" << info->video_height;
    qDebug() << "video bits depth: " << info->video_bit_depth;
    qDebug() << "subtitle format: " << QString::fromStdString(info->subtitle_format);
    qDebug() << "codec_desc format: " << QString::fromStdString(info->video_codec_desc);

    info->file_path = video_file;
    info->already_get_info = true;
    return info;
}
#endif

RtkGst::RtkGst()
{
    rtkGst = this;
    if_platform_wayland = false;
    if_wayland_bg_color_transparency = false;
    if_debug = false;
    video_sink_str = "waylandsink";
    text_sink_str = "waylandsink";
#if GET_INFO_FROM_FRAMEWORK == 1
    rtk_media_cap_init(&inst_video, RTK_VIDEO_CAP);
    rtk_media_cap_init(&inst_audio, RTK_AUDIO_CAP);
    rtk_media_cap_init(&inst_subtitle, RTK_SUBTITLE_CAP);
#if DEBUG_FRAMEWORK == 1
    list_cap_instance_info(&inst_video);
    list_cap_instance_info(&inst_subtitle);
#endif
#endif
}

RtkGst::~RtkGst()
{
#if GET_INFO_FROM_FRAMEWORK == 1
    rtk_media_cap_uninit(&inst_video);
    rtk_media_cap_uninit(&inst_subtitle);
#endif
}

QString RtkGst::getPlatformName(int argc, char *argv[])
{
    QString strPlatform = "";
    QString strQpaVariable = "QT_QPA_PLATFORM=";
    for (int i=0; i< argc; ++i)
    {
        QString strArgv = QString(argv[i]);
        // qDebug() << i << " " << strArgv;

        if (i+1 <argc &&
            (strArgv == "-platform" ||
             strArgv == "--platform"))
        {
            strPlatform = argv[i+1];
            qDebug () << QString().asprintf("%s:%d %s %s", __FUNCTION__, __LINE__,
                            strArgv.toStdString().c_str(),
                            strPlatform.toStdString().c_str());
        }
        else if (strArgv.startsWith(strQpaVariable))
        {
            // ex: QT_QPA_PLATFORM=linuxfb:fb=/dev/fb1
            // but this setting must be placed after the executable filename to be readble
            strPlatform  = strArgv.split(strQpaVariable).last().split(":").at(0);
            qDebug () << QString().asprintf("%s:%d %s %s", __FUNCTION__, __LINE__,
                            strArgv.toStdString().c_str(),
                            strPlatform.toStdString().c_str());
        }
    }
    if_platform_wayland = (strPlatform == _STR_WAYLAND_);
    return strPlatform;
}

void RtkGst::modifyWestonIni(WestonMode mode)
{
    const std::string iniPath = "/etc/xdg/weston/weston.ini"; // Weston config file
    std::ifstream iniFileIn(iniPath);
    if (!iniFileIn) {
        std::cerr << "Cannot open file: " << iniPath << "\n";
        return;
    }

    std::ostringstream buffer;
    std::string line;
    bool inShellSection = false;

    // Read file and modify based on mode
    while (std::getline(iniFileIn, line)) {
        if (line == "[shell]") {
            inShellSection = true;
            buffer << line << "\n";
            continue;
        }

        if (inShellSection) {
            if (line.find("background-type=") == 0) {
                if (mode == WestonMode::Update) {
                    buffer << "background-type=solid\n"; // Update mode modification
                } else if (mode == WestonMode::Reset) {
                    buffer << "background-type=scale\nbackground-image=/etc/xdg/weston/logo_banner.jpg\n"; // Reset mode modification
                }
                continue;
            }
            if (mode == WestonMode::Update && line.find("background-image=") == 0) {
                continue; // Remove background-image in update mode
            }
            if (line.find("background-color=") == 0) {
                if (mode == WestonMode::Update) {
                    buffer << "background-color=0x00ff0000\n"; // Update by transparency to showing video layer
                } else if (mode == WestonMode::Reset) {
                    buffer << "background-color=0xff000000\n"; // Reset mode modification
                }
                continue;
            }
        }

        buffer << line << "\n";
    }

    iniFileIn.close();

    // Write back weston.ini
    std::ofstream iniFileOut(iniPath);
    if (!iniFileOut) {
        std::cerr << "Cannot open file: " << iniPath << "\n";
        return;
    }

    iniFileOut << buffer.str();
    iniFileOut.close();

    std::cout << "Update Weston.ini success!\n";

    // Restart Weston
    int result = system("systemctl restart weston");
    if (result == 0) {
        std::cout << "Restart Weston success!\n";
    } else {
        std::cerr << "Restart Weston failed!\n";
    }
}

void RtkGst::parsePlatformSetting()
{
    const QString iniPath = "/etc/xdg/weston/weston.ini"; // Weston config file
    QString bg_color;

    if (if_platform_wayland != true)
    {
        if_wayland_bg_color_transparency = false;
        return;
    }

    QFile file(iniPath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty())
            continue;
        if (line.startsWith('#') || line.startsWith(';'))
            continue;
        if (line.startsWith("background-image"))
        {
            // assuem the image is not transparent image
            if_wayland_bg_color_transparency = false;
            return;
        }
        if (line.startsWith("background-color"))
        {
            QStringList parts = line.split('=', Qt::SkipEmptyParts);
            if (parts.size() == 2)
            {
                bg_color = parts[1].trimmed();
                if (bg_color.compare("0x00FF0000", Qt::CaseInsensitive) == 0 ||
                    bg_color.compare("0x0000FF00", Qt::CaseInsensitive) == 0 ||
                    bg_color.compare("0x000000FF", Qt::CaseInsensitive) == 0)
                    if_wayland_bg_color_transparency = true;
                continue;
            }
        }
    }
}

void RtkGst::set_debug (bool bDebug)
{
    if_debug = bDebug;
}

void RtkGst::set_sink (QString videosink, QString textsink)
{
    video_sink_str = videosink;
    text_sink_str = textsink;
}

void RtkGst::unref_element(GstElement *element)
{
    for (int i = 0; i < RELEASE_RETRY_COUNT; i++)
    {
        int ref_count = 0;
        ref_count = GST_OBJECT_REFCOUNT(element);
        if (ref_count <= 0) {
            if (ref_count < 0) {
                qDebug () << QString().asprintf("%s:%d %s with invalid ref_count %d !", 
                                __FUNCTION__, __LINE__, gst_element_get_name(element), ref_count);
            }
            break;
        } else {
            // if (if_debug) {
            //     qDebug () << QString().asprintf("%s:%d unref %s until ref_count %d to 0 !", 
            //                     __FUNCTION__, __LINE__, gst_element_get_name(element), ref_count);
            // }
            gst_object_unref (element);
            usleep(50000);
        }
    }
}

QString formatTime(gint64 time) {
    if (time == -1) {
        return "Unknown";
    }
    return QString("%1:%2:%3")
        .arg((time / GST_SECOND) / 3600, 2, 10, QChar('0'))   // hour
        .arg(((time / GST_SECOND) % 3600) / 60, 2, 10, QChar('0')) // minute
        .arg((time / GST_SECOND) % 60, 2, 10, QChar('0'));    // second
}

pair<gint64, gint64> RtkGst::rtk_gst_getPlaybackPositionDuration(GstPlay *play)
{
    gint64 position = 0;
    gint64 duration = 0;

    if (play == NULL || play->playbin == NULL)
        return {0, 0};

    // current position
    gboolean posAvailable = gst_element_query_position(play->playbin, GST_FORMAT_TIME, &position);

    // duration
    gboolean durAvailable = gst_element_query_duration(play->playbin, GST_FORMAT_TIME, &duration);

    if (posAvailable && durAvailable)
    {
        // if (if_debug)
        //     qDebug () << QString().asprintf("position %ld duration %ld", position, duration);
        return {position, duration};
    }
    else
        return {0, 0};
}

pair<gint64, gint64> RtkGst::rtk_gst_getPlaybackPositionDuration()
{
    return rtk_gst_getPlaybackPositionDuration(g_play);
}

bool RtkGst::rtk_gst_setVolume(GstPlay *play, int volume)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d volume %d", __FUNCTION__, __LINE__, volume);
    if(play == NULL || play->playbin == NULL)
        return false;

    if(volume < 0 || volume > 100)
        return false;
    /* the volume range is usually 0.0~10.0, and 0.0~1.0 is generally recommended,
       exceeding 1.0 will amplify the sound and cause distortion or even popping */
    gdouble vol = (gdouble)(volume / 100.0);

    GstElement *element = NULL;
    // qDebug () << QString().asprintf("%s:%d GST_ELEMENT_NAME(play->playbin) %s", __FUNCTION__, __LINE__, GST_ELEMENT_NAME(play->playbin));
    if (strcmp(GST_ELEMENT_NAME(play->playbin), "playbin") == 0)
    {
        element = play->playbin;
    }
    else
    {
        GstElement *gst_volume = gst_bin_get_by_name(GST_BIN(play->playbin), "gst_volume");
        if (gst_volume != NULL)
            element = gst_volume;
        else
        {
            qDebug () << QString().asprintf("%s:%d Cannot find volume object !", __FUNCTION__, __LINE__);
            return false;
        }
    }
    g_print("Playback volume set to %.2f \n", vol);
    g_object_set(element, "volume", vol, NULL);
    return true;
}

bool RtkGst::rtk_gst_setVolume(int volume)
{
    return rtk_gst_setVolume (g_play, volume);
}

void *bus_monitor(void *param)
{
    GstPlay *play = (GstPlay *)param;

    GstMessage * msg;
    while( bus_monitor_running ) {
        if( (msg = gst_bus_pop(play->bus)) ) {
            // Call your bus message handler
            play_bus_msg (play->bus, msg, play);
            gst_message_unref (msg);
        }
        usleep(1000);
    }

    return NULL;
}

gboolean play_bus_msg (GstBus * bus, GstMessage * msg, gpointer user_data)
{
    GstPlay *play = (GstPlay *)user_data;
    GstObject *src = GST_MESSAGE_SRC (msg);

    switch (GST_MESSAGE_TYPE (msg)) {
        case GST_MESSAGE_EOS:
            //sendCommand(CMD_NEXT_FILE);
            g_print("End of stream reached.\n");
            if(play != NULL)
            {
                write(g_pipefd[1], "GST_MESSAGE_EOS", 15);
            }
            break;
        case GST_MESSAGE_ERROR:
            GError *err;
            gchar *dbg;

            gst_message_parse_error (msg, &err, &dbg);
            g_printerr ("ERROR %s for %s\n", err->message, "");
            if (dbg != NULL)
                g_printerr ("ERROR debug information: %s\n", dbg);
            g_error_free (err);
            g_free (dbg);
            break;
    }
    return true;
}

void RtkGst::rtk_gst_remove_audio_flag(GstPlay *play)
{
    if (play == NULL || play->playbin == NULL)
        return;

    uint flags, flags_new;
    g_object_get(play->playbin, "flags", &flags, NULL);
    flags_new = flags & (~GST_PLAY_FLAG_AUDIO);
    g_object_set(play->playbin, "flags", flags_new, NULL);
    // qDebug () << QString().asprintf("%s:%d flags %p -> %p", __FUNCTION__, __LINE__, flags, flags_new);
}

bool RtkGst::rtk_gst_play_new(GstPlay **play_p, const QString filepath, QWidget *gst_window,
                                  bool bFullscreen,
                                  int x, int y, int width, int height,
                                  bool bAudio)
{
    if (play_p == NULL)
        return false;

    // Convert QString to std::string, then to const char*
    string filepath_str = filepath.toStdString();
    const char* filepath_cstr = filepath_str.c_str();

    GstPlay *play_org = *play_p;
    //pause case
    if (play_org!= NULL)
    {
        if (if_debug)
            qDebug () << QString().asprintf("%s:%d play_p %p play %p resume",
                        __FUNCTION__, __LINE__, play_p, play_org);
        rtk_gst_resume (play_org);
        return true;
    }

    GstElement *videosink;
    GstElement *video_bin;
    GstPlay *play;

    //Get video info, subtitle format, video codec description by executing the command
#if GET_INFO_FROM_FRAMEWORK == 1
    MediaInfo *info = get_media_info_from_framework(filepath_str);
#else
    MediaInfo *info = get_media_info(filepath_str);
#endif
    if (!info->already_get_info || info->file_path != filepath_str)
    {
        qDebug () << QString().asprintf("%s:%d get media info fail !", __FUNCTION__, __LINE__);
    }

    play = g_new0 (GstPlay, 1);
    *play_p = play;
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play_p %p play %p filepath=%s bFullscreen=%d x=%d y=%d w=%d h=%d, bAudio=%d",
                    __FUNCTION__, __LINE__, play_p, play,
                    filepath_cstr, bFullscreen, x, y, width, height, bAudio);

    gst_init(NULL, NULL);

    if(info->subtitle_format == "NONE") {
        play->playbin = gst_element_factory_make ("playbin", "playbin");
        videosink = gst_element_factory_make(video_sink_str.toStdString().c_str(), "video-output");

        play->rtkvideoscale = gst_element_factory_make("rtkvideoscale", "scale");
        g_object_set(G_OBJECT(play->rtkvideoscale), "force-passthrough", info->is_video_10_bits, NULL);

        // Create video_bin, include videoflip and videosink
        video_bin = gst_bin_new("video_bin");
        play->rtkvideoflip = gst_element_factory_make("rtkhse", "videoflip");

        // Set rotation
        play->rotation_method = 0;
        g_object_set(G_OBJECT(play->rtkvideoflip), "rotate", play->rotation_method, NULL);

        // Add video_bin
        gst_bin_add_many(GST_BIN(video_bin), play->rtkvideoscale, play->rtkvideoflip, videosink, NULL);
        gst_element_link_many(play->rtkvideoscale, play->rtkvideoflip, videosink);

        // Set ghost pad, let playbin use bin to do video-sink
        GstPad *pad = gst_element_get_static_pad(play->rtkvideoscale, "sink");
        GstPad *ghost_pad = gst_ghost_pad_new("sink", pad);
        gst_pad_set_active(ghost_pad, TRUE);
        gst_element_add_pad(video_bin, ghost_pad);
        gst_object_unref(pad);

        // Set video-sink of playbin
        g_object_set(play->playbin, "video-sink", video_bin, NULL);

        GstVideoOverlay *overlay = GST_VIDEO_OVERLAY(videosink);
        if(overlay != NULL) {
            gst_video_overlay_set_render_rectangle(overlay, x, y, width, height);

            WId winid = 0;
            if (gst_window != NULL)
                winid = gst_window->winId();
            gst_video_overlay_set_window_handle(overlay, winid);
        }

        if(!filepath.isEmpty()) {
            qDebug() << "Play filepath:" << filepath;
            QUrl fileUri = QUrl::fromLocalFile(filepath);
            QString gstreamerUri = fileUri.toString();
            qDebug() << "Play Uri:" << gstreamerUri;
            g_object_set(play->playbin, "uri", gstreamerUri.toUtf8().constData(), NULL);
        }

        if(bAudio != true)
            rtk_gst_remove_audio_flag (play);
        else
            g_object_set(play->playbin, "current-audio", 0, NULL);

        play->bus = GST_ELEMENT_BUS (play->playbin);

        gst_element_set_state(play->playbin, GST_STATE_PLAYING);
    }
    else { //Subtitle with SRT, PGS, ASS
        char pipeline_str[1024]; // Define pipeline string buffer
        char rectangle[32]; // Sufficient size for "<x,y,width,height>"

        // Create the rectangle string
        snprintf(rectangle, sizeof(rectangle), "<%d,%d,%d,%d>", x, y, width, height);
        string rectangle_str = rectangle;

        if (info->video_codec_desc == "265") { // H.265
            snprintf(pipeline_str, sizeof(pipeline_str),
                "rtksubtitlebin name=r "
                "filesrc location=\"%s\" ! parsebin name=d "
                "d. ! r.subtitle_sink r.subtitle_src ! rtkhookqueue ! %s render-rectangle=\"%s\" "
                "d. ! rtkhookqueue ! h265parse ! v4l2h265dec ! r.video_sink r.video_src ! "
                "rtkhookqueue ! %s render-rectangle=\"%s\" ",
                filepath_cstr,
                text_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str()
            );
        } else { // H.264 and others
            snprintf(pipeline_str, sizeof(pipeline_str),
                "rtksubtitlebin name=r "
                "filesrc location=\"%s\" ! parsebin name=d "
                "d. ! r.subtitle_sink r.subtitle_src ! rtkhookqueue ! %s render-rectangle=\"%s\" "
                "d. ! rtkhookqueue ! h264parse ! v4l2h264dec ! r.video_sink r.video_src ! "
                "rtkhookqueue ! %s render-rectangle=\"%s\" ",
                filepath_cstr,
                text_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str()
            );
        }

        if(bAudio == true)
        {
            int start_idx = strlen(pipeline_str);
            snprintf(&pipeline_str[start_idx], sizeof(pipeline_str) - start_idx,
                "d. ! queue ! decodebin ! audioconvert ! audioresample ! volume name=gst_volume ! autoaudiosink ");
        }

        qDebug() << pipeline_str;
        play->playbin = gst_parse_launch(pipeline_str, nullptr);

        play->bus = GST_ELEMENT_BUS (play->playbin);

        gst_element_set_state(play->playbin, GST_STATE_PLAYING);
    }
#if DEBUG_GSTREAMER == 1
    GST_DEBUG_BIN_TO_DOT_FILE(GST_BIN(play->playbin), GST_DEBUG_GRAPH_SHOW_ALL, "playbin_PAUSED_PLAYING");
#endif

    bus_monitor_running = true;
    pthread_create(&thread_id_bus, NULL, bus_monitor, (void *)play);

    return true;
}

bool RtkGst::rtk_gst_play_new(const QString filepath, QWidget *gst_window,
                                  bool bFullscreen,
                                  int x, int y, int width, int height,
                                  bool bAudio)
{
    return rtk_gst_play_new (&g_play, filepath,  gst_window, bFullscreen, x, y, width, height, bAudio);
}

void RtkGst::rtk_gst_play_free(GstPlay **play_p)
{
    if(play_p == NULL || *play_p == NULL)
        return;
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play_p %p", __FUNCTION__, __LINE__, play_p);

    if (g_face_recognition_process.state() == QProcess::Running)
    {
        g_face_recognition_process.terminate();
        g_face_recognition_process.waitForFinished(5000);
        qDebug() << "Face recognition process terminated.";
    }

    GstPlay *play = *play_p;

    bus_monitor_running = false;

    if (thread_id_bus)
    {
        pthread_cancel(thread_id_bus);
        pthread_join(thread_id_bus, 0);
        thread_id_bus = 0;
    }


    // if(play->channel_list)
    //     free(play->channel_list);
    // if(play->demux && GST_OBJECT_REFCOUNT(play->demux) != 0)
    //     gst_object_unref (play->demux);

    if (play->playbin)
    {
        gst_element_set_state(play->playbin, GST_STATE_NULL);

        /*
        Due to the issue in both YOLO and SSD MobileNet modes where stopping and then playing a video
        causes nnstreamer to have resource cleanup problems, a workaround is to try adding this line,
        which has the effect of cleaning up resources.
        */
        GstIterator *it = gst_bin_iterate_elements(GST_BIN(play->playbin)); // This will increment GST_OBJECT_REFCOUNT(play->playbin)

        unref_element(play->playbin);
        play->playbin = NULL;
    }

    g_free (play);
    *play_p = NULL;
}

void RtkGst::rtk_gst_play_free() {
    rtk_gst_play_free(&g_play);
}

bool RtkGst::rtk_gst_seek_by_slider(GstPlay *play, gdouble rate)
{
    gint64 duration = 0;

    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p, rate=%lf",
                    __FUNCTION__, __LINE__, play, rate);
    if(play == NULL || play->playbin == NULL)
        return false;

    gst_element_get_state(play->playbin, NULL, NULL, GST_CLOCK_TIME_NONE);
    if (!gst_element_query_duration(play->playbin, GST_FORMAT_TIME, &duration)) {
        g_printerr("Failed to query duration.\n");
        return false;
    }

    //GstSeekFlags seekFlags = static_cast<GstSeekFlags>(0);  // No flags
    GstSeekFlags seekFlags = static_cast<GstSeekFlags>(GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_ACCURATE);
    if (!gst_element_seek_simple(play->playbin, GST_FORMAT_TIME, seekFlags, duration*rate)) {
        g_printerr("Seek failed to position %" GST_TIME_FORMAT "\n", GST_TIME_ARGS(duration*rate));
        return false;
    }

    return true;
}

bool RtkGst::rtk_gst_seek_by_slider(gdouble rate)
{
    return rtk_gst_seek_by_slider(g_play, rate);
}

bool RtkGst::rtk_gst_seek_with_offset(GstPlay *play, gint64 offset)
{
    gint64 current_position = 0;

    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p, offset=%ld",
                    __FUNCTION__, __LINE__, play, offset);
    if(play == NULL || play->playbin == NULL)
        return false;

    gst_element_get_state(play->playbin, NULL, NULL, GST_CLOCK_TIME_NONE);
    if (!gst_element_query_position(play->playbin, GST_FORMAT_TIME, &current_position)) {
        g_printerr("Failed to query current position.\n");
        return false;
    }

    gint64 new_position = current_position + offset*GST_SECOND;
    new_position = new_position < 0 ? 0 : new_position;

    //GstSeekFlags seekFlags = static_cast<GstSeekFlags>(0);  // No flags
    GstSeekFlags seekFlags = static_cast<GstSeekFlags>(GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_ACCURATE);
    if (!gst_element_seek_simple(play->playbin, GST_FORMAT_TIME, seekFlags, new_position)) {
        g_printerr("Seek failed to position %" GST_TIME_FORMAT "\n", GST_TIME_ARGS(new_position));
        return false;
    }

    return true;
}

bool RtkGst::rtk_gst_seek_with_offset(gint64 offset)
{
    return rtk_gst_seek_with_offset(g_play, offset);
}

void RtkGst::rtk_gst_speedchange(GstPlay *play, gdouble rate)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p, rate=%lf",
                    __FUNCTION__, __LINE__, play, rate);
    if(play == NULL || play->playbin == NULL)
        return;

    //get position
    gint64 position = GST_CLOCK_TIME_NONE;
    if (!gst_element_query_position(play->playbin, GST_FORMAT_TIME, &position)) {
        g_printerr("Failed to retrieve current position\n");
        return;
    }

    GstState state;
    GstSeekFlags flags = static_cast<GstSeekFlags>(0);  // No flags
    gst_element_get_state(play->playbin, &state, NULL, GST_CLOCK_TIME_NONE);
    if (state == GST_STATE_PLAYING || state == GST_STATE_PAUSED)
    {
        if (state == GST_STATE_PAUSED)
            // change speed should on playing state, otherwise thread will be locked on preroll() behavior
            rtk_gst_change_state (play, GST_STATE_PLAYING);
        if (!gst_element_seek(play->playbin, rate, GST_FORMAT_TIME,
                              flags,
                              GST_SEEK_TYPE_SET, position,
                              GST_SEEK_TYPE_NONE, GST_CLOCK_TIME_NONE)) {
            g_printerr("Failed to set playback speed to %.2fx\n", rate);
        } else {
            g_print("Playback speed set to %.2fx\n", rate);
        }
        if (state == GST_STATE_PAUSED)
            rtk_gst_change_state (play, GST_STATE_PAUSED);
    }
    else
        g_printerr("Failed to set playback speed to %.2fx for inappropriate state %s\n", rate,
                    gst_element_state_get_name(state));
}

void RtkGst::rtk_gst_speedchange(gdouble rate)
{
    rtk_gst_speedchange (g_play, rate);
}

bool RtkGst::rtk_gst_change_state(GstPlay *play, GstState state)
{
    if(play == NULL || play->playbin == NULL)
        return false;
    GstState state_old, state_new;
    gst_element_get_state(play->playbin, &state_old, NULL, GST_CLOCK_TIME_NONE);
    gst_element_set_state(play->playbin, state);
    gst_element_get_state(play->playbin, &state_new, NULL, GST_CLOCK_TIME_NONE);
    if (if_debug)
    {
        qDebug () << QString().asprintf("%s:%d play %p, change state to %s, then %s -> %s",
                    __FUNCTION__, __LINE__, play,
                    gst_element_state_get_name(state),
                    gst_element_state_get_name(state_old),
                    gst_element_state_get_name(state_new));
    }

    g_print("Change state %s -> %s\n", gst_element_state_get_name(state_old),
                gst_element_state_get_name(state_new));
    return (state == state_new);
}

bool RtkGst::rtk_gst_pause(GstPlay *play)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p", __FUNCTION__, __LINE__, play);
    if(play == NULL || play->playbin == NULL)
        return false;

    bool result = rtk_gst_change_state (play, GST_STATE_PAUSED);
#if DEBUG_GSTREAMER == 1
    GST_DEBUG_BIN_TO_DOT_FILE(GST_BIN(play->playbin), GST_DEBUG_GRAPH_SHOW_ALL, "playbin_PLAYING_PAUSED");
#endif
    return result;
}

bool RtkGst::rtk_gst_pause()
{
    return rtk_gst_pause(g_play);
}

bool RtkGst::rtk_gst_resume(GstPlay *play)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p", __FUNCTION__, __LINE__, play);
    if(play == NULL)
        return false;

    bool result = rtk_gst_change_state (play, GST_STATE_PLAYING);
    return result;
}

bool RtkGst::rtk_gst_resume()
{
    return rtk_gst_resume(g_play);
}

void RtkGst::rtk_gst_rotation(GstPlay *play)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play %p", __FUNCTION__, __LINE__, play);
    if(play == NULL)
        return;

    if(play->rotation_method < 3){
        play->rotation_method++;
    }
    else{
        play->rotation_method = 0;
    }
    g_object_set(G_OBJECT(play->rtkvideoflip), "rotate", play->rotation_method, NULL);
}

void RtkGst::rtk_gst_rotation()
{
    rtk_gst_rotation (g_play);
}

void RtkGst::rtk_gst_play_ai(GstPlay **play_p, const QString filepath, QString selectedMode,
                            bool bFullscreen, int x, int y, int width, int height,
                            AiParam *param, bool bAudio)
{
    if (play_p == NULL)
        return;

    // Convert QString to std::string, then to const char*
    string filepath_str = filepath.toStdString();
    const char* filepath_cstr = filepath_str.c_str();

    GstPlay *play_org = *play_p;
    //pause case
    if (play_org!= NULL)
    {
        if (if_debug)
            qDebug () << QString().asprintf("%s:%d play_p %p play %p resume",
                        __FUNCTION__, __LINE__, play_p, play_org);
        rtk_gst_resume (play_org);
        return;
    }

    char pipeline_str[2048]; // Define pipeline string buffer
    char video_size[32]; //Sufficient size for "width=x,height=y"
    char rectangle[32]; // Sufficient size for "<x,y,width,height>"
    char option_size[16]; // Sufficient size for "width:height"

    GstPlay *play;

    play = g_new0 (GstPlay, 1);
    *play_p = play;
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d play_p %p play %p filepath=%s selectedMode=%s bFullscreen=%d x=%d y=%d w=%d h=%d, bAudio=%d",
                    __FUNCTION__, __LINE__, play_p, play,
                    filepath_cstr, selectedMode.toStdString().c_str(),
                    bFullscreen, x, y, width, height, bAudio);

    gst_init(NULL, NULL);

    // Create the rectangle string and option4 string
    snprintf(video_size, sizeof(video_size), "width=%d,height=%d", width, height);
    snprintf(rectangle, sizeof(rectangle), "<%d,%d,%d,%d>", x, y, width, height);
    snprintf(option_size, sizeof(option_size), "%d:%d", width, height);
    string video_size_str = video_size;
    string rectangle_str = rectangle;
    string option_size_str = option_size;

    if (filepath_str.rfind("/dev", 0) == 0) // for usb camera
    {
        if (selectedMode == "posenet"){
            //pose
            snprintf(pipeline_str, sizeof(pipeline_str),
                    "v4l2src device=\"%s\" ! videoconvert ! video/x-raw,format=RGB,width=640,height=360 ! tee name=t \
                    t. ! queue ! videoconvert ! videoscale ! video/x-raw,width=257,height=257,format=RGB \
                    ! tensor_converter ! tensor_transform mode=typecast option=uint8 \
                    ! tensor_filter framework=vivante model=\"%s,%s \" \
                    ! tensor_decoder mode=pose_estimation option1=640:360 option2=257:257 \
                    option3=%s option4=heatmap-offset ! compositor name=mix sink_0::zorder=1 sink_1::zorder=0 ! \
                    %s render-rectangle=\"%s\" \
                    t. ! queue ! mix.",
                    filepath_cstr,
                    param->poseNbg.toStdString().c_str(),
                    param->poseCaseCode.toStdString().c_str(),
                    param->poseCoco.toStdString().c_str(),
                    video_sink_str.toStdString().c_str(), rectangle_str.c_str()
                );
            }
        else if (selectedMode == "ssd_mobilenet"){
            //ssd_mobilenet
            snprintf(pipeline_str, sizeof(pipeline_str),
                    "v4l2src device=\"%s\" ! videoconvert ! video/x-raw,format=RGB,width=640,height=360 ! tee name=t \
                    t. ! queue ! compositor name=mix sink_0::zorder=1 sink_1::zorder=2 ! %s render-rectangle=\"%s\" \
                    t. ! queue ! videoconvert ! videoscale ! video/x-raw,width=300,height=300,format=RGB ! tensor_converter ! \
                    tensor_transform mode=typecast option=uint8 ! tensor_filter framework=vivante \
                    model=\"%s,%s \" ! queue ! tensor_decoder mode=bounding_boxes option1=mobilenet-ssd \
                    option2=%s option3=%s option4=640:360 option5=300:300 ! mix.",
                    filepath_cstr,
                    video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                    param->mobilenetNbg.toStdString().c_str(),
                    param->mobilenetCaseCode.toStdString().c_str(),
                    param->mobilenetCoco.toStdString().c_str(),
                    param->mobilenetBoxPri.toStdString().c_str()
            );
        }
        else if (selectedMode == "face_recognition"){
            //face_recognition
            snprintf(pipeline_str, sizeof(pipeline_str),
                    "python3 %s --camera_device=\"%s\" --resolution=1920,1080 --fps=30 --position=%d,%d --window=%d,%d",
                    param->facerecogScript.toStdString().c_str(),
                    filepath_cstr,
                    x,
                    y,
                    width,
                    height
            );
            qDebug() << pipeline_str;
            g_face_recognition_process.start(pipeline_str);
            if (!g_face_recognition_process.waitForStarted())
            {
                qDebug() << "start face recognition process failed.";
            }
            return;
        }
        else if (selectedMode == "yolov5"){
            //yolov5
            snprintf(pipeline_str, sizeof(pipeline_str),
                    "v4l2src device=\"%s\" ! video/x-raw,width=640,height=360, ! tee name=t "
                    "t. ! queue leaky=2 max-size-buffers=10 ! compositor name=mix sink_0::zorder=1 sink_1::zorder=2 ! "
                    "%s sync=true render-rectangle=\"%s\" "
                    "t. ! queue leaky=2 max-size-buffers=2 ! videoconvert ! videoscale ! video/x-raw,width=320,height=320,format=RGB ! "
                    "tensor_converter ! tensor_transform mode=typecast option=uint8 ! "
                    "tensor_filter framework=vivante model=\"%s,%s \" ! "
                    "queue ! tensor_transform mode=arithmetic option=typecast:float32,add:-1,mul:0.00390963489189744 ! "
                    "tensor_decoder mode=bounding_boxes option1=yolov5 option2=%s option3=0 "
                    "option4=640:360 option5=320:320 ! mix.",
                    filepath_cstr,
                    video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                    param->yoloNbg.toStdString().c_str(),
                    param->yoloCaseCode.toStdString().c_str(),
                    param->yoloCoco.toStdString().c_str()
            );
        }
        else {
            qDebug () << QString().asprintf("%s:%d Unknown slectedMode %s !",
                                            __FUNCTION__, __LINE__, selectedMode.toStdString().c_str());
            return;
        }
    }
    else if (selectedMode == "posenet") {
#if 1
        snprintf(pipeline_str, sizeof(pipeline_str),
                "%s location=\"%s\" ! decodebin name=dec ! tee name=t "
                "t. ! queue ! %s render-rectangle=\"%s\" "
                "t. ! queue leaky=2 max-size-buffers=2 ! "
                "v4l2convert output-io-mode=5 extra-controls=\"controls,npp_single_rgb_plane=1\" ! "
                "video/x-raw ! queue ! videoscale ! video/x-raw,width=257,height=257,format=RGB ! "
                "tensor_converter ! tensor_transform mode=typecast option=uint8 ! "
                "tensor_filter framework=vivante model=\"%s,%s\" ! "
                "tensor_decoder mode=pose_estimation option1=%s option2=257:257 option3=%s option4=heatmap-offset ! "
                "%s render-rectangle=\"%s\"",
                filepath.startsWith("rtsp") ? "rtspsrc" : "filesrc",
                filepath_cstr,
                video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                param->poseNbg.toStdString().c_str(),
                param->poseCaseCode.toStdString().c_str(),
                option_size_str.c_str(),
                param->poseCoco.toStdString().c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str()
        );
#else
        // h264 only
        snprintf(pipeline_str, sizeof(pipeline_str),
                "filesrc location=\"%s\" ! qtdemux ! h264parse ! v4l2h264dec ! videoconvert  ! videoscale ! "
                "video/x-raw,%s,format=RGB ! tee name=t  "
                "t. ! queue ! videoscale ! video/x-raw,width=257,height=257,format=RGB ! "
                "tensor_converter ! tensor_transform mode=typecast option=uint8 ! tensor_filter framework=vivante model=\"%s,%s \" ! "
                "tensor_decoder mode=pose_estimation option1=%s option2=257:257 option3=%s option4=heatmap-offset ! "
                "compositor name=mix sink_0::zorder=1 sink_1::zorder=0 ! %s render-rectangle=\"%s\" "
                "t. ! queue ! mix.",
                filepath_cstr,
                video_size_str.c_str(),
                param->poseNbg.toStdString().c_str(),
                param->poseCaseCode.toStdString().c_str(),
                option_size_str.c_str(),
                param->poseCoco.toStdString().c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str()
        );
#endif
    }
    else if (selectedMode == "ssd_mobilenet") {
#if 1
        snprintf(pipeline_str, sizeof(pipeline_str),
                "%s location=\"%s\" ! decodebin name=dec ! tee name=t "
                "t. ! queue ! %s render-rectangle=\"%s\" "
                "t. ! queue leaky=2 max-size-buffers=2 ! "
                "v4l2convert output-io-mode=5 extra-controls=\"controls,npp_single_rgb_plane=1\" ! "
                "video/x-raw ! queue ! videoscale ! video/x-raw,width=300,height=300,format=RGB ! "
                "tensor_converter ! tensor_transform mode=typecast option=uint8 ! "
                "tensor_filter framework=vivante model=\"%s,%s\" ! "
                "queue ! tensor_decoder mode=bounding_boxes option1=mobilenet-ssd option2=%s option3=%s "
                "option4=%s option5=300:300 ! %s render-rectangle=\"%s\"",
                filepath.startsWith("rtsp") ? "rtspsrc" : "filesrc",
                filepath_cstr,
                video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                param->mobilenetNbg.toStdString().c_str(),
                param->mobilenetCaseCode.toStdString().c_str(),
                param->mobilenetCoco.toStdString().c_str(),
                param->mobilenetBoxPri.toStdString().c_str(),
                option_size_str.c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str()
        );
#else
        // h264 only
        snprintf(pipeline_str, sizeof(pipeline_str),
                "filesrc location=\"%s\" ! qtdemux ! h264parse ! v4l2h264dec ! videoconvert  ! videoscale ! "
                "video/x-raw,format=RGB,%s ! tee name=t "
                "t. ! queue ! compositor name=mix sink_0::zorder=1 sink_1::zorder=2 ! "
                "%s render-rectangle=\"%s\" "
                "t. ! queue ! videoscale ! video/x-raw,width=300,height=300,format=RGB ! "
                "tensor_converter ! tensor_transform mode=typecast option=uint8 ! "
                "tensor_filter framework=vivante model=\"%s,%s \" ! "
                "queue ! tensor_decoder mode=bounding_boxes option1=mobilenet-ssd option2=%s option3=%s "
                "option4=%s option5=300:300 ! mix.",
                filepath_cstr,
                video_size_str.c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                param->mobilenetNbg.toStdString().c_str(),
                param->mobilenetCaseCode.toStdString().c_str(),
                param->mobilenetCoco.toStdString().c_str(),
                param->mobilenetBoxPri.toStdString().c_str(),
                option_size_str.c_str()
        );
#endif
    }
    else if (selectedMode == "yolov5") {
#if 1
        snprintf(pipeline_str, sizeof(pipeline_str),
                "%s location=\"%s\" ! decodebin name=dec ! tee name=t "
                "t. ! queue ! %s render-rectangle=\"%s\" "
                "t. ! queue leaky=2 max-size-buffers=2 ! "
                "v4l2convert output-io-mode=5 extra-controls=\"controls,npp_single_rgb_plane=1\" ! "
                "video/x-raw ! queue ! videoscale ! video/x-raw,width=320,height=320,format=RGB ! "
                "tensor_converter ! tensor_transform mode=typecast option=uint8 ! "
                "tensor_filter framework=vivante model=\"%s,%s \" ! "
                "queue ! tensor_transform mode=arithmetic option=typecast:float32,add:-1,mul:0.00390963489189744 ! "
                "tensor_decoder mode=bounding_boxes option1=yolov5 option2=%s option3=0  "
                "option4=%s option5=320:320 ! %s render-rectangle=\"%s\"",
                filepath.startsWith("rtsp") ? "rtspsrc" : "filesrc",
                filepath_cstr,
                video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                param->yoloNbg.toStdString().c_str(),
                param->yoloCaseCode.toStdString().c_str(),
                param->yoloCoco.toStdString().c_str(),
                option_size_str.c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str()
        );
#else
        // h264 only
        snprintf(pipeline_str, sizeof(pipeline_str),
                "filesrc location=\"%s\" ! qtdemux ! h264parse ! v4l2h264dec ! videoconvert  ! videoscale ! "
                "video/x-raw,format=RGB,%s ! tee name=t "
                "t. ! queue leaky=2 max-size-buffers=10 ! "
                "compositor name=mix sink_0::zorder=1 sink_1::zorder=2 ! %s sync=false render-rectangle=\"%s\" "
                "t. ! queue leaky=2 max-size-buffers=2 ! "
                "videoscale ! video/x-raw,width=320,height=320,format=RGB ! tensor_converter ! tensor_transform mode=typecast option=uint8 ! "
                "tensor_filter framework=vivante model=\"%s,%s \" ! "
                "queue ! tensor_transform mode=arithmetic option=typecast:float32,add:-1,mul:0.00390963489189744 ! "
                "tensor_decoder mode=bounding_boxes option1=yolov5 option2=%s option3=0  "
                "option4=%s option5=320:320 ! mix.",
                filepath_cstr,
                video_size_str.c_str(),
                video_sink_str.toStdString().c_str(), rectangle_str.c_str(),
                param->yoloNbg.toStdString().c_str(),
                param->yoloCaseCode.toStdString().c_str(),
                param->yoloCoco.toStdString().c_str(),
                option_size_str.c_str()
        );
#endif
    }
    else if (selectedMode == "face_recognition") {
        qDebug () << QString().asprintf("%s:%d Unsupported filepath %s",
                                        __FUNCTION__, __LINE__, filepath_cstr);
        qDebug () << QString().asprintf("%s:%d Please use USB camera as device. IP camera and video file are unsupported now !",
                                        __FUNCTION__, __LINE__);
        return;
    }
    else {
        qDebug () << QString().asprintf("%s:%d Unknown slectedMode %s !",
                                        __FUNCTION__, __LINE__, selectedMode.toStdString().c_str());
        return;
    }

    qDebug() << pipeline_str;
    GError *error = NULL;
    play->playbin = gst_parse_launch(pipeline_str, &error);
    if (!play->playbin || error) {
        g_printerr("Pipeline creation failed: %s\n", error ? error->message : "Unknown error");
        if (error) g_error_free(error);
        return;
    }
    if(bAudio != true)
        rtk_gst_remove_audio_flag (play);

    play->bus = GST_ELEMENT_BUS (play->playbin);

    gst_element_set_state(play->playbin, GST_STATE_PLAYING);

#if DEBUG_GSTREAMER == 1
    GST_DEBUG_BIN_TO_DOT_FILE(GST_BIN(play->playbin), GST_DEBUG_GRAPH_SHOW_ALL, "playbin_PAUSED_PLAYING");
#endif

    bus_monitor_running = true;
    pthread_create(&thread_id_bus, NULL, bus_monitor, (void *)play);

}

void RtkGst::rtk_gst_play_ai(const QString filepath, QString selectedMode,
                            bool bFullscreen, int x, int y, int width, int height,
                            AiParam *param, bool bAudio)
{
    rtk_gst_play_ai(&g_play , filepath, selectedMode,
                    bFullscreen, x, y, width, height,
                    param, bAudio);
}

bool RtkGst::rtk_gst_play_multi(QString strSource, int ch, GstPlay **play_p,
                                const QString srcpath, QWidget *gst_window,
                                bool bFullscreen,
                                int x, int y, int width, int height,
                                bool bAudio)
{
    if (play_p == NULL)
        return false;

    // Convert QString to std::string, then to const char*
    string srcpath_str = srcpath.toStdString();
    const char* srcpath_cstr = srcpath_str.c_str();

    GstPlay *play_org = *play_p;
    //pause case
    if (play_org!= NULL)
    {
        if (if_debug)
            qDebug () << QString().asprintf("%s:%d %s ch play_p %p play %p resume",
                        __FUNCTION__, __LINE__, strSource.toStdString().c_str(),
                        ch, play_p, play_org);
        rtk_gst_resume (play_org);
        return true;
    }

    GstElement *videosink;
    GstElement *video_bin;
    GstPlay *play;

    //Get video info, subtitle format, video codec description by executing the command
#if GET_INFO_FROM_FRAMEWORK == 1
    MediaInfo *info = get_media_info_from_framework(srcpath_str);
#else
    MediaInfo *info = get_media_info(srcpath_str);
#endif
    if (!info->already_get_info || info->file_path != srcpath_str)
    {
        qDebug () << QString().asprintf("%s:%d get media info fail !", __FUNCTION__, __LINE__);
    }


    play = g_new0 (GstPlay, 1);
    *play_p = play;
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d play_p %p play %p srcpath=%s bFullscreen=%d x=%d y=%d w=%d h=%d, bAudio=%d",
                    __FUNCTION__, __LINE__, strSource.toStdString().c_str(),
                    ch, play_p, play, srcpath_cstr, bFullscreen, x, y, width, height, bAudio);

    gst_init(NULL, NULL);

    if(video_sink_str.startsWith("rtk") && video_sink_str.endsWith("sink")) {

        play->playbin = gst_element_factory_make ("playbin", "playbin");
        videosink = gst_element_factory_make(video_sink_str.toStdString().c_str(), "video-output");


        // Set video-sink of playbin
        g_object_set(play->playbin, "video-sink", videosink, NULL);

        if(device_fd != -1){
            qDebug() << "reused fd:" << device_fd;
            g_object_set(videosink, "x", x,  "y", y, "w", width, "h", height, "chid", ch, "fd", device_fd, NULL);
        }
        else
            g_object_set(videosink, "x", x,  "y", y, "w", width, "h", height, "chid", ch, NULL);

        if(!srcpath.isEmpty()) {
            qDebug() << "Play srcpath:" << srcpath;
            if(srcpath.startsWith("rtsp") ){
                qDebug() << "Play rtsp:" << srcpath;
                g_object_set(play->playbin, "uri", srcpath.toUtf8().constData(), NULL);
            }
            else{
                QUrl fileUri = QUrl::fromLocalFile(srcpath);
                QString gstreamerUri = fileUri.toString();
                qDebug() << "Play Uri:" << gstreamerUri;
                g_object_set(play->playbin, "uri", gstreamerUri.toUtf8().constData(), NULL);
            }
        }

        if(bAudio != true)
            rtk_gst_remove_audio_flag (play);
        else
            g_object_set(play->playbin, "current-audio", 0, NULL);

        play->bus = GST_ELEMENT_BUS (play->playbin);

        gst_element_set_state(play->playbin, GST_STATE_PLAYING);

        if(device_fd == -1){
            g_object_get(videosink, "fd", &device_fd, NULL);
            qDebug() << "fd:" << device_fd;
        }
    }
    else if(info->subtitle_format == "NONE") {
        play->playbin = gst_element_factory_make ("playbin", "playbin");
        videosink = gst_element_factory_make(video_sink_str.toStdString().c_str(), "video-output");

        play->rtkvideoscale = gst_element_factory_make("rtkvideoscale", "scale");
        g_object_set(G_OBJECT(play->rtkvideoscale), "force-passthrough", info->is_video_10_bits, NULL);

        // Create video_bin, include videoflip and videosink
        video_bin = gst_bin_new("video_bin");
        play->rtkvideoflip = gst_element_factory_make("rtkhse", "videoflip");

        // Set rotation
        play->rotation_method = 0;
        g_object_set(G_OBJECT(play->rtkvideoflip), "rotate", play->rotation_method, NULL);

        // Add video_bin
        gst_bin_add_many(GST_BIN(video_bin), play->rtkvideoscale, play->rtkvideoflip, videosink, NULL);
        gst_element_link_many(play->rtkvideoscale, play->rtkvideoflip, videosink);

        // Set ghost pad, let playbin use bin to do video-sink
        GstPad *pad = gst_element_get_static_pad(play->rtkvideoscale, "sink");
        GstPad *ghost_pad = gst_ghost_pad_new("sink", pad);
        gst_pad_set_active(ghost_pad, TRUE);
        gst_element_add_pad(video_bin, ghost_pad);
        gst_object_unref(pad);

        // Set video-sink of playbin
        g_object_set(play->playbin, "video-sink", video_bin, NULL);

        GstVideoOverlay *overlay = GST_VIDEO_OVERLAY(videosink);
        if(overlay != NULL) {
            gst_video_overlay_set_render_rectangle(overlay, x, y, width, height);

            WId winid = gst_window->winId();
            gst_video_overlay_set_window_handle(overlay, winid);
        }

        if(!srcpath.isEmpty()) {
            qDebug() << "Play srcpath:" << srcpath;
            if(srcpath.startsWith("rtsp") ){
                qDebug() << "Play rtsp_:" << srcpath;
                g_object_set(play->playbin, "uri", srcpath.toUtf8().constData(), NULL);
            }
            else{
                QUrl fileUri = QUrl::fromLocalFile(srcpath);
                QString gstreamerUri = fileUri.toString();
                qDebug() << "Play Uri_:" << gstreamerUri;
                g_object_set(play->playbin, "uri", gstreamerUri.toUtf8().constData(), NULL);
            }
        }

        if(bAudio != true)
            rtk_gst_remove_audio_flag (play);
        else
            g_object_set(play->playbin, "current-audio", 0, NULL);

        play->bus = GST_ELEMENT_BUS (play->playbin);

        gst_element_set_state(play->playbin, GST_STATE_PLAYING);
    }
    else{
       qDebug() << "Not supperted!!" ;
    }
#if DEBUG_GSTREAMER == 1
    GST_DEBUG_BIN_TO_DOT_FILE(GST_BIN(play->playbin), GST_DEBUG_GRAPH_SHOW_ALL, "playbin_PAUSED_PLAYING");
#endif

    bus_monitor_running = true;
    pthread_create(&thread_id_bus, NULL, bus_monitor, (void *)play);

    return true;
}

bool RtkGst::rtk_gst_play_multi(QString strSource, int ch,
                                const QString filepath, QWidget *gst_window,
                                bool bFullscreen,
                                int x, int y, int width, int height,
                                bool bAudio)
{
    return rtk_gst_play_multi (strSource, ch, &g_play, filepath,  gst_window, bFullscreen, x, y, width, height, bAudio);
}

QString RtkGst::rtk_gst_findVideoUnderMedia()
{
    QProcess process;
    process.start("v4l2-ctl --list-devices");
    process.waitForFinished();

    QString result = process.readAllStandardOutput();
    QTextStream stream(&result);

    QString line;
    QString firstVideoDevice;
    bool isTargetBlock = false;

    while (stream.readLineInto(&line)) {
        line = line.trimmed();

        if (line.isEmpty()) continue;

        if (!line.startsWith("/dev/")) {
            // clean states when entering new device block
            firstVideoDevice.clear();
            isTargetBlock = false;
            continue;
        }

        if (line.contains("/dev/video") && firstVideoDevice.isEmpty()) {
            firstVideoDevice = line;  // store the first /dev/video in the block
        }

        if (line.contains("/dev/media0")) {
            isTargetBlock = true;
        }

        // If /dev/media0 exists, return the first /dev/video in the block
        if (isTargetBlock && !firstVideoDevice.isEmpty()) {
            return firstVideoDevice;
        }
    }
    return "";  // No devices found
}

void RtkGst::rtk_gst_screenshot(QString videoStr, gint64 position)
{
    gst_init(NULL, NULL);

    qDebug() << videoStr << " / " << position;

    string pipelineStr =
        "filesrc location=\"" + videoStr.toStdString() +
        "\" ! decodebin ! videoconvert ! videoscale ! video/x-raw ! jpegenc ! multifilesink max-files=1 location=" + generateTimestampedFilename();

    GstElement *pipeline = gst_parse_launch(pipelineStr.c_str(), NULL);
    if (!pipeline) {
        qDebug() << "Failed to create GStreamer pipeline";
        return;
    }

    // Set PAUSED to Seek
    GstStateChangeReturn ret = gst_element_set_state(pipeline, GST_STATE_PAUSED);
    if (ret == GST_STATE_CHANGE_FAILURE) {
        qDebug() << "Failed to set pipeline to PAUSED";
        gst_object_unref(pipeline);
        return;
    }

    // Check pause success
    GstState state;
    GstState pending;
    if (gst_element_get_state(pipeline, &state, &pending, GST_CLOCK_TIME_NONE) != GST_STATE_CHANGE_SUCCESS) {
        qDebug() << "Pipeline did not reach PAUSED state";
        gst_object_unref(pipeline);
        return;
    }

    // Set seek position
    //position = 5000000000;
    GstSeekFlags seekFlags = static_cast<GstSeekFlags>(GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_ACCURATE);
    if (!gst_element_seek_simple(pipeline, GST_FORMAT_TIME, seekFlags, position)) {
        qDebug() << "Seek failed";
    }

    // Set PLAYING to get one picture
    gst_element_set_state(pipeline, GST_STATE_PLAYING);

    gst_element_get_state (pipeline, NULL, NULL, GST_CLOCK_TIME_NONE);

    // Stop Pipeline
    gst_element_set_state(pipeline, GST_STATE_NULL);
    gst_object_unref(pipeline);
}

void RtkGst::rtk_gst_face_recog_keyboard_input(QString input)
{
    //qDebug() << "write face name: " << input;
    if (g_face_recognition_process.state() == QProcess::Running)
    {
        g_face_recognition_process.write(input.toUtf8());
        g_face_recognition_process.waitForBytesWritten();
    }
}

bool RtkGst::rtk_gst_is_face_recog_running()
{
    return (g_face_recognition_process.state() == QProcess::Running) ? true : false;
}