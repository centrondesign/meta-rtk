/**
 * @file rtkgst.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The interface/api to use Realtek library
 */

#ifndef RTKGST_H
#define RTKGST_H

#include <QString>
#include <QPixmap>
#include <QWidget>
#include <gst/gst.h>

#define GET_INFO_FROM_FRAMEWORK         1
#define MAX_INSTANCE 32 // same in rtk_media_if.h

#define _STR_WAYLAND_       "wayland"

using namespace std;

typedef struct MediaInfo
{
  /* check if get correct info */
  string file_path;
  bool already_get_info;

  /* media info */
  bool has_video;
  bool has_audio;
  bool has_subtitle;
#if GET_INFO_FROM_FRAMEWORK == 1
  bool decodable_video;
  bool decodable_audio;
  bool decodable_subtitle;
#endif
  bool is_video_4k;
  bool is_video_less_than_4k;
  bool is_video_10_bits;
  bool enable_video_speed_change;
  bool enable_video_rotate;
  int video_width;
  int video_height;
  unsigned int video_bit_depth;
#if GET_INFO_FROM_FRAMEWORK == 1
  int mpegversion;
  int wmvversion;
#endif
  string subtitle_format;
  string video_codec_desc;
} MediaInfo;

typedef struct GstPlay
{
  GstElement *playbin;
  // GstElement *mq;
  // GstElement *demux;
  // GstElement *omxaudiodec;
  GstElement *rtkvideoflip;
  GstElement *rtkvideoscale;

  GstBus *bus;

  /* missing plugin messages */
  GList *missing;

  gboolean buffering;
  gboolean is_live;

  /* configuration */
  gboolean gapless;

  /* calculate bitrate */
  guint64 base_us;
  guint64 duration_us;
  guint64 data_size;
  guint curr_rate;
  gboolean use_pts;
  GstClockTime low_pts;
  GstClockTime high_pts;
  guint64 frame_cnt;

#ifndef ENABLE_V4L2//jim.hsu todo
  /* for 24/25 FPS video playback */
  //HDMI_WRAP_VIDEO_ID_CODE m_vic;
  //HDMI_WRAP_COLOR_SPACE m_colorSpace;
#endif
  bool m_vicSaved;
  bool m_vicChanged;

  // gchar **playlist;
  gint n_video;          /* Number of embedded video streams */
  gint n_audio;          /* Number of embedded audio streams */
  gint n_text;           /* Number of embedded subtitle streams */
  gint current_video;    /* Currently playing video stream */
  gint current_audio;    /* Currently playing audio stream */
  gint current_text;     /* Currently playing subtitle stream */

  bool prgm_selct_status;
  gint prgm_selct_idx;
  // gint *channel_list;
  // gint channel_count;
  gint rotation_method;

} GstPlay;

typedef struct
{
    QString yoloCaseCode;
    QString yoloNbg;
    QString yoloCoco;
    QString poseCaseCode;
    QString poseNbg;
    QString poseCoco;
    QString mobilenetCaseCode;
    QString mobilenetNbg;
    QString mobilenetBoxPri;
    QString mobilenetCoco;
    QString facerecogScript;
} AiParam;

enum class WestonMode {
    Update, //set black background
    Reset
};

class RtkGst
{
public:
    bool if_platform_wayland;
    bool if_wayland_bg_color_transparency;

    RtkGst();
    ~RtkGst();
    QString getPlatformName(int argc, char *argv[]);
    void modifyWestonIni(WestonMode mode);
    void parsePlatformSetting();
    void set_debug (bool bDebug);
    void set_sink (QString videosink, QString textsink);
    void unref_element(GstElement *element);
#if GET_INFO_FROM_FRAMEWORK == 1
    MediaInfo* get_media_info_from_framework(const string& video_file);
#else
    MediaInfo* get_media_info(const string& video_file);
#endif
    void rtk_gst_remove_audio_flag(GstPlay *play);

    // --- for single playback only
    bool rtk_gst_play_new(const QString filepath, QWidget *gst_window,
                          bool bFullscreen, int x, int y, int width, int height,
                          bool bAudio);
    void rtk_gst_play_free();
    bool rtk_gst_pause();
    bool rtk_gst_resume();
    bool rtk_gst_seek_with_offset(gint64 offset);
    bool rtk_gst_setVolume(int volume);
    void rtk_gst_speedchange(gdouble rate);
    void rtk_gst_rotation();
    bool rtk_gst_seek_by_slider(gdouble rate);
    pair<gint64, gint64> rtk_gst_getPlaybackPositionDuration();
    void rtk_gst_play_ai(const QString filepath, QString selectedMode,
                          bool bFullscreen, int x, int y, int width, int height,
                          AiParam *param, bool bAudio);
    bool rtk_gst_play_multi(QString strSource, int ch,
                          const QString filepath, QWidget *gst_window,
                          bool bFullscreen, int x, int y, int width, int height,
                          bool bAudio);

    // --- for specific playback operation
    bool rtk_gst_play_new(GstPlay **play_p, const QString filepath, QWidget *gst_window,
                          bool bFullscreen, int x, int y, int width, int height,
                          bool bAudio);
    void rtk_gst_play_free(GstPlay **play_p);
    bool rtk_gst_change_state(GstPlay *play, GstState state);
    bool rtk_gst_pause(GstPlay *play);
    bool rtk_gst_resume(GstPlay *play);
    bool rtk_gst_seek_with_offset(GstPlay *play, gint64 offset);
    bool rtk_gst_setVolume(GstPlay *play, int volume);
    void rtk_gst_speedchange(GstPlay *play, gdouble rate);
    void rtk_gst_rotation(GstPlay *play);
    bool rtk_gst_seek_by_slider(GstPlay *play, gdouble rate);
    pair<gint64, gint64> rtk_gst_getPlaybackPositionDuration(GstPlay *play);
    void rtk_gst_play_ai(GstPlay **play_p, const QString filepath, QString selectedMode,
                          bool bFullscreen, int x, int y, int width, int height,
                          AiParam *param, bool bAudio);
    bool rtk_gst_play_multi(QString strSource, int ch, GstPlay **play_p,
                          const QString srcpath, QWidget *gst_window,
                          bool bFullscreen, int x, int y, int width, int height,
                          bool bAudio);

    QString rtk_gst_findVideoUnderMedia();
    void rtk_gst_screenshot(QString videoStr, gint64 position);
    void rtk_gst_face_recog_keyboard_input(QString);
    bool rtk_gst_is_face_recog_running();

private:
    bool if_debug;
    QString video_sink_str;
    QString text_sink_str;

#if GET_INFO_FROM_FRAMEWORK == 1
    bool get_check_video_info_from_framework(int stream_idx);
    bool get_check_subtitle_info_from_framework(int stream_idx);
#endif
};

extern RtkGst *rtkGst;

#endif // RTKGST_H
