/**
 * @file rtkgst.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The interface/api to use Realtek library
 */

#ifndef RTKGST_H
#define RTKGST_H

#define GET_INFO_FROM_FRAMEWORK         1

#include <QString>
#include <vector>
#include <QPixmap>
#include <QWidget>
#include <gst/gst.h>
#if GET_INFO_FROM_FRAMEWORK == 1
#include <rtk_media_info.h>
#include <rtk_media_cap.h>
#endif

#define STREAM_MAX 128   // STREAM_INFO_LEN in rtk_media_info.h
#define VOLUME_MAX 100.0
#define VOLUME_DEF 10
#define VOLUME_MIN 0

#define _STR_WAYLAND_       "wayland"

using namespace std;

#if GET_INFO_FROM_FRAMEWORK == 1
/*-------- the same definitions in rtk_media_playback.h --------*/
#define MAX_VIDEO_COUNT 5
#define MAX_SUBTITLE_COUNT 30
#define MAX_AUDIO_COUNT 30

typedef enum rtk_subtitle_kind {
  RTK_DVDSPU,
  RTK_SRT,
  RTK_ASS,
  RTK_UNKNOWN_SUBTITLE,
} RTK_SUBTITLE_KIND;

typedef enum rtk_video_kind {
  RTK_H264_VIDEO,
  RTK_H265_VIDEO,
  RTK_AV1_VIDEO,
  RTK_VP8_VIDEO,
  RTK_VP9_VIDEO,
  RTK_MPEG4_VIDEO,
  RTK_MPEG2_VIDEO,
  RTK_MPEG1_VIDEO,
  RTK_WMV_VIDEO,
  RTK_UNKNOWN_VIDEO,
} RTK_VIDEO_KIND;

typedef enum rtk_audio_kind {
  RTK_AC3_AUDIO,
  RTK_EAC3_AUDIO,
  RTK_AAC_AUDIO,
  RTK_MP1_AUDIO,
  RTK_MP2_AUDIO,
  RTK_MP3_AUDIO,
  RTK_OPUS_AUDIO,
  RTK_VORBIS_AUDIO,
  RTK_DTS_AUDIO,
  RTK_UNKNOWN_AUDIO,
} RTK_AUDIO_KIND;

typedef enum rtk_container_kind {
  RTK_MP4_CONTAINER,
  RTK_TS_CONTAINER,
  RTK_MKV_CONTAINER,
  RTK_ASF_CONTAINER,
  RTK_PS_CONTAINER,
  RTK_AVI_CONTAINER,
  RTK_UNKNOWN_CONTAINER,
} RTK_CONTAINER_KIND;

typedef struct rtk_video_bin {
  RTK_VIDEO_KIND kind;
  GstPad *pad;
  GstElement *queue1;
  GstElement *dec;
  GstElement *queue2;
  GstElement *vqueue;
  GstElement *vscale;
  GstElement *vhse;
  GstElement *squeue;
  GstElement *vsink;
  GstElement *ssink;
  GstElement *selector;
  GstElement *convert;
  GstElement *resample;
  GstElement *volume;
  GstElement *capsfilter;
  GstElement *asink;
} RTK_VIDEO_BIN;

typedef struct rtk_subtitle_bin {
  RTK_SUBTITLE_KIND kind;
  GstPad *pad;
  GstElement *queue1;
  GstElement *subtitle;
} RTK_SUBTITLE_BIN;

typedef struct rtk_audio_bin {
  RTK_AUDIO_KIND kind;
  int audio_active_id;
  GstPad *pad;
  GstElement *queue1;
  GstElement *dec;
  GstElement *queue2;
} RTK_AUDIO_BIN;
/*--------------------------------------------------------------*/

typedef struct StreamInfo
{
  rtk_stream_type type; // define in rtk_media_info.h
  std::string type_name;
  std::string mime;
  int id;
  std::string language;
  std::string title;
  bool decodable;
  bool tmp[3];

  /* for video */
  int video_width;
  int video_height;
  unsigned int video_bit_depth;
  int mpegversion;
  int wmvversion;

  /* for subtitle */
  std::string subtitle_format;

} StreamInfo;
#endif

typedef struct MediaInfo
{
  /* check if get correct info */
  std::string file_path;
  bool already_get_info;
  bool has_video;
  bool has_audio;
  bool tmp;

#if GET_INFO_FROM_FRAMEWORK == 1
  StreamInfo stream[STREAM_MAX];
  int stream_count;
  std::vector<int> vect_v; // the list for video index in stream[]
  std::vector<int> vect_a; // the list for audio index in stream[]
  std::vector<int> vect_s; // the list for subtitle index in stream[]
  int vect_idx_v; // current video index in stream[]
  int vect_idx_a; // current audio index in stream[]
  int vect_idx_s; // current subtitle index in stream[]
  int decodable_v_count;
  int decodable_a_count;
  int decodable_s_count;
#else
  int video_width;
  int video_height;
  unsigned int video_bit_depth;
#endif

  std::string video_codec_desc;
  std::string subtitle_format;
  bool is_video_4k;
  bool is_video_less_than_4k;
  bool is_video_10_bits;
  bool enable_video_speed_change;
  bool enable_video_rotate;
  bool tmp2[3];
} MediaInfo;

typedef struct GstPlay
{
#if GET_INFO_FROM_FRAMEWORK == 1
  string player_name;
  // MediaInfo info;
  GMainLoop *loop;
  GstElement *src;
  GstElement *typefind;
  GstElement *demux;
  RTK_CONTAINER_KIND container_kind;
  RTK_VIDEO_BIN video_bin[MAX_VIDEO_COUNT];
  int video_count;
  int video_index;
  RTK_SUBTITLE_BIN subtitle_bin[MAX_SUBTITLE_COUNT];
  int subtitle_count;
  int subtitle_index;
  RTK_AUDIO_BIN audio_bin[MAX_AUDIO_COUNT];
  int audio_count;
  int audio_index;
  int x;
  int y;
  int width;
  int height;
  // gboolean pipeline_already_quit;
  // gboolean start_playing;
  // gdouble rate;
  int volume_value; // VOLUME_MIN ~ VOLUME_MAX 
  gboolean volume_applied;
  gboolean video_first_frame;
#else
  // GstElement *mq;
  // GstElement *demux;
  // GstElement *omxaudiodec;
#endif

  GstElement *pipeline;
  GstElement *rtkvideoflip;
  GstElement *rtkvideoscale;

  GstBus *bus;

  gint rotation_method;

}  GstPlay;

typedef struct
{
    QString yoloCaseCode;
    QString yoloNbg;
    QString yoloCoco;
    QString poseCaseCode;
    QString poseNbg;
    QString poseCoco;
    QString mobilenetCaseCode;
    QString mobilenetNbg;
    QString mobilenetBoxPri;
    QString mobilenetCoco;
    QString facerecogScript;
} AiParam;

enum class WestonMode {
    Update, //set black background
    Reset
};

class RtkGst
{
public:
    bool if_platform_wayland;
    bool if_wayland_bg_color_transparency;

    RtkGst();
    ~RtkGst();
#if GET_INFO_FROM_FRAMEWORK == 1
    MediaInfo* get_media_info_from_framework(const string& video_file);
    void rtk_gst_play_get_info(GstPlay **play_p, MediaInfo **info_p);
#else
    MediaInfo* get_media_info(const string& video_file);
#endif
    QString getPlatformName(int argc, char *argv[]);
    void modifyWestonIni(WestonMode mode);
    void parsePlatformSetting();
    void set_debug (bool bDebug);
    void set_sink (QString videosink, QString textsink);
    void get_sink (QString *vsink, QString *tsink);
    bool rtk_gst_set_element_state(GstPlay *play, GstElement *element, GstState state);
    void rtk_gst_set_element_state_no_check(GstPlay *play, GstElement *element, GstState state);
    void rtk_gst_unref_element(GstElement *element);
    void rtk_gst_remove_audio_flag(GstPlay *play);

    // --- for single playback only
    bool rtk_gst_play_new(const QString filepath, QWidget *gst_window,
                          bool bFullscreen, int x, int y, int width, int height,
                          bool bAudio);
    void rtk_gst_play_free();
    bool rtk_gst_pause();
    bool rtk_gst_resume();
    bool rtk_gst_seek_with_offset(gint64 offset);
    bool rtk_gst_setVolume(int volume);
    void rtk_gst_speedchange(gdouble rate);
    void rtk_gst_rotation();
    bool rtk_gst_seek_by_slider(gdouble rate);
    pair<gint64, gint64> rtk_gst_getPlaybackPositionDuration();
    void rtk_gst_play_ai(const QString filepath, QString selectedMode,
                          bool bFullscreen, int x, int y, int width, int height,
                          AiParam *param, bool bAudio);
    bool rtk_gst_play_multi(QString strSource, int ch,
                          const QString filepath, QWidget *gst_window,
                          bool bFullscreen, int x, int y, int width, int height,
                          bool bAudio);

    // --- for specific playback operation
    bool rtk_gst_play_new(GstPlay **play_p, const QString filepath, QWidget *gst_window,
                          bool bFullscreen, int x, int y, int width, int height,
                          bool bAudio);
    void rtk_gst_play_free(GstPlay **play_p);
    bool rtk_gst_pause(GstPlay *play);
    bool rtk_gst_resume(GstPlay *play);
    bool rtk_gst_seek_with_offset(GstPlay *play, gint64 offset);
    bool rtk_gst_setVolume(GstPlay *play, int volume);
    void rtk_gst_speedchange(GstPlay *play, gdouble rate);
    void rtk_gst_rotation(GstPlay *play);
    bool rtk_gst_seek_by_slider(GstPlay *play, gdouble rate);
    pair<gint64, gint64> rtk_gst_getPlaybackPositionDuration(GstPlay *play);
#if GET_INFO_FROM_FRAMEWORK == 1
    void rtk_gst_switch_audio(GstPlay *play, int index);
    void rtk_gst_switch_subtitle(GstPlay *play, int index);
#endif
    void rtk_gst_play_ai(GstPlay **play_p, const QString filepath, QString selectedMode,
                          bool bFullscreen, int x, int y, int width, int height,
                          AiParam *param, bool bAudio);
    bool rtk_gst_play_multi(QString strSource, int ch, GstPlay **play_p,
                          const QString srcpath, QWidget *gst_window,
                          bool bFullscreen, int x, int y, int width, int height,
                          bool bAudio);

    QString rtk_gst_findVideoUnderMedia();
    void rtk_gst_screenshot(QString videoStr, gint64 position);
    void rtk_gst_face_recog_keyboard_input(QString);
    bool rtk_gst_is_face_recog_running();

private:
    bool if_debug;
    QString video_sink_str;
    QString text_sink_str;
};

extern RtkGst *rtkGst;

#endif // RTKGST_H
