TEMPLATE      = subdirs

SUBDIRS       += rtk-multi-playback
#SUBDIRS       += rtk-stress-test
#SUBDIRS       += rtk-nvr-layout
