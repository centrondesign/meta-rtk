/**
 * @file hlsprocess.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The process to parse HLS directory and m3u8 files
 */

#ifndef HLSPROCESS_H
#define HLSPROCESS_H

#include <QThread>
#include <QMutex>
#include <QTimer>
#include "define.h"
#include "m3u8info.h"

class HlsProcess : public QThread
{
    Q_OBJECT

public:
    QMutex mutex;
    M3u8Channel *pM3u8Channel[CHANNEL_MAX];

    HlsProcess();
    ~HlsProcess();

    void setStart();
    void run();
    void setStop();
    void finalize();
    void setRefetch();
    void refreshM3u8List(int chIdx);
    bool parseM3U8(QString absFilePath, int absPathHeaderLen, M3u8Info *info);
    bool checkAndMkDir(QString absDirPath);
    uint getHashDateMask(QDate date);

private:
    bool bRun;
    bool bRefetch;
    bool bSelectedMonthUpdated;         // for playback update
    bool bSelectedDateUpdated;          // for playback update
    bool bSelectedDateChannelUpdated;   // for playback update
    QMutex mutexRefetch;
    QTimer *updateTimer;
    QHash<QDate, uint> hashDateMask;    // value: the bitmask of the channel
    int channelIdxMirror;

    double getDirSize(QString absDirPath);
    uint setHashDateMask(bool set, QDate date, int chIdx);
    void updateHashDateMask(int chIdx);

private slots:
    void timer_update();

};

extern HlsProcess *hlsProcess;

#endif // HLSPROCESS_H
