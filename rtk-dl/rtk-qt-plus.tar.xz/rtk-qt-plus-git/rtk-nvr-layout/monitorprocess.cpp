/**
 * @file monitorprocess.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2018
 * @brief Do IPC connection checking, storage managment, and system recovery if necessary.
 */

#include "monitorprocess.h"
#include "gui/mainwidget.h"

PingOp::PingOp(QString ip)
{
    state = PING_FAIL_AND_NO_FRAME;
    bPingOk = false;
    this->ip = ip;
    proc = NULL;
    timer = new QTimer(this);
//    timer->setInterval();
    timer->setSingleShot(true);
    proc = new QProcess(this);
    QObject::connect(timer, SIGNAL(timeout()), this, SLOT(pingStart()));
    QObject::connect(proc, SIGNAL(finished(int)), this, SLOT(pingOperation(int)));
}

PingOp::~PingOp()
{
    if(timer != NULL)
    {
        delete(timer);
        timer = NULL;
    }
    if(proc != NULL)
    {
        delete(proc);
        proc = NULL;
    }
}

void PingOp::finalize()
{
    if(timer->isActive())
    {
        if(DBG(_DBG_RTKAPI_))
            qDebug() << "PingOp::finalize()";
        timer->stop();
    }
    if(proc->state() != QProcess::NotRunning)
    {
        proc->terminate();
    }
}

bool PingOp::isValidIpv4Ip()
{
    // check format
    QRegularExpression re("^(\\d+).(\\d+).(\\d+).(\\d+)$");
    QRegularExpressionMatch match=re.match(this->ip);
    if(match.hasMatch() == false)
    {
//        qDebug() << __func__ << "format mismatch";
        return false;
    }

    // check value
    int ip[4];
    ip[0] = match.captured(1).toInt();
    ip[1] = match.captured(2).toInt();
    ip[2] = match.captured(3).toInt();
    ip[3] = match.captured(4).toInt();
//    qDebug() << __func__ << ip[0] << ip[1] << ip[2] << ip[3];
    if (ip[0] < 0 || ip[0] > 255 ||
        ip[1] < 0 || ip[1] > 255 ||
        ip[2] < 0 || ip[2] > 255 ||
        ip[3] < 0 || ip[3] > 255)
    {
//        qDebug() << __func__ << "value mismatch";
        return false;
    }
    return true;
}

void PingOp::pingStart()
{
    if(proc->state() != QProcess::NotRunning)
    {
        proc->terminate();
    }
    QString str_ping = QString("ping %1 -t 3 -w 3").arg(ip);
    proc->start(str_ping, QStringList());
    if(DBG(_DBG_MONITOR_))
    {
        qDebug() << STR_DBG_MONT
                 << str_ping;
    }
}

void PingOp::pingOperation(int rtnCode)
{
#if QT_ENV_ONLY != 1

    /* [case1] with disconnect ip, command: ping 192.168.0.2 -t 3 -w 3
    PING 192.168.0.2 (192.168.0.2): 56 data bytes

    --- 192.168.0.2 ping statistics ---
    3 packets transmitted, 0 packets received, 100% packet loss
    */
    /* [case2] with connected ip, command: ping 192.168.0.2 -t 3 -w 3
    PING 192.168.0.190 (192.168.0.190): 56 data bytes
    64 bytes from 192.168.0.190: seq=0 ttl=64 time=0.720 ms
    64 bytes from 192.168.0.190: seq=1 ttl=64 time=0.613 ms
    64 bytes from 192.168.0.190: seq=2 ttl=64 time=0.815 ms

    --- 192.168.0.190 ping statistics ---
    3 packets transmitted, 3 packets received, 0% packet loss
    round-trip min/avg/max = 0.613/0.716/0.815 ms
    */
    /* [case3] with connected ip, command: ping 192.168.0.190 -t 3 -w 3 -q
    PING 192.168.0.190 (192.168.0.190): 56 data bytes

    --- 192.168.0.190 ping statistics ---
    3 packets transmitted, 3 packets received, 0% packet loss
    round-trip min/avg/max = 0.353/0.635/0.826 ms
    */
    QList<QString> list;
    QString line;
    int replyCnt = 0;

    monitorProcess->mutex.lock();
    QString output = proc->readAllStandardOutput();
    list = output.split("\n");
    foreach(line, list)
    {
        line = line.trimmed();
//        qDebug() << line;
        if (line.startsWith("64 bytes from "))
        {
            replyCnt++;
        }
    }
    bPingOk = (replyCnt > 0);
    monitorProcess->mutex.unlock();

#else
    bPingOk = false;
#endif
    if(DBG(_DBG_MONITOR_))
    {
        qDebug() << STR_DBG_MONT
                 << ip <<" ping => "
                 << (bPingOk ? "ok" : "fail");
    }
    Q_UNUSED(rtnCode);
}

//-----------------------------------------------------------------------------
MonitorProcess *monitorProcess = NULL;

MonitorProcess::MonitorProcess()
{
    monitorProcess = this;
    pingTimer = new QTimer(this);
    newIpList = new QList<QString>;
    pingList = new QList<PingOp *>;
    connect(pingTimer, SIGNAL(timeout()), this, SLOT(pingControl()));
}

MonitorProcess::~MonitorProcess()
{
    delete (pingTimer);
    delete (newIpList);
    delete (pingList);
}

void MonitorProcess::setStart()
{
    pingTimer->start(Config::sys.monitorProcessPoolingTime/2);
    this->start();
}

void MonitorProcess::run()
{
    int idx, chIdx;
    GridReal *gridIpc;
    unsigned long long bufferWriteCnt, sizeZeroCnt, connectErrCnt, writeErrCnt;
    QList<int> listIdx, listChIdx;
    IPC_CH_S   *ipc_ch;
    IPC_STATE_E newState = PING_BEGIN;

    bRun = true;
    while(bRun)
    {
        this->msleep(Config::sys.monitorProcessPoolingTime);
        listIdx.clear();
        listChIdx.clear();


        viewProcess->mutex.lock();
        for(chIdx=0; chIdx<Config::sys.ipcChannelMax; chIdx++)
        {
            idx = viewProcess->get_ipc_array_idx(chIdx);
            gridIpc = &viewProcess->ipc_gridReal[idx];

            if(gridIpc->ipcState == PING_BEGIN)
            {
                if(gridIpc->bIpValid)
                {
                    if(ptrInPingList(gridIpc->ip) == NULL)
                    {
                        newIpList->append(gridIpc->ip);
                    }
                }
                newState = gridIpc->ipcState;
            }
            else
            {
                newState = getNewState(chIdx, gridIpc);
            }

            if (gridIpc->channelId > ChannelId_Invalid &&
                gridIpc->status != GridReal::GridStatus_NONE)
            {
                gridIpc->monitorQueryTime -= (int)(Config::sys.monitorProcessPoolingTime);
                if(gridIpc->noFrameTime > 0)
                {
                    gridIpc->noFrameTime += Config::sys.monitorProcessPoolingTime;

                    mutex.lock();
                    if(gridIpc->ipcState == PING_FAIL_AND_NO_FRAME &&
                       newState == PING_OK_BUT_NO_FRAME)
                    {
                        listIdx.append(idx);
                        listChIdx.append(chIdx);
                        gridIpc->monitorQueryTime = (int)Config::sys.monitorProcessReconnectTime;
                        updateState(idx, chIdx, gridIpc, newState);
                    }
                    mutex.unlock();
                }
                if(gridIpc->monitorQueryTime > 0)
                    continue;

                if(gridIpc->ipcState == PING_BEGIN)
                {
                    newState = getNewState(chIdx, gridIpc);
                }

                bufferWriteCnt = 0;
                sizeZeroCnt = 0;
                connectErrCnt = 0;
                writeErrCnt = 0;
                if(rtkApi->qt_rtk_ipc_debug_getInfo(gridIpc->channelId,
                                                &bufferWriteCnt, &sizeZeroCnt,
                                                &connectErrCnt, &writeErrCnt) != true)
                {
                    gridIpc->monitorQueryTime = (int)Config::sys.monitorProcessQueryTime;
                    gridIpc->bNewFrameArrived = false;
                    updateState(idx, chIdx, gridIpc, newState);
                    continue;
                }

                if(gridIpc->bufferWriteCnt != bufferWriteCnt)
                {
                    if(bufferWriteCnt > gridIpc->bufferWriteCnt &&
                       (bufferWriteCnt-sizeZeroCnt) > 0 &&
                       (bufferWriteCnt-sizeZeroCnt) > (gridIpc->bufferWriteCnt-gridIpc->sizeZeroCnt))
                    {
                        if(gridIpc->bNewFrameArrived != true)
                        {
                            gridIpc->bNewFrameArrived = true;
                            newState = getNewState(chIdx, gridIpc);
                            if(DBG(_DBG_MONITOR_))
                            {
                                qDebug() << STR_DBG_MONT
                                         << STR_IPC << idx << chIdx
                                         << "connect";
                            }
                        }
                        if(gridIpc->noFrameTime > 0)
                        {
                            // already connect
                            gridIpc->noFrameTime = 0;
                            if(DBG(_DBG_MONITOR_))
                            {
                                qDebug() << STR_DBG_MONT
                                         << STR_IPC << idx << chIdx
                                         << "bufferWriteCnt=" << bufferWriteCnt
                                         << "oldbufferWriteCnt=" << gridIpc->bufferWriteCnt
                                         << "monitorQueryTime reset to 0";
                            }
                        }
                    }
                    gridIpc->bufferWriteCnt = bufferWriteCnt;
                    gridIpc->sizeZeroCnt = sizeZeroCnt;
                    gridIpc->connectErrCnt = connectErrCnt;
                    gridIpc->writeErrCnt = writeErrCnt;
                    gridIpc->monitorQueryTime = (int)Config::sys.monitorProcessQueryTime;
                }
                else
                {
                    gridIpc->monitorQueryTime = (int)Config::sys.monitorProcessQueryTime;
                    if(gridIpc->noFrameTime <= 0)
                    {
                        gridIpc->noFrameTime = Config::sys.monitorProcessPoolingTime;
                    }
                    else if(gridIpc->noFrameTime >= Config::sys.monitorProcessNoFrameTimeout)
                    {
                        if(gridIpc->bNewFrameArrived != false)
                        {
                            gridIpc->bNewFrameArrived = false;
                            newState = getNewState(chIdx, gridIpc);

                            rtkApi->qt_rtk_ipc_debug_reset(gridIpc->channelId);
                            if(rtkApi->qt_rtk_ipc_debug_getInfo(gridIpc->channelId,
                                                            &bufferWriteCnt, &sizeZeroCnt,
                                                            &connectErrCnt, &writeErrCnt))
                            {
                                gridIpc->bufferWriteCnt = bufferWriteCnt;
                                gridIpc->sizeZeroCnt = sizeZeroCnt;
                                gridIpc->connectErrCnt = connectErrCnt;
                                gridIpc->writeErrCnt = writeErrCnt;
                            }
                        }
                        if(gridIpc->bIpValid)
                        {
                            newIpList->append(gridIpc->ip);
                        }

                        listIdx.append(idx);
                        listChIdx.append(chIdx);

                        if(gridIpc->noFrameTime < Config::sys.monitorProcessReconnectTime)
                        {
                            gridIpc->monitorQueryTime = (int)Config::sys.monitorProcessReconnectTime;
                        }
                        else
                        {
                            gridIpc->monitorQueryTime = qMin(qMax((int)gridIpc->noFrameTime, (int)gridIpc->noFrameTime*2),
                                                             (int)Config::sys.monitorProcessReconnectMaxTime);
                        }
                        if(DBG(_DBG_MONITOR_))
                        {
                            qDebug() << STR_DBG_MONT
                                     << STR_IPC << idx << chIdx
                                     << "disconnect =>"
                                     << "monitorQueryTime=" << gridIpc->monitorQueryTime
                                     << "noFrameTime=" << gridIpc->noFrameTime;
                        }
                    }
                }
                updateState(idx, chIdx, gridIpc, newState);
            }
            else
            {
                gridIpc->bufferWriteCnt = 0;
                gridIpc->sizeZeroCnt = 0;
                gridIpc->connectErrCnt = 0;
                gridIpc->writeErrCnt = 0;
                gridIpc->monitorQueryTime = Config::sys.monitorProcessQueryTime;
//                gridIpc->noFrameTime = 0; // maybe in restart process during disconnection
            }
        }
        viewProcess->mutex.unlock();

        while(listIdx.isEmpty() == false &&
              listChIdx.isEmpty() == false)
        {
            idx = listIdx.takeFirst();
            chIdx = listChIdx.takeFirst();
            ipc_ch = &Config::ipc.ch[chIdx];
            if(DBG(_DBG_MONITOR_))
            {
                qDebug() << STR_DBG_MONT
                         << STR_IPC << idx << chIdx
                         << QString("restart connection !");
            }
            viewProcess->ipc_stop(idx, Config::sys.seamless);
            viewProcess->ipc_start(idx, ipc_ch->rtspCmd);
        }
    }
}

void MonitorProcess::setStop()
{
    bRun = false;
    pingTimer->stop();
}

void MonitorProcess::finalize()
{
    bRun = false;
    while (monitorProcess->isRunning())
    {
        msleep(Config::sys.monitorProcessPoolingTime*2);
    }

    for(int i=pingList->count()-1; i>=0; i--)
    {
        PingOp *pingOp = pingList->at(i);
        if(DBG(_DBG_RTKAPI_))
            qDebug() << "MonitorPorcess::finalize()" << i;
        pingOp->finalize();
        pingList->removeOne(pingOp);
        delete(pingOp);
    }
}

bool MonitorProcess::ifInPingList(QString ip)
{
    foreach(PingOp *pingOp, *pingList)
    {
        if(pingOp->ip == ip)
            return true;
    }
    return false;
}

PingOp *MonitorProcess::ptrInPingList(QString ip)
{
    foreach(PingOp *pingOp, *pingList)
    {
        if(pingOp->ip == ip)
            return pingOp;
    }
    return NULL;
}

IPC_STATE_E MonitorProcess::getNewState(int chIdx, GridReal* gridIpc)
{
    IPC_STATE_E newState = PING_BEGIN;
    PingOp *pingOp = NULL;

    if(chIdx < 0 || chIdx >= CHANNEL_MAX || gridIpc == NULL)
        return newState;

    // should do viewProcess->mutex.lock() before calling this function
    mutex.lock();
    if(gridIpc->bIpValid)
    {
        pingOp = ptrInPingList(gridIpc->ip);
    }
    if(pingOp == NULL)
    {
        if(gridIpc->bNewFrameArrived)
        {
            newState = PING_FAIL_BUT_NEW_FRAME;
        }
        else
        {
            newState = PING_FAIL_AND_NO_FRAME;
        }
    }
    else
    {
        if(pingOp->bPingOk == true && gridIpc->bNewFrameArrived == true)
        {
            newState = PING_OK_AND_NEW_FRAME;
        }
        else if(pingOp->bPingOk == true && gridIpc->bNewFrameArrived == false)
        {
            newState = PING_OK_BUT_NO_FRAME;
        }
        else if(pingOp->bPingOk == false && gridIpc->bNewFrameArrived == true)
        {
            newState = PING_FAIL_BUT_NEW_FRAME;
        }
        else
        {
            newState = PING_FAIL_AND_NO_FRAME;
        }
    }
    mutex.unlock();

    return newState;
}

void MonitorProcess::updateState(int idx, int chIdx, GridReal* gridIpc, IPC_STATE_E newState)
{
    if(gridIpc->ipcState == newState)
        return;
    if(DBG(_DBG_MONITOR_))
    {
        qDebug() << STR_DBG_MONT
                 << STR_IPC << idx << chIdx
                 << QString("state:%1 -> %2")
                    .arg(strState(gridIpc->ipcState))
                    .arg(strState(newState));
    }
    gridIpc->ipcState = newState;
}

QString MonitorProcess::strState(IPC_STATE_E state)
{
    switch(state)
    {
    case PING_BEGIN:                return QString("PING_BEGIN");
    case PING_FAIL_AND_NO_FRAME:    return QString("PING_FAIL_AND_NO_FRAME");
    case PING_FAIL_BUT_NEW_FRAME:   return QString("PING_FAIL_BUT_NEW_FRAME");
    case PING_OK_BUT_NO_FRAME:      return QString("PING_OK_BUT_NO_FRAME");
    case PING_OK_AND_NEW_FRAME:     return QString("PING_OK_AND_NEW_FRAME");
    }
    return QString("UNKNOWN");
}

void MonitorProcess::pingControl()
{
    PingOp *pingOp;
    QString newIp;
    GridReal *gridIpc;
    int ipMatchCnt;
    QList<PingOp *> unusedList;

    mutex.lock();

    // remove the ping data with unused ip
    foreach(pingOp, *pingList)
    {
        ipMatchCnt = 0;
        for(int idx=0; idx<CHANNEL_MAX; idx++)
        {
            gridIpc = &viewProcess->ipc_gridReal[idx];
            if(pingOp->ip == gridIpc->ip)
            {
                ipMatchCnt ++;
            }
        }
        if(ipMatchCnt <= 0)
        {
            unusedList.append(pingOp);
            continue;
        }
    }
    foreach(pingOp, unusedList)
    {
        if(DBG(_DBG_MONITOR_))
        {
            qDebug() << STR_DBG_MONT
                     << QString("Remove %1 from ping list")
                        .arg(pingOp->ip);
        }
        pingOp->finalize();
        pingList->removeOne(pingOp);
        delete(pingOp);
    }

    // add new ip to pingList
    while(newIpList->isEmpty() != true)
    {
        newIp = newIpList->takeFirst();
        pingOp = ptrInPingList(newIp);
        if(pingOp == NULL)
        {
            pingOp = new PingOp(newIp);
            pingList->append(pingOp);
            if(DBG(_DBG_MONITOR_))
            {
                qDebug() << STR_DBG_MONT
                         << QString("Add new %1 to ping list")
                            .arg(newIp);
            }
        }
        else
        {
            if(DBG(_DBG_MONITOR_))
            {
                qDebug() << STR_DBG_MONT
                         << QString("Change %1 in ping list to ping now")
                            .arg(newIp);
            }
        }
        pingOp->timer->setInterval(Config::sys.monitorProcessPoolingTime);  // => ping first
        pingOp->timer->start();
    }

    foreach(pingOp, *pingList)
    {
        // check and tune the ping flow
        if(pingOp->bPingOk)
        {
            // do nothing for pingOp->timer is single shot
        }
        else
        {
            if(pingOp->timer->isActive() == false)
            {
                pingOp->timer->setInterval(Config::sys.monitorProcessRepingTime);
                pingOp->timer->start();
            }
        }
    }

    mutex.unlock();
}
