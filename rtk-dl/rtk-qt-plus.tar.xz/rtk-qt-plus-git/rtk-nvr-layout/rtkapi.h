/**
 * @file rtkapi.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The interface/api to use Realtek library
 */

#ifndef RTKAPI_H
#define RTKAPI_H

#include "define.h"
#include "rtksim.h"
#include <QString>
#include <QPixmap>

#define SLOW_DOWN_OUTPUT_FRAME_RATE     0
#define AUTO_SEARCH_AVAILABLE_CHANNEL   0
#define MAX_INSTANCE 32 // same in rtk_media_if.h

class RtkApi
{
public:
    RtkApi();
    ~RtkApi();
    bool setup();
    void msleep(int msec);
    void finalize();
    QString msgRtkReturn(RtkReturn_e rtkReturn);
    QString dbgStrRtkReturn(int rtkReturn);
    QString dbgStrFrameBufferSize(FrameBufferSize_e size);
#if RTSP_AV
#elif RTSP_GST
    QString dbgStrStream(Stream stream);
#endif

    /*-------------------- qdebug api ----------------*/
    bool qt_rtk_serv_initialize();
    bool qt_rtk_serv_terminate();
    bool qt_rtk_serv_force_terminate();
    bool qt_rtk_disp_get_blank(QString head, int idx, int chIdx, WindowId wndId, bool *enable);
    bool qt_rtk_disp_set_blank(QString head, int idx, int chIdx, bool enable, WindowId wndId);
    bool qt_rtk_disp_set_blank(QString head, QList<int> *idxList, QList<int> *chIdxList,
                               bool enable, QList<WindowId> *wndIdList);
    bool qt_rtk_disp_set_freeze(QString head, int idx, int chIdx, bool enable, WindowId wndId);
    WindowId qt_rtk_disp_create(QString head, int idx, int chIdx,
                             uint x, uint y, uint w, uint h,
                             InputStreamType_e inputType);
    bool qt_rtk_disp_resize(QString head, int idx, int chIdx,
                           WindowId wndId, uint x, uint y, uint w, uint h);
    bool qt_rtk_disp_crop(QString head, int idx, int chIdx,
                         WindowId wndId, uint crop_x, uint crop_y,
                         uint crop_w, uint crop_h);
    bool qt_rtk_disp_swap (QString head, int idx_a, int idx_b, int wndId_a, int wndId_b);
    bool qt_rtk_disp_destroy(QString head, int idx, int chIdx, WindowId wndId);
    bool qt_rtk_disp_set_output(HDMIMode_e hdmiMode, DPMode_e dpMode, RtkReturn_e *rtnValue=NULL);
    bool qt_rtk_disp_get_output(HDMIMode_e *hdmiMode, DPMode_e *dpMode);
    bool qt_rtk_disp_set_outputFrameRate(QString head, int idx, int chIdx, ChannelId channelId, unsigned int fps);
    bool qt_rtk_disp_set_brightness(unsigned int brightness);
    bool qt_rtk_disp_get_brightness(unsigned int *brightness);
    bool qt_rtk_disp_set_contrast(unsigned int contrast);
    bool qt_rtk_disp_get_contrast(unsigned int *contrast);
    bool qt_rtk_disp_set_hue(unsigned int hue);
    bool qt_rtk_disp_get_hue(unsigned int *hue);
    bool qt_rtk_disp_set_saturation(unsigned int saturation);
    bool qt_rtk_disp_get_saturation(unsigned int *saturation);
    bool qt_rtk_disp_set_sharpness(unsigned int sharpness);
    bool qt_rtk_disp_get_sharpness(unsigned int *sharpness);
    bool qt_rtk_disp_set_channel_brightness(QString head, int idx, int chIdx, WindowId wndId, unsigned int brightness);
    bool qt_rtk_disp_get_channel_brightness(QString head, int idx, int chIdx, WindowId wndId, unsigned int *brightness);
    bool qt_rtk_disp_set_channel_contrast(QString head, int idx, int chIdx, WindowId wndId, unsigned int contrast);
    bool qt_rtk_disp_get_channel_contrast(QString head, int idx, int chIdx, WindowId wndId, unsigned int *contrast);
    bool qt_rtk_disp_set_channel_hue(QString head, int idx, int chIdx, WindowId wndId, unsigned int hue);
    bool qt_rtk_disp_get_channel_hue(QString head, int idx, int chIdx, WindowId wndId, unsigned int *hue);
    bool qt_rtk_disp_set_channel_saturation(QString head, int idx, int chIdx, WindowId wndId, unsigned int saturation);
    bool qt_rtk_disp_get_channel_saturation(QString head, int idx, int chIdx, WindowId wndId, unsigned int *saturation);
    bool qt_rtk_disp_set_channel_sharpness(QString head, int idx, int chIdx, WindowId wndId, unsigned int sharpness);
    bool qt_rtk_disp_get_channel_sharpness(QString head, int idx, int chIdx, WindowId wndId, unsigned int *sharpness);
    bool qt_rtk_disp_set_bgcolor(uchar r, uchar g, uchar b, RtkReturn_e *rtnValue=NULL);
    bool qt_rtk_disp_set_videoFB_Resolution(FrameBufferSize_e fbSize, RtkReturn_e *rtnValue=NULL);
    bool qt_rtk_disp_get_videoFB_Resolution(FrameBufferSize_e *fbSize);
    ChannelId qt_rtk_dec_add_channel_video(QString head, int idx, int chIdx);
    bool qt_rtk_dec_set_channel_video (QString head, int idx, int chIdx,
                                       ChannelId channelId, VideoCodec_e vid_codec);
    bool qt_rtk_dec_bind(QString head, int idx, int chIdx, ChannelId channelId, WindowId wndId);
    bool qt_rtk_dec_set_play(QString head, int idx, int chIdx, ChannelState_e newState, ChannelId channelId);
    bool qt_rtk_dec_remove_channel(QString head, int idx, int chIdx, ChannelId channelId);
//    bool qt_rtk_dec_get_params(QString head, int idx, int chIdx, ChannelId channelId, ChannelParams_t *param);
    bool qt_rtk_ipc_debug_getInfo(QString head, int idx, int chIdx, ChannelId channelId,
                                  unsigned long long * bufferWriteCnt, unsigned long long * sizeZeroCnt,
                                  unsigned long long * connectErrCnt, unsigned long long * writeErrCnt);
    bool qt_rtk_ipc_debug_getInfo(ChannelId channelId,
                                  unsigned long long * bufferWriteCnt, unsigned long long * sizeZeroCnt,
                                  unsigned long long * connectErrCnt, unsigned long long * writeErrCnt, bool ifMsg=false);
    bool qt_rtk_ipc_debug_reset(QString head, int idx, int chIdx, ChannelId channelId);
    bool qt_rtk_ipc_debug_reset(ChannelId channelId);

    bool qt_rtk_player_initialize();
#if AUTO_SEARCH_AVAILABLE_CHANNEL
    ChannelId qt_rtk_player_get_available_channel();
#endif
    ChannelId qt_rtk_player_add_channel_video(QString head, int idx, int chIdx);
    ChannelId qt_rtk_player_add_channel_av(QString head, int idx, int chIdx);
#if 0
    bool qt_rtk_player_set_channel_video (QString head, int idx, int chIdx,
                                       ChannelId channelId, VideoCodec_e vid_codec);
#endif
    bool qt_rtk_player_open(QString head, int idx, int chIdx, ChannelId channelId, QString absFilePath);
    bool qt_rtk_player_bind(QString head, int idx, int chIdx, ChannelId channelId, WindowId wndId,
                            int x, int y, int width, int height);
    bool qt_rtk_player_set_play(QString head, int idx, int chIdx, ChannelState_e newState, ChannelId channelId);
    bool qt_rtk_player_remove_channel(QString head, int idx, int chIdx, ChannelId channelId);
    bool qt_rtk_player_start_audio(QString head, int idx, int chIdx, ChannelId channelId);
    bool qt_rtk_player_stop_audio(QString head, int idx, int chIdx, ChannelId channelId);
    bool qt_rtk_player_set_mute(QString head, int idx, int chIdx, ChannelId channelId, bool enable);
    bool qt_rtk_player_get_volume(QString head, int idx, int chIdx, ChannelId channelId, double *volume);
    bool qt_rtk_player_set_volume(QString head, int idx, int chIdx, ChannelId channelId, double volume);

#if RTSP_AV
    bool qt_rtk_rtsp_av_initialize();
    bool qt_rtk_rtsp_av_terminate();
    RtspClientId qt_rtk_rtsp_av_client_new(QString head, int idx, int chIdx, QString rtspCmd);
    void qt_rtk_rtsp_av_client_free(QString head, int idx, int chIdx, RtspClientId cid);
    void qt_rtk_rtsp_av_player_play(QString head, int idx, int chIdx, RtspClientId cid, int v_ch, int a_ch);
    void qt_rtk_rtsp_av_player_stop(QString head, int idx, int chIdx, RtspClientId cid);
    void qt_rtk_rtsp_av_rec_set_info(QString head, int idx, int chIdx, RtspClientId cid, int v_ch, int a_ch,
                                  int wnd_x, int wnd_y, int wnd_width, int wnd_height);
    void qt_rtk_rtsp_av_rec_start(QString head, int idx, int chIdx, RtspClientId cid, QString absDirPath, int duration);
    void qt_rtk_rtsp_av_rec_stop(QString head, int idx, int chIdx, RtspClientId cid);
    void qt_rtk_rtsp_av_rec_change(QString head, int idx, int chIdx, RtspClientId cid, QString absDirPath, int duration);
#elif RTSP_GST
    void qt_rtsp_client_set_latency (QString head, int idx, int chIdx, RtspClient* client, uint latency);
    RtspPlayer *qt_rtsp_player_new (QString head, int idx, int chIdx, QString rtspCmd, int ch);
    void qt_rtsp_player_free (QString head, int idx, int chIdx, RtspPlayer* rtspPlayer);
    void qt_rtsp_player_play (QString head, int idx, int chIdx, RtspPlayer* rtspPlayer);
    void qt_rtsp_player_stop (QString head, int idx, int chIdx, RtspPlayer* rtspPlayer);
    void qt_rtsp_player_set_stream (QString head, int idx, int chIdx, RtspPlayer *rtspPlayer, Stream stream);
    void qt_rtsp_player_rec_start (QString head, int idx, int chIdx, RtspPlayer* rtspPlayer, QString absDirPath, uint duration);
    void qt_rtsp_player_rec_stop (QString head, int idx, int chIdx, RtspPlayer* rtspPlayer);
    void qt_rtsp_player_rec_change (QString head, int idx, int chIdx, RtspPlayer* rtspPlayer, QString absDirPath, uint duration);
#endif
    /*-------------------- qdebug api end-------------*/

    bool apply_view_ipc();
    bool apply_view_file();
    bool ipcStart(int idx);
    bool ipcStop(int idx, bool bSeamless);
    void ipcPlayStart(int idx);
    void ipcRecStart(int idx, QString absDirPath, uint duration);
    void ipcRecChange(int idx, QString absDirPath, uint duration);
    void ipcRecStop(int idx);
    bool fileStart(int idx, QString absFilePath);
    bool fileStop(int idx, bool bSeamless);
    bool ipcSwapWndId(int idx_a, int idx_b);
    bool fileSwapWndId(int idx_a, int idx_b);
    bool ipcGetSourceRect(int idx, QRect *rect);
    bool fileGetSourceRect(int idx, QRect *rect);
    bool ipcGetSnapshot(int idx, QPixmap *pixmap);
    bool fileGetSnapshot(int idx, QPixmap *pixmap);
    bool fileGetPlayTime(int idx, uint64_t *pCurrent);
    bool fileSetPlayTime(int idx, int time);
    bool fileSetSpeed(int idx, double speed);

private:
#if AUTO_SEARCH_AVAILABLE_CHANNEL
    bool availableCh[MAX_INSTANCE];
#endif

    bool getSourceRect(QString head, int idx, int chIdx, int wndId, QRect *rect);
    bool getSnapshot(QString head, int idx, int chIdx, int widthFB, int heightFB, int wndId, QPixmap *pixmapOSD);
    void copySnapshot(bool keepOSD, int width, int height, QImage *image, uchar *data);
};

extern RtkApi *rtkApi;

#endif // RTKAPI_H
