/**
 * @file monitorprocess.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2018
 * @brief Do IPC connection checking, storage managment, and system recovery if necessary.
 */

#ifndef MONITORPROCESS_H
#define MONITORPROCESS_H

#include <QTimer>
#include <QThread>
#include <QMutex>
#include <QProcess>
#include "viewinfo.h"
#include "gridreal.h"
#include "config.h"

class PingOp : public QObject
{
    Q_OBJECT
public:
    IPC_STATE_E state;
    bool    bPingOk;
    QString ip;
    QTimer *timer;
    QProcess *proc;

    PingOp(QString ip);
    ~PingOp();
    void finalize();
    bool isValidIpv4Ip();

private slots:
    void pingStart();
    void pingOperation(int rtnCode);
};

class MonitorProcess : public QThread
{
    Q_OBJECT

public:
    QMutex mutex;

    MonitorProcess();
    ~MonitorProcess();

    void setStart();
    void run();
    void setStop();
    void finalize();

private:
    bool bRun;
    QTimer *pingTimer;
    QList<QString> *newIpList;
    QList<PingOp *> *pingList;

    bool ifInPingList(QString ip);
    PingOp *ptrInPingList(QString ip);
    IPC_STATE_E getNewState(int chIdx, GridReal* gridIpc);
    void updateState(int idx, int chIdx, GridReal* gridIpc, IPC_STATE_E newState);
    QString strState(IPC_STATE_E state);

public slots:

private slots:
    void pingControl();
};

extern MonitorProcess *monitorProcess;

#endif // MONITORPROCESS_H
