/**
 * @file network.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page to set network
 */

#ifndef NETWORK_H
#define NETWORK_H

#include <QWidget>
#include "rtablayer.h"

namespace Ui {
class Network;
}

class Network : public QWidget
{
    Q_OBJECT

public:
    explicit Network(QWidget *parent = 0);
    ~Network();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setParentAbsoluteOffset(int x, int y);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);

private:
    Ui::Network *ui;
    RTabLayer *tlNetwork, *tlConnect;
    int parent_absolute_offset_x, parent_absolute_offset_y;

    void initConnect();

private slots:
    void showEvent(QShowEvent *);
    void setConnectStatic(bool);
    void setConnectDhcp(bool);
    void setConnectPppoe(bool);
    void on_cbNetMode_currentIndexChanged(int index);
};

#endif // NETWORK_H
