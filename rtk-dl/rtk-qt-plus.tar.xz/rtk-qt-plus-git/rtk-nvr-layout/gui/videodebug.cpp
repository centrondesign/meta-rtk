/**
 * @file videodebug.cpp
 * @author Realtek Semiconductor Corp.
 * @date Dec 2018
 * @brief The widget page to do video debug operation
 */

#include <QGraphicsDropShadowEffect>
#include "videodebug.h"
#include "ui_videodebug.h"
#include "mainwidget.h"

VideoDebug::VideoDebug(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VideoDebug)
{
    ui->setupUi(this);
    keyboard = NULL;
    keypad = NULL;
    ui->lTitle->setStyleSheet("background-color: rgb(25, 32, 36);"
                              "color: rgb(179, 179, 179);"
                              "font: bold 28px \"Arial\";");
    ui->fCtrl->setStyleSheet("background-color: rgba(25, 32, 36, 50);"
                             "color: rgb(179, 179, 179);"
                             "font: bold 28px \"Arial\";");
    ui->tbBack->setIcons(QIcon(":/images/playback_back_normal.png"),
                         QIcon(":/images/playback_back_hover.png"),
                         QIcon(":/images/playback_back_normal.png"),
                         QIcon(":/images/playback_back_hover.png"),
                         false);
    ui->tbBack->setStyleSheet("QToolButton{"
                                    "border:0px;"    // transparent for Linux
                               "}"
                               "QToolButton:hover{"
                                    "border:0px;"    // transparent for Linux
                               "}");
    connect(ui->tbBack, SIGNAL(clicked(bool)), this, SLOT(close_clicked(bool)));
}

VideoDebug::~VideoDebug()
{
    delete ui;
}

void VideoDebug::setup()
{
//    ui->fCtrl->setVisible(false);
}

void VideoDebug::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);
}

void VideoDebug::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
    ui->lTitle->setGeometry(0, 0, 320/*wOptionWidth*/, 60/*titleHeight*/);
    ui->tbBack->raise();
    ui->tbBack->setGeometry(ui->lTitle->width() - ui->tbBack->width() - 3, 3,
                            ui->tbBack->width(),ui->tbBack->height());
}

void VideoDebug::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    this->keyboard = (QWidget *)keyboard;
    this->keypad = (QWidget *)keypad;
}

void VideoDebug::showEvent(QShowEvent *e)
{
    Q_UNUSED(e);
}

bool VideoDebug::eventFilter(QObject *o, QEvent *e)
{
//    qDebug() << __func__ << o << e;
#if 0
    if(o == ui->wTouchBoard &&
       e->type() == QEvent::MouseButtonPress)
    {
        const QMouseEvent* const me = static_cast<const QMouseEvent*>( e );
        if(me->buttons() & Qt::LeftButton)
        {
            double newMSec = playViewStartMSec +
                    (0.0 + me->pos().x())/ui->wTouchBoard->width() * playViewPeriodMSec;
            resetUpdateStartTime(newMSec);
            play_control(newMSec, true);
        }
    }
    return QObject::eventFilter(o, e);
#endif
}

void VideoDebug::mousePressEvent(QMouseEvent *e)
{
//    qDebug() << __func__ << e;
    QWidget::mousePressEvent(e);
    QWidget *wdgt;
    int margin = 15; //pixels
    int x, y;

    if( e->button() == Qt::RightButton )
    {
//        qDebug() << "right";
        //emit mouseRightPressed();
#if 0
        if (ui->widgetLogin->isVisible() ||
            ui->widgetPlayback->isVisible() ||
            ui->widgetVideoDebug->isVisible())
        {
            return;
        }
#endif
        if (keyboard != NULL)
        {
            if (keyboard->isVisible())
                return;
        }
        if (keypad != NULL)
        {
            if (keypad->isVisible())
                return;
        }
        wdgt = getClickedWidget(e);
        if (wdgt != NULL)
        {
            return;
        }
#if 0
        wdgt = getVisibleWidget(e);
        if (wdgt != NULL)
        {
            wdgt->setHidden(true);
        }
#endif
        {
            wdgt = ui->fCtrl;

            // calculate x, y for widget
            x = (e->x() + wdgt->width() - margin < Config::sys.width) ? e->x() : Config::sys.width - wdgt->width();
            y = (e->y() + wdgt->height() - margin < Config::sys.height) ? e->y() : Config::sys.height - wdgt->height();
            // tune margin for x, y
            x = (Config::sys.width - e->x() < wdgt->width() - margin * 2) ? x+margin : x-margin;
            y = (Config::sys.height - e->y() < wdgt->height() - margin * 2) ? y+margin : y-margin;
            wdgt->setGeometry(x, y, wdgt->width(), wdgt->height());

            if (wdgt->isHidden())
            {
                wdgt->setVisible(true);
                wdgt->raise();
            }
//            qDebug() << QString().sprintf("x=%d, y=%d, w=%d, h=%d", x, y, widget->width(), widget->height());
        }
    }
    else if( e->button() == Qt::LeftButton )
    {
//        qDebug() << "left";
        //emit mouseLeftPressed();
        if (dialog->isVisible())
        {
            return;
        }
        wdgt = getClickedWidget(e);
        if (wdgt != NULL)
        {
            return;
        }
        else
        {
#if 0
            showIdxWidgetOnly(NULL);
#else
            ui->fCtrl->setVisible(false);
#endif
        }
    }
}

QWidget* VideoDebug::getVisibleWidget(QMouseEvent *e)
{
    Q_UNUSED(e);
    QWidget *wdgt;
    QList<QWidget *>wList = {ui->fCtrl};
    foreach (wdgt, wList)
    {
        if(wdgt->isVisible())
        {
            return wdgt;
        }
    }
    return NULL;
}

QWidget* VideoDebug::getClickedWidget(QMouseEvent *e)
{
    int x, y;
    QWidget *wdgt;
    QList<QWidget *>wList = {ui->fCtrl};
    foreach (wdgt, wList)
    {
        if(wdgt->isVisible() != true)
            continue;
        x = e->localPos().x(); // localPos, windowPos, screenPos
        y = e->localPos().y();
//        qDebug() << QString("x=%1, widget.x=%2").arg(x).arg(widget->x());
//        qDebug() << QString("y=%1, widget.y=%2").arg(y).arg(widget->y());
        if(x>wdgt->x() && x<wdgt->x()+wdgt->width() &&
           y>wdgt->y() && y<wdgt->y()+wdgt->height())
        {
            return wdgt;
        }
    }
    return NULL;
}

void VideoDebug::close_clicked(bool)
{
#if 0
    if(ui->tbPlayCtrl->getActived())
    {
        bIfPlayBefore = true;
        ui->tbPlayCtrl->setActive(false, false);
        playCtrl_action(false);
    }
    else
    {
        if(Config::sys.seamless)
            playCtrl_action(false);
    }
#endif
    viewProcess->file_setViewMode(ViewProcess::ViewMode_Hide,
                                  viewProcess->get_file_grid_num());
    viewProcess->ipc_setViewMode(ViewProcess::ViewMode_Grid,
                                 viewProcess->get_ipc_grid_num());
#if 0
    if(Config::sys.playbackBlankEnable)
    {
        bBlankHideWhole = true;
        blankHideTimer->start();
        ui->wBlank->raise();
        ui->wBlank->setVisible(true);
    }
    else
    {
        this->hide();
    }
#endif
    this->hide();
}

void VideoDebug::file_open_clicked(bool)
{
#if 0
    ui->tbFile->setStyleSheet(tbFileStyleSheet_select);
    btnFileChannelIdx_select();
    ui->fFile->setVisible(true);
    ui->fFile->raise();
#endif
}

void VideoDebug::file_close_clicked(bool)
{
#if 0
    ui->tbFile->setStyleSheet(tbFileStyleSheet_normal);
    ui->fFile->setVisible(false);
#endif
}
