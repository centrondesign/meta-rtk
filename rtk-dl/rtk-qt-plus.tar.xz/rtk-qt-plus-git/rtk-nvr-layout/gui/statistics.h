/**
 * @file statistics.h
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The widget page to do statistics report
 */

#ifndef STATISTICS_H
#define STATISTICS_H

#include <QWidget>
#include <QLabel>
#include <QTimer>
#include "rtablayer.h"

namespace Ui {
class Statistics;
}

class Statistics : public QWidget
{
    Q_OBJECT

public:
    explicit Statistics(QWidget *parent = 0);
    ~Statistics();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setParentAbsoluteOffset(int x, int y);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);

private:
    Ui::Statistics *ui;
    RTabLayer *tlStatistics;
    int parent_absolute_offset_x, parent_absolute_offset_y;
    QList<QLabel*> *lbDispList, *lbSuppList;
    QList<QToolButton*> *tbResetDispList, *tbResetSuppList;
    QTimer *refreshTimer;
    QObject *_rcvObject;

    void initValue(bool fromStatus);

private slots:
    void refresh_interval_changed(int);
    void refresh_action(bool);
    void btn_disp_reset_clicked(bool);
    void btn_supp_reset_clicked(bool);
    void getDispStatistics();
    void getSuppStatistics();

protected:
//    void showEvent(QShowEvent *);
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // STATISTICS_H
