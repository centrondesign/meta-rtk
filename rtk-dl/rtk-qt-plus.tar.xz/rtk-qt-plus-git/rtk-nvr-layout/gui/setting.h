/**
 * @file setting.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page to do setting
 */

#ifndef SETTING_H
#define SETTING_H

#include <QWidget>
#include <QToolButton>
#include "network.h"
#include "ipc.h"
#include "storage.h"
#include "system.h"

namespace Ui {
class Setting;
}

class Setting : public QWidget
{
    Q_OBJECT

public:
    Network *network;
    Ipc *ipc;
    Storage *storage;
    System *system;

    explicit Setting(QWidget *parent = 0);
    ~Setting();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);

private:
    Ui::Setting *ui;

    void setOption(QToolButton *btn);

private slots:
    void setNetwork(bool);
    void setIPC(bool);
    void setStorage(bool);
    void setSystem(bool);
};

#endif // SETTING_H
