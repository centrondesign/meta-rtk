/**
 * @file storage.cpp
 * @author Realtek Semiconductor Corp.
 * @date Oct 2017
 * @brief The widget page to do storage
 */

#include "storage.h"
#include "ui_storage.h"
#include "mainwidget.h"

Storage::Storage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Storage)
{
    ui->setupUi(this);

    QList<QToolButton *> btnLayer1 = {ui->tbManage, ui->tbExport};
    tlStorage = new RTabLayer(this);
    tlStorage->init(btnLayer1, ui->stkLayer1, TABLAYER_LAYER_1);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;

    ui->lStorage->setStyleSheet(STYLESHEET_TITLE_2);
    ui->pgManagement->installEventFilter(this);
    ui->pgExport->installEventFilter(this);

    this->lChannelList = new QList<QLabel*>();
    this->lStatusList = new QList<QLabel*>();
    this->checkBoxList = new QList<RCheckBox*>();

    {   // Connect table initialization
        QLabel *lb;
        RCheckBox *check;
        int i;
        QStringList horHeadList, verHeadList;

        ui->tableStorage->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);

        // Storage header
        for(i=0; i<CHANNEL_MAX; i++)
        {
            verHeadList.append("Channel " + HLS_SUBDIR(i));
        }
        horHeadList << "Channel" << "Status" << "Set";
        ui->tableStorage->setColumnCount(horHeadList.count());
        ui->tableStorage->setRowCount(verHeadList.count());
        ui->tableStorage->setHorizontalHeaderLabels(horHeadList);
        ui->tableStorage->horizontalHeader()->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE);
        ui->tableStorage->horizontalHeader()->setFixedHeight(TABLE_ITEM_HEIGHT);
        ui->tableStorage->verticalHeader()->setVisible(false);

        ui->tableStorage->setColumnWidth(0, 150);
        ui->tableStorage->setColumnWidth(1, 300);
        ui->tableStorage->setColumnWidth(2, 160);
        for(i=0; i<ui->tableStorage->rowCount(); i++)
        {
            ui->tableStorage->setRowHeight(i, TABLE_ITEM_HEIGHT);
        }

        // Storage item
        for(i=0; i<CHANNEL_MAX; i++)
        {
            lb = new QLabel();
            lb->setAlignment(Qt::AlignCenter | Qt::AlignVCenter);
            lb->setText(verHeadList.at(i));
            this->lChannelList->append(lb);
            ui->tableStorage->setCellWidget(i, 0, (QWidget*)lb);

            lb = new QLabel();
            lb->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            lb->setText("Disconnect");
            this->lStatusList->append(lb);
            ui->tableStorage->setCellWidget(i, 1, (QWidget*)lb);

            check = new RCheckBox();
            check->setText("Store");
            this->checkBoxList->append(check);
            ui->tableStorage->setCellWidget(i, 2, (QWidget*)check);
        }
    }

    connect(ui->tbManageSet, SIGNAL(clicked(bool)), this, SLOT(manage_set_clicked(bool)));
}

Storage::~Storage()
{
    foreach(RCheckBox *check, *checkBoxList)
    {
        delete check;
    }
    delete checkBoxList;
    foreach(QLabel *lb, *lStatusList)
    {
        delete lb;
    }
    delete lStatusList;
    foreach(QLabel *lb, *lChannelList)
    {
        delete lb;
    }
    delete lChannelList;
    delete tlStorage;
    delete ui;
}

void Storage::setup()
{
    labelList->append({ui->lDirectory, ui->lSegmentTime, ui->lSegmentTimeUnit});
    editList->append({ui->leDirectory, ui->leSegmentTime});
    for (int i=0; i<Config::sys.ipcChannelMax; i++)
    {
        labelList->append(this->lChannelList->at(i));
        labelList->append(this->lStatusList->at(i));
        checkList->append(this->checkBoxList->at(i));
    }
    actionList->append({ui->tbManageSet});

    ui->leSegmentTime->setValueRange(ui->lSegmentTime, 1, Config::setting.segmentTimeMax, 0);
    tlStorage->clickTabIndex(0);

    for (int i=Config::sys.ipcChannelMax; i<CHANNEL_MAX; i++)
    {
        ui->tableStorage->setRowHidden(i, true);
    }

    initValue();
}

void Storage::initValue()
{
    if(ui->pgManagement->isVisible())
    {
        ui->leDirectory->setText(Config::absoluteHlsDirPath);
        ui->leSegmentTime->setText((double)Config::setting.segmentTime);
        for (int chIdx=0; chIdx<Config::sys.ipcChannelMax; chIdx++)
        {
            checkBoxList->at(chIdx)->setChecked(Config::ipc.ch[chIdx].ifStorage);
        }
    }
}

void Storage::setGeometry(const QRect &rect)
{
//    qDebug() << __func__ << "(const QRect &rect)";
    QWidget::setGeometry(rect);

    int tab_x_offset = parent_absolute_offset_x+rect.x()+ui->stkLayer1->x();
    int tab_y_offset = parent_absolute_offset_y+rect.y()+ui->stkLayer1->y();
    ui->leDirectory->setParentAbsoluteOffset(tab_x_offset,
                                             tab_y_offset);
    ui->leSegmentTime->setParentAbsoluteOffset(tab_x_offset,
                                               tab_y_offset);
}

void Storage::setGeometry(int x, int y, int w, int h)
{
//    qDebug() << __func__ << "(int x, int y, int w, int h)";
    this->setGeometry(QRect(x, y, w, h));
}

void Storage::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void Storage::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    ui->leDirectory->installEventFilter(keyboard);
    ui->leSegmentTime->installEventFilter(keypad);
}

//void Storage::showEvent(QShowEvent *)
//{
//    initValue();
//}

bool Storage::eventFilter(QObject *o, QEvent *e)
{
    if(e->type() == QEvent::Show)
    {
        if(o==ui->pgManagement ||
           o==ui->pgExport)
        {
            initValue();
        }
    }
    return QObject::eventFilter(o, e);
}

void Storage::doIdxRec(int idx, bool doRec)
{
    int chIdx;
    qDebug() << __func__ << idx << doRec;
    if (idx < 0 || idx >= CHANNEL_MAX)
        return;
    if (doRec)
    {
        if (!hlsProcess->checkAndMkDir(Config::absoluteHlsDirPath))
        {
            return;
        }
    }
    chIdx = viewProcess->ipc_gridReal[idx].channelIndex;
    Config::ipc.ch[chIdx].ifStorage = doRec;
    Config::saveDefaultProfile();

    processRec(idx, false);
}

void Storage::manage_set_clicked(bool)
{
    int chIdx, i;
    bool bNeedDir, bNewDir;
    QString absDirPath;

    bNeedDir = false;
    absDirPath= Config::getAbsDirPath(ui->leDirectory->text());
    absDirPath += absDirPath.endsWith("/") ? "" : "/";
    for(chIdx=0; chIdx<Config::sys.ipcChannelMax; chIdx++)
    {
        if (checkBoxList->at(chIdx)->isChecked() &&
            Config::ipc.ch[chIdx].ifConnect)
        {
            bNeedDir = true;
        }
    }
    if(bNeedDir)
    {
        if (!hlsProcess->checkAndMkDir(absDirPath))
        {
            return;
        }
    }
    bNewDir = (Config::absoluteHlsDirPath.trimmed() != absDirPath.trimmed());

    //TBD: if dirpath changed, all records in hlsprocess need to restart
    //TBD: stop plyaback(file frame) first ??
    // if input time < 0 => keep recording
    // else stop current and restart

    QString str;
    QList<QString> msgList;
    if(ui->leSegmentTime->isTextValid(&str) != true)
        if(str.length()>0)
            msgList.append(str);
    if(msgList.count()>0)
    {
        dialog->showError(msgList.join("\r\n"));
        return;
    }
    Config::setting.segmentTime = ui->leSegmentTime->getValue();
    for(chIdx=0; chIdx<Config::sys.ipcChannelMax; chIdx++)
    {
        Config::ipc.ch[chIdx].segmentTime = ui->leSegmentTime->getValue();
    }
    viewProcess->update_ipc_recSegment();

    Config::absoluteHlsDirPath = absDirPath;
    for(chIdx=0; chIdx<Config::sys.ipcChannelMax; chIdx++)
    {
        Config::ipc.ch[chIdx].ifStorage = checkBoxList->at(chIdx)->isChecked();
    }
    Config::saveDefaultProfile();

    for(i=0; i<Config::sys.ipcChannelMax; i++)
    {
        processRec(i, bNewDir);
    }
    dialog->showInfo(STR_SETTING_APPLY);
}


void Storage::processRec(int idx, bool bNewDir)
{
    int chIdx = viewProcess->ipc_gridReal[idx].channelIndex;
    IPC_CH_S   *ipc_ch = &Config::ipc.ch[chIdx];

    if (ipc_ch->ifStorage)
    {
        if (viewProcess->ipc_gridReal[idx].bNeedRecStart ||
            viewProcess->ipc_gridReal[idx].bAlreadyRec)
        {
            if (! ipc_ch->ifConnect)
            {
                viewProcess->ipc_rec_stop(idx);
            }
            else
            {
                if(bNewDir && viewProcess->ipc_gridReal[idx].bAlreadyRec)
                {
                    // if bNewDir => change dir of i
                    //TBD: if dirpath changed, stop and restart the recording ipc
                }
            }
        }
        else
        {
            if (ipc_ch->ifConnect)
            {
                viewProcess->ipc_rec_start(idx);
            }
        }
    }
    else
    {
        if (viewProcess->ipc_gridReal[idx].bNeedRecStart ||
            viewProcess->ipc_gridReal[idx].bAlreadyRec)
        {
            viewProcess->ipc_rec_stop(idx);
        }
        else
        {
        }
    }
}
