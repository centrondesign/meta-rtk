/**
 * @file mainwidget.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The main background widget page of GUI
 */

#include "mainwidget.h"
#include "ui_mainwidget.h"
#include <QListView>
#include <QFrame>

MainWidget *mainWidget = NULL;
MainMenu *mainMenu = NULL;
MainLogin *mainLogin = NULL;
IpcAdd *ipcAdd = NULL;
IpcConnect *ipcConnect = NULL;
IpcDetect *ipcDetect = NULL;
Setting *setting = NULL;
Network *network = NULL;
Ipc *ipc = NULL;
Storage *setStorage = NULL;
System *setSystem = NULL;
Info *info = NULL;
Alarm *infoAlarm = NULL;
Statistics *infoStatistics = NULL;
Playback *playback = NULL;
VideoDebug *videoDebug = NULL;
FaceDetect *faceDetect = NULL;
Keypad *keypad = NULL;
Keyboard *keyboard = NULL;
RDialog *dialog = NULL;

QList<QLabel*> *labelList;
QList<QLineEdit*> *editList;
QList<QLineEdit*> *readOnlyList;
QList<QComboBox*> *optionList;
QList<RCheckBox*> *checkList;
QList<QToolButton*> *actionList;

MainWidget::MainWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWidget)
{
    ui->setupUi(this);

    // [20180807:Brian] enable 3840x2160
    this->setGeometry(0, 0, Config::sys.width, Config::sys.height);
    ui->wBg->setGeometry(0, 0, Config::sys.width, Config::sys.height);
    bootTimer = NULL;

    mainWidget = this;
    mainLogin = ui->widgetLogin;
    mainMenu = ui->widgetMenu;
    ipcAdd = ui->widgetIpcAdd;
    ipcConnect = ipcAdd->ipcConnect;
    ipcDetect = ipcAdd->ipcDetect;
    setting = ui->widgetSetting;
    network = setting->network;
    ipc = setting->ipc;
    setStorage = setting->storage;
    setSystem = setting->system;
    info = ui->widgetInfo;
    infoAlarm = info->alarm;
    infoStatistics = info->statistics;
    playback = ui->widgetPlayback;
    videoDebug = ui->widgetVideoDebug;
    faceDetect = ui->widgetFaceDetect;
    keypad = ui->widgetKeypad;
    keyboard = ui->widgetKeyboard;
    dialog = ui->widgetDialog;
    widgetList << mainLogin;
    widgetList << mainMenu;
    widgetList << ipcAdd;
    widgetList << setting;
    widgetList << info;
    widgetList << playback;
    widgetList << videoDebug;
    widgetList << keypad;
    widgetList << keyboard;
    widgetList << dialog;

    labelList = new QList<QLabel*>();
    editList = new QList<QLineEdit*>();
    readOnlyList = new QList<QLineEdit*>();
    optionList = new QList<QComboBox*>();
    checkList = new QList<RCheckBox*>();
    actionList = new QList<QToolButton*>();

    mainLogin->installEventFilterForKeyboard(keyboard);
    playback->installEventFilterForKeyboard(keyboard, keypad);
    videoDebug->installEventFilterForKeyboard(keyboard, keypad);
    network->installEventFilterForKeyboard(keyboard, keypad);
    ipc->installEventFilterForKeyboard(keyboard, keypad);
    setStorage->installEventFilterForKeyboard(keyboard, keypad);
    setting->system->installEventFilterForKeyboard(keyboard, keypad);
    ipcConnect->installEventFilterForKeyboard(keyboard, keypad);
    ipcDetect->installEventFilterForKeyboard(keyboard, keypad);
    faceDetect->installEventFilterForKeyboard(keyboard, keypad);

    this->setWindowOpacity(1);
#if QT_ENV_ONLY == 1
    this->setAttribute(Qt::WA_TranslucentBackground);
    this->setWindowFlags(Qt::FramelessWindowHint);
#else
    if (Config::sys.isWayland)
    {
        this->setStyleSheet("background:transparent;");
    }
    else
    {
        this->setAttribute(Qt::WA_TranslucentBackground);
    }
    this->setWindowFlags(Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint);
#endif
    /*
    QPalette pal = palette();
    pal.setColor(QPalette::Background, QColor(0x00,0xff,0x00,0x00));
    this->setPalette(pal);
    */

    ui->widgetMenu->setGeometry(710, 226, 490, 686);
    ui->widgetLogin->setGeometry(710, 310, 490, 460);
    ui->widgetKeypad->setGeometry(550, 0, 315, 225);
    ui->widgetKeyboard->setGeometry(550, 0, 715, 270);
    ui->widgetDialog->setGeometry(0, 0, Config::sys.width, Config::sys.height);
    ui->widgetIpcAdd->setGeometry(350, 136, 1220, 808);
    ui->widgetSetting->setGeometry(350, 136, 1220, 808);
    ui->widgetInfo->setGeometry(350, 136, 1220, 808);
    ui->widgetPlayback->setGeometry(0, 0, Config::sys.width, Config::sys.height);
    ui->widgetVideoDebug->setGeometry(0, 0, Config::sys.width, Config::sys.height);
    ui->widgetFaceDetect->setGeometry(785, 740, 350, 50);

    faceDetect->setVisible(false);
}

MainWidget::~MainWidget()
{
    if(bootTimer != NULL)
    {
        bootTimer->stop();
        delete bootTimer;
    }
    for(int i=0; i<CHANNEL_MAX; i++)
    {
        delete ipcFrame[i];
    }
    delete actionList;
    delete checkList;
    delete optionList;
    delete readOnlyList;
    delete editList;
    delete labelList;
    delete ui;
}

bool MainWidget::setup()
{
    bool bOutOfRange;
    for(int i=0; i<CHANNEL_MAX; i++)
    {
        bOutOfRange = (i < Config::sys.ipcChannelMax);
        ipcFrame[i] = new RFrame(this, true, true, true, false, i);
        ipcFrame[i]->setGeometry(QRect(0,0,0,0));
        ipcFrame[i]->setTagVisible(bOutOfRange);
        ipcFrame[i]->setBtnRecVisible(bOutOfRange);
        ipcFrame[i]->setBtnVoiceVisible(false);

        ipcFrame[i]->setFrameShape(QFrame::Box);
        ipcFrame[i]->setFrameShadow(QFrame::Plain);
        ipcFrame[i]->setLineWidth(0);

        ipcFrame[i]->setChText(HLS_SUBDIR(i));
        ipcFrame[i]->prepareStyleSheet();

        ipcFrame[i]->setGridReal(&viewProcess->ipc_gridReal[i]);
    }
    for(int i=widgetList.count()-1; i>=0; i--)
    {
        widgetList.at(i)->raise();
    }

    if(rtkApi->setup() != true)
    {
        return false;
    }
    playback->setup();
    videoDebug->setup();
    faceDetect->setup();
    mainMenu->setup();
    if (Config::sys.autoLogin)
    {
        showIdxWidgetOnly(mainMenu);
    }
    else
    {
        showIdxWidgetOnly(mainLogin);
    }

    setting->setup();
    info->setup();
    ipcAdd->setup();
    ipc->setup();
    setStorage->setup();

    setComponentStyleSheet();
#if QT_ENV_ONLY == 1
#if RTSP_AV
#elif RTSP_GST
    rtkSim->setStart();
#endif
#endif
    hlsProcess->setStart();
    viewProcess->setStart();
    if(Config::sys.monitorProcessEnable)
    {
        monitorProcess->setStart();
    }
    if(Config::sys.onvifEnable)
    {
        onvifProcess->setStart();
    }
    if(Config::sys.bootupIpcConnect)
    {
        bootTimer = new QTimer(this);
        bootTimer->setSingleShot(true);
        connect(bootTimer, SIGNAL(timeout()), this, SLOT(boot_applay()));
        bootTimer->start(3000);
    }
    return true;
}

void MainWidget::finalize()
{
    if(DBG(_DBG_RTKAPI_))
        qDebug() << "MainWidget::finalize()";
    onvifProcess->setStop();
    viewProcess->setStop();
    monitorProcess->setStop();
    hlsProcess->setStop();
#if QT_ENV_ONLY == 1
#if RTSP_AV
#elif RTSP_GST
    rtkSim->setStop();
#endif
#endif
//    rtkApi->setStop();

    onvifProcess->finalize();
    viewProcess->finalize();
    monitorProcess->finalize();
    hlsProcess->finalize();
#if QT_ENV_ONLY == 1
#if RTSP_AV
#elif RTSP_GST
    rtkSim->finalize();
#endif
#endif
    rtkApi->finalize();
}

void MainWidget::setComponentStyleSheet()
{
    int i;
    for (i=0; i<labelList->count(); i++)
    {
        labelList->at(i)->setStyleSheet("color: rgb(102, 109, 109);"
                                        "border:0px;"
                                        "font: 20px \"Arial\";"
                                        "padding:2px;");
    }
    for (i=0; i<editList->count(); i++)
    {
        QLineEdit *le = editList->at(i);
        le->setFrame(false);
        le->setStyleSheet("color: rgb(255, 255, 255);"
                          "border:0px;"
                          "background-color: rgb(69, 77, 77);"
                          "font: bold 20px \"Arial Black\";");
        QMargins margin = le->textMargins();
        le->setTextMargins(margin.left()+5, margin.top(), margin.right()+5, margin.bottom());
    }
    for (i=0; i<readOnlyList->count(); i++)
    {
        readOnlyList->at(i)->setFrame(false);
        readOnlyList->at(i)->setReadOnly(true);
        readOnlyList->at(i)->setStyleSheet("color: rgb(255, 255, 255);"
                                           "border:0px;"
                                           "font: bold 20px \"Arial Black\";");
    }
#if 0
    for (i=0; i<optionList->count(); i++)
    {

        optionList->at(i)->setMaxVisibleItems(optionList->at(i)->count());
#if 0
        optionList->at(i)->setStyleSheet(QString(
                                             "background-color: rgb(20, 25, 28);"
                                             "font: bold 20px \"Arial Black\";"
                                             "color: rgb(169, 204, 135);"
                                             ));
#else
        optionList->at(i)->setView(new QListView());    // before setStyleSheet()
        optionList->at(i)->setStyleSheet(
                                    QString(
                                    "QComboBox{"
                                        "%1"
                                        "%2"
                                        "%3"
                                        "%4"
                                        "}"
                                    "QComboBox QAbstractItemView::item {"
                                        "min-height: 30px; min-width: 60px;"
                                        "%1"
                                        "%2"
                                        "color: rgb(255, 255, 255);"
                                        "%4"
                                        "}"
                                    "QComboBox QAbstractItemView::item:selected {"
                                        "min-height: 30px; min-width: 60px;"
                                        "%1"
                                        "%2"
                                        "%3"
                                        "%4"
                                        "}"
//                                    "QListView {"
//                                        "show-decoration-selected: 1;"
//                                        "}"
                                    )
                                    .arg("font: bold 20px \"Arial Black\";")
                                    .arg("border: 1px solid rgb(69, 77, 77);")
                                    .arg("color: rgb(169, 204, 135);")
                                    .arg("background-color: rgb(20, 25, 28);")
                                    );
#endif
    }
#endif
    for (i=0; i<checkList->count(); i++)
    {
        checkList->at(i)->label->setStyleSheet("background:transparent;"
                                            "border:0px;"
                                            "color: rgb(69, 77, 77);"
                                            "font: 20px \"Arial\";");
    }
    for (i=0; i<actionList->count(); i++)
    {
        actionList->at(i)->setStyleSheet(
                                    QString(
                                    "QToolButton{"
                                         "border:0px;"    // transparent for Linux
                                         "border-radius:6px;"
                                         "color: rgb(32, 38, 41);"
                                         "background-color: rgb(120, 120, 120);"
                                         "%1"
                                         "}"
                                    "QToolButton:hover{"
                                         "border:0px;"    // transparent for Linux
                                         "border-radius:6px;"
                                         "color: rgb(32, 38, 41);"
                                         "background-color: rgb(140, 140, 140);"
                                         "%1"
                                         "}")
                                    .arg("font: bold 20px \"Arial Black\";")
                                   );
    }
}

void MainWidget::mouseMoveEvent(QMouseEvent *e)
{
    QWidget::mouseMoveEvent(e);
//    qDebug() << QString().sprintf("%d, %d", e->x(), e->y());
}

void MainWidget::mousePressEvent(QMouseEvent *e)
{
//    qDebug() << __func__ << e;
    QWidget::mousePressEvent(e);
    QWidget *wdgt;
    int margin = 15; //pixels
    int x, y;

    if( e->button() == Qt::RightButton )
    {
//        qDebug() << "right";
        //emit mouseRightPressed();
        if (ui->widgetLogin->isVisible() ||
            ui->widgetPlayback->isVisible() ||
            ui->widgetVideoDebug->isVisible())
        {
            return;
        }
        if (ui->widgetKeyboard->isVisible() ||
            ui->widgetKeypad->isVisible())
        {
            return;
        }
        wdgt = getClickedWidget(e);
        if (wdgt != NULL)
        {
            return;
        }
        wdgt = getVisibleWidget(e);
        if (wdgt != NULL)
        {
            wdgt->setHidden(true);
        }
        {
            wdgt = ui->widgetMenu;

            // calculate x, y for widget
            x = (e->x() + wdgt->width() - margin < Config::sys.width) ? e->x() : Config::sys.width - wdgt->width();
            y = (e->y() + wdgt->height() - margin < Config::sys.height) ? e->y() : Config::sys.height - wdgt->height();
            // tune margin for x, y
            x = (Config::sys.width - e->x() < wdgt->width() - margin * 2) ? x+margin : x-margin;
            y = (Config::sys.height - e->y() < wdgt->height() - margin * 2) ? y+margin : y-margin;
            wdgt->setGeometry(x, y, wdgt->width(), wdgt->height());

            if (wdgt->isHidden())
            {
                wdgt->setVisible(true);
                wdgt->raise();
            }
//            qDebug() << QString().sprintf("x=%d, y=%d, w=%d, h=%d", x, y, widget->width(), widget->height());
        }
    }
    else if( e->button() == Qt::LeftButton )
    {
//        qDebug() << "left";
        //emit mouseLeftPressed();
        if (ui->widgetLogin->isVisible() || dialog->isVisible() ||
            ui->widgetPlayback->isVisible() || ui->widgetVideoDebug->isVisible())
        {
            return;
        }
        wdgt = getClickedWidget(e);
        if (wdgt != NULL)
        {
            return;
        }
        else
        {
            showIdxWidgetOnly(NULL);
        }
    }
}

QWidget* MainWidget::getVisibleWidget(QMouseEvent *e)
{
    Q_UNUSED(e);
    QWidget *wdgt;
    QList<QWidget *>wList = {ui->widgetSetting, ui->widgetInfo, ui->widgetIpcAdd};
    foreach (wdgt, wList)
    {
        if(wdgt->isVisible())
        {
            return wdgt;
        }
    }
    return NULL;
}

QWidget* MainWidget::getClickedWidget(QMouseEvent *e)
{
    int x, y;
    QWidget *wdgt;
    QList<QWidget *>wList = {ui->widgetMenu, ui->widgetSetting, ui->widgetInfo,
                             ui->widgetIpcAdd, ui->widgetFaceDetect};
    foreach (wdgt, wList)
    {
        if(wdgt->isVisible() != true)
            continue;
        x = e->localPos().x(); // localPos, windowPos, screenPos
        y = e->localPos().y();
//        qDebug() << QString("x=%1, widget.x=%2").arg(x).arg(widget->x());
//        qDebug() << QString("y=%1, widget.y=%2").arg(y).arg(widget->y());
        if(x>wdgt->x() && x<wdgt->x()+wdgt->width() &&
           y>wdgt->y() && y<wdgt->y()+wdgt->height())
        {
            return wdgt;
        }
    }
    return NULL;
}

void MainWidget::showIdxWidgetOnly(QWidget *idxWidget)
{
//    qDebug() << __func__ << idxWidget;
    QWidget *wdgt;
    foreach (wdgt, widgetList)
    {
//        if (wdgt == NULL)
//            continue;
        if (wdgt == idxWidget)
        {
            wdgt->setVisible(true);
            dialog->setGeometry(wdgt->x(), wdgt->y(), wdgt->width(), wdgt->height());
        }
        else
            wdgt->setVisible(false);
    }
}

void MainWidget::playback_selected(bool)
{
    if(Config::sys.seamless)
    {
        for (int idx=0; idx<CHANNEL_MAX; idx++)
        {
            GridReal *gridIpc = &viewProcess->ipc_gridReal[idx];
            if(gridIpc->wndId > WindowId_Invalid &&
               gridIpc->channelId <= ChannelId_Invalid)
            {
                viewProcess->ipc_stop(idx, false);
            }
        }
    }
    viewProcess->ipc_setViewMode(ViewProcess::ViewMode_Hide,
                                 viewProcess->get_ipc_grid_num());
    viewProcess->file_setViewMode(ViewProcess::ViewMode_Grid,
                                  viewProcess->get_file_grid_num());
    showIdxWidgetOnly(playback);
}

void MainWidget::ctrl_selected(bool)
{
//    showIdxWidgetOnly();
//    dialog->showConfirm(QString("do test"), &(test));
}

//void test()
//{
//    dialog->showInfo("test successfully");
//}

void MainWidget::add_selected(bool)
{
//    qDebug() << __func__;
    showIdxWidgetOnly(ipcAdd);
}

void MainWidget::setting_selected(bool)
{
//    qDebug() << __func__;
    showIdxWidgetOnly(setting);
}

void MainWidget::info_selected(bool)
{
//    qDebug() << __func__;
    showIdxWidgetOnly(info);
}

void MainWidget::videoDebug_selected(bool)
{
    if(Config::sys.seamless)
    {
        for (int idx=0; idx<CHANNEL_MAX; idx++)
        {
            GridReal *gridIpc = &viewProcess->ipc_gridReal[idx];
            if(gridIpc->wndId > WindowId_Invalid &&
               gridIpc->channelId <= ChannelId_Invalid)
            {
                viewProcess->ipc_stop(idx, false);
            }
        }
    }
    viewProcess->ipc_setViewMode(ViewProcess::ViewMode_Hide,
                                 viewProcess->get_ipc_grid_num());
    viewProcess->file_setViewMode(ViewProcess::ViewMode_Hide,
                                  viewProcess->get_file_grid_num());
    showIdxWidgetOnly(videoDebug);
}

void MainWidget::power_selected(bool)
{
    mainWidget->close();
}

void MainWidget::boot_applay()
{
    ipcConnect->set_apply(false, false);
}
