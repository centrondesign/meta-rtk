/**
 * @file mainlogin.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page to login
 */

#ifndef MAINLOGIN_H
#define MAINLOGIN_H

#include <QWidget>

namespace Ui {
class MainLogin;
}

class MainLogin : public QWidget
{
    Q_OBJECT

public:
    explicit MainLogin(QWidget *parent = 0);
    ~MainLogin();

    void installEventFilterForKeyboard(QObject *obj);
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
private slots:
    void showEvent(QShowEvent *);
    void showPassword(bool);
    void signin(void);
    void cancel(void);

private:
    Ui::MainLogin *ui;
    bool _mousePressed;
    QPoint _mousePosition;

protected:
    virtual void mousePressEvent( QMouseEvent *e );
    virtual void mouseMoveEvent( QMouseEvent *e );
    virtual void mouseReleaseEvent( QMouseEvent *e );
};

#endif // MAINLOGIN_H
