/**
 * @file playback.cpp
 * @author Realtek Semiconductor Corp.
 * @date Oct 2017
 * @brief The widget page to do playback operation
 */

#include <QGraphicsDropShadowEffect>
#include "playback.h"
#include "ui_playback.h"
#include "mainwidget.h"

#define FRAME_FILE_HEIGHT_HIGH  0

#define TIMESTAMP_LABEL_HEIGHT  30
#define PLAY_END_MSEC_MAX        86400000   // 24*60*60*1000
#define PLAYBACK_RGB_YELLOWGREEN "rgb(191, 255, 57);"
#define PLAYBACK_RGB_DARK   "rgb(29, 31, 33);"
#define PLAYBACK_NO_REC     "No Rec"
#define PLAYBACK_SPEED_DEF      1
#define PLAYBACK_UPDATE_TIME    100
#define CHANNEL_PER_FILE_PAGE   8
#define CHANNEL_FOR_FILE_MAX    (CHANNEL_PER_FILE_PAGE + 2/*replace prev/next buttons*/)

Playback::Playback(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Playback)
{
    ui->setupUi(this);
    this->rCalendar = ui->rCalendar;

#if 0
    ui->lTitle->setStyleSheet(STYLESHEET_TITLE_1);
#else
    ui->lTitle->setStyleSheet("background-color: rgb(25, 32, 36);"
                              "color: rgb(179, 179, 179);"
                              "font: bold 28px \"Arial\";");
#endif

    ui->rCalendar->strSelectedColor = PLAYBACK_RGB_YELLOWGREEN;
    ui->rCalendar->initStyleSheet(true, true);
    connect(ui->rCalendar, SIGNAL(dayClicked()), this, SLOT(calendar_day_clicked()));

    ui->wOption->setStyleSheet("background-color: rgb(25, 32, 36);");
    {
        ui->lView->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE);
        ui->wGrid->setStyleSheet("background-color: transparent");
        ui->wOperation->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE_BG);
    }
    QGraphicsDropShadowEffect* effect = new QGraphicsDropShadowEffect();
    effect->setBlurRadius(2);
    ui->fFile->setGraphicsEffect(effect);
    ui->fFile->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE_BG);
    {
        ui->lDate->setStyleSheet(QString(
                        "color: rgb(76, 87, 8);"
                        "background-color: %1"
                        "%2")
                    .arg(PLAYBACK_RGB_YELLOWGREEN)
                    .arg("font: bold 16px \"Arial Black\";"));
        ui->lDate->setText(ui->rCalendar->strDateSelected(true));
        ui->tbFileClose->setStyleSheet(
                    "QToolButton {"
                            "background: url(\":/images/playback_filelist_back_normal.png\") transparent top center no-repeat;"
                            "}"
                    "QToolButton:hover {"
                            "background: url(\":/images/playback_filelist_back_hover.png\") transparent top center no-repeat;"
                            "}");

        channelPageIdx = 0;
        for(int chIdx=0; chIdx<CHANNEL_MAX; chIdx++)
        {
            btnFileChannelIdx[chIdx] = new QToolButton(ui->wChannel);
            btnFileChannelIdx[chIdx]->setText(HLS_SUBDIR(chIdx)/*auto +1*/);
//            btnChannelIdx[chIdx]->setStyleSheet();
            btnFileChannelIdx[chIdx]->setAutoRaise(true);
            connect(btnFileChannelIdx[chIdx], SIGNAL(clicked(bool)), this, SLOT(btnFileChannelIdx_clicked(bool)));
        }
        btnFileChannelNext = new QToolButton(ui->wChannel);
        btnFileChannelNext->setText(">");
        btnFileChannelNext->setAutoRaise(true);
        connect(btnFileChannelNext, SIGNAL(clicked(bool)), this, SLOT(btnFileChannelNext_clicked(bool)));
        btnFileChannelPrev = new QToolButton(ui->wChannel);
        btnFileChannelPrev->setText("<");
        btnFileChannelPrev->setAutoRaise(true);
        connect(btnFileChannelPrev, SIGNAL(clicked(bool)), this, SLOT(btnFileChannelPrev_clicked(bool)));

        ui->wChannel->setStyleSheet("background-color:" PLAYBACK_RGB_DARK);
        ui->lChannel->setStyleSheet("color: rgb(78, 79, 78);"
                                    "font: bold 14px \"Arial Black\";");
        ui->twFile->setStyleSheet("border: 0px solid;"
                                  STYLESHEET_PLAYBACK_SUBTITLE_BG
                                  "color: " PLAYBACK_RGB_YELLOWGREEN
                                  "font: 16px;");
        ui->twFile->setSelectionBehavior(QAbstractItemView::SelectRows);
        ui->twFile->setColumnHidden(twFile_ColumnIdx_AbsPath, true);
#if FRAME_FILE_HEIGHT_HIGH
        ui->wPageCtrl->initItemPerPage(20);
#else
        ui->wPageCtrl->initItemPerPage(12);
#endif
        connect(ui->wPageCtrl, SIGNAL(pageUpdated()), this, SLOT(file_page_update()));
    }
    ui->wLeft->setStyleSheet("background-color: rgb(20, 25, 28);");
    ui->wRight->setStyleSheet("background-color: rgb(20, 25, 28);");
    ui->wTop->setStyleSheet("background-color: rgb(20, 25, 28);");
    ui->wBottom->setStyleSheet("background-color: rgb(20, 25, 28);");
    ui->cbPlayChannel->setStyleSheet(STYLESHEET_COMBOBOX);  // before ui->wTime
    ui->wTime->setStyleSheet("background-color: rgb(20, 25, 28);");
    ui->wTimeTitle->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE_BG);
    ui->wTouchBoard->setStyleSheet("border:0px;"    // transparent for Linux
                                   "background:transparent;");
    ui->wTimelineBar->setStyleSheet("border:0px;"    // transparent for Linux
                                    "background: url(\":/images/slider_bar_bg_normal.png\");"); // default: repeat
    ui->tbBack->setIcons(QIcon(":/images/playback_back_normal.png"),
                         QIcon(":/images/playback_back_hover.png"),
                         QIcon(":/images/playback_back_normal.png"),
                         QIcon(":/images/playback_back_hover.png"),
                         false);
    ui->tbBack->setStyleSheet("QToolButton{"
                                    "border:0px;"    // transparent for Linux
                               "}"
                               "QToolButton:hover{"
                                    "border:0px;"    // transparent for Linux
                               "}");
    tbFileStyleSheet_normal =
            "QToolButton {"
                    "background: url(\":/images/playback_filelist_normal.png\") transparent top center no-repeat;"
                    "border:0px;"    // transparent for Linux
                    "font: bold 16px \"Arial\";"
                    "color: rgb(117, 117, 117);"
                    "}"
            "QToolButton:hover {"
                    "background: url(\":/images/playback_filelist_hover.png\") transparent top center no-repeat;"
                    "border:0px;"    // transparent for Linux
                    "font: bold 16px \"Arial\";"
                    "color: rgb(76, 87, 8);"
                    "}";
    tbFileStyleSheet_select =
                    "background: url(\":/images/playback_filelist_selected.png\") transparent top center no-repeat;"
                    "border:0px;"    // transparent for Linux
                    "font: bold 16px \"Arial\";"
                    "color: rgb(117, 117, 117);";
    ui->tbFile->setStyleSheet(tbFileStyleSheet_normal);
    ui->tbPlayCtrl->setIcons(QIcon(":/images/playback_play_normal.png"),
                            QIcon(":/images/playback_play_hover.png"),
                            QIcon(":/images/playback_stop_normal.png"),
                            QIcon(":/images/playback_stop_hover.png"),
                            true);
    ui->tbSeekBack->setIcons(QIcon(":/images/playback_seek_back_normal.png"),
                            QIcon(":/images/playback_seek_back_hover.png"),
                            QIcon(":/images/playback_seek_back_normal.png"),
                            QIcon(":/images/playback_seek_back_hover.png"),
                            false);
    ui->tbSeekFront->setIcons(QIcon(":/images/playback_seek_front_normal.png"),
                            QIcon(":/images/playback_seek_front_hover.png"),
                            QIcon(":/images/playback_seek_front_normal.png"),
                            QIcon(":/images/playback_seek_front_hover.png"),
                            false);
    connect(ui->tbSeekBack, SIGNAL(clicked(bool)), this, SLOT(btnPlaySeekBack_clicked(bool)));
    connect(ui->tbSeekFront, SIGNAL(clicked(bool)), this, SLOT(btnPlaySeekFront_clicked(bool)));

    ui->rspinSpeed->append("1/4 X", 0.25);
    ui->rspinSpeed->append("1/2 X", 0.5);
    ui->rspinSpeed->append("1 X", 1.0);
    ui->rspinSpeed->append("2 X", 2.0);
    ui->rspinSpeed->append("4 X", 4.0);
//    ui->rspinSpeed->append("8 X", 8.0);
    ui->rspinSpeed->setValue(PLAYBACK_SPEED_DEF);
    ui->rspinSpeed->wBg->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE);
    ui->rspinSpeed->leText->setStyleSheet("border:0px;"    // transparent for Linux
                                          STYLESHEET_PLAYBACK_SUBTITLE_BG
                                          "color: rgb(140, 140, 140);"
                                          "font: bold 16px \"Arial Black\";");
    ui->rspinSpeed->btnLeft->setStyleSheet(
                            "QToolButton {"
                                    "background: url(\":/images/playback_prev_normal.png\") transparent top center no-repeat;"
                                    "}"
                            "QToolButton:hover {"
                                    "background: url(\":/images/playback_prev_hover.png\") transparent top center no-repeat;"
                                    "}"
                            );
    ui->rspinSpeed->btnRight->setStyleSheet(
                            "QToolButton {"
                                    "background: url(\":/images/playback_next_normal.png\") transparent top center no-repeat;"
                                    "}"
                            "QToolButton:hover {"
                                    "background: url(\":/images/playback_next_hover.png\") transparent top center no-repeat;"
                                    "}"
                            );
    connect(ui->rspinSpeed, SIGNAL(leftClicked(bool)), this, SLOT(speed_changed(bool)));
    connect(ui->rspinSpeed, SIGNAL(rightClicked(bool)), this, SLOT(speed_changed(bool)));
//    connect(ui->rspinSpeed, SIGNAL(valueChanged(double)), this, SLOT(speed_changed(double)));
    connect(ui->rSound,     SIGNAL(muteChanged(bool)), this, SLOT(mute_changed(bool)));
    connect(ui->rSound,     SIGNAL(volumeChanged(int)), this, SLOT(volume_changed(int)));

    ui->tbGrid1->setIcons(QIcon(":/images/playback_grid1_normal.png"),
                         QIcon(":/images/playback_grid1_hover.png"),
                         QIcon(":/images/playback_grid1_selected.png"),
                         QIcon(":/images/playback_grid1_hover.png"),
                         true);
    ui->tbGrid4->setIcons(QIcon(":/images/playback_grid4_normal.png"),
                         QIcon(":/images/playback_grid4_hover.png"),
                         QIcon(":/images/playback_grid4_selected.png"),
                         QIcon(":/images/playback_grid4_hover.png"),
                         true);
    ui->tbGrid9->setIcons(QIcon(":/images/playback_grid9_normal.png"),
                         QIcon(":/images/playback_grid9_hover.png"),
                         QIcon(":/images/playback_grid9_selected.png"),
                         QIcon(":/images/playback_grid9_hover.png"),
                         true);
    connect(ui->tbBack, SIGNAL(clicked(bool)), this, SLOT(close_clicked(bool)));
    connect(ui->tbFile, SIGNAL(clicked(bool)), this, SLOT(file_open_clicked(bool)));
    connect(ui->tbFileClose, SIGNAL(clicked(bool)), this, SLOT(file_close_clicked(bool)));
    connect(ui->tbPlayCtrl, SIGNAL(clicked(bool)), this, SLOT(playCtrl_clicked(bool)));
    connect(ui->tbGrid1, SIGNAL(clicked(bool)), this, SLOT(file_grid1_selected(bool)));
    connect(ui->tbGrid4, SIGNAL(clicked(bool)), this, SLOT(file_grid4_selected(bool)));
    connect(ui->tbGrid9, SIGNAL(clicked(bool)), this, SLOT(file_grid9_selected(bool)));

    timelineViewList.append({{24*60*60*_K_, 4*60*60*_K_,    20*60*_K_},
                             {12*60*60*_K_, 2*60*60*_K_,    10*60*_K_},
                             {6*60*60*_K_,  60*60*_K_,      5*60*_K_},
                             {3*60*60*_K_,  30*60*_K_,      3*60*_K_},
                             {60*60*_K_,    10*60*_K_,      1*60*_K_},
                             {30*60*_K_,    5*60*_K_,       30*_K_},
                             {10*60*_K_,    60*_K_,         10*_K_}
                            });
    pM3u8PlayCurr = NULL;
    timelineViewIdx = 0;
    timelineBarOffsetY = 40;
    timelineBarHeight = 20;
    playViewStartMSec = 0;
    playViewPeriodMSec = timelineViewList.at(timelineViewIdx).viewPeriod;
    playViewUnitMSec = timelineViewList.at(timelineViewIdx).viewUnit;
    playSeekMSec = timelineViewList.at(timelineViewIdx).seekUnit;
    playViewEndMSec = playViewStartMSec + playViewPeriodMSec;
    playCurrentMSec = 0;
    refetchTime = QDateTime::currentDateTime();
    bIfPlayBefore = false;

    ui->btnPlayZoomOut->setIcons(QIcon(":/images/playback_timeline_zoomout_normal.png"),
                            QIcon(":/images/playback_timeline_zoomout_hover.png"),
                            QIcon(":/images/playback_timeline_zoomout_normal.png"),
                            QIcon(":/images/playback_timeline_zoomout_hover.png"),
                            true);
    ui->btnPlayZoomIn->setIcons(QIcon(":/images/playback_timeline_zoomin_normal.png"),
                            QIcon(":/images/playback_timeline_zoomin_hover.png"),
                            QIcon(":/images/playback_timeline_zoomin_normal.png"),
                            QIcon(":/images/playback_timeline_zoomin_hover.png"),
                            true);
    ui->btnPlayShiftLeft->setIcons(QIcon(":/images/playback_timeline_shift_left_normal.png"),
                            QIcon(":/images/playback_timeline_shift_left_hover.png"),
                            QIcon(":/images/playback_timeline_shift_left_normal.png"),
                            QIcon(":/images/playback_timeline_shift_left_hover.png"),
                            true);
    ui->btnPlayShiftRight->setIcons(QIcon(":/images/playback_timeline_shift_right_normal.png"),
                            QIcon(":/images/playback_timeline_shift_right_hover.png"),
                            QIcon(":/images/playback_timeline_shift_right_normal.png"),
                            QIcon(":/images/playback_timeline_shift_right_hover.png"),
                            true);
    connect(ui->btnPlayZoomIn, SIGNAL(clicked(bool)), this, SLOT(btnPlayZoomIn_clicked(bool)));
    connect(ui->btnPlayZoomOut, SIGNAL(clicked(bool)), this, SLOT(btnPlayZoomOut_clicked(bool)));
    connect(ui->btnPlayShiftLeft, SIGNAL(clicked(bool)), this, SLOT(btnPlayShiftLeft_clicked(bool)));
    connect(ui->btnPlayShiftRight,SIGNAL(clicked(bool)), this, SLOT(btnPlayShiftRight_clicked(bool)));
    ui->wTouchBoard->installEventFilter(this);

    ui->lCurrentTime->setAlignment(Qt::AlignCenter | Qt::AlignHCenter);
    ui->lCurrentTime->setStyleSheet(STYLESHEET_PLAYBACK_SUBTITLE_BG
                                  "color: rgb(170, 0, 0);"
                                  "font: bold 16px \"Arial Black\";");
    ui->lFileName->setText(PLAYBACK_NO_REC);
    ui->lFileName->setAlignment(Qt::AlignCenter | Qt::AlignHCenter);
    ui->lFileName->setStyleSheet("color: rgb(78, 79, 78);"
                                 "font: bold 16px \"Arial Black\";");
    timelineTimer = new QTimer();
    connect(timelineTimer, SIGNAL(timeout()), this, SLOT(timer_update()));
    bBlankHideWhole = false;
    blankHideTimer = new QTimer();
    connect(blankHideTimer, SIGNAL(timeout()), this, SLOT(timer_blankHide()));
}

Playback::~Playback()
{
    for(int i=0; i<CHANNEL_MAX; i++)
    {
        delete(btnFileChannelIdx[i]);
        if (fileFrame[i] != NULL)
        {
            delete (fileFrame[i]);
            fileFrame[i] = NULL;
        }
    }
    timelineLabelList.clear();
    widgetList.clear();
    delete ui;
}

void Playback::setup()
{
    ui->rSound->setVolume(Config::sys.playbackSound);

    playChannelIdx = 0;
    for (int i=0; i<Config::sys.ipcChannelMax; i++)
    {
        ui->cbPlayChannel->addItem(QString().asprintf("Channel %02d", i+1));
    }
    ui->cbPlayChannel->setStyleSheet(STYLESHEET_COMBOBOX);
    ui->cbPlayChannel->setCurrentIndex(playChannelIdx);
    connect(ui->cbPlayChannel, SIGNAL(currentIndexChanged(int)), this, SLOT(play_channel_changed(int)));

    for(int i=0; i<CHANNEL_MAX; i++)
    {
        fileFrame[i] = new RFrame(this, true, true, false, false, i);
        fileFrame[i]->setGeometry(QRect(0,0,0,0));

        fileFrame[i]->setFrameShape(QFrame::Box);
        fileFrame[i]->setFrameShadow(QFrame::Plain);
        fileFrame[i]->setLineWidth(0);

#if 0
        fileFrame[i]->setChText(HLS_SUBDIR(i));
#else
        fileFrame[i]->setChText("");
#endif
        fileFrame[i]->prepareStyleSheet();

        fileFrame[i]->setGridReal(&viewProcess->file_gridReal[i]);
    }
#if 0   // auto refresh by apply_view_file() in viewProcess
    int playGridIdx = playGridIndex();
    fileFrame[playGridIdx]->setChText(HLS_SUBDIR(ui->cbPlayChannel->currentIndex()));
#endif

    // default value
    switch(Config::style.fileGridNum)
    {
    case 1:
        file_grid1_selected(true);   break;
    case 4:
        file_grid4_selected(true);   break;
    case 9:
    default:
        file_grid9_selected(true);   break;
    }

    // update file list
    channelPageIdx = 0;
    fileChannelIdx = 0;
    file_channel_update();
    play_update();

    queryTimeCount = 0;
    timelineTimer->setInterval(PLAYBACK_UPDATE_TIME);
    blankHideTimer->setInterval(Config::sys.playbackBlankTime);

    updateBgColor();
    ui->wBlank->raise();
    ui->wBlank->setVisible(false);
    ui->fFile->setVisible(false);
}

void Playback::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);
    ui->wBlank->setGeometry(rect.x(), rect.y(), rect.width(), rect.height());

    int wRightWidth = qMax(Config::sys.playbackLeftRightBorder,
                           rect.width()-(Config::sys.playbackX+Config::sys.playbackWidth));
    int height = Config::sys.playbackHeight + Config::sys.playbackTopDownBorder*2;

    int wOptionWidth = Config::sys.playbackX-Config::sys.playbackLeftRightBorder;
    int titleHeight = 80;
    int calendarHeight = 358;
    int yFile = 340;
    ui->wOption->setGeometry(0, 0, wOptionWidth, height);
    {   // in wOption
        ui->lTitle->setGeometry(0, 0, wOptionWidth, titleHeight);
        ui->line_1->setVisible(false);
        ui->tbBack->raise();
        ui->tbBack->setGeometry(14, 14,
                                ui->tbBack->width(),ui->tbBack->height());
        int lViewHeight = 36;
        int wGridHeight = 90;
        int wOperationHeight = 216;
        int rSoundWidth = 320;
        int rSoundHeight = 44;
        int y = ui->lTitle->height();
        ui->rCalendar->setGeometry(0, y, wOptionWidth, calendarHeight);
        y += calendarHeight;
        ui->lView->setGeometry(0, y, wOptionWidth, lViewHeight);
        y += lViewHeight;
        ui->wGrid->setGeometry(0, y, wOptionWidth, wGridHeight);
        y += wGridHeight;
        ui->wOperation->setGeometry(0, y, wOptionWidth, wOperationHeight);
        y += wOperationHeight;
        ui->rSound->setGeometry((wOptionWidth-rSoundWidth)/2, y+(height-y-rSoundHeight)/2,
                                rSoundWidth, rSoundHeight);
        int tbFileWidth = 110;
        ui->tbFile->setGeometry(wOptionWidth-tbFileWidth, yFile, tbFileWidth, 45);
        {   // grids in wGrid
            int tbGridWidth = 54;
            int tbGridNum = 3;  // for tbGrid1, tbGrid4, tbGrid9
            int y_offset = (wGridHeight - tbGridWidth) / 2;
            ui->tbGrid1->setGeometry((wOptionWidth-tbGridWidth*tbGridNum)/2, y_offset,
                                     tbGridWidth, tbGridWidth);
            ui->tbGrid4->setGeometry(ui->tbGrid1->x()+tbGridWidth, y_offset,
                                     tbGridWidth, tbGridWidth);
            ui->tbGrid9->setGeometry(ui->tbGrid4->x()+tbGridWidth, y_offset,
                                     tbGridWidth, tbGridWidth);
        }
        {   // in wOperation
            int y_offset = 46;
            int ctrlHeight = 78;
            int ctrlDiv = 2;
            ui->tbSeekBack->setGeometry((wOptionWidth - (ctrlHeight*3 + ctrlDiv*2))/2, y_offset,
                                        ctrlHeight, ctrlHeight);
            ui->tbPlayCtrl->setGeometry(ui->tbSeekBack->x()+ctrlHeight+ctrlDiv, y_offset,
                                        ctrlHeight, ctrlHeight);
            ui->tbSeekFront->setGeometry(ui->tbPlayCtrl->x()+ctrlHeight+ctrlDiv, y_offset,
                                         ctrlHeight, ctrlHeight);
            int speedBtnWidth = 46;
            int speedWidth = speedBtnWidth*2 + 74;
            ui->rspinSpeed->setBtnWidth(speedBtnWidth, true);
            ui->rspinSpeed->setGeometry((wOptionWidth-speedWidth)/2, y_offset+ctrlHeight+10,
                                   speedWidth, speedBtnWidth);
        }
    }
    int fFileWidth = 390;
#if FRAME_FILE_HEIGHT_HIGH
    ui->fFile->setGeometry(380, titleHeight,
                           fFileWidth, height - titleHeight);
#else
    ui->fFile->setGeometry(380, yFile,
                           fFileWidth, height - yFile);
#endif
    {   // in fFile
        int channelBtnWidth = 30;
        int channelHeight = 30;

        int dateHeight = 40;
        ui->lDate->setGeometry(0, 0, fFileWidth, dateHeight);
        ui->tbFileClose->setGeometry(4, 4, dateHeight-8, dateHeight-8);
        ui->tbFileClose->raise();
        ui->wChannel->setGeometry(0, ui->lDate->y() + dateHeight,
                                  fFileWidth, channelHeight);
        if(Config::sys.ipcChannelMax <= CHANNEL_FOR_FILE_MAX)
        {
            for(int i=0; i<CHANNEL_MAX; i++)
            {
                btnFileChannelIdx[i]->setGeometry(ui->lChannel->width() + channelBtnWidth * i, 0,
                                            channelBtnWidth, channelHeight);
                btnFileChannelIdx[i]->setVisible(i<Config::sys.ipcChannelMax);
            }
            btnFileChannelPrev->setVisible(false);
            btnFileChannelNext->setVisible(false);
        }
        else
        {
            for(int i=0; i<CHANNEL_MAX; i++)
            {
                btnFileChannelIdx[i]->setGeometry(ui->lChannel->width() + channelBtnWidth * (i%CHANNEL_PER_FILE_PAGE), 0,
                                            channelBtnWidth, channelHeight);
            }
            btnFileChannelPrev->setGeometry(ui->lChannel->width() + channelBtnWidth * CHANNEL_PER_FILE_PAGE, 0,
                                        channelBtnWidth, channelHeight);
            btnFileChannelNext->setGeometry(ui->lChannel->width() + channelBtnWidth * (CHANNEL_PER_FILE_PAGE+1), 0,
                                        channelBtnWidth, channelHeight);
        }
        file_channel_update();

        int pageCtrlHeight = 45;
        int y = ui->wChannel->y() + channelHeight;
        ui->twFile->setGeometry(0, y,
                                fFileWidth, ui->fFile->height() - y - pageCtrlHeight);
        ui->twFile->setColumnWidth(twFile_ColumnIdx_Title, fFileWidth - 220);
        ui->twFile->setColumnWidth(twFile_ColumnIdx_Time, 100);
        ui->twFile->setColumnWidth(twFile_ColumnIdx_Size, 120);
        ui->wPageCtrl->setGeometry(0, ui->fFile->height()-pageCtrlHeight, fFileWidth, pageCtrlHeight);
        ui->wPageCtrl->setParentAbsoluteOffset(ui->fFile->x(), ui->fFile->y()); // after setGeometry
    }

    ui->wLeft->setGeometry(wOptionWidth, 0,
                           Config::sys.playbackLeftRightBorder, height);
    ui->wRight->setGeometry(rect.width()-wRightWidth, 0, wRightWidth, height);
    ui->wTop->setGeometry(Config::sys.playbackX, 0, Config::sys.playbackWidth, Config::sys.playbackTopDownBorder);
    ui->wBottom->setGeometry(Config::sys.playbackX, Config::sys.playbackHeight + Config::sys.playbackTopDownBorder,
                             Config::sys.playbackWidth, Config::sys.playbackTopDownBorder);

    int heightOffset = Config::sys.playbackHeight + Config::sys.playbackTopDownBorder*2;
    int wTimeHeight = qMax(0, rect.height() - heightOffset);
    ui->wTime->setGeometry(0, heightOffset, rect.width(), wTimeHeight);

    // in wTime
    int wTimeTitleHeight = 34;
    ui->wTimeTitle->setGeometry(0, 0, ui->wTime->width(), wTimeTitleHeight);
    int wTimeOptWidth = 310;
    int wTouchBoardWidth = rect.width()-wTimeOptWidth;
    int lStartlineHeight = qMax(0, ui->wTime->height() - wTimeTitleHeight);
    ui->lStartline->setGeometry(wTimeOptWidth, wTimeTitleHeight,
                                ui->lStartline->width(),lStartlineHeight);
    ui->lCurrentline->setGeometry(ui->lStartline->x(), 0,
                                  ui->lCurrentline->width(), wTimeHeight);
    ui->cbPlayChannel->setGeometry((wTimeOptWidth-ui->cbPlayChannel->width())/2,
                                   wTimeTitleHeight+timelineBarOffsetY-ui->cbPlayChannel->height(),
                                   ui->cbPlayChannel->width(), ui->cbPlayChannel->height());
    ui->lFileName->setGeometry(0, wTimeTitleHeight+timelineBarOffsetY,
                               wTimeOptWidth, 30);
    ui->wTouchBoard->setGeometry(wTimeOptWidth, 0,
                               wTouchBoardWidth, wTimeHeight);
    // in wTimeTitle
    ui->btnPlayShiftLeft->setIconSize(QSize(wTimeTitleHeight, wTimeTitleHeight));
    ui->btnPlayZoomOut->setIconSize(QSize(wTimeTitleHeight, wTimeTitleHeight));
    ui->btnPlayZoomIn->setIconSize(QSize(wTimeTitleHeight, wTimeTitleHeight));
    ui->btnPlayShiftRight->setIconSize(QSize(wTimeTitleHeight, wTimeTitleHeight));
    ui->btnPlayShiftLeft->setGeometry(0, 0, wTimeTitleHeight, wTimeTitleHeight);
    ui->btnPlayZoomOut->setGeometry(wTimeTitleHeight, 0, wTimeTitleHeight, wTimeTitleHeight);
    ui->btnPlayZoomIn->setGeometry(wTimeTitleHeight*2, 0, wTimeTitleHeight, wTimeTitleHeight);
    ui->btnPlayShiftRight->setGeometry(wTimeTitleHeight*3, 0, wTimeTitleHeight, wTimeTitleHeight);
    ui->lCurrentTime->setGeometry(wTimeTitleHeight*4, 0, ui->lCurrentTime->width(), TIMESTAMP_LABEL_HEIGHT);

    // under wTouchBoard
    ui->wTimelineBar->setGeometry(wTimeOptWidth, wTimeTitleHeight + timelineBarOffsetY,
                                  wTouchBoardWidth, timelineBarHeight);
}

void Playback::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void Playback::showEvent(QShowEvent *e)
{
//    qDebug() << __func__;
    if(bIfPlayBefore)
    {
        ui->tbPlayCtrl->setActive(true, false);
        playCtrl_action(false);
        bIfPlayBefore = false;
    }

    hlsProcess->setRefetch();
    if (Config::sys.playbackBlankEnable)
    {
        ui->wBlank->raise();
        ui->wBlank->setVisible(true);
        bBlankHideWhole = false;
        blankHideTimer->start();
    }
    ui->rCalendar->regetCalendar();
    btnFileChannelIdx_select ();
    Q_UNUSED(e);
}

bool Playback::eventFilter(QObject *o, QEvent *e)
{
//    qDebug() << __func__ << o << e;
    if(o == ui->wTouchBoard &&
       e->type() == QEvent::MouseButtonPress)
    {
        const QMouseEvent* const me = static_cast<const QMouseEvent*>( e );
        if(me->buttons() & Qt::LeftButton)
        {
            double newMSec = playViewStartMSec +
                    (0.0 + me->pos().x())/ui->wTouchBoard->width() * playViewPeriodMSec;
            resetUpdateStartTime(newMSec);
            play_control(newMSec, true);
        }
    }
    return QObject::eventFilter(o, e);
}

void Playback::timer_update()
{
    double newMSec = updateStartMSec +
                    (0.0 + updateStartTime.msecsTo(QDateTime::currentDateTime())) * ui->rspinSpeed->getValue();
//    qDebug() << newMSec << timelineTimer->interval() << ui->rspinSpeed->getValue();
    if(newMSec < PLAY_END_MSEC_MAX)
    {
        queryTimeCount += PLAYBACK_UPDATE_TIME;
        if(queryTimeCount > 0 &&
           (uint)queryTimeCount >= Config::sys.playbackQueryTime)
        {
            queryTimeCount = 0;
            play_control(newMSec, false);
        }
        else
        {
            play_currentline_update(newMSec);
        }
    }
    else
    {
        playCtrl_stop(Config::sys.seamless);
    }
}

void Playback::timer_blankHide()
{
    blankHideTimer->stop();
    if (bBlankHideWhole)
        this->hide();
    else
        ui->wBlank->setVisible(false);
}

void Playback::calendar_day_clicked()
{
    hlsProcess->setRefetch();
    file_list_update();
    play_update(true);
}

void Playback::close_clicked(bool)
{
    if(ui->tbPlayCtrl->getActived())
    {
        bIfPlayBefore = true;
        ui->tbPlayCtrl->setActive(false, false);
        playCtrl_action(false);
    }
    else
    {
        if(Config::sys.seamless)
            playCtrl_action(false);
    }

    viewProcess->file_setViewMode(ViewProcess::ViewMode_Hide,
                                  viewProcess->get_file_grid_num());
    viewProcess->ipc_setViewMode(ViewProcess::ViewMode_Grid,
                                 viewProcess->get_ipc_grid_num());
    if(Config::sys.playbackBlankEnable)
    {
        bBlankHideWhole = true;
        blankHideTimer->start();
        ui->wBlank->raise();
        ui->wBlank->setVisible(true);
    }
    else
    {
        this->hide();
    }
}

void Playback::file_open_clicked(bool)
{
    ui->tbFile->setStyleSheet(tbFileStyleSheet_select);
    btnFileChannelIdx_select();
    ui->fFile->setVisible(true);
    ui->fFile->raise();
}

void Playback::file_close_clicked(bool)
{
    ui->tbFile->setStyleSheet(tbFileStyleSheet_normal);
    ui->fFile->setVisible(false);
}

void Playback::play_channel_changed(int)
{
    if(playChannelIdx != ui->cbPlayChannel->currentIndex())
    {
        playChannelIdx = ui->cbPlayChannel->currentIndex();
#if 0   // auto refresh by apply_view_file() in viewProcess
        int playGridIdx = playGridIndex();
        if(playGridIdx >= 0)
        {
            fileFrame[playGridIdx]->setChText(HLS_SUBDIR(ui->cbPlayChannel->currentIndex()));
        }
#endif
    }
    play_update(true);
}

void Playback::speed_changed(bool)
{
    if (!timelineTimer->isActive())
        return;
    int playGridIdx = playGridIndex();
    if(playGridIdx >= 0)
    {
        viewProcess->file_gridReal[playGridIdx].setSpeed(ui->rspinSpeed->getValue());
    }
    resetUpdateStartTime(playCurrentMSec);
}

void Playback::mute_changed(bool)
{
    int playGridIdx = playGridIndex();
    if(playGridIdx >= 0)
    {
        viewProcess->file_gridReal[playGridIdx].setMute(ui->rSound->getMute());
        if(ui->rSound->getMute() != true)
        {
            viewProcess->file_gridReal[playGridIdx].setVolume(ui->rSound->getVolume());
        }
    }
}

void Playback::volume_changed(int)
{
    int playGridIdx = playGridIndex();
    if(playGridIdx >= 0)
    {
        viewProcess->file_gridReal[playGridIdx].setVolume(ui->rSound->getVolume());
    }
    Config::saveDefaultProfile();
}

void Playback::playCtrl_clicked(bool)
{
    playCtrl_action(Config::sys.seamless);
}

void Playback::playCtrl_action(bool bSeamless)
{
    if(ui->tbPlayCtrl->getActived())
    {
        resetUpdateStartTime(playCurrentMSec);

        play_control(playCurrentMSec, true);
        queryTimeCount = 0;
        timelineTimer->start();
    }
    else
    {
        playCtrl_stop(bSeamless);
    }
}

void Playback::playCtrl_stop(bool bSeamless)
{
    ui->tbPlayCtrl->setActive(false, false);
    timelineTimer->stop();
    int playGridIdx = playGridIndex();
    if(playGridIdx >= 0)
    {
        GridReal *grid = &viewProcess->file_gridReal[playGridIdx];
        if(grid->status == GridReal::GridStatus_PLAY ||
           grid->status == GridReal::GridStatus_FILE_PAUSE)
        {
            viewProcess->file_stop(playGridIdx, bSeamless);
        }
        else if(Config::sys.seamless && bSeamless == false)
        {
            /* to set balnk and destroy window for closing playback */
            viewProcess->file_stop(playGridIdx, bSeamless);
        }
    }
}

void Playback::resetUpdateStartTime(uint newMSec)
{
    updateStartTime = QDateTime::currentDateTime();
    updateStartMSec = newMSec;
}

int Playback::playGridIndex()
{
    for(int i=0; i<CHANNEL_MAX; i++)
    {
        if(viewProcess->file_gridReal[i].channelIndex >= 0 &&
           viewProcess->file_gridReal[i].channelIndex < Config::sys.ipcChannelMax)
            return i;
    }
    return -1;
}

void Playback::btnPlaySeekBack_clicked(bool)
{
    double newMSec = 0;
    if(playCurrentMSec > playSeekMSec)
    {
        newMSec = playCurrentMSec - playSeekMSec;
    }
    resetUpdateStartTime(newMSec);
    play_control(newMSec, true);
}

void Playback::btnPlaySeekFront_clicked(bool)
{
    double newMSec = PLAY_END_MSEC_MAX;
    if(playCurrentMSec + playSeekMSec < PLAY_END_MSEC_MAX)
    {
        newMSec = playCurrentMSec + playSeekMSec;
    }
    resetUpdateStartTime(newMSec);
    play_control(newMSec, true);
}

void Playback::btnPlayZoom_tune()
{
    uint currentPlayMSec;
    playViewPeriodMSec = timelineViewList.at(timelineViewIdx).viewPeriod;
    playViewUnitMSec = timelineViewList.at(timelineViewIdx).viewUnit;
    playSeekMSec = timelineViewList.at(timelineViewIdx).seekUnit;
    if(playCurrentMSec >= playViewStartMSec && playCurrentMSec <= playViewEndMSec)
    {
        if(playCurrentMSec > playViewPeriodMSec/2)
        {
            currentPlayMSec = playCurrentMSec - playViewPeriodMSec / 2;
        }
        else
        {
            currentPlayMSec = 0;
        }
    }
    else
    {
        currentPlayMSec = (playViewStartMSec + playViewEndMSec - playViewPeriodMSec) / 2;
    }
    playViewStartMSec = (int)((0.0 + (double)currentPlayMSec) / playViewUnitMSec) * playViewUnitMSec;
    playViewEndMSec = playViewStartMSec + playViewPeriodMSec;
    if(playViewEndMSec > PLAY_END_MSEC_MAX)
    {
        playViewEndMSec = PLAY_END_MSEC_MAX;
        playViewStartMSec = playViewEndMSec - playViewPeriodMSec;
    }
    play_timeline_update();
    play_currentline_update(playCurrentMSec);
}

void Playback::btnPlayZoomOut_clicked(bool)
{
    if(timelineViewIdx <= 0)
    {
        timelineViewIdx = 0;
    }
    else
    {
        timelineViewIdx --;
    }
    btnPlayZoom_tune();
}

void Playback::btnPlayZoomIn_clicked(bool)
{
    if(timelineViewIdx+1 >= timelineViewList.count())
    {
        timelineViewIdx = timelineViewList.count() - 1;
    }
    else
    {
        timelineViewIdx ++;
    }
    btnPlayZoom_tune();
}

void Playback::btnPlayShiftLeft_clicked(bool)
{
    if(playViewStartMSec > playViewUnitMSec)
    {
        playViewStartMSec = playViewStartMSec - playViewUnitMSec;
    }
    else
    {
        playViewStartMSec = 0;
    }
    playViewEndMSec = playViewStartMSec + playViewPeriodMSec;
    play_timeline_update();
    play_currentline_update(playCurrentMSec);
}

void Playback::btnPlayShiftRight_clicked(bool)
{
    if(playViewEndMSec + playViewUnitMSec < PLAY_END_MSEC_MAX)
    {
        playViewEndMSec = playViewEndMSec + playViewUnitMSec;
    }
    else
    {
        playViewEndMSec = PLAY_END_MSEC_MAX;
    }
    playViewStartMSec = playViewEndMSec - playViewPeriodMSec;
    play_timeline_update();
    play_currentline_update(playCurrentMSec);
}

Playback::M3u8Play Playback::tuneM3u8InfoToSelectedDate(M3u8Info m3u8Info, QDate selectedDate)
{
    M3u8Play m3u8Play;
    m3u8Play.m3u8Info.copy(m3u8Info);
    if(m3u8Info.recStartTime.date() < selectedDate)
    {
        QDateTime datetime = QDateTime(selectedDate, QTime(0,0,0));
        m3u8Play.crossStartMSec = (0.0 + m3u8Info.recStartTime.msecsTo(datetime));
        m3u8Play.playStartMSec = 0;
        m3u8Play.playStartTime = datetime;
    }
    else
    {
        QDateTime datetime = QDateTime(selectedDate, QTime(0,0,0));
        m3u8Play.crossStartMSec = 0;
        m3u8Play.playStartMSec = (0.0 + datetime.msecsTo(m3u8Info.recStartTime));
        m3u8Play.playStartTime = m3u8Info.recStartTime;
    }
    if(m3u8Info.recEndTime.date() > selectedDate)
    {
        QDateTime datetime = QDateTime(selectedDate.addDays(1), QTime(0,0,0));
        m3u8Play.playEndMSec = PLAY_END_MSEC_MAX;
        m3u8Play.playEndTime = datetime;
    }
    else
    {
        QDateTime datetime = QDateTime(selectedDate, QTime(0,0,0));
        m3u8Play.playEndMSec = (0.0 + datetime.msecsTo(m3u8Info.recEndTime));
        m3u8Play.playEndTime = m3u8Info.recEndTime;
    }
    m3u8Play.playTimeMSec = m3u8Play.playEndMSec - m3u8Play.playStartMSec;
    return m3u8Play;
}

void Playback::play_list_update()
{
    QHash<QString, M3u8Info> *pHash;

    QDate selectedDate;
    QList<QString> strList;

    mutex.lock();
    hlsProcess->mutex.lock();
    selectedDate = ui->rCalendar->getDateSelected();
    m3u8PlayList.clear();

    pHash = &(hlsProcess->pM3u8Channel[playChannelIdx]->hashM3u8);
    strList = hlsProcess->pM3u8Channel[playChannelIdx]->hashKeyListByDate(selectedDate);
    foreach(QString absoluteFilePath, strList)
    {
        M3u8Info m3u8Info = pHash->value(absoluteFilePath);
        M3u8Play m3u8Play = tuneM3u8InfoToSelectedDate(m3u8Info, selectedDate);
        m3u8PlayList.append(m3u8Play);
    }
    hlsProcess->mutex.unlock();
    mutex.unlock();
}

void Playback::play_currentline_update(uint playNewMSec)
{
    if(playNewMSec < playViewStartMSec || playNewMSec > playViewEndMSec)
    {
        ui->lCurrentline->setVisible(false);
    }
    else
    {
        int intX = ui->lStartline->x() +
                   (0.0 + playNewMSec - playViewStartMSec) / playViewPeriodMSec * ui->wTouchBoard->width();
        ui->lCurrentline->setGeometry(intX, 0, ui->lCurrentline->width(), ui->lCurrentline->height());
        ui->lCurrentline->setVisible(true);
    }
    ui->lCurrentTime->setText(strMSec(playNewMSec, false));
}

void Playback::play_timeline_update()
{
    double x0, x1, width;
    int idx;
    QWidget *wdg;

    if(DBG(_DBG_PLAYBACK_))
    {
        qDebug() << STR_DBG_PLAY
                 << QString("playViewStartSec=%1, playViewEndSec=%2")
                    .arg(strMSec(playViewStartMSec))
                    .arg(strMSec(playViewEndMSec));
    }
    ui->btnPlayShiftLeft->setVisible(playViewStartMSec > 0);
    ui->btnPlayShiftRight->setVisible(playViewEndMSec < PLAY_END_MSEC_MAX);
    ui->btnPlayZoomIn->setVisible(timelineViewIdx<(timelineViewList.count()-1));
    ui->btnPlayZoomOut->setVisible(timelineViewIdx>0);
    mutex.lock();

    // update line mark under wTouchBoard
    int lTimestampWidth = 60;
    int lLineWidth = 3;
    int lLineHeight = ui->wTime->height() - TIMESTAMP_LABEL_HEIGHT;
    idx = 0;
    for(uint timestamp=playViewStartMSec; timestamp<=playViewEndMSec; timestamp+=playViewUnitMSec)
    {
        if(timelineLabelList.count() <= idx)
        {
            TIME_LABEL_S label;
            label.lLine = new QFrame(ui->wTime);
            label.lLine->setStyleSheet(QStringLiteral("color: rgb(200, 200, 200);"));
            label.lLine->setFrameShadow(QFrame::Plain);
            label.lLine->setFrameShape(QFrame::VLine);
            label.lTimestamp = new QLabel(ui->wTimeTitle);
            label.lTimestamp->setAlignment(Qt::AlignCenter | Qt::AlignHCenter);
            label.lTimestamp->setStyleSheet("color: rgb(200, 200, 200);"
                                            "font: bold 16px \"Arial\";");
            timelineLabelList.append(label);
            ui->lCurrentline->raise();
            ui->wTouchBoard->raise();
        }
        QTime time = QTime(0, 0, 0).addMSecs(timestamp);
        QFrame *lLine = timelineLabelList.at(idx).lLine;
        QLabel *lTimestamp = timelineLabelList.at(idx).lTimestamp;
        int x0;
        double xCenter = ui->lStartline->x() +
                        (0.0 + timestamp - playViewStartMSec) / playViewPeriodMSec * ui->wTimelineBar->width();
        if(xCenter + lLineWidth/2 > ui->wTimeTitle->width())
        {
            x0 = ui->wTimeTitle->width() - lLineWidth;
        }
        else
        {
            x0 = xCenter-lLineWidth/2;
        }
        lLine->setGeometry(x0, TIMESTAMP_LABEL_HEIGHT, lLineWidth, lLineHeight);
        lLine->setVisible(true);

        if(timestamp >= PLAY_END_MSEC_MAX)
        {
            lTimestamp->setText(QString().asprintf(Config::strTimeFormat().toStdString().c_str(), 24, 0, 0).left(5));
        }
        else
        {
            lTimestamp->setText(time.toString(Config::strQTimeFormat()).left(5));
        }
        if(xCenter + lTimestampWidth/2 > ui->wTimeTitle->width())
        {
            x0 = ui->wTimeTitle->width() - lTimestampWidth;
        }
        else
        {
            x0 = xCenter-lTimestampWidth/2;
        }
        lTimestamp->setGeometry(x0, 0, lTimestampWidth, TIMESTAMP_LABEL_HEIGHT);
        lTimestamp->setVisible(true);
        idx ++;
    }
    if(timelineLabelList.count() > idx)
    {
        for(;idx < timelineLabelList.count(); idx++)
        {
            timelineLabelList.at(idx).lLine->setVisible(false);
            timelineLabelList.at(idx).lTimestamp->setVisible(false);
        }
    }

    // update record section under wTouchBoard
    idx = 0;
    foreach(M3u8Play m3u8Play, m3u8PlayList)
    {
        if(m3u8Play.playEndMSec < playViewStartMSec ||
            m3u8Play.playStartMSec > playViewEndMSec)
            continue;
        if(widgetList.count() <= idx)
        {
            wdg = new QWidget(ui->wTime);
            wdg->setStyleSheet("border:0px;"    // transparent for Linux
                               "background: url(\":/images/slider_bar_bg_selected.png\");"); // default: repeat
            widgetList.append(wdg);
            ui->lCurrentline->raise();
            ui->wTouchBoard->raise();
        }
        wdg = widgetList.at(idx);
        if(m3u8Play.playStartMSec < playViewStartMSec)
        {
            x0 = ui->lStartline->x() + 0;
        }
        else
        {
            x0 = ui->lStartline->x() + (0.0 + m3u8Play.playStartMSec - playViewStartMSec) / playViewPeriodMSec * ui->wTimelineBar->width();
        }
        if(m3u8Play.playEndMSec > playViewEndMSec)
        {
            x1 = ui->lStartline->x() + ui->wTimelineBar->width();
        }
        else
        {
            x1 = ui->lStartline->x() + (0.0 + m3u8Play.playEndMSec - playViewStartMSec) / playViewPeriodMSec * ui->wTimelineBar->width();
        }
        width = qMax(2, (int)(x1 - x0));
//        qDebug() << "x0=" << x0 << "x1=" << x1 << "width=" << width;
        wdg->setVisible(true);
        wdg->setGeometry(x0, ui->wTimeTitle->height() + timelineBarOffsetY, width, timelineBarHeight);
        idx ++;
    }
    if(widgetList.count() > idx)
    {
        for(;idx < widgetList.count(); idx++)
        {
            widgetList.at(idx)->setVisible(false);
        }
    }

    mutex.unlock();
}

void Playback::play_update(bool bActive)
{
    play_list_update();
    play_timeline_update();
    play_control(playCurrentMSec, bActive);
}

void Playback::play_control(uint playNewMSec, bool bActive)
{
    int playGridIdx = playGridIndex();
    if(playGridIdx < 0)
    {
        return;
    }
    GridReal *grid = &viewProcess->file_gridReal[playGridIdx];
    QDateTime playNewTime = QDateTime(ui->rCalendar->getDateSelected(),
                                      QTime(0, 0, 0).addMSecs(playNewMSec));
    M3u8Play *pM3u8PlayNew = NULL;
    M3u8Play m3u8PlayNew;
    QList<M3u8Play> m3u8PlayMatchList;
    QString strMsg;

    foreach(M3u8Play m3u8Play, m3u8PlayList)
    {
        if(playNewMSec >= m3u8Play.playStartMSec && playNewMSec <= m3u8Play.playEndMSec)
        {
            m3u8PlayMatchList.append(m3u8Play);
        }
    }
    if(m3u8PlayMatchList.count() > 0)
    {
        if(m3u8PlayMatchList.count() > 1)
        {
            strMsg = QString("Error ! %1 records conflict: ").arg(m3u8PlayMatchList.count());
            // choose the nearest start ones, not the longest one
            uint startMSec = 0;
            foreach(M3u8Play m3u8Play, m3u8PlayMatchList)
            {
                strMsg.append(m3u8Play.m3u8Info.baseName + ", ");
                if(m3u8Play.playStartMSec > startMSec)
                {
                    startMSec = m3u8Play.playStartMSec;
                    m3u8PlayNew = m3u8Play;
                }
            }
        }
        else
        {
            m3u8PlayNew = m3u8PlayMatchList.at(0);
        }
        pM3u8PlayNew = &m3u8PlayNew;
    }
    if(DBG(_DBG_PLAYBACK_) || strMsg.length()>0)
    {
        if(strMsg.length() > 0)
        {
            qDebug() << STR_DBG_PLAY
                     << QString("playNewMSec=%1 ,playNewTime=%2 => %3")
                        .arg(strMSec(playNewMSec))
                        .arg(Config::strQDateTime(playNewTime))
                        .arg(strMsg);
        }
        else
        {
            qDebug() << STR_DBG_PLAY
                     << QString("playNewMSec = %1")
                        .arg(strMSec(playNewMSec));
        }
    }

    if(ui->tbPlayCtrl->getActived())
    {
        if(pM3u8PlayNew == NULL)
        {
            if(grid->status == GridReal::GridStatus_PLAY ||
               grid->status == GridReal::GridStatus_FILE_PAUSE)
            {
                viewProcess->file_stop(playGridIdx, Config::sys.seamless);
            }
        }
        else
        {
            int seekTime = (pM3u8PlayNew->crossStartMSec + playNewMSec - pM3u8PlayNew->playStartMSec)/1000;
            int seekTimeDelay = (pM3u8PlayNew->crossStartMSec + playNewMSec - pM3u8PlayNew->playStartMSec +
                                 Config::sys.playbackPlayDelayTime)/1000;
            bool bAlreadySameRec = false;
            if(pM3u8PlayCurr != NULL)
            {
                if(pM3u8PlayNew->m3u8Info.absPath == pM3u8PlayCurr->m3u8Info.absPath &&
                   (grid->status == GridReal::GridStatus_PLAY ||
                    grid->status == GridReal::GridStatus_FILE_PAUSE))
                {
                    bAlreadySameRec = true;
                }
            }
            if(bAlreadySameRec)
            {
                if(bActive)
                {
                    if(DBG(_DBG_PLAYBACK_))
                    {
                        qDebug() << STR_DBG_PLAY
                                 << "Same file => fileSetPlayTime() with seekTime=" << seekTime;
                    }
                    rtkApi->fileSetPlayTime(playGridIdx, seekTime);
                    if(ui->rspinSpeed->getValue() != PLAYBACK_SPEED_DEF)
                    {
                        ui->rspinSpeed->setValue(PLAYBACK_SPEED_DEF);   // to sync rtk api operation after seek
                        resetUpdateStartTime(playNewMSec);
                    }
                }
                else
                {
#if 0   // unsupport now
#if QT_ENV_ONLY != 1
                    uint64_t recCurrentTime;
                    if(rtkApi->fileGetPlayTime(playGridIdx, &recCurrentTime))
                    {
                        playNewMSec = (recCurrentTime * _K_ + pM3u8PlayNew->playStartMSec);
                        playNewTime = QDateTime(ui->rCalendar->getDateSelected(),
                                                QTime(0, 0, 0).addMSecs(playNewMSec));
                        if(DBG(_DBG_PLAYBACK_))
                        {
                            qDebug() << STR_DBG_PLAY
                                     << QString("after fileGetPlayTime(), plaplayCurrentMSec=%1 ,playCurrentTime=%2")
                                        .arg(strMSec(playNewMSec))
                                        .arg(Config::strQDateTime(playNewTime));
                        }
                        resetUpdateStartTime(playNewMSec);
                    }
                    else
                    {
                    }
#endif
#endif
                }
            }
            else
            {
                if(DBG(_DBG_PLAYBACK_))
                {
                    qDebug() << STR_DBG_PLAY
                             << "Diff file => file_start(), path=" << pM3u8PlayNew->m3u8Info.absPath;
                }
                {   // tune the seekTime for applying playbackPlayDelayTime
                    if (seekTimeDelay < 0 ||
                        (uint)seekTimeDelay < pM3u8PlayNew->playTimeMSec)
                    {
                        seekTime = seekTimeDelay;
                    }
                }
#if QT_ENV_ONLY == 1
                viewProcess->file_gridReal[playGridIdx].bgColor = QColor(rand()%255, rand()%255, rand()%255);
#endif
                viewProcess->file_start(playGridIdx, pM3u8PlayNew->m3u8Info.absPath,
                                        seekTime);
                if(bActive)
                {
                    if(ui->rspinSpeed->getValue() != PLAYBACK_SPEED_DEF)
                    {
                        ui->rspinSpeed->setValue(PLAYBACK_SPEED_DEF);   // to sync rtk api operation after seek
                        resetUpdateStartTime(playNewMSec);
                    }
                }
                else
                {
                    if(ui->rspinSpeed->getValue() != PLAYBACK_SPEED_DEF)
                    {
                        grid->setSpeed(ui->rspinSpeed->getValue());
                        resetUpdateStartTime(playNewMSec);
                    }
                }
            }
        }

        // quickly update current recording if necessary
        QDateTime currentTime = QDateTime::currentDateTime();
        uint currentMSec = QTime(0,0,0).msecsTo(currentTime.time());
        int idx = viewProcess->get_ipc_array_idx(ui->cbPlayChannel->currentIndex());
        if(idx >= 0 && idx<CHANNEL_MAX &&
           playNewTime.date() == currentTime.date())
        {
            GridReal *gridIpc = &viewProcess->ipc_gridReal[idx];
            if(gridIpc->bAlreadyRec &&
               (currentMSec > playNewMSec) &&
               (currentMSec - playNewMSec) < 120*_K_)
            {
                if(refetchTime.msecsTo(currentTime) >= 5*_K_)
                {
                    hlsProcess->setRefetch();
                    refetchTime = currentTime;
                    if(DBG(_DBG_PLAYBACK_))
                    {
                        qDebug() << STR_DBG_PLAY
                                 << "refetch at " << currentTime;
                    }
                }
            }
        }
    }
    else
    {
        if(grid->status == GridReal::GridStatus_PLAY ||
           grid->status == GridReal::GridStatus_FILE_PAUSE)
        {
            if(DBG(_DBG_PLAYBACK_))
            {
                qDebug() << STR_DBG_PLAY
                         << "Stop play => file_stop()";
            }
            viewProcess->file_stop(playGridIdx, Config::sys.seamless);
        }
    }

    if(pM3u8PlayNew != NULL)
    {
        pM3u8PlayCurr = &m3u8PlayCurr;
        m3u8PlayCurr.copy(*pM3u8PlayNew);
    }
    else
    {
        pM3u8PlayCurr = NULL;
    }
    ui->lFileName->setText((pM3u8PlayCurr == NULL)? PLAYBACK_NO_REC : pM3u8PlayCurr->m3u8Info.baseName);

    if(playNewMSec != playCurrentMSec)
    {
        playCurrentMSec = playNewMSec;
    }
    play_currentline_update(playCurrentMSec);
}

void Playback::file_channel_update()
{
    int i, idx;
    if(Config::sys.ipcChannelMax < CHANNEL_FOR_FILE_MAX)
    {
        return;
    }

    for(idx=0; idx<channelPageIdx; idx++)
    {
        btnFileChannelIdx[idx]->setVisible(false);
    }
    for(i=0, idx=channelPageIdx;
        i<CHANNEL_PER_FILE_PAGE && idx<CHANNEL_MAX;
        i++, idx++)
    {
        if (idx >= Config::sys.ipcChannelMax) // not fileChannelMax
        {
            btnFileChannelIdx[idx]->setVisible(false);
        }
        else
        {
            btnFileChannelIdx[idx]->setVisible(true);
        }
    }
    for(; idx<CHANNEL_MAX; idx++)
    {
        btnFileChannelIdx[idx]->setVisible(false);
    }
}

void Playback::file_list_update()
{
    QHash<QString, M3u8Info> *pHash;

    QDate selectedDate;
    QList<QString> strList;

    hlsProcess->mutex.lock();
    selectedDate = ui->rCalendar->getDateSelected();
    for(int chIdx=0; chIdx<CHANNEL_MAX; chIdx++)
    {
        m3u8ChannelList[chIdx].clear();
        pHash = &(hlsProcess->pM3u8Channel[chIdx]->hashM3u8);
        strList = hlsProcess->pM3u8Channel[chIdx]->hashKeyListByDate(selectedDate);
        foreach(QString absoluteFilePath, strList)
        {
            M3u8Info m3u8Info = pHash->value(absoluteFilePath);
            M3u8Play m3u8Play = tuneM3u8InfoToSelectedDate(m3u8Info, selectedDate);
            m3u8ChannelList[chIdx].append(m3u8Play);
        }
    }
    hlsProcess->mutex.unlock();

    btnFileChannelIdx_select();
}

void Playback::btnFileChannelNext_clicked(bool)
{
    channelPageIdx = (channelPageIdx + CHANNEL_PER_FILE_PAGE) % CHANNEL_MAX;
    channelPageIdx = (channelPageIdx >= Config::sys.ipcChannelMax) ? 0 : channelPageIdx;
    channelPageIdx = (channelPageIdx / CHANNEL_PER_FILE_PAGE) * CHANNEL_PER_FILE_PAGE;
    file_channel_update();
}

void Playback::btnFileChannelPrev_clicked(bool)
{
    do
    {
        channelPageIdx = (channelPageIdx + CHANNEL_MAX - CHANNEL_PER_FILE_PAGE) % CHANNEL_MAX;
        channelPageIdx = (channelPageIdx / CHANNEL_PER_FILE_PAGE) * CHANNEL_PER_FILE_PAGE;
    }
    while(channelPageIdx >= Config::sys.ipcChannelMax);
    file_channel_update();
}

void Playback::btnFileChannelIdx_clicked(bool)
{
    QObject *btn = sender();
    for (int i=0; i < CHANNEL_MAX; i++)
    {
        if(btnFileChannelIdx[i] == btn)
        {
            hlsProcess->setRefetch();
            fileChannelIdx = i;
            btnFileChannelIdx_select();
            return;
        }
    }
}

void Playback::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
#if 0
    ui->rCalendar->sbYear->installEventFilter(keypad);
    ui->rCalendar->sbMonth->installEventFilter(keypad);
#endif
    ui->wPageCtrl->installEventFilterForKeypad(keypad);
    Q_UNUSED(keyboard);
}

void Playback::updateTimeString()
{
    file_page_update();
    play_timeline_update();
    play_currentline_update(playCurrentMSec);
}

void Playback::updateBgColor()
{
    QString strBgColor = QString("background-color: rgb(%1, %2, %3);")
                                .arg(Config::setting.bgColorR)
                                .arg(Config::setting.bgColorG)
                                .arg(Config::setting.bgColorB);
//    qDebug() << strBgColor;
    ui->wBlank->setStyleSheet(strBgColor);
}

void Playback::setZoominOption(bool enable)
{
    ui->tbBack->setVisible(!enable);
    ui->tbGrid1->setVisible(!enable);
    ui->tbGrid4->setVisible(!enable);
    ui->tbGrid9->setVisible(!enable);
}

void Playback::btnFileChannelIdx_select()
{
    bool bCurrCh;
    bool bAlreadyRecData;
    uint bitmask = hlsProcess->getHashDateMask(ui->rCalendar->getDateSelected());

//    qDebug() << idx << ui->rCalendar->getDateSelected() << bitmask;
    for (int i=0; i < CHANNEL_MAX; i++)
    {
        bCurrCh = (i == fileChannelIdx);
        bAlreadyRecData = (((bitmask >> i) & 0x00000001) > 0);
        btnFileChannelIdx[i]->setStyleSheet(QString(
                    "QToolButton{"
                         "border:0px;"    // transparent for Linux
                         "%1"
                         "%4"             // background-color
                         "%3"
                         "}"
                    "QToolButton:hover{"
                         "border:0px;"    // transparent for Linux
                         "%2"
                         "background-color: rgb(54, 56, 59);"
                         "%3"
                         "}")
                    .arg(bCurrCh ?
                             ("color: " PLAYBACK_RGB_DARK) :
                             (bAlreadyRecData ?
                             ("color: " PLAYBACK_RGB_YELLOWGREEN) :
                             "color: rgb(107, 108, 107);"))
                    .arg(bAlreadyRecData ?
                             ("color: " PLAYBACK_RGB_YELLOWGREEN) :
                             "color: rgb(107, 108, 107);")
                    .arg("font: bold 14px \"Arial Black\";")
                    .arg(bCurrCh ?
                             ("background-color: " PLAYBACK_RGB_YELLOWGREEN) :
                             ("background-color: " PLAYBACK_RGB_DARK)));
    }
    QList<QToolButton *> btnList = {btnFileChannelPrev, btnFileChannelNext};
    foreach (QToolButton *btn, btnList)
    {
        btn->setStyleSheet(QString(
                          "QToolButton{"
                               "border:0px;"    // transparent for Linux
                               "%1"
                               "%4"             // background-color
                               "%3"
                               "}"
                          "QToolButton:hover{"
                               "border:0px;"    // transparent for Linux
                               "%2"
                               "background-color: rgb(54, 56, 59);"
                               "%3"
                               "}")
                          .arg("color: rgb(107, 108, 107);")
                          .arg("color: rgb(107, 108, 107);")
                          .arg("font: bold 14px \"Arial Black\";")
                          .arg("background-color: " PLAYBACK_RGB_DARK));
    }
    ui->wPageCtrl->setItemCount(m3u8ChannelList[fileChannelIdx].count());
}

void Playback::file_grid_selected(RToolButton *select_btn)
{
    QList<RToolButton *> gridBtnList = {ui->tbGrid1, ui->tbGrid4,
                                        ui->tbGrid9};
    RToolButton *btn;
    foreach(btn, gridBtnList)
    {
        if (btn == select_btn)
        {
            btn->setActive(true, true);
        }
        else
        {
            btn->setActive(false, false);
        }
    }
}

void Playback::file_grid1_selected(bool)
{
    int playGridIdx = playGridIndex();
    file_grid_selected(ui->tbGrid1);
    ui->tbGrid1->setActive(true, false);
    viewProcess->set_file_grid_num(1, playGridIdx);
}

void Playback::file_grid4_selected(bool)
{
    int playGridIdx = playGridIndex();
    file_grid_selected(ui->tbGrid4);
    ui->tbGrid4->setActive(true, false);
    viewProcess->set_file_grid_num(4, ((int)(playGridIdx/4))*4);
}

void Playback::file_grid9_selected(bool)
{
    int playGridIdx = playGridIndex();
    file_grid_selected(ui->tbGrid9);
    ui->tbGrid9->setActive(true, false);
    viewProcess->set_file_grid_num(9, ((int)(playGridIdx/9))*9);
}

void Playback::file_page_update()
{
//    qDebug() << __func__;
    QTableWidget *table = ui->twFile;
    QTableWidgetItem *newItem;
    QList<M3u8Play> list = m3u8ChannelList[fileChannelIdx];
    QString strTitle, strTime, strSize;
    int idx_start = ui->wPageCtrl->getPageCurr() * ui->wPageCtrl->getItemPerPage();
    int idx_end = qMin(idx_start + ui->wPageCtrl->getItemPerPage(), list.count());
    int count = idx_end - idx_start;
    int i;

    ui->lDate->setText(ui->rCalendar->strDateSelected(true));   // update here for timeformat
    for (i=table->rowCount()-1; i>=count; i--)
    {
        table->removeRow(i);
    }

    for(i=0; i<count; i++)
    {
        M3u8Play m3u8Play = list.at(i+idx_start);
        M3u8Info *pM3u8Info = &m3u8Play.m3u8Info;

        strTitle = m3u8Play.playStartTime.toString(Config::strQTimeFormat()) + "-" +
                   m3u8Play.playEndTime.toString(Config::strQTimeFormat());
        strTime = strMSec(m3u8Play.playTimeMSec, false);

        if(pM3u8Info->storeSize > 1000000000)
        {
            strSize = QString().asprintf("%.3f G", pM3u8Info->storeSize / 1000000000);
        }
        else if(pM3u8Info->storeSize > 1000000)
        {
            strSize = QString().asprintf("%.3f M", pM3u8Info->storeSize / 1000000);
        }
        else if(pM3u8Info->storeSize > 1000)
        {
            strSize = QString().asprintf("%.3f K", pM3u8Info->storeSize / 1000);
        }
        else
        {
            strSize = QString().asprintf("%.0f B", pM3u8Info->storeSize);
        }
        strSize += " ";

        if (table->rowCount() <= i)
        {
            table->insertRow(i);
            table->setRowHeight(i, 32);
            newItem= new QTableWidgetItem(strTitle);
            table->setItem(i, twFile_ColumnIdx_Title, newItem);
            table->item(i, twFile_ColumnIdx_Title)->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
            newItem = new QTableWidgetItem(strTime);
            table->setItem(i, twFile_ColumnIdx_Time, newItem);
            table->item(i, twFile_ColumnIdx_Time)->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
            newItem = new QTableWidgetItem(strSize);
            table->setItem(i, twFile_ColumnIdx_Size, newItem);
            table->item(i, twFile_ColumnIdx_Size)->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            newItem = new QTableWidgetItem(pM3u8Info->absPath);
            table->setItem(i, twFile_ColumnIdx_AbsPath, newItem);
        }
        else
        {
            table->item(i, twFile_ColumnIdx_Title)->setText(strTitle);
            table->item(i, twFile_ColumnIdx_Time)->setText(strTime);
            table->item(i, twFile_ColumnIdx_Size)->setText(strSize);
            table->item(i, twFile_ColumnIdx_AbsPath)->setText(pM3u8Info->absPath);
        }
    }
}

QString Playback::strMSec(uint msec, bool showMSec)
{
    QString str = Config::strTime(msec/_K_);
    if(showMSec)
    {
        str += QString().asprintf(".%03d", msec%_K_);
    }
    return str;
}
