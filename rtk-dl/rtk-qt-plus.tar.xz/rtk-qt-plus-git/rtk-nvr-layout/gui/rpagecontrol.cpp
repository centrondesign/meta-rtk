/**
 * @file rlineedit.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The extension of QLineEdit
 */

#include "rpagecontrol.h"
#include "mainwidget.h"

RPageControl::RPageControl(QWidget *parent) :
    QWidget(parent)
{
    btnPrev = new QToolButton(this);
    btnNext = new QToolButton(this);
    leCurrent = new RLineEdit(this);
    lTotal = new QLabel(this);
    btnPrev->setStyleSheet(
                "QToolButton {"
                        "background: url(\":/images/playback_prev_normal.png\") transparent top center no-repeat;"
                        "}"
                "QToolButton:hover {"
                        "background: url(\":/images/playback_prev_hover.png\") transparent top center no-repeat;"
                        "}"
                );
    btnNext->setStyleSheet(
                "QToolButton {"
                        "background: url(\":/images/playback_next_normal.png\") transparent top center no-repeat;"
                        "}"
                "QToolButton:hover {"
                        "background: url(\":/images/playback_next_hover.png\") transparent top center no-repeat;"
                        "}"
                );
    leCurrent->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    leCurrent->setStyleSheet(
                        "QLineEdit {"
                            "border: 0px;"
                            "color: rgb(140, 140, 140);"
                            "font: bold 14px \"Arial Black\";"
                            "}"
                        "QLineEdit:hover {"
                            "background: rgb(204, 204, 204);"
                            "border-radius:16px;"
                            "border: 0px;"
                            "color: rgb(140, 140, 140);"
                            "font: bold 14px \"Arial Black\";"
                            "}");
    lTotal->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    lTotal->setStyleSheet("border: 0px solid;"
                          "color: rgb(140, 140, 140);"
                          "font: bold 14px \"Arial Black\";");

    pageCurr = 0;
    pageCount = 1;
    itemPerPage = 20;
    itemCount = 0;
    btnSize = 45;

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;
    installEventFilter(this);

    connect(this->btnPrev, SIGNAL(clicked(bool)), this, SLOT(pagePrev(bool)));
    connect(this->btnNext, SIGNAL(clicked(bool)), this, SLOT(pageNext(bool)));

    // to close the visual keyboard/keypad in screen after typing "enter" key in physical keyboard
    connect(this->leCurrent, SIGNAL(returnPressed()), this, SLOT(closeKeyboard()));
}

RPageControl::~RPageControl()
{
}

void RPageControl::initItemPerPage(int itemPerPage)
{
    this->itemPerPage = itemPerPage;
}

void RPageControl::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
    leCurrent->setParentAbsoluteOffset(x+this->x(), y+this->y());
}

void RPageControl::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);
    int leWidth = btnSize;
    int x = qMax(0, rect.width()-(btnSize*2+leWidth*2))/2;
    int y = qMax(0, (rect.height()-btnSize)/2);

    btnPrev->setGeometry(x, y, btnSize, btnSize);
    x += btnSize;
    leCurrent->setGeometry(x, y, leWidth, btnSize);
    x += leWidth;
    lTotal->setGeometry(x, y, leWidth, btnSize);
    x += leWidth;
    btnNext->setGeometry(x, y, btnSize, btnSize);
}

void RPageControl::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void RPageControl::installEventFilterForKeypad(QObject *keypad)
{
    leCurrent->installEventFilter(keypad);
}

bool RPageControl::eventFilter(QObject *o, QEvent *e)
{
    RLineEdit *le = (RLineEdit *)o;
    int center_x, new_x, new_y, shift_y;

    if(le == this->leCurrent &&
       e->type() == QEvent::MouseButtonPress)
    {
//        qDebug() << __func__;
//        qDebug() << this->x() << this->y() << this->width() << this->height();
//        qDebug() << "parent_absolute_offset_x=" << parent_absolute_offset_x;
//        qDebug() << "parent_absolute_offset_y=" << parent_absolute_offset_y;
//        qDebug() << "this";
//        qDebug() << this->x() << this->y() << this->width() << this->height();

        QList<QWidget *>keyList = {keyboard, keypad};
        foreach (QWidget *key, keyList)
        {
            center_x = this->parent_absolute_offset_x + this->x() + this->width()/2;
            new_x = center_x - key->width()/2;
            new_y = this->parent_absolute_offset_y + this->y() + this->height();
            if (new_x<0)
            {
                new_x=0;
            }
            else if (new_x + key->width() > Config::sys.width)
            {
                new_x = Config::sys.width - key->width();
            }
            shift_y = (key == keyboard) ? KEYBOARD_Y_OFFSET : 0;
            // tune the widget position
            key->setGeometry(new_x,
                                new_y + shift_y,
                                key->width(),
                                key->height());
//            qDebug() << key->x() << key->y() << key->width()<< key->height();
        }

    }
    return QObject::eventFilter(o, e);
}

void RPageControl::closeKeyboard()
{
    QList<QWidget *>keyList = {keyboard, keypad};
    foreach(QWidget *key, keyList)
    {
        if (key->isVisible())
        {
            key->setVisible(false);
        }
    }
    if(leCurrent->isTextValid(NULL, true))
    {
        pageCurr = (int)(leCurrent->getValue()) - 1;
        pageUpdate(true);
    }
    else
    {
        leCurrent->setText(QString("%1").arg(pageCurr+1));
    }
}

void RPageControl::pagePrev(bool)
{
    if (pageCurr <= 0)
        return;
    pageCurr --;
    pageUpdate(true);
}

void RPageControl::pageNext(bool)
{
    if (pageCurr + 1 >= pageCount)
        return;
    pageCurr ++;
    pageUpdate(true);
}

void RPageControl::updatePageCount()
{
    pageCount = (itemCount / itemPerPage);
    if (itemCount > 0 &&
        itemCount % itemPerPage == 0)
    {
    }
    else
    {
        pageCount ++;
    }
    if (pageCurr >= pageCount)
        pageCurr = pageCount-1;
    leCurrent->setValueRange(1, pageCount, 0);
}

void RPageControl::setItemCount(int count)
{
//    qDebug() << __func__ << count;
    itemCount = count;
    updatePageCount();
    pageUpdate(true);
}

void RPageControl::setItemPerPage(int count)
{
    if (count < 0)
        return;
    itemPerPage = count;
    updatePageCount();
    pageUpdate(true);
}

int RPageControl::getItemPerPage()
{
    return itemPerPage;
}

int RPageControl::getPageCurr()
{
    return pageCurr;
}

void RPageControl::pageUpdate(bool ifSignal)
{
    btnPrev->setVisible((pageCurr > 0));
    btnNext->setVisible((pageCurr+1 < pageCount));

    leCurrent->setText(QString("%1").arg(pageCurr+1));
    lTotal->setText(QString(" / %1").arg(pageCount));
    if(ifSignal)
    {
        emit(pageUpdated());
    }
}
