/**
 * @file playback.h
 * @author Realtek Semiconductor Corp.
 * @date Oct 2017
 * @brief The widget page to do playback operation
 */

#ifndef PLAYBACK_H
#define PLAYBACK_H

#include <QWidget>
#include <QTimer>
#include <QToolButton>
#include <QList>
#include "rcalendarwidget.h"
#include "rtoolbutton.h"
#include "rframe.h"
#include "m3u8info.h"

namespace Ui {
class Playback;
}

class Playback : public QWidget
{
    Q_OBJECT

public:
    RFrame *fileFrame[CHANNEL_MAX];
    RCalendarWidget *rCalendar;
    QToolButton *btnFileChannelNext, *btnFileChannelPrev;
    QToolButton *btnFileChannelIdx[CHANNEL_MAX];
    int channelPageIdx; // start channel idx of this page
    int fileChannelIdx;
    int playChannelIdx;

    explicit Playback(QWidget *parent = 0);
    ~Playback();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);
    void updateTimeString();
    void updateBgColor();
    void setZoominOption(bool enable);
    void btnFileChannelIdx_select();
    void file_channel_update();
    void file_list_update();
    void play_list_update();
    void play_currentline_update(uint playNewMSec);
    void play_timeline_update();
    void play_update(bool bActive=false);
    void play_control(uint playNewMSec, bool bActive=false);
    QString strMSec(uint msec, bool showMSec=true);

private:
    typedef struct
    {
        QLabel  *lTimestamp;
        QFrame  *lLine;
    } TIME_LABEL_S;

    typedef struct
    {
        uint    viewPeriod; // unit: msec
        uint    viewUnit;   // unit: msec
        uint    seekUnit;   // unit: msec
    } VIEW_OPT_S;

    class M3u8Play
    {
    public:
        M3u8Info m3u8Info;
        uint crossStartMSec;  // unit: msec, to tune overnight
        QDateTime playStartTime;
        QDateTime playEndTime;
        uint playStartMSec; // unit: msec
        uint playEndMSec;   // unit: msec
        uint playTimeMSec;      // unit: msec

        void copy(M3u8Play src)
        {
            m3u8Info.copy(src.m3u8Info);
            crossStartMSec = src.crossStartMSec;
            playStartTime = src.playStartTime;
            playEndTime = src.playEndTime;
            playStartMSec = src.playStartMSec;
            playEndMSec = src.playEndMSec;
            playTimeMSec = src.playTimeMSec;
        }
    };

    Ui::Playback *ui;
    QMutex mutex;
    QTimer *timelineTimer;
    QString tbFileStyleSheet_normal, tbFileStyleSheet_select;
    bool bBlankHideWhole;
    QTimer *blankHideTimer;
    QList<M3u8Play> m3u8ChannelList[CHANNEL_MAX];
    QList<M3u8Play> m3u8PlayList;
    M3u8Play m3u8PlayCurr;
    M3u8Play *pM3u8PlayCurr;
    int timelineBarOffsetY, timelineBarHeight;
    QList<QWidget *> widgetList;
    QList<TIME_LABEL_S> timelineLabelList;
    QList<VIEW_OPT_S> timelineViewList;
    int timelineViewIdx;
    uint playViewStartMSec, playViewEndMSec, playViewPeriodMSec;
    uint playViewUnitMSec, playSeekMSec;
    uint playCurrentMSec;    // current sec from 00:00:00
    uint updateStartMSec;
    QDateTime updateStartTime;
    int queryTimeCount;
    QDateTime refetchTime;
    bool bIfPlayBefore;

    typedef enum
    {
        twFile_ColumnIdx_Title      = 0,
        twFile_ColumnIdx_Time       = 1,
        twFile_ColumnIdx_Size       = 2,
        twFile_ColumnIdx_AbsPath    = 3,
    } TwFile_ColumnIdx_E;

    void file_grid_selected(RToolButton *btn);
    void btnPlayZoom_tune();
    void resetUpdateStartTime(uint newMSec);
    int playGridIndex();

protected:
    void showEvent(QShowEvent *);
    bool eventFilter(QObject *o, QEvent *e);

private slots:
    void timer_update();
    void timer_blankHide();

    void calendar_day_clicked();
    void close_clicked(bool);
    void file_open_clicked(bool);
    void file_close_clicked(bool);
    void play_channel_changed(int);
    void speed_changed(bool);
    void mute_changed(bool);
    void volume_changed(int);
    void playCtrl_clicked(bool);
    void playCtrl_action(bool bSeamless);
    void playCtrl_stop(bool bSeamless);
    void btnPlaySeekBack_clicked(bool);
    void btnPlaySeekFront_clicked(bool);
    void btnPlayZoomOut_clicked(bool);
    void btnPlayZoomIn_clicked(bool);
    void btnPlayShiftLeft_clicked(bool);
    void btnPlayShiftRight_clicked(bool);
    M3u8Play tuneM3u8InfoToSelectedDate(M3u8Info m3u8Info, QDate selectedDate);
    void btnFileChannelNext_clicked(bool);
    void btnFileChannelPrev_clicked(bool);
    void btnFileChannelIdx_clicked(bool);
    void file_grid1_selected(bool);
    void file_grid4_selected(bool);
    void file_grid9_selected(bool);
    void file_page_update();

};

#endif // PLAYBACK_H
