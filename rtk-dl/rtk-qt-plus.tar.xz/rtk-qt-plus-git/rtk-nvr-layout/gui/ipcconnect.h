/**
 * @file ipcconnect.h
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The widget page to connect IPC
 */

#ifndef IPCCONNECT_H
#define IPCCONNECT_H

#include <QWidget>
#include <QList>
#include <QLabel>
#include <QComboBox>
#include "rtablayer.h"
#include "define.h"
#include "rlineedit.h"
#include "rcheckbox.h"

namespace Ui {
class IpcConnect;
}

class IpcConnect : public QWidget
{
    Q_OBJECT

public:
    QList<QLabel*> *lStatusList;

    explicit IpcConnect(QWidget *parent = 0);
    ~IpcConnect();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setParentAbsoluteOffset(int x, int y);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);
    void set_apply(bool ifDialog, bool ifSave);

private:
    Ui::IpcConnect *ui;
//    RTabLayer *tlIpcConnect;
    int parent_absolute_offset_x, parent_absolute_offset_y;
    QList<QLabel*> *lChannelList;
    QList<RLineEdit *> *edList;
    QList<QComboBox *> *comboBoxList;
    QList<RCheckBox*> *checkBoxList;

    void initValue();
    void initWidgetEdit(int chIdx);

private slots:
    void showEvent(QShowEvent *);
    void knownIpc_clicked(bool);
    void usrDefine_clicked(bool);
    void ip_index_changed(int);
    void rtsp_cancel_clicked(bool);
    void rtsp_set_clicked(bool);
    void set_clicked(bool);

protected:
//    void showEvent(QShowEvent *event);
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // IPCCONNECT_H
