/**
 * @file videodebug.h
 * @author Realtek Semiconductor Corp.
 * @date Dec 2018
 * @brief The widget page to do video debug operation
 */

#ifndef VIDEODEBUG_H
#define VIDEODEBUG_H

#include <QWidget>
#include <QTimer>
#include <QToolButton>
#include <QList>
#include "rcalendarwidget.h"
#include "rtoolbutton.h"
#include "rframe.h"
#include "m3u8info.h"

namespace Ui {
class VideoDebug;
}

class VideoDebug : public QWidget
{
    Q_OBJECT

public:
    RFrame *fileFrame[CHANNEL_MAX];
    RCalendarWidget *rCalendar;
    QToolButton *btnFileChannelNext, *btnFileChannelPrev;
    QToolButton *btnFileChannelIdx[CHANNEL_MAX];
    int channelPageIdx; // start channel idx of this page
    int fileChannelIdx;
    int playChannelIdx;

    explicit VideoDebug(QWidget *parent = 0);
    ~VideoDebug();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);

private:
    Ui::VideoDebug *ui;
    QWidget *keyboard;
    QWidget *keypad;

protected:
    void showEvent(QShowEvent *);
    void mousePressEvent(QMouseEvent *);
    QWidget* getVisibleWidget(QMouseEvent *);
    QWidget* getClickedWidget(QMouseEvent *);
    bool eventFilter(QObject *o, QEvent *e);

private slots:
    void close_clicked(bool);
    void file_open_clicked(bool);
    void file_close_clicked(bool);

};

#endif // VIDEODEBUG_H
