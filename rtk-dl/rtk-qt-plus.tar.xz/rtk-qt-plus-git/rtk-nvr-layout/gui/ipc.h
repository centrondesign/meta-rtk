/**
 * @file ipc.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page to set IP camera
 */

#ifndef IPC_H
#define IPC_H

#include <QWidget>
#include <QTimer>
#include "rtablayer.h"
#include "rslider.h"

namespace Ui {
class Ipc;
}

class Ipc : public QWidget
{
    Q_OBJECT

public:
    RSlider *rsBrightness, *rsContrast, *rsHue, *rsSaturation, *rsSharpness;

    explicit Ipc(QWidget *parent = 0);
    ~Ipc();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setParentAbsoluteOffset(int x, int y);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);

private:
    Ui::Ipc *ui;
    RTabLayer *tlIpc, *tlDisplay;
    int parent_absolute_offset_x, parent_absolute_offset_y;
    QTimer *imgBrightnessTimer, *imgContrastTimer, *imgHueTimer,
           *imgSaturationTimer, *imgSharpnessTimer;

    void initValue(bool fromStatus);
    void getDisplayImage(bool fromStatus);
    void image_frame_changed(int chIdx_new);

private slots:
    void image_channel_changed(int);
    void image_reset_clicked(bool);
    void system_set_clicked(bool);
    void brightness_value_changed(int);
    void contrast_value_changed(int);
    void hue_value_changed(int);
    void saturation_value_changed(int);
    void sharpness_value_changed(int);
    void apply_brightness();
    void apply_contrast();
    void apply_hue();
    void apply_saturation();
    void apply_sharpness();

protected:
//    void showEvent(QShowEvent *);
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // IPC_H
