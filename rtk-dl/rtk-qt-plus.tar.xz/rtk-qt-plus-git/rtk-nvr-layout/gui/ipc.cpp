/**
 * @file ipc.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page to set IP camera
 */

#include "ipc.h"
#include "ui_ipc.h"
#include "mainwidget.h"

Ipc::Ipc(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Ipc)
{
    ui->setupUi(this);

    QList<QToolButton *> btnLayer1 = {ui->tbAdd, ui->tbDisplay};
    tlIpc = new RTabLayer(this);
    tlIpc->init(btnLayer1, ui->stkLayer1, TABLAYER_LAYER_1);

    QList<QToolButton *> btnLayerDisplay = {ui->tbImage, ui->tbSystem};
    tlDisplay = new RTabLayer(this);
    tlDisplay->init(btnLayerDisplay, ui->stkDisplay, TABLAYER_LAYER_2);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;

    ui->lIpc->setStyleSheet(STYLESHEET_TITLE_2);
    ui->pgImage->installEventFilter(this);
    ui->pgSystem->installEventFilter(this);

    QList<QWidget *>wList = {ui->wTitle,
                             ui->wImageSet, ui->pgAdd, ui->pgSystem};
    for(int i=0; i<wList.count(); i++)
    {
        wList.at(i)->setStyleSheet("background-color: rgb(20, 25, 28);");
    }
    QList<QWidget *>wBgList = {ui->wUp, ui->wLeft, ui->wRight, ui->wDown,
                               ui->wImageBottom,};
    for(int i=0; i<wBgList.count(); i++)
    {
        wBgList.at(i)->setStyleSheet("background-color: rgb(20, 25, 28);");
        wBgList.at(i)->lower();
    }
    connect(ui->tbImageReset, SIGNAL(clicked(bool)), this, SLOT(image_reset_clicked(bool)));
    connect(ui->tbDisplaySystemSet, SIGNAL(clicked(bool)), this, SLOT(system_set_clicked(bool)));

    rsBrightness = ui->rsBrightness;
    rsContrast = ui->rsContrast;
    rsHue = ui->rsHue;
    rsSaturation = ui->rsSaturation;
    rsSharpness = ui->rsSharpness;
    connect(ui->rsBrightness, SIGNAL(valueChanged(int)), this, SLOT(brightness_value_changed(int)));
    connect(ui->rsContrast, SIGNAL(valueChanged(int)), this, SLOT(contrast_value_changed(int)));
    connect(ui->rsHue, SIGNAL(valueChanged(int)), this, SLOT(hue_value_changed(int)));
    connect(ui->rsSaturation, SIGNAL(valueChanged(int)), this, SLOT(saturation_value_changed(int)));
    connect(ui->rsSharpness, SIGNAL(valueChanged(int)), this, SLOT(sharpness_value_changed(int)));
    imgBrightnessTimer = new QTimer(this);
    imgBrightnessTimer->setSingleShot(true);
    imgBrightnessTimer->setInterval(200);
    imgContrastTimer = new QTimer(this);
    imgContrastTimer->setSingleShot(true);
    imgContrastTimer->setInterval(200);
    imgHueTimer = new QTimer(this);
    imgHueTimer->setSingleShot(true);
    imgHueTimer->setInterval(200);
    imgSaturationTimer = new QTimer(this);
    imgSaturationTimer->setSingleShot(true);
    imgSaturationTimer->setInterval(200);
    imgSharpnessTimer = new QTimer(this);
    imgSharpnessTimer->setSingleShot(true);
    imgSharpnessTimer->setInterval(200);
    connect(imgBrightnessTimer, SIGNAL(timeout()), this, SLOT(apply_brightness()));
    connect(imgContrastTimer,   SIGNAL(timeout()), this, SLOT(apply_contrast()));
    connect(imgHueTimer,        SIGNAL(timeout()), this, SLOT(apply_hue()));
    connect(imgSaturationTimer, SIGNAL(timeout()), this, SLOT(apply_saturation()));
    connect(imgSharpnessTimer, SIGNAL(timeout()), this, SLOT(apply_sharpness()));
}

Ipc::~Ipc()
{
    delete imgSharpnessTimer;
    delete imgSaturationTimer;
    delete imgHueTimer;
    delete imgContrastTimer;
    delete imgBrightnessTimer;
    delete tlIpc;
    delete tlDisplay;
    delete ui;
}

void Ipc::setup()
{
    labelList->append({ui->lImageChannel, ui->lBrightness, ui->lContrast, ui->lHue,
                       ui->lSaturation, ui->lSharpness,
                       ui->lImageReset, ui->lBootupConnection, ui->lTagLignment,
                       ui->lSlideshowInt, ui->lSlideshowIntUnit});
    editList->append({ui->leSlideshowInt});
    for (int i=0; i<Config::sys.ipcChannelMax; i++)
    {
        ui->cbImageChannel->addItem(QString().asprintf("Channel %02d", i+1));
    }
    connect(ui->cbImageChannel, SIGNAL(currentIndexChanged(int)), this, SLOT(image_channel_changed(int)));

    ui->rsBrightness->setValueRange(IMAGE_VALUE_MIN - IMAGE_VALUE_OFFSET,
                                    IMAGE_VALUE_MAX - IMAGE_VALUE_OFFSET,
                                    1, 0);
    ui->rsContrast->setValueRange(IMAGE_VALUE_MIN - IMAGE_VALUE_OFFSET,
                                  IMAGE_VALUE_MAX - IMAGE_VALUE_OFFSET,
                                  1, 0);
    ui->rsHue->setValueRange(IMAGE_VALUE_MIN - IMAGE_VALUE_OFFSET,
                             IMAGE_VALUE_MAX - IMAGE_VALUE_OFFSET,
                             1, 0);
    ui->rsSaturation->setValueRange(IMAGE_VALUE_MIN - IMAGE_VALUE_OFFSET,
                                    IMAGE_VALUE_MAX - IMAGE_VALUE_OFFSET,
                                    1, 0);
    ui->rsSharpness->setValueRange(SHARPNESS_VALUE_MIN,
                                    SHARPNESS_VALUE_MAX,
                                    1, 0);
    ui->leSlideshowInt->setValueRange(ui->lSlideshowInt,
                                      SLIDESHOW_INTERVAL_MIN, SLIDESHOW_INTERVAL_MAX, 0);
#if 0
    optionList->append({ui->cbImageChannel, ui->cbBootupConnection, ui->cbTagAlignment});
#else
    ui->cbImageChannel->setStyleSheet(STYLESHEET_COMBOBOX);
    ui->cbBootupConnection->setStyleSheet(STYLESHEET_COMBOBOX);
    ui->cbTagAlignment->setStyleSheet(STYLESHEET_COMBOBOX);
#endif
    actionList->append({ui->tbImageReset, ui->tbDisplaySystemSet});
    tlIpc->clickTabIndex(0);
    tlDisplay->clickTabIndex(0);
}

void Ipc::initValue(bool fromStatus)
{
    if(ui->pgImage->isVisible())
    {
        getDisplayImage(fromStatus);
    }
    else if(ui->pgSystem->isVisible())
    {
        ui->cbBootupConnection->setCurrentIndex(Config::sys.bootupIpcConnect);
        ui->cbTagAlignment->setCurrentIndex(Config::style.tagAlignment);
        ui->leSlideshowInt->setText(Config::setting.slideshowInterval);
    }
}

void Ipc::getDisplayImage(bool fromStatus)
{
    int chIdx = ui->cbImageChannel->currentIndex();
    int idx = viewProcess->get_ipc_array_idx(chIdx);
    GridReal *grid = &viewProcess->ipc_gridReal[idx];
    if(fromStatus)
    {
        if(grid->status == GridReal::GridStatus_PLAY ||
           grid->status == GridReal::GridStatus_IPC_HIDE)
        {
            unsigned int value;
            if(rtkApi->qt_rtk_disp_get_channel_brightness(
                        STR_IPC, idx, chIdx, grid->wndId, &value))
            {
                Config::ipc.ch[chIdx].brightness = value;
            }
            if(rtkApi->qt_rtk_disp_get_channel_contrast(
                        STR_IPC, idx, chIdx, grid->wndId, &value))
            {
                Config::ipc.ch[chIdx].contrast = value;
            }
            if(rtkApi->qt_rtk_disp_get_channel_hue(
                        STR_IPC, idx, chIdx, grid->wndId, &value))
            {
                Config::ipc.ch[chIdx].hue = value;
            }
            if(rtkApi->qt_rtk_disp_get_channel_saturation(
                        STR_IPC, idx, chIdx, grid->wndId, &value))
            {
                Config::ipc.ch[chIdx].saturation = value;
            }
            if(rtkApi->qt_rtk_disp_get_channel_sharpness(
                        STR_IPC, idx, chIdx, grid->wndId, &value))
            {
                Config::ipc.ch[chIdx].sharpness = value;
            }
        }
    }
    ui->rsBrightness->setEmitValueChanged(false);
    ui->rsBrightness->setValue((double)Config::ipc.ch[chIdx].brightness - IMAGE_VALUE_OFFSET);
    ui->rsBrightness->setEmitValueChanged(true);
    ui->rsContrast->setEmitValueChanged(false);
    ui->rsContrast->setValue((double)Config::ipc.ch[chIdx].contrast - IMAGE_VALUE_OFFSET);
    ui->rsContrast->setEmitValueChanged(true);
    ui->rsHue->setEmitValueChanged(false);
    ui->rsHue->setValue((double)Config::ipc.ch[chIdx].hue - IMAGE_VALUE_OFFSET);
    ui->rsHue->setEmitValueChanged(true);
    ui->rsSaturation->setEmitValueChanged(false);
    ui->rsSaturation->setValue((double)Config::ipc.ch[chIdx].saturation - IMAGE_VALUE_OFFSET);
    ui->rsSaturation->setEmitValueChanged(true);
    ui->rsSharpness->setEmitValueChanged(false);
    ui->rsSharpness->setValue((double)Config::ipc.ch[chIdx].sharpness);
    ui->rsSharpness->setEmitValueChanged(true);
}

void Ipc::setGeometry(const QRect &rect)
{
//    qDebug() << __func__ << "(const QRect &rect)";
    QWidget::setGeometry(rect);

    int frameTopY = ui->wTitle->y()+ui->wTitle->height();
    int frameRightX = ui->stkLayer1->x()+ui->stkDisplay->x() + ui->stkDisplay->width();
    int frameDownY = ui->stkLayer1->y()+ui->stkDisplay->y() + ui->stkDisplay->height();
    ui->wTitle->setGeometry(0, 0, rect.width(), ui->wTitle->height());
    ui->wUp->setGeometry(0, ui->wTitle->height(), rect.width(), ui->stkDisplay->y());
    ui->wLeft->setGeometry(0, frameTopY, ui->stkLayer1->x()+ui->stkDisplay->x(), rect.height() - frameTopY);
    ui->wRight->setGeometry(frameRightX, frameTopY, rect.width()-frameRightX, rect.height() - frameTopY);
    ui->wDown->setGeometry(0, frameDownY, rect.width(), rect.height() - frameDownY);

    RLineEdit *le;
    int tab_x_offset = parent_absolute_offset_x+rect.x()+ui->stkLayer1->x()+ui->stkDisplay->x();
    int tab_y_offset = parent_absolute_offset_y+rect.y()+ui->stkLayer1->y()+ui->stkDisplay->y();
    QList<RLineEdit *>leSystemList = {ui->leSlideshowInt};
    foreach(le, leSystemList)
    {
        le->setParentAbsoluteOffset(tab_x_offset, tab_y_offset);
    }
}

void Ipc::setGeometry(int x, int y, int w, int h)
{
//    qDebug() << __func__ << "(int x, int y, int w, int h)";
    this->setGeometry(QRect(x, y, w, h));
}

void Ipc::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void Ipc::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    QList<RLineEdit *>keybadList = {ui->leSlideshowInt};

    RLineEdit *le;
    foreach(le, keybadList)
    {
        le->installEventFilter(keypad);
    }
    Q_UNUSED(keyboard);
}

bool Ipc::eventFilter(QObject *o, QEvent *e)
{
    if(e->type() == QEvent::Show)
    {
        if(o == ui->pgImage ||
           o == ui->pgSystem)
        {
//            qDebug() << o << e;
            initValue(true);
        }
        if(o == ui->pgImage)
        {
            image_frame_changed(ui->cbImageChannel->currentIndex());
        }
    }
    else if(e->type() == QEvent::Hide)
    {
        if(o == ui->pgImage)
        {
            viewProcess->ipc_setViewMode(ViewProcess::ViewMode_Grid,
                                         viewProcess->get_ipc_grid_num());
        }
    }
    return QObject::eventFilter(o, e);
}

void Ipc::image_frame_changed(int chIdx_new)
{
//    qDebug() << __func__ << chIdx_new;

    int idx = viewProcess->get_ipc_array_idx(chIdx_new);
    viewProcess->ipc_setViewMode(ViewProcess::ViewMode_Set,
                                 idx);
}

void Ipc::image_channel_changed(int)
{
    getDisplayImage(true);
    image_frame_changed(ui->cbImageChannel->currentIndex());
}

void ipc_image_reset_confirm()
{
    ipc->rsBrightness->setValue(IMAGE_VALUE_DEF - IMAGE_VALUE_OFFSET);
    ipc->rsContrast->setValue(IMAGE_VALUE_DEF - IMAGE_VALUE_OFFSET);
    ipc->rsHue->setValue(IMAGE_VALUE_DEF - IMAGE_VALUE_OFFSET);
    ipc->rsSaturation->setValue(IMAGE_VALUE_DEF - IMAGE_VALUE_OFFSET);
    ipc->rsSharpness->setValue(SHARPNESS_VALUE_DEF);
}

void Ipc::image_reset_clicked(bool)
{
    dialog->showConfirm(QString("Do you confirm to reset %1 to default value ?")
                        .arg(ui->cbImageChannel->currentText()),
                        &(ipc_image_reset_confirm));
}

void Ipc::system_set_clicked(bool)
{
    Config::sys.bootupIpcConnect = ui->cbBootupConnection->currentIndex();
    Config::style.tagAlignment = ui->cbTagAlignment->currentIndex();
    Config::setting.slideshowInterval = ui->leSlideshowInt->getValue();
    Config::saveDefaultProfile();

    QRect rect;
    for(int i=0; i<CHANNEL_MAX; i++)
    {
        rect = mainWidget->ipcFrame[i]->rect();
        mainWidget->ipcFrame[i]->setGeometry(rect);
        rect = playback->fileFrame[i]->rect();
        playback->fileFrame[i]->setGeometry(rect);
    }
    viewProcess->set_slideshow_interval();
    dialog->showInfo(STR_SETTING_APPLY);
}

void Ipc::brightness_value_changed(int)
{
    if(imgBrightnessTimer->isActive() != true)
    {
        imgBrightnessTimer->start();
    }
}

void Ipc::contrast_value_changed(int)
{
    if(imgContrastTimer->isActive() != true)
    {
        imgContrastTimer->start();
    }
}

void Ipc::hue_value_changed(int)
{
    if(imgHueTimer->isActive() != true)
    {
        imgHueTimer->start();
    }
}

void Ipc::saturation_value_changed(int)
{
    if(imgSaturationTimer->isActive() != true)
    {
        imgSaturationTimer->start();
    }
}

void Ipc::sharpness_value_changed(int)
{
    if(imgSharpnessTimer->isActive() != true)
    {
        imgSharpnessTimer->start();
    }
}

void Ipc::apply_brightness()
{
    int chIdx = ui->cbImageChannel->currentIndex();
    int idx = viewProcess->get_ipc_array_idx(chIdx);
    GridReal *grid = &viewProcess->ipc_gridReal[idx];
    uint value = (uint)(ui->rsBrightness->getValue() + IMAGE_VALUE_OFFSET);

#if 1
    if(grid->wndId > WindowId_Invalid)
#else
    if(grid->status == GridReal::GridStatus_PLAY ||
       grid->status == GridReal::GridStatus_IPC_HIDE)
#endif
    {
        if(rtkApi->qt_rtk_disp_set_channel_brightness(
                    STR_IPC, idx, chIdx, grid->wndId,
                    value) != true)
        {
            QString msg = "Fail to apply " + ui->lBrightness->text() + " !";
            qDebug() << msg;
        }
    }
    imgBrightnessTimer->stop();
    Config::ipc.ch[chIdx].brightness = value;
    Config::saveDefaultProfile();
}

void Ipc::apply_contrast()
{
    int chIdx = ui->cbImageChannel->currentIndex();
    int idx = viewProcess->get_ipc_array_idx(chIdx);
    GridReal *grid = &viewProcess->ipc_gridReal[idx];
    uint value = (uint)(ui->rsContrast->getValue() + IMAGE_VALUE_OFFSET);

#if 1
    if(grid->wndId > WindowId_Invalid)
#else
    if(grid->status == GridReal::GridStatus_PLAY ||
       grid->status == GridReal::GridStatus_IPC_HIDE)
#endif
    {
        if(rtkApi->qt_rtk_disp_set_channel_contrast(
                    STR_IPC, idx, chIdx, grid->wndId,
                    value) != true)
        {
            QString msg = "Fail to apply " + ui->lContrast->text() + " !";
            qDebug() << msg;
        }
    }
    imgContrastTimer->stop();
    Config::ipc.ch[chIdx].contrast = value;
    Config::saveDefaultProfile();
}

void Ipc::apply_hue()
{
    int chIdx = ui->cbImageChannel->currentIndex();
    int idx = viewProcess->get_ipc_array_idx(chIdx);
    GridReal *grid = &viewProcess->ipc_gridReal[idx];
    uint value = (uint)(ui->rsHue->getValue() + IMAGE_VALUE_OFFSET);

#if 1
    if(grid->wndId > WindowId_Invalid)
#else
    if(grid->status == GridReal::GridStatus_PLAY ||
       grid->status == GridReal::GridStatus_IPC_HIDE)
#endif
    {
        if(rtkApi->qt_rtk_disp_set_channel_hue(
                    STR_IPC, idx, chIdx, grid->wndId,
                    value) != true)
        {
            QString msg = "Fail to apply " + ui->lHue->text() + " !";
            qDebug() << msg;
        }
    }
    imgHueTimer->stop();
    Config::ipc.ch[chIdx].hue = value;
    Config::saveDefaultProfile();
}

void Ipc::apply_saturation()
{
    int chIdx = ui->cbImageChannel->currentIndex();
    int idx = viewProcess->get_ipc_array_idx(chIdx);
    GridReal *grid = &viewProcess->ipc_gridReal[idx];
    uint value = (uint)(ui->rsSaturation->getValue() + IMAGE_VALUE_OFFSET);

#if 1
    if(grid->wndId > WindowId_Invalid)
#else
    if(grid->status == GridReal::GridStatus_PLAY ||
       grid->status == GridReal::GridStatus_IPC_HIDE)
#endif
    {
        if(rtkApi->qt_rtk_disp_set_channel_saturation(
                    STR_IPC, idx, chIdx, grid->wndId,
                    value) != true)
        {
            QString msg = "Fail to apply " + ui->lSaturation->text() + " !";
            qDebug() << msg;
        }
    }
    imgSaturationTimer->stop();
    Config::ipc.ch[chIdx].saturation = value;
    Config::saveDefaultProfile();
}

void Ipc::apply_sharpness()
{
    int chIdx = ui->cbImageChannel->currentIndex();
    int idx = viewProcess->get_ipc_array_idx(chIdx);
    GridReal *grid = &viewProcess->ipc_gridReal[idx];
    uint value = (uint)ui->rsSharpness->getValue();

#if 1
    if(grid->wndId > WindowId_Invalid)
#else
    if(grid->status == GridReal::GridStatus_PLAY ||
       grid->status == GridReal::GridStatus_IPC_HIDE)
#endif
    {
        if(rtkApi->qt_rtk_disp_set_channel_sharpness(
                    STR_IPC, idx, chIdx, grid->wndId,
                    value) != true)
        {
            QString msg = "Fail to apply " + ui->lSharpness->text() + " !";
            qDebug() << msg;
        }
    }
    imgSharpnessTimer->stop();
    Config::ipc.ch[chIdx].sharpness = value;
    Config::saveDefaultProfile();
}
