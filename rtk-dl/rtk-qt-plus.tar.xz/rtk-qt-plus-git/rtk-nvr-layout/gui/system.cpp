/**
 * @file system.cpp
 * @author Realtek Semiconductor Corp.
 * @date Dec 2017
 * @brief The widget page to do system setting
 */

#include "system.h"
#include "ui_system.h"
#include "mainwidget.h"

System::System(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::System)
{
    ui->setupUi(this);

    QList<QToolButton *> btnLayer1 = {ui->tbDatetime, ui->tbDisplay, ui->tbOutput, ui->tbAdmin};
    tlSystem = new RTabLayer(this);
    tlSystem->init(btnLayer1, ui->stkLayer1, TABLAYER_LAYER_1);
    QList<QToolButton *> btnDatetime = {ui->tbCurrent, ui->tbFormat};
    tlDatetime = new RTabLayer(this);
    tlDatetime->init(btnDatetime, ui->stkDatetime, TABLAYER_LAYER_2);
    QList<QToolButton *> btnDisplay = {ui->tbImage, ui->tbBg, ui->tbFb};
    tlDisplay = new RTabLayer(this);
    tlDisplay->init(btnDisplay, ui->stkDisplay, TABLAYER_LAYER_2);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;

    ui->lSystem->setStyleSheet(STYLESHEET_TITLE_2);
    ui->pgCurrent->installEventFilter(this);
    ui->pgFormat->installEventFilter(this);
    ui->rCalendar->initStyleSheet(false, false);
    ui->pgImage->installEventFilter(this);
    ui->pgBg->installEventFilter(this);
    ui->pgFb->installEventFilter(this);
    ui->pgOutput->installEventFilter(this);
    ui->pgAdmin->installEventFilter(this);
//    ui->rCalendar->setVisible(false);

    opt_AddOpt(ui->cbVideoFb, optVideoFb, {});
    opt_AddOpt(ui->cbHdmiMode, optHdmiMode, {});
    opt_AddOpt(ui->cbDpMode, optDpMode, {});
    foreach(QString str, Config::listDateFormat)
    {
        ui->cbDateFormat->addItem(str);
    }
    foreach(QString str, Config::listTimeFormat)
    {
        ui->cbTimeFormat->addItem(str);
    }
    QList<QComboBox*> optionList = {ui->cbDateFormat, ui->cbTimeFormat,
                                    ui->cbVideoFb,
                                    ui->cbHdmiMode, ui->cbDpMode,
                                    ui->cbAutoLogin};
    foreach(QComboBox *cb, optionList)
    {
        cb->setStyleSheet(STYLESHEET_COMBOBOX);
    }

    rsBrightness = ui->rsBrightness;
    rsContrast = ui->rsContrast;
    rsHue = ui->rsHue;
    rsSaturation = ui->rsSaturation;
    rsSharpness = ui->rsSharpness;
    connect(ui->rsBrightness, SIGNAL(valueChanged(int)), this, SLOT(brightness_value_changed(int)));
    connect(ui->rsContrast, SIGNAL(valueChanged(int)), this, SLOT(contrast_value_changed(int)));
    connect(ui->rsHue, SIGNAL(valueChanged(int)), this, SLOT(hue_value_changed(int)));
    connect(ui->rsSaturation, SIGNAL(valueChanged(int)), this, SLOT(saturation_value_changed(int)));
    connect(ui->rsSharpness, SIGNAL(valueChanged(int)), this, SLOT(sharpness_value_changed(int)));
    connect(ui->rsBgColorR, SIGNAL(valueChanged(int)), this, SLOT(bgColor_value_changed(int)));
    connect(ui->rsBgColorG, SIGNAL(valueChanged(int)), this, SLOT(bgColor_value_changed(int)));
    connect(ui->rsBgColorB, SIGNAL(valueChanged(int)), this, SLOT(bgColor_value_changed(int)));
    imgBrightnessTimer = new QTimer(this);
    imgBrightnessTimer->setSingleShot(true);
    imgBrightnessTimer->setInterval(200);
    imgContrastTimer = new QTimer(this);
    imgContrastTimer->setSingleShot(true);
    imgContrastTimer->setInterval(200);
    imgHueTimer = new QTimer(this);
    imgHueTimer->setSingleShot(true);
    imgHueTimer->setInterval(200);
    imgSaturationTimer = new QTimer(this);
    imgSaturationTimer->setSingleShot(true);
    imgSaturationTimer->setInterval(200);
    imgSharpnessTimer = new QTimer(this);
    imgSharpnessTimer->setSingleShot(true);
    imgSharpnessTimer->setInterval(200);
    imgBgColorRTimer = new QTimer(this);
    imgBgColorRTimer->setSingleShot(true);
    imgBgColorRTimer->setInterval(200);
    imgBgColorGTimer = new QTimer(this);
    imgBgColorGTimer->setSingleShot(true);
    imgBgColorGTimer->setInterval(200);
    imgBgColorBTimer = new QTimer(this);
    imgBgColorBTimer->setSingleShot(true);
    imgBgColorBTimer->setInterval(200);
    connect(imgBrightnessTimer, SIGNAL(timeout()), this, SLOT(apply_brightness()));
    connect(imgContrastTimer,   SIGNAL(timeout()), this, SLOT(apply_contrast()));
    connect(imgHueTimer,        SIGNAL(timeout()), this, SLOT(apply_hue()));
    connect(imgSaturationTimer, SIGNAL(timeout()), this, SLOT(apply_saturation()));
    connect(imgSharpnessTimer, SIGNAL(timeout()), this, SLOT(apply_sharpness()));
    connect(imgBgColorRTimer, SIGNAL(timeout()), this, SLOT(preview_bgColor()));
    connect(imgBgColorGTimer, SIGNAL(timeout()), this, SLOT(preview_bgColor()));
    connect(imgBgColorBTimer, SIGNAL(timeout()), this, SLOT(preview_bgColor()));

    connect(ui->rCalendar, SIGNAL(dayClicked()), this, SLOT(calendar_day_clicked()));
    connect(ui->tbCalendar, SIGNAL(clicked(bool)), this, SLOT(calendar_clicked(bool)));
    connect(ui->tbCurrentSet, SIGNAL(clicked(bool)), this, SLOT(current_set_clicked(bool)));
    connect(ui->tbFormatSet, SIGNAL(clicked(bool)), this, SLOT(format_set_clicked(bool)));
    connect(ui->tbImageReset, SIGNAL(clicked(bool)), this, SLOT(image_reset_clicked(bool)));
    connect(ui->tbBgSet, SIGNAL(clicked(bool)), this, SLOT(bgColor_set_clicked(bool)));
    connect(ui->tbFbSet, SIGNAL(clicked(bool)), this, SLOT(fb_set_clicked(bool)));
    connect(ui->tbOutputSet, SIGNAL(clicked(bool)), this, SLOT(output_set_clicked(bool)));
    connect(ui->tbAdminSet, SIGNAL(clicked(bool)), this, SLOT(admin_set_clicked(bool)));
}

System::~System()
{
    delete imgBrightnessTimer;
    delete imgContrastTimer;
    delete imgHueTimer;
    delete imgSaturationTimer;
    delete imgSharpnessTimer;
    delete imgBgColorRTimer;
    delete imgBgColorGTimer;
    delete imgBgColorBTimer;
    delete tlDisplay;
    delete tlDatetime;
    delete tlSystem;
    delete ui;
}

void System::setup()
{
    labelList->append({ui->lCurrentDate, ui->lCurrentTime,
                       ui->lDateFormat, ui->lTimeFormat,
                       ui->lBrightness, ui->lContrast, ui->lHue, ui->lSaturation, ui->lSharpness,
                       ui->lImageReset,
                       ui->lBgColor, ui->lBgColorR, ui->lBgColorG, ui->lBgColorB,
                       ui->lVideoFb,
                       ui->lHdmiMode, ui->lDpMode,
                       ui->lAutoLogin});
    editList->append({ui->leCurrentH, ui->leCurrentM, ui->leCurrentS});
    readOnlyList->append({ui->leCurrentDate, ui->leCurrentSymbol1, ui->leCurrentSymbol2});
    actionList->append({ui->tbCalendar, ui->tbCurrentSet, ui->tbFormatSet,
                        ui->tbImageReset, ui->tbBgSet, ui->tbFbSet,
                        ui->tbOutputSet, ui->tbAdminSet});

    ui->leCurrentH->setValueRange("Hour", 0, 23, 0);
    ui->leCurrentM->setValueRange("Minute", 0, 59, 0);
    ui->leCurrentS->setValueRange("Second", 0, 59, 0);
    updateTimeSymbol();

    ui->rsBrightness->setValueRange(IMAGE_VALUE_MIN - IMAGE_VALUE_OFFSET,
                                    IMAGE_VALUE_MAX - IMAGE_VALUE_OFFSET,
                                    1, 0);
    ui->rsContrast->setValueRange(IMAGE_VALUE_MIN - IMAGE_VALUE_OFFSET,
                                  IMAGE_VALUE_MAX - IMAGE_VALUE_OFFSET,
                                  1, 0);
    ui->rsHue->setValueRange(IMAGE_VALUE_MIN - IMAGE_VALUE_OFFSET,
                             IMAGE_VALUE_MAX - IMAGE_VALUE_OFFSET,
                             1, 0);
    ui->rsSaturation->setValueRange(IMAGE_VALUE_MIN - IMAGE_VALUE_OFFSET,
                                    IMAGE_VALUE_MAX - IMAGE_VALUE_OFFSET,
                                    1, 0);
    ui->rsSharpness->setValueRange(SHARPNESS_VALUE_MIN,
                                    SHARPNESS_VALUE_MAX,
                                    1, 0);

    ui->rsBgColorR->setValueRange(0, 0xFF, 1, 0);
    ui->rsBgColorG->setValueRange(0, 0xFF, 1, 0);
    ui->rsBgColorB->setValueRange(0, 0xFF, 1, 0);

    /* [20180920:Brian] Fix bug NAS-485:
     *                  if set rtk_disp_set_videoFB_Resolution() fail,
     *                  then use rtk_disp_get_videoFB_Resolution() as default value */
    if(rtkApi->qt_rtk_disp_set_videoFB_Resolution(
                (FrameBufferSize_e)Config::sys.frameBufferSizeIndex))
    {
        getFb(false);
    }
    else
    {
        int usrFbSize, sysFbSize;
        usrFbSize = Config::sys.frameBufferSizeIndex;
        getFb(true);
        sysFbSize = Config::sys.frameBufferSizeIndex;
        qDebug() << QString("Use rtk_disp_get_videoFB_Resolution():%1 instead of user value:%2 !")
                    .arg(opt_ValToStr(optVideoFb, sysFbSize))
                    .arg(opt_ValToStr(optVideoFb, usrFbSize));

        Config::setFrameBufferSizeIndex(sysFbSize);
        Config::saveDefaultProfile();
    }

    getOutput(false);
    output_set(false);

    /* [20180808:Brian] Fix bug NAS-444:
     *                  rtk_disp_set_output() will let display black,
     *                  therefore do rtk_disp_set_output() first,
     *                  then rtk_disp_set_bgcolor() */
    getDisplayImage(false);
    bgColor_set(false);

//    admin_set(false); // unnecessary
    tlSystem->clickTabIndex(0);
    tlDatetime->clickTabIndex(0);
    tlDisplay->clickTabIndex(0);
}

void System::initValue(bool fromStatus)
{
    if(ui->pgCurrent->isVisible())
    {
        ui->rCalendar->selectCurrentDate();
        calendar_day_clicked();
        QTime time = QTime::currentTime();
        ui->leCurrentH->setText(time.hour());
        ui->leCurrentM->setText(time.minute());
        ui->leCurrentS->setText(time.second());
    }
    else if(ui->pgFormat->isVisible())
    {
        ui->cbDateFormat->setCurrentText(Config::strQDateFormat());
        ui->cbTimeFormat->setCurrentText(Config::strQTimeFormat());
    }
    else if(ui->pgImage->isVisible())
    {
        getDisplayImage(fromStatus);
    }
    else if(ui->pgBg->isVisible())
    {
        getBackground(fromStatus);
    }
    else if(ui->pgFb->isVisible())
    {
        getFb(fromStatus);
    }
    else if(ui->pgOutput->isVisible())
    {
        getOutput(fromStatus);
    }
    else if(ui->pgAdmin->isVisible())
    {
        ui->cbAutoLogin->setCurrentIndex(Config::sys.autoLogin ? 1 : 0);
    }
}

void System::getDisplayImage(bool fromStatus)
{
    if(fromStatus)
    {
        unsigned int value;
        if(rtkApi->qt_rtk_disp_get_brightness(&value))
        {
            Config::setting.brightness = value;
        }
        if(rtkApi->qt_rtk_disp_get_contrast(&value))
        {
            Config::setting.contrast = value;
        }
        if(rtkApi->qt_rtk_disp_get_hue(&value))
        {
            Config::setting.hue = value;
        }
        if(rtkApi->qt_rtk_disp_get_saturation(&value))
        {
            Config::setting.saturation = value;
        }
        if(rtkApi->qt_rtk_disp_get_sharpness(&value))
        {
            Config::setting.sharpness = value;
        }
    }
    ui->rsBrightness->setEmitValueChanged(false);
    ui->rsBrightness->setValue((double)Config::setting.brightness - IMAGE_VALUE_OFFSET);
    ui->rsBrightness->setEmitValueChanged(true);
    ui->rsContrast->setEmitValueChanged(false);
    ui->rsContrast->setValue((double)Config::setting.contrast - IMAGE_VALUE_OFFSET);
    ui->rsContrast->setEmitValueChanged(true);
    ui->rsHue->setEmitValueChanged(false);
    ui->rsHue->setValue((double)Config::setting.hue - IMAGE_VALUE_OFFSET);
    ui->rsHue->setEmitValueChanged(true);
    ui->rsSaturation->setEmitValueChanged(false);
    ui->rsSaturation->setValue((double)Config::setting.saturation - IMAGE_VALUE_OFFSET);
    ui->rsSaturation->setEmitValueChanged(true);
    ui->rsSharpness->setEmitValueChanged(false);
    ui->rsSharpness->setValue((double)Config::setting.sharpness);
    ui->rsSharpness->setEmitValueChanged(true);
}

void System::getFb(bool fromStatus)
{
    FrameBufferSize_e fbSize = (FrameBufferSize_e)Config::sys.frameBufferSizeIndex;
    if(fromStatus)
    {
        if(rtkApi->qt_rtk_disp_get_videoFB_Resolution(&fbSize))
        {
            if(Config::sys.frameBufferSizeIndex != fbSize)
            {
                Config::sys.frameBufferSizeIndex = fbSize;
            }
        }
    }
    ui->cbVideoFb->setCurrentText(opt_ValToStr(optVideoFb, Config::sys.frameBufferSizeIndex));
}

void System::getBackground(bool fromStatus)
{
    ui->rsBgColorR->setValue(Config::setting.bgColorR);
    ui->rsBgColorG->setValue(Config::setting.bgColorG);
    ui->rsBgColorB->setValue(Config::setting.bgColorB);
    preview_bgColor();
    Q_UNUSED(fromStatus);
}

void System::getOutput(bool fromStatus)
{
    HDMIMode_e  hdmiMode;
    DPMode_e    dpMode;
    if(fromStatus)
    {
        if(rtkApi->qt_rtk_disp_get_output(&hdmiMode, &dpMode))
        {
            Config::setting.hdmiMode = hdmiMode;
            Config::setting.dpMode = dpMode;
        }
    }
    ui->cbHdmiMode->setCurrentText(opt_ValToStr(optHdmiMode, Config::setting.hdmiMode));
    ui->cbDpMode->setCurrentText(opt_ValToStr(optDpMode, Config::setting.dpMode));
}

void System::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);

    RLineEdit *le;
    int tab_x_offset = parent_absolute_offset_x+rect.x()+ui->stkLayer1->x()+ui->stkDatetime->x();
    int tab_y_offset = parent_absolute_offset_y+rect.y()+ui->stkLayer1->y()+ui->stkDatetime->y();

    QList<RLineEdit *>leDatetimeList = {
                        ui->leCurrentH, ui->leCurrentM, ui->leCurrentS};
    foreach(le, leDatetimeList)
    {
        le->setParentAbsoluteOffset(tab_x_offset, tab_y_offset);
    }
//    qDebug()<<"tab_x_offset" << tab_x_offset <<"tab_y_offset" << tab_y_offset;
}

void System::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void System::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void System::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    QList<RLineEdit *>keyboardList = {};
    QList<RLineEdit *>keybadList = {ui->leCurrentH, ui->leCurrentM, ui->leCurrentS};
    RLineEdit *le;
    foreach(le, keyboardList)
    {
        le->installEventFilter(keyboard);
    }
    foreach(le, keybadList)
    {
        le->installEventFilter(keypad);
    }
}

//void System::showEvent(QShowEvent *)
//{
//    initValue(true);
//}

bool System::eventFilter(QObject *o, QEvent *e)
{
    if(e->type() == QEvent::Show)
    {
        if(o==ui->pgCurrent ||
           o==ui->pgFormat ||
           o==ui->pgImage ||
           o==ui->pgBg ||
           o==ui->pgFb ||
           o==ui->pgOutput ||
           o==ui->pgAdmin)
        {
            initValue(true);
        }
    }
    return QObject::eventFilter(o, e);
}

void System::updateTimeSymbol()
{
    QString symbol = Config::listTimeFormat.at(Config::setting.timeFormat).data()[2];
    ui->leCurrentSymbol1->setText(symbol);
    ui->leCurrentSymbol2->setText(symbol);
}

void System::bgColor_set(bool ifDialog)
{
    RtkReturn_e rtnValue;
    Config::updateBorderColorByBgColor();
    playback->updateBgColor();
    viewProcess->mutex.lock();
    viewProcess->bUpdateIpcFrame = true;
    viewProcess->mutex.unlock();
    rtkApi->qt_rtk_disp_set_bgcolor(
                            Config::setting.bgColorR,
                            Config::setting.bgColorG,
                            Config::setting.bgColorB,
                            &rtnValue);
    {
        rtkApi->qt_rtk_disp_set_blank(STR_IPC, -1, -1, true, -1);// apply new bgColor
        QThread::msleep(Config::sys.setBlankTime);
        rtkApi->qt_rtk_disp_set_blank(STR_IPC, -1, -1, false, -1);
    }
    if(ifDialog)
    {
        if(rtnValue == RTK_SUCCESS)
        {
            dialog->showInfo(STR_SETTING_APPLY);
            Config::saveDefaultProfile();
        }
        else
        {
            dialog->showError(rtkApi->msgRtkReturn(rtnValue));
        }
    }
}

void System::fb_set()
{
    int fbSize = opt_StrToVal(optVideoFb, ui->cbVideoFb->currentText());
    if(fbSize == (int)OPT_ERROR)
    {
        dialog->showError("Invalid values !");
        return;
    }

    RtkReturn_e rtnValue;
    rtkApi->qt_rtk_disp_set_videoFB_Resolution((FrameBufferSize_e)fbSize, &rtnValue);
    if(rtnValue == RTK_SUCCESS)
    {
        Config::setFrameBufferSizeIndex(fbSize);
        Config::saveDefaultProfile();
    }

    getFb(true);    // no matter if rtnValue == RTK_SUCCESS, get current status

    if(rtnValue == RTK_SUCCESS)
    {
        dialog->showInfo(STR_SETTING_APPLY);
    }
    else
    {
        dialog->showError(rtkApi->msgRtkReturn(rtnValue));
    }
}

void System::output_set(bool ifDialog)
{
    int hdmiMode = opt_StrToVal(optHdmiMode, ui->cbHdmiMode->currentText());
    int dpMode = opt_StrToVal(optDpMode, ui->cbDpMode->currentText());

    if(hdmiMode == (int)OPT_ERROR || dpMode == (int)OPT_ERROR)
    {
        if(ifDialog)
        {
            dialog->showError("Invalid values !");
        }
        return;
    }
    if(hdmiMode == HDMI_NONE && dpMode == DP_NONE)
    {
        if(ifDialog)
        {
            dialog->showError("Invalid to set both HDMI and DP as None !");
        }
        return;
    }
    else if(hdmiMode != HDMI_NONE && dpMode == DP_4K_30)
    {
        if(ifDialog)
        {
            dialog->showError(QString("Invalid to set HDMI not None when DP is %1 !")
                            .arg(opt_ValToStr(optDpMode, DP_4K_30)));
        }
        return;
    }

    RtkReturn_e rtnValue;
    rtkApi->qt_rtk_disp_set_output((HDMIMode_e)hdmiMode, (DPMode_e)dpMode, &rtnValue);

    Config::setting.hdmiMode = hdmiMode;
    Config::setting.dpMode = dpMode;
    getOutput(true);    // no matter if rtnValue == RTK_SUCCESS, get current status
    if(ifDialog)
    {
        if(rtnValue == RTK_SUCCESS)
        {
            dialog->showInfo(STR_SETTING_APPLY);
            Config::saveDefaultProfile();
        }
        else
        {
            dialog->showError(rtkApi->msgRtkReturn(rtnValue));
        }
    }
}

void System::admin_set(bool ifDialog)
{
    Config::sys.autoLogin = (ui->cbAutoLogin->currentIndex() > 0);
    if(ifDialog)
    {
        Config::saveDefaultProfile();
        dialog->showInfo(STR_SETTING_APPLY);
    }

}

void System::calendar_day_clicked()
{
    ui->leCurrentDate->setText(ui->rCalendar->strDateSelected(false));
    ui->rCalendar->setVisible(false);
}

void System::calendar_clicked(bool)
{
    ui->rCalendar->setVisible(true);
}

void System::current_set_clicked(bool)
{
    // retrieve value and check first
    int year=0, month=0, day=0, hour=0, min=0, sec=0;

    QList<RLineEdit *> leList = {ui->leCurrentH, ui->leCurrentM, ui->leCurrentS};
    QString str;
    QList<QString> msgList;
    foreach(RLineEdit *le, leList)
    {
        if(le->isTextValid(&str) != true)
        {
            if(str.length()>0)
                msgList.append(str);
        }
    }
    if(msgList.count()>0)
    {
        dialog->showError(msgList.join("\r\n"));
        return;
    }
    hour = ui->leCurrentH->getValue();
    min = ui->leCurrentM->getValue();
    sec = ui->leCurrentS->getValue();

    year = ui->rCalendar->yearSelected();
    month = ui->rCalendar->monthSelected();
    day = ui->rCalendar->daySelected();

    // set datetime
    QProcess proc;
    // set command example: date -s "2017-12-15 14:13:12"
    proc.start("date", QStringList() << "-s" 
                                << QString().asprintf("\"%04d-%02d-%02d %02d:%02d:%02d\"",
                                year, month, day, hour, min, sec));
    proc.waitForFinished();

    proc.start("date", QStringList() << "+%Y%m%d%H%M");
    proc.waitForFinished();
    QString output = proc.readAllStandardOutput();
    QList<QString> list = output.split("\n");
    QString strExpect = QString().asprintf("%04d%02d%02d%02d%02d",
                                         year, month, day, hour, min);
    foreach(QString line, list)
    {
        line = line.trimmed();
        qDebug() << line;
        if (line == strExpect)
        {
            dialog->showInfo(STR_SETTING_APPLY);
            return;
        }
    }
    dialog->showError(STR_SETTING_FAILED);
}

void System::format_set_clicked(bool)
{
    int timeIdxOld = Config::setting.timeFormat;
    Config::setting.dateFormat = ui->cbDateFormat->currentIndex();
    Config::setting.timeFormat = ui->cbTimeFormat->currentIndex();
    Config::saveDefaultProfile();
    if(Config::setting.timeFormat != timeIdxOld)
    {
        updateTimeSymbol();
        playback->updateTimeString();
    }
    dialog->showInfo(STR_SETTING_APPLY);
}

void set_image_reset_confirm()
{
    setSystem->rsBrightness->setValue(IMAGE_VALUE_DEF - IMAGE_VALUE_OFFSET);
    setSystem->rsContrast->setValue(IMAGE_VALUE_DEF - IMAGE_VALUE_OFFSET);
    setSystem->rsHue->setValue(IMAGE_VALUE_DEF - IMAGE_VALUE_OFFSET);
    setSystem->rsSaturation->setValue(IMAGE_VALUE_DEF - IMAGE_VALUE_OFFSET);
    setSystem->rsSharpness->setValue(SHARPNESS_VALUE_DEF);
}

void System::image_reset_clicked(bool)
{
    dialog->showConfirm(QString("Do you confirm to resetto default value ?"),
                        &(set_image_reset_confirm));
}

void System::output_set_clicked(bool)
{
    output_set(true);
}

void System::bgColor_set_clicked(bool)
{
    Config::setting.bgColorR = (int)ui->rsBgColorR->getValue();
    Config::setting.bgColorG = (int)ui->rsBgColorG->getValue();
    Config::setting.bgColorB = (int)ui->rsBgColorB->getValue();
    Config::saveDefaultProfile();

    bgColor_set(true);
}

void System::fb_set_clicked(bool)
{
    fb_set();
}

void System::admin_set_clicked(bool)
{
    admin_set(true);
}

void System::brightness_value_changed(int)
{
    if(imgBrightnessTimer->isActive() != true)
    {
        imgBrightnessTimer->start();
    }
}

void System::contrast_value_changed(int)
{
    if(imgContrastTimer->isActive() != true)
    {
        imgContrastTimer->start();
    }
}

void System::hue_value_changed(int)
{
    if(imgHueTimer->isActive() != true)
    {
        imgHueTimer->start();
    }
}

void System::saturation_value_changed(int)
{
    if(imgSaturationTimer->isActive() != true)
    {
        imgSaturationTimer->start();
    }
}

void System::sharpness_value_changed(int)
{
    if(imgSharpnessTimer->isActive() != true)
    {
        imgSharpnessTimer->start();
    }
}

void System::bgColor_value_changed(int)
{
    if(imgBgColorBTimer->isActive() != true)
    {
        imgBgColorBTimer->start();
    }
}

void System::apply_brightness()
{
    uint value = (uint)(ui->rsBrightness->getValue() + IMAGE_VALUE_OFFSET);
    if(rtkApi->qt_rtk_disp_set_brightness(value) != true)
    {
        QString msg = "Fail to apply " + ui->lBrightness->text() + " !";
        qDebug() << msg;
    }
    imgBrightnessTimer->stop();
    Config::setting.brightness = value;
    Config::saveDefaultProfile();
}

void System::apply_contrast()
{
    uint value = (uint)(ui->rsContrast->getValue() + IMAGE_VALUE_OFFSET);
    if(rtkApi->qt_rtk_disp_set_contrast(value) != true)
    {
        QString msg = "Fail to apply " + ui->lContrast->text() + " !";
        qDebug() << msg;
    }
    imgContrastTimer->stop();
    Config::setting.contrast = value;
    Config::saveDefaultProfile();
}

void System::apply_hue()
{
    uint value = (uint)(ui->rsHue->getValue() + IMAGE_VALUE_OFFSET);
    if(rtkApi->qt_rtk_disp_set_hue(value) != true)
    {
        QString msg = "Fail to apply " + ui->lHue->text() + " !";
        qDebug() << msg;
    }
    imgHueTimer->stop();
    Config::setting.hue = value;
    Config::saveDefaultProfile();
}

void System::apply_saturation()
{
    uint value = (uint)(ui->rsSaturation->getValue() + IMAGE_VALUE_OFFSET);
    if(rtkApi->qt_rtk_disp_set_saturation(value) != true)
    {
        QString msg = "Fail to apply " + ui->lSaturation->text() + " !";
        qDebug() << msg;
    }
    imgSaturationTimer->stop();
    Config::setting.saturation = value;
    Config::saveDefaultProfile();
}

void System::apply_sharpness()
{
    uint value = (uint)ui->rsSharpness->getValue();
    if(rtkApi->qt_rtk_disp_set_sharpness(value) != true)
    {
        QString msg = "Fail to apply " + ui->lSharpness->text() + " !";
        qDebug() << msg;
    }
    imgSharpnessTimer->stop();
    Config::setting.sharpness = value;
    Config::saveDefaultProfile();
}

void System::preview_bgColor()
{
    QString strBgColor = QString("background-color: rgb(%1, %2, %3);")
                                .arg((int)ui->rsBgColorR->getValue())
                                .arg((int)ui->rsBgColorG->getValue())
                                .arg((int)ui->rsBgColorB->getValue());
//    qDebug() << strBgColor;
    ui->wBgColor->setStyleSheet(strBgColor);
}
