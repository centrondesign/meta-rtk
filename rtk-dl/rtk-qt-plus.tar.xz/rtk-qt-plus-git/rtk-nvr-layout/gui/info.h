/**
 * @file info.h
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The widget page to show info
 */

#ifndef INFO_H
#define INFO_H

#include <QWidget>
#include <QToolButton>
#include "alarm.h"
#include "statistics.h"

namespace Ui {
class Info;
}

class Info : public QWidget
{
    Q_OBJECT

public:
    Alarm *alarm;
    Statistics *statistics;

    explicit Info(QWidget *parent = 0);
    ~Info();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);

private:
    Ui::Info *ui;

    void setOption(QToolButton *btn);

private slots:
    void setAlarm(bool);
    void setStatus(bool);
};

#endif // INFO_H
