/**
 * @file rframe.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The frame for each IPC or playback per channel
 */

#ifndef RFRAME_H
#define RFRAME_H

#include <QFrame>
#include <QLabel>
#include <QMimeData>
#include <QRect>
#include <QMutex>
#include "define.h"
#include "gridreal.h"
#include "rtoolbutton.h"

#define RFrame_Id_Invalid   -1
#define RFrame_MimeDataHead "RFrameIndex="

class RFrame: public QFrame
{
    Q_OBJECT

public:
    typedef enum
    {
        TagAlign_TOP_LEFT   = 0,
        TagAlign_TOP_RIGHT,
        TagAlign_BOTTOM_LEFT,
        TagAlign_BOTTOM_RIGHT
    } TagAlign_E;

    explicit RFrame(QWidget *parent = 0,
                    bool enableZoomin = false,
                    bool enableDrag = false,
                    bool enableRec = false,
                    bool enableSound = false,
                    int id = RFrame_Id_Invalid);
    ~RFrame();

    void setBorderSize(int size);
#if QT_ENV_ONLY == 1
    void setBackground(int r, int g, int b, int a);
#endif
    void prepareUpdateComponent();
    void prepareStyleSheet(QString appendStr = "");
    void prepareGeometry(int x, int y, int w, int h);
    void updateComponent();
    void updateStyleSheet();
    void updateGeometry();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setChText(QString text);
    QString getChText();
    void showZoomText(bool visible, double zoomRatio);
    bool isTagVisible();
    void setTagVisible(bool visible);
    bool isBtnRecVisible();
    void setBtnRecVisible(bool visible);
    bool isBtnRecActived();
    void setBtnRecActived(bool active);
    bool isBtnVoiceVisible();
    void setBtnVoiceVisible(bool visible);
    void setGridReal(GridReal *grid);
    GridReal* getGridReal();

private:
    GridReal *gridReal;
    QLabel *tagCh, *tagZoom;
    RToolButton *btnRec, *btnSound;
    QFrame *zoomZone;
    QPoint dragStartPosition;
    QPixmap framePixmap;
    int id; /* same to the array index of
               mainWidget.ipcFrame[] or playback.fileFrame[],
               do not change it */
#if QT_ENV_ONLY == 1
    int r, g, b, a;
#endif
    int borderSize;
    bool enableRec;
    bool enableSound;
    bool enableZoomin;
    bool enableDrag;
    bool bDragProcess;
    int currDragId;

    bool bUpdateComponent;
    bool bUpdateStyleSheet;
    QString strStyleSheet;
    bool bUpdateGeometry;
    QRect geometry;
    QMutex mutex;

    bool isMaxSize();
    void showZoomZone(QPoint p);
    int getIdFromMime(const QMimeData *mime);
    void mousePressEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
    void dragEnterEvent(QDragEnterEvent *);
    void dragLeaveEvent(QDragLeaveEvent *);
    void dragMoveEvent(QDragMoveEvent *);
    void dropEvent(QDropEvent *);
    void mouseDoubleClickEvent(QMouseEvent *);
    bool transformToRect(QPoint pos_0, QPoint pos_1, QRect *pRect);

private slots:
    void rec_selected(bool);
    void sound_selected(bool);
};

#endif // RFRAME_H
