/**
 * @file onvifprocess.h
 * @author Realtek Semiconductor Corp.
 * @date May 2018
 * @brief The process to operate ONVIF procedure
 */

#include "onvifprocess.h"
#include <QFile>
#include <QFileInfo>
#include <QTime>
#include <QDebug>
#include "gui/mainwidget.h"

OnvifProcess *onvifProcess = NULL;

OnvifProcess::OnvifProcess()
{
    onvifProcess = this;

    pollingMsec.append({1000, 2000, 4000, 6000, 8000, 10000, 20000, 30000, 40000, 50000, 60000});
    bRun = false;

}

OnvifProcess::~OnvifProcess()
{
}

void OnvifProcess::setStart()
{
    this->start();
}

void OnvifProcess::setStop()
{
    bRun = false;
}

void OnvifProcess::finalize()
{
    bRun = false;
    while (onvifProcess->isRunning())
    {
        msleep(200);
    }
}

void OnvifProcess::run()
{
}

bool OnvifProcess::isValidIpv4Ip(QString strIp)
{
    // check format
    QRegularExpression re("^(\\d+).(\\d+).(\\d+).(\\d+)$");
    QRegularExpressionMatch match=re.match(strIp);
    if(match.hasMatch() == false)
    {
//        qDebug() << __func__ << "format mismatch";
        return false;
    }

    // check value
    int ip[4];
    ip[0] = match.captured(1).toInt();
    ip[1] = match.captured(2).toInt();
    ip[2] = match.captured(3).toInt();
    ip[3] = match.captured(4).toInt();
//    qDebug() << __func__ << ip[0] << ip[1] << ip[2] << ip[3];
    if (ip[0] < 0 || ip[0] > 255 ||
        ip[1] < 0 || ip[1] > 255 ||
        ip[2] < 0 || ip[2] > 255 ||
        ip[3] < 0 || ip[3] > 255)
    {
//        qDebug() << __func__ << "value mismatch";
        return false;
    }
    return true;
}
