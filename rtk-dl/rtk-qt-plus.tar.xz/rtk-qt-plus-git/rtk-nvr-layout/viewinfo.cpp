/**
 * @file viewinfo.cpp
 * @author Realtek Semiconductor Corp.
 * @date Oct 2017
 * @brief The array of GridInfo
 */

#include "viewinfo.h"
#include "config.h"

ViewInfo::ViewInfo()
{
    gridInfoList = new QList<GridInfo*>();
    for (int i=0; i<CHANNEL_MAX; i++)
    {
        gridInfoList->append(&gridInfo[i]);
    }
}

ViewInfo::~ViewInfo()
{
    delete(gridInfoList);
}

void ViewInfo::setGridInfo(int idx, int x, int y, int width, int height,
                          int border, bool visible)
{
    if (idx < 0 || idx >= CHANNEL_MAX)
    {
        return;
    }
    gridInfo[idx].setGridInfo(x, y, width, height, border, visible);
}
