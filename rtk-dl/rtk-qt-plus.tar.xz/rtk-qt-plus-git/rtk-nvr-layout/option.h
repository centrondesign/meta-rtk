/**
 * @file option.h
 * @author Realtek Semiconductor Corp.
 * @date Nov 2017
 * @brief The option structure and api
 */

#ifndef OPTION_H
#define OPTION_H

#include <QString>
#include <QComboBox>

#define OPT_ERROR   0xFFFFFFFF

typedef struct
{
    int         value;
    QString     str;
} OPTION_S;

extern const OPTION_S optHdmiMode[];
extern const OPTION_S optDpMode[];
extern const OPTION_S optVideoCodec[];
extern const OPTION_S optVideoFb[];

QString opt_ValToStr (const OPTION_S *pOption, int value);
int opt_StrToVal (const OPTION_S *pOption, QString str);
bool opt_AddOpt (QComboBox *cb, const OPTION_S *pOption, QList<int>listExclusiveVal);

#endif // OPTION_H
