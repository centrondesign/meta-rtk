/**
 * @file viewinfo.h
 * @author Realtek Semiconductor Corp.
 * @date Oct 2017
 * @brief The array of GridInfo
 */

#ifndef VIEWINFO_H
#define VIEWINFO_H

#include <QList>
#include "define.h"
#include "gridinfo.h"

class ViewInfo
{
private:
    GridInfo gridInfo[CHANNEL_MAX];
public:
    int gridNum;
    QList<GridInfo*> *gridInfoList;

    ViewInfo();
    ~ViewInfo();
    void setGridInfo(int idx, int x, int y, int width, int height,
                     int border, bool visible);
};

#endif // VIEWINFO_H
