#-------------------------------------------------
#
# Project created by QtCreator 2017-08-04T17:40:29
#
#-------------------------------------------------

QT       += core gui network

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = rtk-stress-test
TEMPLATE = app

# The following define makes your compiler emit warnings if you use
# any feature of Qt which as been marked as deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS

SOURCES += \
    main.cpp

HEADERS += \

CONFIG += link_pkgconfig
PKGCONFIG += gstreamer-1.0
PKGCONFIG += gstreamer-video-1.0
INCLUDEPATH += ../lib-rtk-qt-base
LIBS += -L../lib-rtk-qt-base -lrtkqtbase

QMAKE_CXXFLAGS += -w
