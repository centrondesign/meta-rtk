#include <QApplication>
#include <QDateTime>
#include <QFileInfo>
#include <QTextCodec>
#include "gui/mainwidget.h"
#include "rtkgst.h"
#include "rtkgstplus.h"
#include "commandserver.h"
#include <signal.h>

#define _LOG_FILE_       "log.txt"
QtMessageHandler defMsgHandler;

QFile logFile;
static MainWidget *pMainWidget = NULL;
RtkGst rtkGs;
CommandServer cmdServer;
QString strPlatformName;

void finalize()
{
    if (pMainWidget != NULL)
    {
        pMainWidget->finalize();
        pMainWidget = NULL;
    }
    if (logFile.isOpen())
    {
        logFile.close();
    }
    if (Config::sys.restartWeston && strPlatformName == _STR_WAYLAND_)
    {
        rtkGs.modifyWestonIni(WestonMode::Reset);
    }
}

static void sig_handler(int sig)
{
    switch(sig)
    {
    case SIGSEGV:   // crash
    case SIGKILL:   // kill command
    case SIGTERM:
    case SIGINT:    // ctrl+c
    case SIGTSTP:   // ctrl+z
//    case SIGILL:
//    case SIGABRT:
//    case SIGBUS:
//    case SIGHUP:
        qDebug() << QString().asprintf("%s() with signal=%d", __func__, sig);
        finalize();
        exit(1);
        break;
    }
}

void myMsgHandler(QtMsgType type, const QMessageLogContext &log, const QString &msg)
{
    static bool lock = false;
    static bool initLog = true;

    if (lock)
        return;
    lock = true;

    QString str = QString("[%1] %2")
                  .arg(QDateTime::currentDateTime().toString("yy/MM/dd HH:mm:ss.zzz"))
                  .arg(msg);

    // Qt Gui Application
    if(defMsgHandler != NULL)
    {
        defMsgHandler(type, log, str);
    }
    else
    {
        fprintf(stderr, "%s\n", str.toLatin1().constData());
    }

    if(Config::sys.logMsg)
    {
        if (logFile.isOpen() != true)
        {
            logFile.open(logFile.exists() ? QIODevice::Append : QIODevice::WriteOnly);
        }
        if (logFile.isOpen() == true)
        {
            QTextStream out(&logFile);
            if(initLog)
            {
                out << QString("[%1] ---------------------- LOG START -----------------------\n")
                       .arg(QDateTime::currentDateTime().toString("yy/MM/dd HH:mm:ss.zzz"));
                initLog = false;
            }
            out << QString("%1\n").arg(str);
            out.flush();
        }
    }

#if 0
     switch (type) {
     case QtDebugMsg:
         fprintf(stderr, "Debug: %s\n", msg);
         break;
     case QtWarningMsg:
         fprintf(stderr, "Warning: %s\n", msg);
         break;
     case QtCriticalMsg:
         fprintf(stderr, "Critical: %s\n", msg);
         break;
     case QtFatalMsg:
         fprintf(stderr, "Fatal: %s\n", msg);
         abort();
     }
#endif

     // sysLog.logInfo(msg);
     lock = false;
}

int main(int argc, char *argv[])
{
    // Use argv[0] as the application name to get the absolute dir path
    QFileInfo fileInfo(QString::fromLocal8Bit(argv[0]));
    QString absolutePath = fileInfo.absolutePath()+"/";

    logFile.setFileName(absolutePath+_LOG_FILE_);
    qDebug() << "logFile=" << logFile.fileName();
    // In WriteOnly or ReadWrite mode, if the relevant file does not already exist,
    // this function will try to create a new file before opening it.
    logFile.open(logFile.exists() ? QIODevice::Append : QIODevice::WriteOnly);

    Config config;
    if (!config.init(absolutePath))
    {
        qDebug() << "Initialization Fail !";
    }

    strPlatformName = rtkGs.getPlatformName(argc, argv);
    if (Config::sys.restartWeston && strPlatformName == _STR_WAYLAND_)
    {
        rtkGs.modifyWestonIni(WestonMode::Update);
    }
    rtkGs.parsePlatformSetting();

    int rtn = 0;

    // in Qt Console Application, defMsgHandler is null
    // in Qt Gui Application, defMsgHandler is NOT null
    defMsgHandler = qInstallMessageHandler(myMsgHandler);

    /*
    QtSingleApplication a("NVR", argc, argv);
    if (a.sendMessage("Wake up!"))
    {
        QMessageBox::critical(NULL, "", "NVR is Already Running !");
        return 0;
    }
    */

    QApplication a(argc, argv);
    // a.setApplicationName("rtk-playback");
    // a.setApplicationVersion("1.0");

    // In order to display correct file name with other languages, ex: Chinese for zh-cn or zh-tw
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));

    struct sigaction newact;
    newact.sa_handler = (__sighandler_t)sig_handler;
    sigemptyset(&newact.sa_mask);
    newact.sa_flags = 0;
    sigaction(SIGSEGV, &newact, NULL);
    sigaction(SIGKILL, &newact, NULL);
    sigaction(SIGTERM, &newact, NULL);
    sigaction(SIGINT, &newact, NULL);
    sigaction(SIGTSTP, &newact, NULL);
//    sigaction(SIGILL, &newact, NULL);
//    sigaction(SIGABRT, &newact, NULL);
//    sigaction(SIGBUS, &newact, NULL);
//    sigaction(SIGHUP, &newact, NULL);

    // Upper part is failed, add these to set signal
    signal(SIGINT, sig_handler);
    signal(SIGTERM, sig_handler);
    signal(SIGTSTP, sig_handler);
    signal(SIGSEGV, sig_handler);

    MainWidget mainwidget;
    RtkGstPlus rtkGsPls;
    rtkGs.set_debug((Config::sys.dbgFlag & _DBG_RTKGST_) > 0);
    rtkGs.set_sink(Config::sys.videoSink, Config::sys.textSink);
    rtkGsPls.set_debug((Config::sys.dbgFlag & _DBG_RTKGST_) > 0);

    pMainWidget = &mainwidget;
    if(mainwidget.setup()) // also setup other API
    {
        QScreen *screen = QGuiApplication::primaryScreen();
        QSize screenSize = screen->availableSize();
        qDebug() << QString("Screen size: w=%1, h=%2").arg(screenSize.width()).arg(screenSize.height());

        cmdServer.startServer();
        mainwidget.show();
        rtn = a.exec();
    }
    else
    {
        qDebug() << "setup fail and abort !";
    }

    finalize();
    return rtn;
}
