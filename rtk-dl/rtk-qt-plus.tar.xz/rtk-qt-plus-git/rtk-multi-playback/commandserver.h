/**
 * @file commandserver.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2025
 * @brief The server for automation test
 */
 #include <QTcpServer>

class CommandServer : public QTcpServer {
    Q_OBJECT
public:
    CommandServer(QObject* parent = nullptr);
    void startServer();

protected:
    void incomingConnection(qintptr socketDescriptor);

private:
	bool ifEndServer;

    QStringList parseArgs(const QString& line);
    QString handleCommand(const QString& line);
};
