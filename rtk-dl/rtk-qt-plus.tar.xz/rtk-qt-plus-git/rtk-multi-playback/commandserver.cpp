/**
 * @file commandserver.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2025
 * @brief The server for automation test
 */
#include "commandserver.h"
#include "config.h"
#include "gui/mainwidget.h"
#include <QTcpSocket>
#include <QStringList>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QThread>

#define HEADER      "CmdSrv: "
#define HEADER_ERR  "CmdSrv: [ERR] "

CommandServer::CommandServer(QObject* parent) :
    QTcpServer(parent)
{
    ifEndServer = false;
}

void CommandServer::startServer()
{
    if (!listen(QHostAddress::Any, Config::sys.cmdServerPort))
        qInfo() << HEADER << "listen failed";
    else
        qDebug() << HEADER << "started. Listening on port " << Config::sys.cmdServerPort;
}

void CommandServer::incomingConnection(qintptr socketDescriptor)
{
    QTcpSocket* clientConnection = new QTcpSocket(this);
    clientConnection->setSocketDescriptor(socketDescriptor);

    connect(clientConnection, &QTcpSocket::readyRead, [this, clientConnection]() {
        QByteArray data = clientConnection->readAll();
        QString cmd = QString::fromUtf8(data).trimmed();
        qDebug() << HEADER << "rcv cmd:" << cmd;

        QString reply = handleCommand(cmd);
        clientConnection->write(reply.toUtf8());
        clientConnection->flush();
        clientConnection->disconnectFromHost();
        if(ifEndServer)
        {
            playback->btnPlayStop_clicked();
            playback->power_clicked();
        }
    });

    connect(clientConnection, &QTcpSocket::disconnected, clientConnection, &QTcpSocket::deleteLater);
}

QStringList CommandServer::parseArgs(const QString& line)
{
    QStringList argsCandidate = line.split(' ');
    QStringList args;
    int i=0, maxIdx = argsCandidate.count()-1;
    while (i<=maxIdx)
    {
        if (argsCandidate[i].startsWith("\""))
        {
            QString arg;
            argsCandidate[i] = argsCandidate[i].right(argsCandidate[i].length()-1);
            // to correctly recognize the string with ""
            int endIdx = maxIdx;
            for (int j=i; j<=maxIdx; j++)
            {
                bool bMarkEnd = argsCandidate[j].endsWith("\"");
                if (bMarkEnd)
                {
                    argsCandidate[j] = argsCandidate[j].left(argsCandidate[j].length()-1);
                }
                if(j!=i)
                    arg.append(' ');
                arg.append(argsCandidate[j]);
                if (bMarkEnd)
                {
                    endIdx = j;
                    break;
                }
            }
            // qDebug() << HEADER << i << "startsWith \" ~ " << endIdx;
            args.append(arg);
            i = endIdx + 1;
        }
        else
        {
            args.append(argsCandidate[i]);
            i += 1;
        }
    }
    return args;
}

QString CommandServer::handleCommand(const QString& line)
{
    QStringList args = parseArgs(line);
    QStringList replyLines;
    QString reply;
    int i = 0;
    while (i < args.size())
    {
        reply.clear();
        if ((args[i] == "-d" || args[i] == "--AddDir") && i + 1 < args.size())
        {
            QString dirPath = args[i+1];
            QDir dir(dirPath);
            if (dir.exists()) {
                selectVideo->addDir(dirPath);
                reply = "Directory: " + dirPath;
            }
            else
            {
                reply = "Directory not found: " + dirPath;
                qInfo() << HEADER_ERR << reply;
            }
            i += 2;
        }
        else if ((args[i] == "-f" || args[i] == "--AddFile") && i + 1 < args.size())
        {
            QString filePath = QString(args[i+1]);
            QFile file(filePath);
            if (file.exists())
            {
                if (playback->getIdxOfListForSpecificVideo(filePath) < 0)
                {
                    QStringList files;
                    files.append(filePath);
                    selectVideo->addFiles(files);
                    reply = "File to list: " + filePath;
                }
                else
                    reply = "File already in list: " + filePath;
            }
            else
            {
                reply = "File does not exist: " + filePath;
                qInfo() << HEADER_ERR << reply;
            }
            i += 2;
        }
        else if ((args[i] == "-l" || args[i] == "--LoadList") && i + 1 < args.size())
        {
            QString filePath = QString(args[i+1]);
            QFile file(filePath);
            if (file.exists())
            {
                if (selectVideo->loadList(filePath, false, true))
                {
                    reply = "Success to load list in " + filePath;
                }
                else
                {
                    reply = "Fail to load list in " + filePath;
                    qInfo() << HEADER_ERR << reply;
                }
            }
            else
            {
                reply = "File does not exist: " + filePath;
                qInfo() << HEADER_ERR << reply;
            }
            i += 2;
        }
        else if (args[i] == "-c" || args[i] == "--ClearList")
        {
            selectVideo->clearList();
            reply = "Clear list";
            // qInfo() << HEADER << reply;
            i ++;
        }
        else if ((args[i] == "-pl" || args[i] == "--Play") && i + 1 < args.size())
        {
            QString filePath = QString(args[i+1]);
            QFile file(filePath);
            if (file.exists())
            {
                if (playback->getIdxOfListForSpecificVideo(filePath) < 0)
                {
                    // file does not in video list, then add it
                    QStringList files;
                    files.append(filePath);
                    selectVideo->addFiles(files);
                }
                if (playback->selectSpecificVideoInList(filePath))
                {
                    // stop original play
                    playback->btnPlayStop_clicked();
                    if (playback->isPlayable(filePath, false, false))
                    {
                        QThread::msleep(500);
                        // start current play
                        playback->setPlayPauseButton(true);
                        reply = "Play file: " + filePath;
                        // qInfo() << HEADER << reply;
                    }
                    else
                    {
                        reply = "File over spec: " + filePath;
                        qInfo() << HEADER_ERR << reply;
                    }
                }
                else
                {
                    reply = "Fail to select file in list: " + filePath;
                    qInfo() << HEADER_ERR << reply;
                }
            }
            else
            {
                reply = "File does not exist: " + filePath;
                qInfo() << HEADER_ERR << reply;
            }
            i += 2;
        }
        else if (args[i] == "-ps" || args[i] == "--Pause")
        {
            if (playback->setPlayPaused())
            {
                reply = "Pause";
                // qInfo() << HEADER << reply;
            }
            else
            {
                reply = "Pause failed";
                qInfo() << HEADER_ERR << reply;
            }
            reply = "Pause";
            // qInfo() << HEADER << reply;
            i ++;
        }
        else if (args[i] == "-rs" || args[i] == "--Resume")
        {
            if (playback->setPlayResumed())
            {
                reply = "Resume";
                // qInfo() << HEADER << reply;
            }
            else
            {
                reply = "Resume failed";
                qInfo() << HEADER_ERR << reply;
            }
            i ++;
        }
        else if (args[i] == "-st" || args[i] == "--Stop")
        {
            playback->btnPlayStop_clicked();
            reply = "Stop";
            // qInfo() << HEADER << reply;
            i ++;
        }
        else if ((args[i] == "-fs" || args[i] == "--Fullscreen") && i + 1 < args.size())
        {
            QString strFullscreen = QString(args[i+1]);
            bool ok = false;
            int value = 0;
            value = strFullscreen.toInt(&ok);
            if (ok == true && value >= 0 && value <= 1)
            {
                playback->setPlayFullscreen(value>0);
                reply = QString("Set fullscreen to %1").arg(args[i+1]);
                qInfo() << HEADER << reply;
            }
            else
            {
                reply = QString("Error fullscreen %1").arg(args[i+1]);
                qInfo() << HEADER_ERR << reply;
            }
            i += 2;
        }
        else if (args[i] == "-rt" || args[i] == "--Rotate")
        {
            playback->setPlayRotate();
            reply = "Rotate";
            // qInfo() << HEADER << reply;
            i ++;
        }
        else if (args[i] == "-mt" || args[i] == "--Mute")
        {
            playback->setMute();
            reply = "Mute";
            // qInfo() << HEADER << reply;
            i ++;
        }
        else if (args[i] == "-um" || args[i] == "--Unmute")
        {
            playback->setUnmute();
            reply = "Unmute";
            // qInfo() << HEADER << reply;
            i ++;
        }
        else if ((args[i] == "-vl" || args[i] == "--Volume") && i + 1 < args.size())
        {
            QString strVolume = QString(args[i+1]);
            bool ok = false;
            int value = 0;
            value = strVolume.toInt(&ok);
            if (ok == true && value >= 0 && value <= 100)
            {
                playback->setVolume(value);
                reply = QString("Set volume to %1").arg(args[i+1]);
                qInfo() << HEADER << reply;
            }
            else
            {
                reply = QString("Error volume %1").arg(args[i+1]);
                qInfo() << HEADER_ERR << reply;
            }
            i += 2;
        }
        else if ((args[i] == "-sp" || args[i] == "--Speed") && i + 1 < args.size())
        {
            QString strSpeed = QString(args[i+1]);
            bool ok = false;
            double value = 0;
            value = strSpeed.toDouble(&ok);
            if (ok == true && value >= 0.0)
            {
                playback->setPlaySpeed(value);
                reply = QString("Set speed to %1 x").arg(args[i+1]);
                qInfo() << HEADER << reply;
            }
            else
            {
                reply = QString("Error speed %1 x").arg(args[i+1]);
                qInfo() << HEADER_ERR << reply;
            }
            i += 2;
        }
        else if ((args[i] == "-sr" || args[i] == "--SeekRate") && i + 1 < args.size())
        {
            QString strRate = QString(args[i+1]);
            bool ok = false;
            double value = 0;
            value = strRate.toDouble(&ok);
            if (ok == true && value >= 0.0 && value <= 100.0)
            {
                double rate = value / 100.0;
                playback->seekToPositionByRate(rate);
                reply = QString("Seek to %1 \%").arg(args[i+1]);
                // qInfo() << HEADER << reply;
            }
            else
            {
                reply = QString("Error seek rate %1 \%").arg(args[i+1]);
                qInfo() << HEADER_ERR << reply;
            }
            i += 2;
        }
        else if ((args[i] == "-ss" || args[i] == "--SeekSecond") && i + 1 < args.size())
        {
            QString strOffset = QString(args[i+1]);
            bool ok = false;
            long long offset = 0;
            offset = strOffset.toLongLong(&ok);
            if (ok == true)
            {
                playback->seekToPositionByOffset(offset);
                reply = QString("Seek offset %1 seconds").arg(offset);
                // qInfo() << HEADER << reply;
            }
            else
            {
                reply = QString("Error seek offset %1 seconds").arg(args[i+1]);
                qInfo() << HEADER_ERR << reply;
            }
            i += 2;
        }
        else if (args[i] == "--EndServer")
        {
            reply = QString("End server");
            qInfo() << HEADER << reply;
            ifEndServer = true;
            i += 1;
        }
        else if (args[i] == "--help")
        {
            // client will response, server jsut does nothing
            i += 1;
        }
        else
        {
            reply = "Unknown cmd " + args[i] + " or insufficient parameters";
            qInfo() << HEADER_ERR << reply;
            i ++;
        }
        if (!reply.isEmpty())
        {
            replyLines << reply;
        }
    }
    if (replyLines.isEmpty())
        replyLines << "No valid arguments processed.";
    // 多行資料用 '\n' 結尾，符合常見 CLI 行為
    return replyLines.join('\n') + '\n';
}