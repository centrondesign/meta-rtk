/**
 * @file rtkgstplus.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The interface/api to use Realtek library
 */
#include <QUrl>
#include <QDebug>
#include "rtkgstplus.h"

RtkGstPlus *rtkGstPlus = NULL;

RtkGstPlus::RtkGstPlus()
{
    rtkGstPlus = this;
    if_debug = false;
}

RtkGstPlus::~RtkGstPlus()
{
}

void RtkGstPlus::set_debug (bool bDebug)
{
    if_debug = bDebug;
}

pair<gint64, gint64> RtkGstPlus::rtk_plus_getPositionDuration(QString strSource, int ch, GstPlay *play)
{
    auto [position, duration] = rtkGst->rtk_gst_getPlaybackPositionDuration(play);
    // if (duration > 0)
    // {
    //     if (if_debug)
    //         qDebug () << QString().asprintf("%s ch %d position %ld duration %ld", 
    //                                 strSource.toStdString().c_str(), ch, position, duration);
    // }
    return {position, duration};
}

bool RtkGstPlus::rtk_plus_setVolume(QString strSource, int ch, GstPlay *play, int volume)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d volume %d", __FUNCTION__, __LINE__, 
                                strSource.toStdString().c_str(), ch, volume);
    return rtkGst->rtk_gst_setVolume (play, volume);
}

bool RtkGstPlus::rtk_plus_play_new(QString strSource, int ch, GstPlay **play_p, const QString filepath, QWidget *gst_window,
                                  bool bFullscreen,
                                  int x, int y, int width, int height,
                                  bool bAudio)
{
    if (play_p == NULL)
        return false;

    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d play_p %p filepath=%s bFullscreen=%d x=%d y=%d w=%d h=%d, bAudio=%d",
                    __FUNCTION__, __LINE__, strSource.toStdString().c_str(),
                    ch, play_p, filepath.toStdString().c_str(), bFullscreen, x, y, width, height, bAudio);

    return rtkGst->rtk_gst_play_new (play_p, filepath, gst_window, bFullscreen, x, y, width, height, bAudio);
}

void RtkGstPlus::rtk_plus_play_free(QString strSource, int ch, GstPlay **play_p)
{
    if(play_p == NULL || *play_p == NULL)
        return;

    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d play_p %p",
                     __FUNCTION__, __LINE__, strSource.toStdString().c_str(), ch, play_p);

    return rtkGst->rtk_gst_play_free (play_p);
}

bool RtkGstPlus::rtk_plus_seek_by_slider(QString strSource, int ch, GstPlay *play, gdouble rate)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d play %p, rate=%lf",
                    __FUNCTION__, __LINE__, strSource.toStdString().c_str(), ch, play, rate);

    return rtkGst->rtk_gst_seek_by_slider (play, rate);
}

bool RtkGstPlus::rtk_plus_seek_with_offset(QString strSource, int ch, GstPlay *play, gint64 offset)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d play %p, offset=%ld",
                    __FUNCTION__, __LINE__, strSource.toStdString().c_str(), ch, play, offset);

    return rtkGst->rtk_gst_seek_with_offset (play, offset);
}

void RtkGstPlus::rtk_plus_speedchange(QString strSource, int ch, GstPlay *play, gdouble rate)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d play %p, rate=%lf",
                    __FUNCTION__, __LINE__, strSource.toStdString().c_str(), ch, play, rate);
    return rtkGst->rtk_gst_speedchange (play, rate);
}

bool RtkGstPlus::rtk_plus_pause(QString strSource, int ch, GstPlay *play)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d play %p",
                     __FUNCTION__, __LINE__, strSource.toStdString().c_str(), ch, play);
    return rtkGst->rtk_gst_pause(play);
}

bool RtkGstPlus::rtk_plus_resume(QString strSource, int ch, GstPlay *play)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d play %p",
                     __FUNCTION__, __LINE__, strSource.toStdString().c_str(), ch, play);
    return rtkGst->rtk_gst_resume(play);
}

void RtkGstPlus::rtk_plus_rotation(QString strSource, int ch, GstPlay *play)
{
    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d play %p",
                     __FUNCTION__, __LINE__, strSource.toStdString().c_str(), ch, play);
    return rtkGst->rtk_gst_rotation(play);
}

void RtkGstPlus::rtk_plus_play_ai(QString strSource, int ch, GstPlay **play_p, const QString filepath, QString selectedMode,
                            bool bFullscreen, int x, int y, int width, int height,
                            AiParam *param, bool bAudio)
{
    if (play_p == NULL)
        return;

    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d, play_p %p filepath=%s selectedMode=%s bFullscreen=%d x=%d y=%d w=%d h=%d, bAudio=%d",
                    __FUNCTION__, __LINE__, strSource.toStdString().c_str(),
                    ch, play_p, selectedMode, filepath.toStdString().c_str(), bFullscreen, x, y, width, height, bAudio);

    return rtkGst->rtk_gst_play_ai (play_p, filepath, selectedMode,
                        bFullscreen, x, y, width, height, param, bAudio);
}

bool RtkGstPlus::rtk_plus_play_multi(QString strSource, int ch, GstPlay **play_p, const QString srcpath, QWidget *gst_window,
                                  bool bFullscreen,
                                  int x, int y, int width, int height,
                                  bool bAudio)
{
    if (play_p == NULL)
        return false;

    if (if_debug)
        qDebug () << QString().asprintf("%s:%d %s ch %d play_p %p srcpath=%s bFullscreen=%d x=%d y=%d w=%d h=%d, bAudio=%d",
                    __FUNCTION__, __LINE__, strSource.toStdString().c_str(),
                    ch, play_p, srcpath.toStdString().c_str(), bFullscreen, x, y, width, height, bAudio);

    return rtkGst->rtk_gst_play_multi (strSource, ch, play_p, srcpath, gst_window, bFullscreen, x, y, width, height, bAudio);
}
