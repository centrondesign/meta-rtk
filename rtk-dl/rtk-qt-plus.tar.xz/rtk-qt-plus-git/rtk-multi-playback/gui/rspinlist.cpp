/**
 * @file rspinlist.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The reimplementation of QSpinBox
 */

#include "rspinlist.h"

#define INVALID_INDEX   -1

RSpinList::RSpinList(QWidget *parent) : QWidget(parent)
{
    wBg = new QWidget(this);
    btnLeft = new QToolButton(this);
    btnRight = new QToolButton(this);
    leText = new QLineEdit(this);
    leText->setEnabled(false);
    leText->setAlignment(Qt::AlignCenter);
    leText->setText("1 x");
    bFixBtnSize = true;
    btnWidth = 54;
    currentIdx = INVALID_INDEX;

    connect(btnLeft,    SIGNAL(clicked(bool)), this, SLOT(slotLeftClicked(bool)));
    connect(btnRight,   SIGNAL(clicked(bool)), this, SLOT(slotRightClicked(bool)));
}

RSpinList::~RSpinList()
{
    delete(btnLeft);
    delete(btnRight);
    delete(leText);
    delete(wBg);
}

void RSpinList::setBtnWidth(int width, bool bFix)
{
    bFixBtnSize = bFix;
    btnWidth = width;
    setGeometry(this->rect());
}

void RSpinList::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);

    int leWidth, heightOffset;
    if(bFixBtnSize)
    {
        heightOffset = (rect.height() - btnWidth)/2;
        leWidth = rect.width() - btnWidth*2;
    }
    else
    {
        if (rect.width() > rect.height()*5)
        {
            btnWidth = rect.height();
            heightOffset = 0;
        }
        else
        {
            btnWidth = rect.width()/5;
            heightOffset = (rect.height() - btnWidth)/2;
        }
        leWidth = rect.width() - btnWidth*2;
    }
    leWidth = qMax(0, leWidth);
    wBg->setGeometry(0, 0, rect.width(), rect.height());
    btnLeft->setGeometry(0, heightOffset, btnWidth, btnWidth);
    btnRight->setGeometry(rect.width()-btnWidth, heightOffset, btnWidth, btnWidth);
    leText->setGeometry(btnLeft->width(), heightOffset, leWidth, btnWidth);
}

void RSpinList::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void RSpinList::append(QString optName, double optValue)
{
    listOptName.append(optName);
    listOptVal.append(optValue);
    if (currentIdx < 0)
        updateCurrentIndex(0);
    else
        updateCurrentIndex(currentIdx);
}

void RSpinList::setValue(double optValue)
{
    int index = INVALID_INDEX;

    for(int i=0; i<listOptVal.count(); i++)
    {
        if(listOptVal.at(i) == optValue)
        {
            index = i;
            break;
        }
    }
    if (index != INVALID_INDEX)
    {
        updateCurrentIndex (index);
        emit valueChanged(getValue());
    }
}

double RSpinList::getValue()
{
    if (currentIdx >= 0 && currentIdx < listOptVal.count())
        return listOptVal.at(currentIdx);
    else
        return 0;
}

void RSpinList::slotLeftClicked(bool ifClicked)
{
    if (currentIdx <= 0)
        return;
    updateCurrentIndex (currentIdx - 1);
    emit leftClicked(ifClicked);
    emit valueChanged(getValue());
}

void RSpinList::slotRightClicked(bool ifClicked)
{
    if (currentIdx >= listOptName.count())
        return;
    updateCurrentIndex (currentIdx + 1);
    emit rightClicked(ifClicked);
    emit valueChanged(getValue());
}

void RSpinList::updateCurrentIndex(int index)
{
    bool bBtnLeftEnable, bBtnRightEnable;
    if (index >= 0 && index < listOptVal.count())
    {
        currentIdx = index;
    }
    leText->setText(listOptName.at(currentIdx));
    bBtnLeftEnable = !(currentIdx <= 0);
//    btnLeft->setEnabled(bBtnLeftEnable);
    btnLeft->setVisible(bBtnLeftEnable);
    bBtnRightEnable = !(currentIdx >= listOptVal.count()-1);
//    btnRight->setEnabled(bBtnRightEnable);
    btnRight->setVisible(bBtnRightEnable);
}
