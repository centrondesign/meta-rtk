/**
 * @file rtoolbutton.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The extenstion of QToolButton
 */

#include "rtoolbutton.h"
#include <QEvent>
#include <QDebug>

RToolButton::RToolButton(QWidget *parent) :
    QToolButton(parent)
{
    on_text = "";
    off_text = "";
    checkActive = false;
    bActived = false;
    this->setStyleSheet("border:0px;"    // transparent for Linux
                         "background:transparent;");
}

RToolButton::~RToolButton()
{
}

void RToolButton::setIcons(const QIcon &off_normal_icon,
                           const QIcon &off_hover_icon,
                           const QIcon &on_normal_icon,
                           const QIcon &on_hover_icon,
                           bool checkActive)
{
    this->off_normal_icon = off_normal_icon;
    this->off_hover_icon = off_hover_icon;
    this->on_normal_icon = on_normal_icon;
    this->on_hover_icon = on_hover_icon;
    this->checkActive = checkActive;
    this->installEventFilter(this);
    this->setIcon(this->off_normal_icon);
    if (this->checkActive)
    {
        connect(this, SIGNAL(clicked(bool)), this, SLOT(_switchActive(bool)));
    }
}

void RToolButton::setTexts(QString off_text, QString on_text)
{
    this->off_text = off_text;
    this->on_text = on_text;
}

bool RToolButton::eventFilter(QObject * obj, QEvent * event)
{
    RToolButton * button = qobject_cast<RToolButton*>(obj);
//    qDebug() << button << event->type();

    if (button)
    {
        switch(event->type())
        {
        case QEvent::Enter:
            // The push button is hovered by mouse
            _setHoverIcon();
            break;
        case QEvent::Leave:
            // The push button is not hovered by mouse
            _setNormalIcon();
            break;
        default:
            break;
        }
    }
    return QObject::eventFilter(obj, event);
}

void RToolButton::_setHoverIcon()
{
    this->setIcon((checkActive & bActived) ?
                    this->on_hover_icon : this->off_hover_icon);
}

void RToolButton::_setNormalIcon()
{
    this->setIcon((checkActive & bActived) ?
                    this->on_normal_icon : this->off_normal_icon);
}

void RToolButton::_switchActive(bool)
{
    this->bActived = !this->bActived;
    if(checkActive & bActived)
    {
        if(on_text.length() > 0)
            this->setText(on_text);
    }
    else
    {
        if(off_text.length() > 0)
            this->setText(off_text);
    }
    _setHoverIcon();
}

void RToolButton::setActive(bool active, bool bHover)
{
    this->bActived = active;
    if(checkActive & bActived)
    {
        if(on_text.length() > 0)
            this->setText(on_text);
    }
    else
    {
        if(off_text.length() > 0)
            this->setText(off_text);
    }
    if(bHover)
    {
        _setHoverIcon();
    }
    else
    {
        _setNormalIcon();
    }
}

bool RToolButton::getActived()
{
    return this->bActived;
}
