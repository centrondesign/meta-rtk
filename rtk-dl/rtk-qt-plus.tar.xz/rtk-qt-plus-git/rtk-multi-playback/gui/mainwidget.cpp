/**
 * @file mainwidget.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The main background widget page of GUI
 */

#include "mainwidget.h"
#include "ui_mainwidget.h"
#include <QListView>
#include <QFrame>
#include <fcntl.h>
#include <sys/wait.h>

MainWidget *mainWidget = NULL;
Playback *playback = NULL;
SelectVideo *selectVideo = NULL;
Setting *setting = NULL;
Source *setSource = NULL;
System *setSystem = NULL;
Test *setTest = NULL;
Keypad *keypad = NULL;
Keyboard *keyboard = NULL;
RDialog *dialog = NULL;
int g_pipefd[2];

QList<QLabel*> *labelList;
QList<QLineEdit*> *editList;
QList<QLineEdit*> *readOnlyList;
QList<RCheckBox*> *checkList;
QList<QToolButton*> *actionList;

MainWidget::MainWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWidget)
{
    ui->setupUi(this);

    // [20180807:Brian] enable 3840x2160
    this->setGeometry(0, 0, Config::sys.width, Config::sys.height);
    ui->wBg->setGeometry(0, 0, Config::sys.width, Config::sys.height);
    bootTimer = NULL;

    mainWidget = this;
    playback = ui->widgetPlayback;
    selectVideo = ui->widgetSelectVideo;
    setting = ui->widgetSetting;
    setSource = ui->widgetSetting->source;
    setSystem = ui->widgetSetting->system;
    setTest = ui->widgetSetting->test;
    keypad = ui->widgetKeypad;
    keyboard = ui->widgetKeyboard;
    dialog = ui->widgetDialog;
    widgetList << playback;
    widgetList << selectVideo;
    widgetList << setting;
    widgetList << keypad;
    widgetList << keyboard;
    widgetList << dialog;

    labelList = new QList<QLabel*>();
    editList = new QList<QLineEdit*>();
    readOnlyList = new QList<QLineEdit*>();
    checkList = new QList<RCheckBox*>();
    actionList = new QList<QToolButton*>();

    faceRecogEdit = new QLineEdit(this);
    faceRecogEdit->setPlaceholderText("Input name");
    faceRecogEdit->setMinimumWidth(100);
    faceRecogEdit->setFont(QFont(faceRecogEdit->font().family(), 16));
    faceRecogEdit->hide();
    connect(faceRecogEdit, &QLineEdit::textChanged, [=](const QString &text) {
            QFontMetrics fontMetrics(faceRecogEdit->font());
            int textWidth = fontMetrics.horizontalAdvance(text);
            int padding = 20;
            int newWidth = textWidth + padding;
            faceRecogEdit->setMinimumWidth(newWidth > 100 ? newWidth : 100);
    });

    faceRecogEditTimer = new QTimer(this);
    connect(faceRecogEditTimer, &QTimer::timeout, this, [=]() {
        if (!ui->widgetPlayback->is_face_recog_running()) {
            faceRecogEdit->clear();
            faceRecogEdit->hide();
            faceRecogEditTimer->stop();
        }
    });

    //playback->installEventFilterForKeyboard(keyboard, keypad);
    setSource->installEventFilterForKeyboard(keyboard, keypad);
    setTest->installEventFilterForKeyboard(keyboard, keypad);

    this->setWindowOpacity(1);
// #if QT_ENV_ONLY == 1
    this->setAttribute(Qt::WA_TranslucentBackground);
    this->setWindowFlags(Qt::FramelessWindowHint);
// #else
    // if (Config::sys.isWayland)
    // {
    //     this->setStyleSheet("background:transparent;");
    // }
    // else
    // {
    //     this->setAttribute(Qt::WA_TranslucentBackground);
    // }
    // this->setWindowFlags(Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint);
// #endif
    /*
    QPalette pal = palette();
    pal.setColor(QPalette::Background, QColor(0x00,0xff,0x00,0x00));
    this->setPalette(pal);
    */

    ui->widgetKeypad->setGeometry(550, 0, 315, 225);
    ui->widgetKeyboard->setGeometry(550, 0, 715, 270);
    ui->widgetDialog->setGeometry(0, 0, Config::sys.width, Config::sys.height);
    ui->widgetSelectVideo->setGeometry(400, 76, 700, 600);
    ui->widgetSetting->setGeometry(350, 136, 1220, 808);
    ui->widgetPlayback->setGeometry(0, 0, Config::sys.width, Config::sys.height);

    if (pipe(g_pipefd) == -1) {
        perror("pipe");
    } else {
        int flags = fcntl(g_pipefd[0], F_GETFL, 0);
        fcntl(g_pipefd[0], F_SETFL, flags | O_NONBLOCK);
    }
}

MainWidget::~MainWidget()
{
    if(bootTimer != NULL)
    {
        bootTimer->stop();
        delete bootTimer;
    }
    delete actionList;
    delete checkList;
    delete readOnlyList;
    delete editList;
    delete labelList;
    delete ui;
}

bool MainWidget::setup()
{
    for(int i=widgetList.count()-1; i>=0; i--)
    {
        widgetList.at(i)->raise();
    }

    selectVideo->setup();
    setting->setup();
    playback->setup();
    showIdxWidgetOnly(playback);

    setComponentStyleSheet();
    return true;
}

void MainWidget::finalize()
{
    if(DBG(_DBG_RTKGST_))
        qDebug() << "MainWidget::finalize()";
}

void MainWidget::repaintBackground()
{
    ui->wBg->repaint();
}

void MainWidget::setComponentStyleSheet()
{
    int i;
    for (i=0; i<labelList->count(); i++)
    {
        labelList->at(i)->setStyleSheet("color: rgb(102, 109, 109);"
                                        "border:0px;"
                                        "font: 20px \"Arial\";"
                                        "padding:2px;");
    }
    for (i=0; i<editList->count(); i++)
    {
        QLineEdit *le = editList->at(i);
        le->setFrame(false);
        le->setStyleSheet("color: rgb(255, 255, 255);"
                          "border:0px;"
                          "background-color: rgb(69, 77, 77);"
                          "font: bold 20px \"Arial Black\";");
        QMargins margin = le->textMargins();
        le->setTextMargins(margin.left()+5, margin.top(), margin.right()+5, margin.bottom());
    }
    for (i=0; i<readOnlyList->count(); i++)
    {
        readOnlyList->at(i)->setFrame(false);
        readOnlyList->at(i)->setReadOnly(true);
        readOnlyList->at(i)->setStyleSheet("color: rgb(255, 255, 255);"
                                           "border:0px;"
                                           "font: bold 20px \"Arial Black\";");
    }
    for (i=0; i<checkList->count(); i++)
    {
        checkList->at(i)->label->setStyleSheet("background:transparent;"
                                            "border:0px;"
                                            "color: rgb(69, 77, 77);"
                                            "font: 20px \"Arial\";");
    }
    for (i=0; i<actionList->count(); i++)
    {
        actionList->at(i)->setStyleSheet(
                                    QString(
                                    "QToolButton{"
                                         "border:0px;"    // transparent for Linux
                                         "border-radius:6px;"
                                         "color: rgb(32, 38, 41);"
                                         "background-color: rgb(120, 120, 120);"
                                         "%1"
                                         "}"
                                    "QToolButton:hover{"
                                         "border:0px;"    // transparent for Linux
                                         "border-radius:6px;"
                                         "color: rgb(32, 38, 41);"
                                         "background-color: rgb(140, 140, 140);"
                                         "%1"
                                         "}")
                                    .arg("font: bold 20px \"Arial Black\";")
                                   );
    }
}

void MainWidget::keyPressEvent(QKeyEvent *e)
{
    QString keyText = e->text();
    //qDebug() << keyText;
    if (e->key() == Qt::Key_Return || e->key() == Qt::Key_Enter) {
        if (faceRecogEdit->isVisible()) {
            QString face_nme = faceRecogEdit->text();
            if (!face_nme.isEmpty())
                ui->widgetPlayback->face_recog_keyboard_input("\n" + face_nme + "\n");
        }
        faceRecogEdit->clear();
        faceRecogEdit->hide();
    }
    QWidget::keyPressEvent(e);
}

void MainWidget::mouseMoveEvent(QMouseEvent *e)
{
    QWidget::mouseMoveEvent(e);
    // qDebug() << QString().sprintf("%d, %d", e->x(), e->y());
}

void MainWidget::mousePressEvent(QMouseEvent *e)
{
//    qDebug() << __func__ << e;
    QWidget *wdgt;
    QPoint clickPos = e->pos();
    int margin = 15; //pixels
    int x = clickPos.x();
    int y = clickPos.y();

    if( e->button() == Qt::RightButton )
    {
//        qDebug() << "right";
        //emit mouseRightPressed();
        if (ui->widgetPlayback->isVisible() != true)
            ui->widgetPlayback->setPlayFullscreen(false);

        if (ui->widgetPlayback->isVisible())
        {
            return;
        }
        if (ui->widgetKeyboard->isVisible() ||
            ui->widgetKeypad->isVisible())
        {
            return;
        }
        wdgt = getClickedWidget(e);
        if (wdgt != NULL)
        {
            return;
        }
        wdgt = getVisibleWidget(e);
        if (wdgt != NULL)
        {
            wdgt->setHidden(true);
        }
        {
            wdgt = ui->widgetPlayback;
            if (wdgt->isHidden())
            {
                wdgt->setVisible(true);
                wdgt->raise();
            }
//            qDebug() << QString().sprintf("x=%d, y=%d, w=%d, h=%d", x, y, widget->width(), widget->height());
        }
    }
    else if( e->button() == Qt::LeftButton )
    {
//        qDebug() << "left";
        //emit mouseLeftPressed();
        if(ui->widgetPlayback->is_face_recog_running())
        {
            faceRecogEdit->move(x, y);
            faceRecogEdit->show();
            QTimer::singleShot(100, [=]() {
                faceRecogEdit->setFocus();
            });
            faceRecogEditTimer->start(1000);
        }

        if (dialog->isVisible() ||
            ui->widgetPlayback->isVisible())
        {
            return;
        }
        wdgt = getClickedWidget(e);
        if (wdgt != NULL)
        {
            return;
        }
        else
        {
            showIdxWidgetOnly(NULL);
        }
    }
    QWidget::mousePressEvent(e);
}

QWidget* MainWidget::getVisibleWidget(QMouseEvent *e)
{
    Q_UNUSED(e);
    QWidget *wdgt;
    QList<QWidget *>wList = {};
    foreach (wdgt, wList)
    {
        if(wdgt->isVisible())
        {
            return wdgt;
        }
    }
    return NULL;
}

QWidget* MainWidget::getClickedWidget(QMouseEvent *e)
{
    int x, y;
    QWidget *wdgt;
    QList<QWidget *>wList = {};
    foreach (wdgt, wList)
    {
        if(wdgt->isVisible() != true)
            continue;
        x = e->localPos().x(); // localPos, windowPos, screenPos
        y = e->localPos().y();
//        qDebug() << QString("x=%1, widget.x=%2").arg(x).arg(widget->x());
//        qDebug() << QString("y=%1, widget.y=%2").arg(y).arg(widget->y());
        if(x>wdgt->x() && x<wdgt->x()+wdgt->width() &&
           y>wdgt->y() && y<wdgt->y()+wdgt->height())
        {
            return wdgt;
        }
    }
    return NULL;
}

void MainWidget::showIdxWidgetOnly(QWidget *idxWidget)
{
//    qDebug() << __func__ << idxWidget;
    QWidget *wdgt;
    foreach (wdgt, widgetList)
    {
//        if (wdgt == NULL)
//            continue;
        if (wdgt == idxWidget)
        {
            wdgt->setVisible(true);
            dialog->setGeometry(wdgt->x(), wdgt->y(), wdgt->width(), wdgt->height());
        }
        else
            wdgt->setVisible(false);
    }
}

void MainWidget::power_selected(bool)
{
    mainWidget->close();
}
