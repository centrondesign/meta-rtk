/**
 * @file rtoolbutton.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The extenstion of QToolButton
 */

#ifndef RTOOLBUTTON_H
#define RTOOLBUTTON_H

#include <QToolButton>

class RToolButton : public QToolButton
{
    Q_OBJECT
public:
    RToolButton(QWidget *parent = 0);
    ~RToolButton();

    void setIcons(const QIcon &off_normal_icon,
                  const QIcon &off_hover_icon,
                  const QIcon &on_normal_icon,
                  const QIcon &on_hover_icon,
                  bool checkActive);
    void setTexts(QString off_text,
                 QString on_text);
    virtual bool eventFilter(QObject * obj, QEvent * event);
    void setActive(bool active, bool bHover);
    bool getActived();

private:
    QIcon off_normal_icon;
    QIcon off_hover_icon;
    QIcon on_normal_icon;
    QIcon on_hover_icon;
    QString on_text, off_text;
    bool checkActive, bActived;
    void _setNormalIcon();
    void _setHoverIcon();

private slots:
    void _switchActive(bool actived);
};

#endif // RTOOLBUTTON_H
