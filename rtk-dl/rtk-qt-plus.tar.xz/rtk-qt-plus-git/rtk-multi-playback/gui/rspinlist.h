/**
 * @file rspinlist.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The reimplementation of QSpinBox
 */

#ifndef RSPINLIST_H
#define RSPINLIST_H

#include <QWidget>
#include <QToolButton>
#include <QLineEdit>

class RSpinList : public QWidget
{
    Q_OBJECT
public:
    explicit RSpinList(QWidget *parent = nullptr);
    ~RSpinList();

    QWidget *wBg;
    QToolButton *btnLeft, *btnRight;
    QLineEdit *leText;
    bool bFixBtnSize;
    int btnWidth;

    void setBtnWidth(int width, bool bFix);
    void setGeometry(const QRect &rect);
    void setGeometry(int x, int y, int w, int h);
    void append(QString optName, double optValue);
    void setValue(double optValue);
    double getValue();

private:
    int currentIdx;
    QList<QString> listOptName;
    QList<double>  listOptVal;
    void updateCurrentIndex(int index);

signals:
    void leftClicked(bool);
    void rightClicked(bool);
    void valueChanged(double);

public slots:
    void slotLeftClicked(bool);
    void slotRightClicked(bool);
};

#endif // RSPINLIST_H
