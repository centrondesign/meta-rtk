/**
 * @file test.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2025
 * @brief The widget page to do testing
 */

#ifndef Test_H
#define Test_H

#include <QWidget>
#include <QTimer>
#include <QListWidget>
#include <QMutex>
#include <QThread>
#include "rtablayer.h"
#include "rslider.h"
#include "rcheckbox.h"

namespace Ui {
class Test;
}


class TestThread : public QThread
{
    Q_OBJECT
public:
    TestThread();
    ~TestThread();

    void setStart();
    void setStop();
    void run();
    void finalize();
private:
    bool bRun;
};

class Test : public QWidget
{
    Q_OBJECT

public:
    QStringList selectedItemList;

    explicit Test(QWidget *parent = 0);
    ~Test();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setParentAbsoluteOffset(int x, int y);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);
    void setFileNameList(QListWidget *list);
    void updateSelectedItemList();
    void selectAllItems(bool selected);

private:
    Ui::Test *ui;
    int parent_absolute_offset_x, parent_absolute_offset_y;
    QList<RCheckBox *> itemList;
    QListWidget *lFileName;
    TestThread testThrad;
    QMutex mutexChange;
    bool bSelectChanged;
    QTimer *testTimer;

    void initValue(bool fromStatus);

private slots:
    void test_select_all_clicked(bool);
    void test_clear_all_clicked(bool);
    void test_start_clicked(bool);
    void test_stop_clicked(bool);
    void test_hide_clicked(bool);
    void test_select_changed(bool);
    void test_interval_changed();

protected:
    void showEvent(QShowEvent *);
    // bool eventFilter(QObject *o, QEvent *e);
};

#endif // Test_H
