/**
 * @file rsound.cpp
 * @author Realtek Semiconductor Corp.
 * @date July 2018
 * @brief The sound control in Realtek style
 */

#include "rsound.h"
#include "define.h"
#include <QEvent>
#include <QMouseEvent>
#include <QDebug>

RSound::RSound(QWidget *parent) :
    QWidget(parent)
{
    this->setStyleSheet("border:0px;"    // transparent for Linux
                        "background:transparent;");
    dataType = DataType_INT;
    val = SOUND_VALUE_DEF;
    valMax = SOUND_VALUE_MAX;
    valMin = SOUND_VALUE_MIN;
    valStep = 1;
    valLogInt = 2;
    res = 0;
    ifEmitVolumeChanged = true;

    ifBtnBarPressed = false;
    btnBarCenterBase.setX(0);
    btnBarCenterBase.setY(0);
    btnBarScreenBase.setX(0);
    btnBarScreenBase.setY(0);

    bMute = true;
    btnMute = new RToolButton(this);
    btnMute->setGeometry(0, 0, 30, 30);
    btnMute->setIconSize(QSize(30, 30));
    btnMute->setStyleSheet("border:0px;"    // transparent for Linux
                             "background:transparent;");
    btnMute->setIcons(QIcon(":/images/playback_sound_mute_normal.png"),
                      QIcon(":/images/playback_sound_mute_hover.png"),
                      QIcon(":/images/playback_sound_on_normal.png"),
                      QIcon(":/images/playback_sound_on_hover.png"),
                      false);

    wBarCenter = new QWidget(this);
    wBarCenter->setStyleSheet("border:0px;"    // transparent for Linux
                        "background:transparent;");
    wBarLeft = new QWidget(this);
//    wBarLeft->setStyleSheet("border:0px;"    // transparent for Linux
//                            "background: url(\":/images/slider_bar_bg-left_selected.png\")");
    wBarRight = new QWidget(this);
    wBarRight->setStyleSheet("border:0px;"    // transparent for Linux
                             "background: url(\":/images/slider_bar_bg-right_normal.png\")");
    wBarSelect = new QWidget(wBarCenter);
//    wBarSelect->setStyleSheet("border:0px;"    // transparent for Linux
//                              "background: url(\":/images/slider_bar_bg_selected.png\");"); // default: repeat
    wBarNormal = new QWidget(wBarCenter);
    wBarNormal->setStyleSheet("border:0px;"    // transparent for Linux
                              "background: url(\":/images/slider_bar_bg_normal.png\");"); // default: repeat

    label = new QLabel(this);
    label->setGeometry(36, 0, 100, 10);
//    label->setStyleSheet("background:transparent;"
//                         "color: rgb(176, 176, 176);"
//                         "font: bold 18px \"Arial\";");
    label->setAlignment(Qt::AlignCenter | Qt::AlignTop);

    btnBar = new RToolButton(this);
    btnBar->setGeometry(0, 0, 30, 30);
    btnBar->setIconSize(QSize(30, 30));
    btnBar->setStyleSheet("border:0px;"    // transparent for Linux
                          "background:transparent;");
//    btnBar->setIcons(QIcon(":/images/slider_bar_btn_normal.png"),
//                        QIcon(":/images/slider_bar_btn_hover.png"),
//                        QIcon(":/images/slider_bar_btn_normal.png"),
//                        QIcon(":/images/slider_bar_btn_hover.png"),
//                        false);
    btnBar->setMouseTracking(true);
    btnBar->installEventFilter(this);

    _updateColor();
    connect(btnMute, SIGNAL(pressed()),  this, SLOT(_btnMutePressed()));
    connect(btnMute, SIGNAL(released()), this, SLOT(_btnMuteReleased()));
}

RSound::~RSound()
{
    delete(btnMute);
    delete(wBarNormal);
    delete(wBarSelect);
    delete(wBarLeft);
    delete(wBarRight);
    delete(wBarCenter);
    delete(btnBar);

    delete(label);
}

void RSound::setGeometry(int x, int y, int w, int h)
{
    setGeometry(QRect(x, y, w, h));
}

void RSound::setGeometry(const QRect &rect)
{
//    qDebug() << rect.x() << rect.y() << rect.width() << rect.height();
    QWidget::setGeometry(rect);
    int btnWidth = (rect.height() * 4 <= rect.width()) ? rect.height() : 30;
    int y = (rect.height() - btnWidth) / 2;
    btnMute->setGeometry(0, y, btnWidth, btnWidth);
    btnMute->setIconSize(QSize(btnWidth, btnWidth));
    label->setGeometry(rect.width()-btnWidth, y, btnWidth, btnWidth);
    int interval = btnWidth/3;
    int wBarCenterWidth = rect.width() - btnWidth * 2 - interval;
    wBarCenterXMin = btnWidth+interval/2;
    wBarCenterXMax = wBarCenterXMin + wBarCenterWidth;
    int wBarHeight = 20;
    int wBarY = (rect.height()-wBarHeight)/2;
    wBarCenter->setGeometry(wBarCenterXMin, wBarY, wBarCenterWidth, wBarHeight);
    wBarLeft->setGeometry(wBarCenterXMin-4, wBarY, 4, wBarHeight);
    wBarRight->setGeometry(wBarCenterXMax , wBarY, 4, wBarHeight);
    btnBar->setIconSize(QSize(btnWidth, btnWidth));
    btnBar->setGeometry((wBarCenterXMin+wBarCenterXMax)/2-btnWidth/2, 0, btnWidth, btnWidth);
    wBarSelect->setGeometry(0, 0, wBarCenterWidth/2, 20);
    wBarNormal->setGeometry(wBarCenterWidth/2, 0, wBarCenterWidth/2, 20);

    setVolume(val);
}

bool RSound::eventFilter(QObject *o, QEvent *e)
{
    RToolButton *btn = (RToolButton *)o;

    if(btn == btnBar && bMute == false)
    {
        const QMouseEvent* const me = static_cast<const QMouseEvent*>( e );

        if(e->type() == QEvent::MouseButtonPress)
        {
            btnBarCenterBase.setX(btnBar->pos().x()+btnBar->width()/2);
            btnBarCenterBase.setY(btnBar->pos().y()+btnBar->height()/2);
            btnBarScreenBase = me->screenPos();
            ifBtnBarPressed = true;

        }
        else if(e->type() == QEvent::MouseButtonRelease ||
                e->type() == QEvent::MouseMove)
        {
            if(ifBtnBarPressed)
            {
                int centerX = btnBarCenterBase.x() + me->screenPos().x() - btnBarScreenBase.x();
                centerX = qMin(centerX, wBarCenterXMax);
                centerX = qMax(centerX, wBarCenterXMin);
                if(wBarCenterXMax > wBarCenterXMin &&
                   valMax > valMin)
                {
                    double value = valMin + (valMax - valMin) * (centerX - wBarCenterXMin) / (wBarCenterXMax - wBarCenterXMin);
                    setVolume(value, true);
                }
            }
            if(e->type() == QEvent::MouseButtonRelease)
            {
                ifBtnBarPressed = false;
            }
//            qDebug() << e << btnBar->geometry() << me->pos();
        }
    }
    return QObject::eventFilter(o, e);
}

bool RSound::setValueRange(double valMin, double valMax, double valStep, int res)
{
    if(res > 0)
    {
        dataType = DataType_DOUBLE;
        strType = "real number";
    }
    else
    {
        dataType = DataType_INT;
        strType = "integer";
        res = 0;
    }

    this->valMin = qMin(valMin, valMax);
    this->valMax = qMax(valMin, valMax);
    this->valStep = valStep;
    this->res = res;

    return true;
}

bool RSound::setVolume(double value, bool discardSameValue)
{
    static double valueUpdate = SOUND_VALUE_DEF;
    value = qMin(value, valMax);
    value = qMax(value, valMin);

    if(dataType == DataType_INT ||
       dataType == DataType_DOUBLE)
    {
        if(value != valMin &&
           value != valMax &&
           value != val &&
           valStep != 0)
        {
            int step = (int)((value - valMin) / valStep + 0.5);
            value = valMin + valStep * step;
            value = qMin(value, valMax);
        }
        val = value;
    }

    int centerX = wBarCenterXMin + 0.5 + (wBarCenterXMax - wBarCenterXMin) * (val - valMin) / (valMax - valMin);
    btnBar->setGeometry(centerX-btnBar->width()/2, btnBar->pos().y(),
                        btnBar->width(), btnBar->height());
    int selectWidth = centerX - wBarCenterXMin;
    wBarSelect->setGeometry(0, 0, selectWidth, wBarSelect->height());
    wBarNormal->setGeometry(selectWidth, 0, wBarCenter->width()-selectWidth, wBarSelect->height());
    _updateLabelText();

    if(discardSameValue &&
       valueUpdate == val)
        return true;
    valueUpdate = val;

    if(ifEmitVolumeChanged)
    {
        if(dataType == DataType_INT)
        {
            emit(volumeChanged((int)val));
        }
        else
        {
            emit(volumeChanged(val));
        }
    }
    return true;
}

double RSound::getVolume()
{
    return val;
}

bool RSound::getMute()
{
    return bMute;
}

void RSound::setEmitVolumeChanged(bool ifEmit)
{
    ifEmitVolumeChanged = ifEmit;
}

void RSound::_btnMutePressed()
{
}

void RSound::_btnMuteReleased()
{
    bMute = !bMute;
    _updateColor();
    emit(muteChanged(bMute));
}

void RSound::_updateLabelText()
{
    QString str;
    if(dataType == DataType_INT)
    {
        str = QString().asprintf("%.0lf", val);
    }
    else if(dataType == DataType_DOUBLE)
    {
        switch(res)
        {
        case 1: str = QString().asprintf("%.1lf", val);    break;
        case 2: str = QString().asprintf("%.2lf", val);    break;
        case 3: str = QString().asprintf("%.3lf", val);    break;
        case 4: str = QString().asprintf("%.4lf", val);    break;
        case 5: str = QString().asprintf("%.5lf", val);    break;
        case 6:
        default:
             str = QString().asprintf("%.6lf", val);    break;
        }
    }
    label->setText(str);
}

void RSound::_updateColor()
{
    if(bMute)
    {
        btnMute->setIcons(QIcon(":/images/playback_sound_mute_normal.png"),
                          QIcon(":/images/playback_sound_mute_hover.png"),
                          QIcon(":/images/playback_sound_mute_normal.png"),
                          QIcon(":/images/playback_sound_mute_hover.png"),
                          false);
        label->setStyleSheet("background:transparent;"
                             "color: rgb(176, 176, 176);"
                             "font: bold 18px \"Arial\";");
        btnBar->setEnabled(false);
        btnBar->setIcons(QIcon(":/images/slider_bar_btn_disable.png"),
                        QIcon(":/images/slider_bar_btn_disable.png"),
                        QIcon(":/images/slider_bar_btn_disable.png"),
                        QIcon(":/images/slider_bar_btn_disable.png"),
                        false);
        wBarLeft->setStyleSheet("border:0px;"    // transparent for Linux
                                "background: url(\":/images/slider_bar_bg-left_disable.png\")");
        wBarSelect->setStyleSheet("border:0px;"    // transparent for Linux
                                  "background: url(\":/images/slider_bar_bg_disable.png\");"); // default: repeat
    }
    else
    {
        btnMute->setIcons(QIcon(":/images/playback_sound_on_normal.png"),
                          QIcon(":/images/playback_sound_on_hover.png"),
                          QIcon(":/images/playback_sound_on_normal.png"),
                          QIcon(":/images/playback_sound_on_hover.png"),
                          false);
        label->setStyleSheet("background:transparent;"
                             "color: rgb(191, 255, 57);"
                             "font: bold 18px \"Arial\";");
        btnBar->setEnabled(true);
        btnBar->setIcons(QIcon(":/images/slider_bar_btn_normal.png"),
                        QIcon(":/images/slider_bar_btn_hover.png"),
                        QIcon(":/images/slider_bar_btn_normal.png"),
                        QIcon(":/images/slider_bar_btn_hover.png"),
                        false);
        wBarLeft->setStyleSheet("border:0px;"    // transparent for Linux
                                "background: url(\":/images/slider_bar_bg-left_selected.png\")");
        wBarSelect->setStyleSheet("border:0px;"    // transparent for Linux
                                  "background: url(\":/images/slider_bar_bg_selected.png\");"); // default: repeat
    }
}
