/**
 * @file rtablayer.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The reimplementation of QTabWidget
 */

#ifndef RTABLAYER_H
#define RTABLAYER_H

#include <QList>
#include <QToolButton>
#include <QStackedWidget>

#define TABLAYER_LAYER_1  1
#define TABLAYER_LAYER_2  2

class RTabLayer: public QObject
{
    Q_OBJECT

public:
    explicit RTabLayer(QObject *parent = 0);
    ~RTabLayer();

    void init(QList<QToolButton *> &btnOrderList,
              QStackedWidget *stkWidget, int layer);

    virtual bool eventFilter(QObject *o, QEvent *e);
    void clickTabIndex(int index);

private:
    QList<QToolButton *> *btnList;
    QStackedWidget *stkWidget;
    QObject *_rcvObject;
    int layer;

signals:
    void currentTabIndexChanged(int index);

private slots:
    void btnClicked(bool);
};

#endif // RTABLAYER_H
