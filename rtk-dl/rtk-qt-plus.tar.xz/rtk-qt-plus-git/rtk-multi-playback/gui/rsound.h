/**
 * @file rsound.h
 * @author Realtek Semiconductor Corp.
 * @date July 2018
 * @brief The sound control in Realtek style
 */

#ifndef RSOUND_H
#define RSOUND_H

#include <QWidget>
#include <QTimer>
#include <QLabel>
#include "rtoolbutton.h"

class RSound : public QWidget
{
    Q_OBJECT
public:
    typedef enum
    {
        DataType_TEXT   = 0,
        DataType_INT,
        DataType_DOUBLE
    } DataType_E;

    RSound(QWidget *parent = 0);
    ~RSound();

    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    bool setValueRange(double valMin, double valMax, double valStep, int res);
    bool setVolume(double value, bool discardSameValue=false);
    double getVolume();
    bool getMute();
    void setEmitVolumeChanged(bool ifEmit);

private:
    RToolButton *btnMute, *btnBar;
    QWidget *wBarCenter, *wBarLeft, *wBarRight, *wBarSelect, *wBarNormal;
    QLabel      *label;

    bool bMute;
    DataType_E dataType;
    double  val, valMax, valMin, valStep;
    int res;    // resolution
    int valLogInt;
    QString strType;
    bool ifEmitVolumeChanged;
    bool ifBtnBarPressed;
    int wBarCenterXMin, wBarCenterXMax; // the range of btnBar center x (=btnBar->x()+btnBar->width()/2)
    QPointF btnBarCenterBase;  // the center position of btnBar when mouse pressed
    QPointF btnBarScreenBase; // the screen position of btnBar when mouse pressed

    void _updateLabelText();
    void _updateColor();

signals:
    void muteChanged(bool);
    void volumeChanged(double);
    void volumeChanged(int);

private slots:
    void _btnMutePressed();
    void _btnMuteReleased();

protected:
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // RSOUND_H
