/**
 * @file rdialog.cpp
 * @author Realtek Semiconductor Corp.
 * @date Oct 2017
 * @brief The widget page of dialog to show message or confirm
 */

#include "rdialog.h"
#include "ui_rdialog.h"
#include <QDialog>
#include <QDebug>

RDialog::RDialog(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RDialog)
{
    ui->setupUi(this);
    ui->bg->setStyleSheet("background-color: rgba(0, 0, 0, 125)");
    ui->bg->lower();

    frameList = {ui->fConfirm, ui->fError, ui->fInfo, ui->fWarning};
    fnAccept = NULL;
    fnReject = NULL;

    QTextBrowser *txt;
    QList<QTextBrowser *> txtList = {ui->txtConfirm, ui->txtError, ui->txtInfo, ui->txtWarning};
    foreach(txt, txtList)
    {
        txt->setStyleSheet(
                    "color: rgb(32, 38, 41);"
                    "background-color: rgb(153, 153, 153);"
                    "font: bold 20px \"Arial\";"
                    );
    }

    QFrame *frame;
    foreach(frame, frameList)
    {
        frame->setStyleSheet(
                           "border-radius:10px;"
                           "background-color: rgb(153, 153, 153);");
    }

    QToolButton *btn;
    QList<QToolButton *> btnLst = {ui->tbAccept, ui->tbErrorClose, ui->tbInfoClose, ui->tbWarningClose};
    foreach(btn, btnLst)
    {
        btn->setStyleSheet(
                QString(
                "QToolButton{"
                    "border:0px;"    // transparent for Linux
                    "border-radius:6px;"
                    "color: rgb(32, 38, 41);"
                    "background-color: rgb(169, 204, 125);"
                    "font: bold 20px \"Arial\";"
                    "}"
                ));
    }
    ui->tbReject->setStyleSheet(
                QString(
                "QToolButton{"
                     "border:0px;"    // transparent for Linux
                     "border-radius:6px;"
                     "background-color: rgb(140, 140, 140);"
                     "font: bold 20px \"Arial\";"
                     "}"
                ));

    connect(ui->tbAccept,       SIGNAL(clicked(bool)),  this,   SLOT(doAccept(bool)));
    connect(ui->tbReject,       SIGNAL(clicked(bool)),  this,   SLOT(doReject(bool)));
    connect(ui->tbErrorClose,   SIGNAL(clicked(bool)),  this,   SLOT(doErrorClose(bool)));
    connect(ui->tbInfoClose,    SIGNAL(clicked(bool)),  this,   SLOT(doInfoClose(bool)));
    connect(ui->tbWarningClose, SIGNAL(clicked(bool)),  this,   SLOT(doWarningClose(bool)));
}

RDialog::~RDialog()
{
    delete ui;
}

void RDialog::showDialog(QFrame *obj)
{
    QFrame *frame;
    foreach(frame, frameList)
    {
        frame->setVisible(frame == obj);
    }
    this->raise();
    this->setVisible(true);
}

void RDialog::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);
    ui->bg->setGeometry(0, 0, rect.width(), rect.height());
//    qDebug() << __func__ << rect.x() << rect.y() << rect.width() << rect.height();

    QFrame *frame;
    foreach(frame, frameList)
    {
        frame->setGeometry((this->width()-frame->width())/2,
                         (this->height()-frame->height())/2,
                         frame->width(),
                         frame->height());
//        qDebug() << __func__ << obj->x() << obj->y() << obj->width() << obj->height();
    }
}

void RDialog::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void RDialog::mousePressEvent(QMouseEvent *e)
{
    Q_UNUSED(e);
}

void RDialog::doAccept(bool)
{
//    qDebug() << __func__;
    this->setVisible(false);
    if (fnAccept != NULL)
    {
        (*fnAccept)();
        fnAccept = NULL;
    }
}

void RDialog::doReject(bool)
{
//    qDebug() << __func__;
    this->setVisible(false);
    if (fnReject != NULL)
    {
        (*fnReject)();
        fnReject = NULL;
    }
}

void RDialog::doErrorClose(bool)
{
//    qDebug() << __func__;
    this->setVisible(false);
}

void RDialog::doInfoClose(bool)
{
//    qDebug() << __func__;
    this->setVisible(false);
}

void RDialog::doWarningClose(bool)
{
//    qDebug() << __func__;
    this->setVisible(false);
}

void RDialog::showError(QString msg)
{
    ui->txtError->setText(msg);
    showDialog(ui->fError);
}

void RDialog::showInfo(QString msg)
{
    ui->txtInfo->setText(msg);
    showDialog(ui->fInfo);
}

void RDialog::showWarning(QString msg)
{
    ui->txtWarning->setText(msg);
    showDialog(ui->fWarning);
}

void RDialog::showConfirm(QString msg, void(*fnAccept)(), void(*fnReject)())
{
    this->fnAccept = fnAccept;
    this->fnReject = fnReject;
    ui->txtConfirm->setText(msg);
    showDialog(ui->fConfirm);
}
