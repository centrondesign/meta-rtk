/**
 * @file keyboard.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page for keypad operation
 */

#ifndef KEYPAD_H
#define KEYPAD_H

#include <QtGui>
#include <QtCore>
#include <QList>
#include <QWidget>
#include <QToolButton>

namespace Ui {
class Keypad;
}

class Keypad : public QWidget
{
    Q_OBJECT

public:
    explicit Keypad(QWidget *parent = 0);
    ~Keypad();

public slots:
    //void hide();

private slots:
    void sendKeyEvent(QWidget *w);

private:
    Ui::Keypad *ui;
    QObject *_rcvObject;
    QList<QToolButton *> _textBtnList;
    bool _mousePressed;
    QPoint _mousePosition;

protected:
    virtual void mousePressEvent( QMouseEvent *e );
    virtual void mouseMoveEvent( QMouseEvent *e );
    virtual void mouseReleaseEvent( QMouseEvent *e );
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // KEYPAD_H
