/**
 * @file keyboard.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The widget page for keyboard operation
 */

#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <QtGui>
#include <QtCore>
#include <QList>
#include <QWidget>
#include <QToolButton>

namespace Ui {
class Keyboard;
}

class Keyboard : public QWidget
{
    Q_OBJECT

public:
    explicit Keyboard(QWidget *parent = 0);
    ~Keyboard();

public slots:
    //void hide();

private slots:
    void sendKeyEvent(QWidget *w);
    void on_btn_0_caps_clicked();
    void on_btn_1_caps_clicked();
    void on_btn_0_123_clicked();
    void on_btn_1_123_clicked();
    void on_btn_eng_clicked();

private:
    Ui::Keyboard *ui;
    QObject *_rcvObject;
    QList<QToolButton *> _textBtnList;
    unsigned int _old_eng_pg_idx;
    bool _mousePressed;
    QPoint _mousePosition;

protected:
    virtual void mousePressEvent( QMouseEvent *e );
    virtual void mouseMoveEvent( QMouseEvent *e );
    virtual void mouseReleaseEvent( QMouseEvent *e );
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // KEYBOARD_H
