/**
 * @file rtablayer.cpp
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The reimplementation of QTabWidget
 */

#include "rtablayer.h"
#include <QDebug>
#include <QEvent>

RTabLayer::RTabLayer(QObject *parent) :
    QObject(parent)
{
    _rcvObject = NULL;
    layer = 0;
    btnList = new QList<QToolButton *>();
}

RTabLayer::~RTabLayer()
{
    delete(btnList);
}

void RTabLayer::init(QList<QToolButton *> &btnOrderList,
                     QStackedWidget *stkWidget, int layer)
{
    this->btnList->append(btnOrderList);
    this->stkWidget = stkWidget;
    this->layer = layer;
    if (this->btnList->count() <= 0 || this->stkWidget == NULL)
        return;
    for(int i=0; i<this->btnList->count(); i++)
    {
        if(this->btnList->at(i) != NULL)
        {

            this->btnList->at(i)->setAttribute(Qt::WA_StyleSheet);
            this->btnList->at(i)->installEventFilter(this);
            connect(btnList->at(i), SIGNAL(clicked(bool)), this, SLOT(btnClicked(bool)));
        }
    }
}

bool RTabLayer::eventFilter(QObject *o, QEvent *e)
{
    if(e->type() == QEvent::MouseButtonPress && o!=NULL)
    {
        _rcvObject = o;
//        qDebug() << "RTabLayer::eventFilter";
//        qDebug() << _rcvObject;
    }
    return QObject::eventFilter(o, e);
}

void RTabLayer::btnClicked(bool)
{
    for(int i=0; i<this->btnList->count(); i++)
    {
        if(_rcvObject == this->btnList->at(i))
        {
            _rcvObject = NULL;
            clickTabIndex(i);
            emit(currentTabIndexChanged(i));
            return;
        }
    }
}

void RTabLayer::clickTabIndex(int index)
{
//    qDebug() << __func__ << index;
    for(int i=0; i<btnList->count(); i++)
    {
        switch (layer)
        {
        case TABLAYER_LAYER_1:
            if(i == index)
            {
                btnList->at(i)->setStyleSheet(
                            QString(
                            "QToolButton{"
                                        "border-radius:6px;"
                                        "background-color: transparent;"
                                        "color: rgb(224, 255, 24);"
                                        "%1"
                                        "}"
                            "QToolButton:hover{"
                                        "border-radius:6px;"
                                        "background-color: rgb(36,41,30);"
                                        "color: rgb(224, 225, 24);"
                                        "%1"
                                        "}"
                            ).arg("font: bold 20px \"Arial Black\";")
                                        );
            }
            else
            {
                btnList->at(i)->setStyleSheet(
                            QString(
                            "QToolButton{"
                                        "border-radius:6px;"
                                        "background-color: transparent;"
                                        "color: rgb(86, 86, 86);"
                                        "%1"
                                        "}"
                            "QToolButton:hover{"
                                        "border-radius:6px;"
                                        "background-color: rgb(36,41,30);"
                                        "color: rgb(86, 86, 86);"
                                        "%1"
                                        "}"
                            ).arg("font: bold 20px \"Arial Black\";")
                            );
            }
            break;
        case TABLAYER_LAYER_2:
            if(i == index)
            {
                btnList->at(i)->setStyleSheet(
                            QString(
                            "QToolButton{"
                                        "border-radius:6px;"
                                        "background-color: rgb(169,204,135);"
                                        "color: rgb(36, 40, 43);"
                                        "%1"
                                        "}"
                            "QToolButton:hover{"
                                        "border-radius:6px;"
                                        "background-color: rgb(169,204,135);"
                                        "color: rgb(36, 40, 43);"
                                        "%1"
                                        "}"
                            ).arg("font: 20px \"Arial\";")
                            );
            }
            else
            {
                btnList->at(i)->setStyleSheet(
                            QString(
                            "QToolButton{"
                                        "border-radius:6px;"
                                        "background-color: rgb(45,48,51);"
                                        "color: rgb(86, 86, 86);"
                                        "%1"
                                        "}"
                            "QToolButton:hover{"
                                        "border-radius:6px;"
                                        "background-color: rgb(45,48,51);"
                                        "color: rgb(86, 86, 86);"
                                        "%1"
                                        "}"
                            ).arg("font: 20px \"Arial\";")
                            );
            }
        default:
            break;
        }
    }
    this->stkWidget->setCurrentIndex(index);

}
