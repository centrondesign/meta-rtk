/**
 * @file source.h
 * @author Realtek Semiconductor Corp.
 * @date May 2025
 * @brief The widget page to connect IPC
 */

#ifndef SOURCE_H
#define SOURCE_H

#include <QWidget>
#include <QList>
#include <QLabel>
#include <QComboBox>
#include "rtablayer.h"
#include "define.h"
#include "rlineedit.h"
#include "rcheckbox.h"
#include "config.h"

namespace Ui {
class Source;
}

class Source : public QWidget
{
    Q_OBJECT

public:

    explicit Source(QWidget *parent = 0);
    ~Source();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setParentAbsoluteOffset(int x, int y);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);
    void set_apply(bool ifDialog, bool ifSave);

private:
    Ui::Source *ui;
//    RTabLayer *tlSource;
    int parent_absolute_offset_x, parent_absolute_offset_y;
    QList<QLabel*> *lChannelList[SOURCE_COUNT];
    QList<QLabel*> *lStatusList[SOURCE_COUNT];
    QList<RLineEdit*> *edList[SOURCE_COUNT];
    QList<RCheckBox*> *checkBoxList[SOURCE_COUNT];
    int test[SOURCE_COUNT];

    void initValue(bool fromStatus);

private slots:
    void input_changed(int);
    void set_clicked(bool);
    void cancel_clicked(bool);

protected:
    void showEvent(QShowEvent *);
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // SOURCE_H
