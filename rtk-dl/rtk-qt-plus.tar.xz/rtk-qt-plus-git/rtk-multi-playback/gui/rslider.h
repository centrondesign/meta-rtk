/**
 * @file rslider.h
 * @author Realtek Semiconductor Corp.
 * @date March 2018
 * @brief The slider in Realtek style
 */

#ifndef RSLIDER_H
#define RSLIDER_H

#include <QWidget>
#include <QTimer>
#include <QLabel>
#include "rtoolbutton.h"

class RSlider : public QWidget
{
    Q_OBJECT
public:
    typedef enum
    {
        DataType_TEXT   = 0,
        DataType_INT,
        DataType_DOUBLE
    } DataType_E;

    RSlider(QWidget *parent = 0);
    ~RSlider();

    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    bool setValueRange(double valMin, double valMax, double valStep, int res);
    bool setValue(double value, bool discardSameValue=false);
    double getValue();
    void setEmitValueChanged(bool ifEmit);

private:
    RToolButton *btnAdd, *btnSub, *btnBar;
    QWidget *wBarCenter, *wBarLeft, *wBarRight, *wBarSelect, *wBarNormal;
    QLabel      *label;

    QTimer *timerAdd, *timerSub;

    DataType_E dataType;
    double  val, valMax, valMin, valStep;
    int res;    // resolution
    int valLogInt;
    QString strType;
    bool ifEmitValueChanged;
    bool ifBtnBarPressed;
    int wBarCenterXMin, wBarCenterXMax; // the range of btnBar center x (=btnBar->x()+btnBar->width()/2)
    QPointF btnBarCenterBase;  // the center position of btnBar when mouse pressed
    QPointF btnBarScreenBase; // the screen position of btnBar when mouse pressed

    void _updateLabelText();
    void _updateTimerInterval(QTimer *timer);

signals:
    void valueChanged(double);
    void valueChanged(int);

private slots:
    void _btnAddPressed();
    void _btnAddReleased();
    void _btnSubPressed();
    void _btnSubReleased();
    void _timerAddUpdate();
    void _timerSubUpdate();

protected:
    bool eventFilter(QObject *o, QEvent *e);
};

#endif // RSLIDER_H
