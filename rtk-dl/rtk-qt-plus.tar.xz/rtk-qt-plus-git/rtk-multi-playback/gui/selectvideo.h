/**
 * @file selectvideo.h
 * @author Realtek Semiconductor Corp.
 * @date May 2025
 * @brief The widget page to do video selection
 */

#ifndef SELECTVIDEO_H
#define SELECTVIDEO_H

#include <QWidget>
#include <QListWidget>
#include "rtablayer.h"
#include "rslider.h"

#define VIDEO_LIST_TMP_FILE "video_list.tmp"

namespace Ui {
class SelectVideo;
}

class SelectVideo : public QWidget
{
    Q_OBJECT

public:
    explicit SelectVideo(QWidget *parent = 0);
    ~SelectVideo();

    void setup();
    void setFileNameList(QListWidget *list);
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setParentAbsoluteOffset(int x, int y);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);
    void addFiles(QStringList files);
    void addDir(QString folderPath);
    bool loadList(QString filePath, bool ifDialog, bool ifMsg);
    bool saveList(QString filePath, bool ifDialog, bool ifMsg);
    void clearList();
private:
    Ui::SelectVideo *ui;
    QListWidget *lFileName;
    int parent_absolute_offset_x, parent_absolute_offset_y;
    QStringList videoFileFilter;

    void initValue(bool fromStatus);
    void setLastItemToolTip (QString filePath);
    bool ifPassFileFilter(QString filePath);

private slots:
    void add_files_clicked(bool);
    void add_dir_clicked(bool);
    void load_list_clicked(bool);
    void save_list_clicked(bool);
    void cancel_clicked(bool);
    void clear_list_clicked(bool);

protected:
    void showEvent(QShowEvent *);
    // bool eventFilter(QObject *o, QEvent *e);
};

#endif // SELECTVIDEO_H
