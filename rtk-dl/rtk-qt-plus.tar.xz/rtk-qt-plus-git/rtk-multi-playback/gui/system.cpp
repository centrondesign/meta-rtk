/**
 * @file system.cpp
 * @author Realtek Semiconductor Corp.
 * @date May 2025
 * @brief The widget page to do system setting
 */

#include "system.h"
#include "ui_system.h"
#include "mainwidget.h"
#include "rtkgstplus.h"

System::System(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::System)
{
    ui->setupUi(this);

    parent_absolute_offset_x = 0;
    parent_absolute_offset_y = 0;
    strAiMode = "ssd_mobilenet";

    ui->lSystem->setStyleSheet(STYLESHEET_TITLE_2);

    QList<QComboBox*> optionList = {ui->cbAiMode, ui->cbVideoSink};
    foreach(QComboBox *cb, optionList)
    {
        cb->setStyleSheet(STYLESHEET_COMBOBOX);
    }

    connect(ui->tbSet, SIGNAL(clicked(bool)), this, SLOT(system_set_clicked(bool)));
    connect(ui->tbCancel, SIGNAL(clicked(bool)), this, SLOT(system_cancel_clicked(bool)));
}

System::~System()
{
    delete ui;
}

void System::setup()
{
    labelList->append({ui->lAiMode, ui->lVideoSink});
    actionList->append({ui->tbSet, ui->tbCancel});
    // optionList->append({ui->cbAiMode, ui->cbVideoSink});

    ui->cbAiMode->addItem("yolov5");
    ui->cbAiMode->addItem("ssd_mobilenet");
    ui->cbAiMode->addItem("posenet");
    ui->cbAiMode->addItem("face_recognition");
    ui->cbVideoSink->addItem(_STR_WAYLANDSINK_);
    ui->cbVideoSink->addItem(_STR_RTKNVRSINK_);

    ui->lAiMode->setVisible(Config::sys.aiApplication);
    ui->cbAiMode->setVisible(Config::sys.aiApplication);
}

void System::initValue(bool fromStatus)
{
    // qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);
    ui->cbAiMode->setCurrentText(strAiMode);
    ui->cbVideoSink->setCurrentText(Config::sys.videoSink);
}

void System::setGeometry(const QRect &rect)
{
    QWidget::setGeometry(rect);
}

void System::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void System::setParentAbsoluteOffset(int x, int y)
{
    parent_absolute_offset_x = x;
    parent_absolute_offset_y = y;
}

void System::installEventFilterForKeyboard(QObject *keyboard, QObject *keypad)
{
    // QList<RLineEdit *>keyboardList = {};
    // QList<RLineEdit *>keybadList = {};
    // RLineEdit *le;
    // foreach(le, keyboardList)
    // {
    //     le->installEventFilter(keyboard);
    // }
    // foreach(le, keybadList)
    // {
    //     le->installEventFilter(keypad);
    // }
}

void System::showEvent(QShowEvent *)
{
    initValue(true);
}

// bool System::eventFilter(QObject *o, QEvent *e)
// {
//     if(e->type() == QEvent::Show)
//     {
//         if(o==ui->pgCurrent ||
//            o==ui->pgFormat ||
//            o==ui->pgImage ||
//            o==ui->pgBg ||
//            o==ui->pgFb ||
//            o==ui->pgOutput ||
//            o==ui->pgAdmin)
//         {
//             initValue(true);
//         }
//     }
//     return QObject::eventFilter(o, e);
// }

void System::system_set_clicked(bool)
{
    // qDebug () << QString().asprintf("%s:%d", __FUNCTION__, __LINE__);
    if (strAiMode != ui->cbAiMode->currentText())
    {
        qDebug () << QString().asprintf("strAiMode = %s -> %s", strAiMode.toStdString().c_str(), ui->cbAiMode->currentText().toStdString().c_str());
        strAiMode = ui->cbAiMode->currentText();
    }
    if (Config::sys.videoSink != ui->cbVideoSink->currentText())
    {
        qDebug () << QString().asprintf("videoSink = %s -> %s", Config::sys.videoSink.toStdString().c_str(), ui->cbVideoSink->currentText().toStdString().c_str());
        Config::sys.videoSink = ui->cbVideoSink->currentText();
        rtkGst->set_sink(Config::sys.videoSink, Config::sys.textSink);
    }
    setting->setVisible(false);
}

void System::system_cancel_clicked(bool)
{
    setting->setVisible(false);
}
