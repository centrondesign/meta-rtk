/**
 * @file system.h
 * @author Realtek Semiconductor Corp.
 * @date May 2025
 * @brief The widget page to do system setting
 */

#ifndef System_H
#define System_H

#include <QWidget>
#include "rtablayer.h"
#include "rslider.h"

namespace Ui {
class System;
}

class System : public QWidget
{
    Q_OBJECT

public:
    QString strAiMode;

    explicit System(QWidget *parent = 0);
    ~System();

    void setup();
    void setGeometry(int x, int y, int w, int h);
    void setGeometry(const QRect &rect);
    void setParentAbsoluteOffset(int x, int y);
    void installEventFilterForKeyboard(QObject *keyboard, QObject *keypad);

private:
    Ui::System *ui;
    int parent_absolute_offset_x, parent_absolute_offset_y;
    int cb_idx_v, cb_idx_a, cb_idx_s;   // check box index

    void initValue(bool fromStatus);
    void output_set(bool ifDialog);
    void admin_set(bool ifDialog);

private slots:
    void system_set_clicked(bool);
    void system_cancel_clicked(bool);

protected:
    void showEvent(QShowEvent *);
    // bool eventFilter(QObject *o, QEvent *e);
};

#endif // System_H
