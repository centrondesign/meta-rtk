/**
 * @file rcheckbox.cpp
 * @author Realtek Semiconductor Corp.
 * @date Jan 2018
 * @brief The extenstion of QWidget to fix bug of QCheckBox
 */

#include "rcheckbox.h"
#include <QDebug>

RCheckBox::RCheckBox(QWidget *parent) :
    QWidget(parent)
{
    this->btn = new RToolButton(this);
    this->btn->setGeometry(0, 0, 30, 30);
    this->btn->setIconSize(QSize(30, 30));
    this->btn->setStyleSheet("border:0px;"    // transparent for Linux
                             "background:transparent;");
    this->btn->setIcons(QIcon(":/images/checkbox-off_normal.png"),
                        QIcon(":/images/checkbox-off_hover.png"),
                        QIcon(":/images/checkbox-on_normal.png"),
                        QIcon(":/images/checkbox-on_hover.png"),
                        true);
    this->label = new QLabel(this);
    this->label->setGeometry(36, 0, 240, 30);
    this->label->setStyleSheet("background:transparent;"
                               "border:0px;"
                                "color: rgb(176, 176, 176);"
                                "font: 20px \"Arial\";");

    connect(this->btn, SIGNAL(pressed()), this, SLOT(_btnPressed()));
    connect(this->btn, SIGNAL(released()), this, SLOT(_btnReleased()));
    connect(this->btn, SIGNAL(clicked(bool)), this, SLOT(_btnClicked(bool)));
    connect(this->btn, SIGNAL(toggled(bool)), this, SLOT(_btnToggled(bool)));
}

RCheckBox::~RCheckBox()
{
    delete(btn);
    delete(label);
}

//void RCheckBox::setIcons(const QIcon &off_normal_icon,
//                           const QIcon &off_hover_icon,
//                           const QIcon &on_normal_icon,
//                           const QIcon &on_hover_icon,
//                           bool checkActive)
//{
//    this->btn->setIcons(off_normal_icon, off_hover_icon,
//                       on_normal_icon, on_hover_icon,
//                       checkActive);
//}

//void RCheckBox::setActive(bool active, bool bHover)
//{
//    this->btn->setActive(active, bHover);
//}

bool RCheckBox::isChecked()
{
    return this->btn->getActived();
}

void RCheckBox::setChecked(bool checked)
{
    this->btn->setActive(checked, false);
}

void RCheckBox::setText(QString text)
{
    this->label->setText(text);
}

QString RCheckBox::getText()
{
    return this->label->text();
}

void RCheckBox::setGeometry(int x, int y, int w, int h)
{
    this->setGeometry(QRect(x, y, w, h));
}

void RCheckBox::setGeometry(const QRect &rect)
{
//    qDebug() << rect.x() << rect.y() << rect.width() << rect.height();
    QWidget::setGeometry(rect);
    int y = qMax((rect.height() - rect.width())/2, 0);
    int height = qMin(rect.width(), rect.height());
    int width = qMax(height, 20);
    int labelX = (int)(1.2*width);
    int labelWidth = qMax(rect.width()-labelX, 0);
    this->btn->setGeometry(0, y, width, height);
    this->btn->setIconSize(QSize(width, height));
    this->label->setGeometry(labelX, y,
                            labelWidth, rect.height());
}

void RCheckBox::_btnPressed()
{
    emit(pressed());
}

void RCheckBox::_btnReleased()
{
    emit(released());
}

void RCheckBox::_btnClicked(bool act)
{
    emit(clicked(act));
}

void RCheckBox::_btnToggled(bool act)
{
    emit(toggled(act));
}
