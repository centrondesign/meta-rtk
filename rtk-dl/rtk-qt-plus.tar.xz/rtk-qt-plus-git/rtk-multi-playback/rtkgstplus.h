/**
 * @file rtkgst.h
 * @author Realtek Semiconductor Corp.
 * @date Sep 2017
 * @brief The interface/api to use Realtek library
 */

#ifndef RTKGSTPLUS_H
#define RTKGSTPLUS_H

#include <QString>
#include <QPixmap>
#include <QWidget>
#include <gst/gst.h>
#include <rtkgst.h>

using namespace std;

class RtkGstPlus
{
public:
    RtkGstPlus();
    ~RtkGstPlus();
    void set_debug (bool bDebug);
    bool rtk_plus_play_new(QString strSource, int ch, GstPlay **play_p, const QString filepath, QWidget *gst_window,
                          bool bFullscreen, int x, int y, int width, int height, bool bAudio);
    void rtk_plus_play_free(QString strSource, int ch, GstPlay **play_p);
    bool rtk_plus_pause(QString strSource, int ch, GstPlay *play);
    bool rtk_plus_resume(QString strSource, int ch, GstPlay *play);
    bool rtk_plus_seek_with_offset(QString strSource, int ch, GstPlay *play, gint64 offset);
    bool rtk_plus_setVolume(QString strSource, int ch, GstPlay *play, int volume);
    void rtk_plus_speedchange(QString strSource, int ch, GstPlay *play, gdouble rate);
    void rtk_plus_rotation(QString strSource, int ch, GstPlay *play);
    bool rtk_plus_seek_by_slider(QString strSource, int ch, GstPlay *play, gdouble rate);
    pair<gint64, gint64> rtk_plus_getPositionDuration(QString strSource, int ch, GstPlay *play);
    void rtk_plus_play_ai(QString strSource, int ch, GstPlay **play_p, const QString filepath, QString selectedMode, 
                          bool bFullscreen, int x, int y, int width, int height,
                          AiParam *param, bool bAudio);
    bool rtk_plus_play_multi(QString strSource, int ch, GstPlay **play_p, const QString srcpath, QWidget *gst_window,
                          bool bFullscreen, int x, int y, int width, int height, bool bAudio);

private:
    bool if_debug;
};

extern RtkGstPlus *rtkGstPlus;

#endif // RTKGSTPLUS_H
