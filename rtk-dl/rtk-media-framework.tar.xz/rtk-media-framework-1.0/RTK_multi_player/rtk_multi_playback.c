#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "rtk_multi_playback.h"

static gboolean bus_call (GstBus *bus, GstMessage *msg, gpointer data)
{
	RTK_MULTI_PLAYBACK *playback = (RTK_MULTI_PLAYBACK *)data;
	switch (GST_MESSAGE_TYPE (msg)) {
		case GST_MESSAGE_EOS:
			printf ("End of stream\n");
			playback->pipeline_already_quit = TRUE;
			g_main_loop_quit (playback->loop);
			break;
		case GST_MESSAGE_ERROR:
		{
			gchar  *debug = NULL;
			GError *error;

			gst_message_parse_error (msg, &error, &debug);

			printf ("element:%s Error: %s\n", GST_OBJECT_NAME(GST_MESSAGE_SRC(msg)), error->message);
			printf ("elmenet:%s Debug: %s\n", GST_OBJECT_NAME(GST_MESSAGE_SRC(msg)), (debug) ? debug : "none");
			g_error_free (error);
			g_free(debug);
			playback->pipeline_already_quit = TRUE;
			g_main_loop_quit (playback->loop);
			break;
		}
		default:
			break;
	}

	return TRUE;
}

RTK_MULTI_PLAYBACK *playback_init(void)
{
	RTK_MULTI_PLAYBACK *playback = (RTK_MULTI_PLAYBACK *)malloc(sizeof(RTK_MULTI_PLAYBACK));
	memset(playback, 0, sizeof(RTK_MULTI_PLAYBACK));
	playback->pipeline_already_quit = TRUE;
	playback->source_type = RTK_UNKNOWN_SOURCE_TYPE;
	playback->codec_type = RTK_UNKNOWN_CODEC_TYPE;
	playback->drm_fd = -1;
	playback->x = -1;
	playback->y = -1;
	playback->w = -1;
	playback->h = -1;
	playback->channel_id = -1;
	return playback;
}

void playback_uninit(RTK_MULTI_PLAYBACK* playback)
{
	free(playback);
}

int playback_start(RTK_MULTI_PLAYBACK *playback)
{
	char pipeline_desc[1024] = {0};
	char src_plugin[64] = {0};
	char parser_plugin[64] = {0};
	char decoder_plugin[64] = {0};
	char render_plugin[64] = {0};
	GError *err = NULL;

	if (strlen(playback->file_path) == 0) {
		printf("file path is not set\n");
		return -1;
	}

	if (playback->drm_fd == -1)
	{
		printf("get wrong drm_fd:%d\n", playback->drm_fd);
		return -1;
	}	

	if (playback->w <= 0 || playback->h <= 0)
	{
		printf("get wrong x:%d y:%d w:%d h:%d\n", playback->x, playback->y, playback->w, playback->h);
		return -1;
	}

	if (playback->channel_id == -1)
	{
		printf("get wrong channel_id:%d\n", playback->channel_id);
		return -1;
	}

	switch (playback->source_type) {
		case RTK_FILE_SOURCE_TYPE:
			strcpy(src_plugin, "filesrc");
			break;
		case RTK_RTSP_SOURCE_TYPE:
			strcpy(src_plugin, "rtspsrc");
			break;
		default:
			playback->source_type = RTK_UNKNOWN_SOURCE_TYPE;
			break;
	}

	if (playback->source_type == RTK_UNKNOWN_SOURCE_TYPE) {
		printf("unsupport source type:%d\n", playback->source_type);
		return -1;
	}

	if (playback->dec_type != RTK_HW_DEC_TYPE && playback->dec_type != RTK_SW_DEC_TYPE)
		playback->dec_type = RTK_SW_DEC_TYPE;

	switch (playback->codec_type) {
		case RTK_H264_CODEC_TYPE:
			strcpy(parser_plugin, "h264parse");
			if (playback->dec_type == RTK_HW_DEC_TYPE)
				strcpy(decoder_plugin, "v4l2h264dec");
			else
				strcpy(decoder_plugin, "avdec_h264");
			break;
		case RTK_H265_CODEC_TYPE:
			strcpy(parser_plugin, "h265parse");
			if (playback->dec_type == RTK_HW_DEC_TYPE)
				strcpy(decoder_plugin, "v4l2h265dec");
			else
				strcpy(decoder_plugin, "avdec_h265");
			break;
		default:
			playback->codec_type = RTK_UNKNOWN_CODEC_TYPE;
			break;
	}	

	if (playback->codec_type == RTK_UNKNOWN_CODEC_TYPE) {
		printf("unsupport codec type:%d\n", playback->codec_type);
		return -1;
	}

	switch (playback->render_type) {
		case RTK_GPU_RENDER_TYPE:
			strcpy(render_plugin, "waylandsink");
			break;
		case RTK_NVRSINK_RENDER_TYPE:
			strcpy(render_plugin, "nvrsink");
			break;
		default:
			strcpy(render_plugin, "waylandsink");
			playback->render_type = RTK_GPU_RENDER_TYPE;
			break;
	}

	gst_init(NULL, NULL);
	printf("channel_id:%d filesrc:%s (x,y,w,h)=(%d,%d,%d,%d)\n", playback->channel_id, playback->file_path, playback->x, playback->y, playback->w, playback->h);

	if (playback->render_type == RTK_NVRSINK_RENDER_TYPE) {
		sprintf(pipeline_desc, "%s location=%s ! qtdemux ! %s ! %s ! rtknvrsink fd=%d chid=%d x=%d y=%d w=%d h=%d",
			src_plugin, playback->file_path, parser_plugin, decoder_plugin, playback->drm_fd,
			playback->channel_id, playback->x, playback->y, playback->w, playback->h);
	} else {
		sprintf(pipeline_desc, "%s location=%s ! qtdemux ! %s ! %s ! waylandsink render-rectangle=\"<%d,%d,%d,%d>\"",
			src_plugin, playback->file_path, parser_plugin, decoder_plugin,
			playback->x, playback->y, playback->w, playback->h);
	}

	printf("gst-launch:%s\n", pipeline_desc);

	playback->pipeline = gst_parse_launch(pipeline_desc, &err);
	playback->pipeline_already_quit = FALSE;
	playback->loop = g_main_loop_new (NULL, FALSE);
	playback->bus = gst_pipeline_get_bus (GST_PIPELINE (playback->pipeline));
	gst_bus_add_watch (playback->bus, bus_call, playback);
	gst_element_set_state (playback->pipeline, GST_STATE_PLAYING);
	g_main_loop_run(playback->loop);
	return 0;
}

int playback_stop(RTK_MULTI_PLAYBACK *playback)
{
	if (playback->loop && playback->pipeline_already_quit == FALSE) {
		g_main_loop_quit(playback->loop);
	}

    gst_element_set_state (playback->pipeline, GST_STATE_NULL);
    gst_object_unref(playback->pipeline);

    if (playback->bus)
        gst_object_unref(playback->bus);

    if (playback->loop)
        g_main_loop_unref(playback->loop);

	return 0;
}
