#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include "rtk_multi_playback.h"

static char optstr[] = "c:s:p:x:t:f:r:d:";

int main(int argc, char **argv)
{
	char *cmd = NULL;
	char *str = NULL;
	char *rec = NULL;
	char *source = NULL;
	char *codec = NULL;
	char *render = NULL;
	char *dec = NULL;
	int player_id = -1;
	int c = 0;
	int x = -1, y = -1, w = -1, h = -1;

	RTK_PLAYER_CMD player_cmd = {0};

	opterr = 0;
	while ((c = getopt(argc, argv, optstr)) != -1) {
		switch (c) {
			case 'c':
				cmd = (char *)malloc(128);
				strcpy(cmd, optarg);
				break;
			case 's':
				str = (char *)malloc(512);
				strcpy(str, optarg);
				break;
			case 'p':
				player_id = atoi(optarg);
				break;
			case 'x':
				rec = (char *)malloc(258);
				strcpy(rec, optarg);
				break;
			case 't':
				codec = (char *)malloc(128);
				strcpy(codec, optarg);
				break;
			case 'f':
				source = (char *)malloc(128);
				strcpy(source, optarg);
				break;
			case 'r':
				render = (char *)malloc(128);
				strcpy(render, optarg);
				break;
			case 'd':
				dec = (char *)malloc(128);
				strcpy(dec, optarg);
				break;
			default:
				break;
		}
	}

	if (cmd == NULL)
		return -1;

	if (!strcmp(cmd, "start") && str && rec && codec && source) {
		sscanf(rec, "%d:%d:%d:%d", &x, &y, &w, &h);
		player_cmd.cmd_type = CMD_START;
		strcpy(player_cmd.file_path, str);
		if (!strcmp(source, "file"))
			player_cmd.source_type = RTK_FILE_SOURCE_TYPE;
		else if (!strcmp(source, "rtsp"))
			player_cmd.source_type = RTK_RTSP_SOURCE_TYPE;
		else {
			printf("unsupport source type:%s\n", source);
			goto finish;
		}
		
		if (!strcmp(codec, "265"))
			player_cmd.codec_type = RTK_H265_CODEC_TYPE;
		else if (!strcmp(codec, "264"))
			player_cmd.codec_type = RTK_H264_CODEC_TYPE;
		else {
			printf("unsupport codec type:%s\n", codec);
			goto finish;
		}

		if (render) {
			if (!strcmp(render, "nvr"))
				player_cmd.render_type = RTK_NVRSINK_RENDER_TYPE;
			else
				player_cmd.render_type = RTK_GPU_RENDER_TYPE;
		} else {
			player_cmd.render_type = RTK_GPU_RENDER_TYPE;
		}

		if (dec) {
			if (!strcmp(dec, "sw"))
				player_cmd.dec_type = RTK_SW_DEC_TYPE;
			else
				player_cmd.dec_type = RTK_HW_DEC_TYPE;
		} else {
			player_cmd.dec_type = RTK_HW_DEC_TYPE;
		}

		player_cmd.channel_id = player_id;
		player_cmd.x = x;
		player_cmd.y = y;
		player_cmd.w = w;
		player_cmd.h = h;
	} else if (!strcmp(cmd, "stop")) {
		player_cmd.cmd_type = CMD_STOP;
		player_cmd.channel_id = player_id;
	} else {
		goto finish;
	} 

	int socket_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
	struct sockaddr_un serveraddr;

	memset(&serveraddr,0,sizeof(serveraddr));
	socklen_t s_addrlen = sizeof(serveraddr);
	serveraddr.sun_family = AF_UNIX;
	strcpy(serveraddr.sun_path, RTK_PLAYER_SOCKET_PATH);
	sendto(socket_fd, &player_cmd, sizeof(RTK_PLAYER_CMD), MSG_NOSIGNAL, (struct sockaddr*)&serveraddr,s_addrlen);
	shutdown(socket_fd, SHUT_RDWR);

finish:
	if (cmd)
		free(cmd);

	if (str)
		free(str);

	if (rec)
		free(rec);

	if (codec)
		free(codec);

	if (source)
		free(source);
	return 0;
}
