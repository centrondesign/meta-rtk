#ifndef __RTK_MULTI_PLAYER__
#define __RTK_MULTI_PLAYER__
#include <gst/gst.h>
#include <pthread.h>

#define RTK_PLAYER_SOCKET_PATH "/tmp/rtk_multi_player.sock"

typedef enum rtk_source_type {
	RTK_FILE_SOURCE_TYPE,
	RTK_RTSP_SOURCE_TYPE,
	RTK_UNKNOWN_SOURCE_TYPE,
} RTK_SOURCE_TYPE;

typedef enum rtk_decoder_type {
	RTK_HW_DEC_TYPE,
	RTK_SW_DEC_TYPE,
	RTK_UNKNOWN_DEC_TYPE,
} RTK_DECODER_TYPE;

typedef enum rtk_codec_type {
	RTK_H264_CODEC_TYPE,
	RTK_H265_CODEC_TYPE,
	RTK_UNKNOWN_CODEC_TYPE,
} RTK_CODEC_TYPE;

typedef enum rtk_render_type {
	RTK_GPU_RENDER_TYPE,
	RTK_NVRSINK_RENDER_TYPE,
	RTK_UNKNOWN_RENDER_TYPE,
} RTK_RENDER_TYPE;

typedef struct rtk_multi_payback {
	RTK_SOURCE_TYPE source_type;
	RTK_CODEC_TYPE codec_type;
	RTK_RENDER_TYPE render_type;
	RTK_DECODER_TYPE dec_type;
	char file_path[512];
	GMainLoop *loop;
	GstBus *bus;
	GstElement *pipeline;
	gboolean pipeline_already_quit;
	int drm_fd;
	int channel_id;
	int x;
	int y;
	int w;
	int h;
	pthread_t thread;	
} RTK_MULTI_PLAYBACK;

typedef enum rtk_cmd_type {
    CMD_START,
    CMD_STOP,
} RTK_CMD_TYPE;

typedef struct rtk_player_cmd {
	RTK_CMD_TYPE cmd_type;
	RTK_SOURCE_TYPE source_type;
	RTK_CODEC_TYPE codec_type;
	RTK_RENDER_TYPE render_type;
	RTK_DECODER_TYPE dec_type;
	char file_path[512];
	int channel_id;
	int x;
	int y;
	int w;
	int h;
} RTK_PLAYER_CMD;

RTK_MULTI_PLAYBACK *playback_init(void);
void playback_uninit(RTK_MULTI_PLAYBACK *playback);
int playback_start(RTK_MULTI_PLAYBACK *playback);
int playback_stop(RTK_MULTI_PLAYBACK *playback);

#endif // end of __RTK_MULTI_PLAYER__
