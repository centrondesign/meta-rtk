#include <stdlib.h>
#include <stdio.h>
#include "rtk_media_info.h"
int main(int argc, char *argv[])
{
	struct rtk_media_info info = {0};
	get_media_info(argv[1], &info, true);
	list_media_info(&info);

	return 0;
}
