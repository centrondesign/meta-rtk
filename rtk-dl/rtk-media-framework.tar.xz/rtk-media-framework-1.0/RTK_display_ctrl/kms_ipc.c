#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <inttypes.h>
#include "rtk_display_ctrl.h"

static void process_display_cmd(struct kms_device *dev, char *display_cmd)
{
	int enable = 1;
	int conn_id = 0;
	char mode[64] = {0};
	sscanf(display_cmd, "%[^:]:%d:%d", mode, &conn_id, &enable);

	if (strcmp(mode, "vo") == 0) {
		set_vo_enable(dev, conn_id, enable);
	} else if (strcmp(mode, "display") == 0) {
		set_display_enable(dev, conn_id, enable);
	} else {
		printf("no this mode:%s\n", mode);
	}
}

static void process_plane_mode(struct kms_device *dev, char *plane_mode) {
	char plane[256] = {0};
	char mode[256] = {0};
	sscanf(plane_mode, "%[^:]:%s", plane, mode);
	set_plane_mode(dev, plane, mode);
}

static void process_edid_cmd (struct kms_device *dev, char *edid_cmd)
{
	char cmd[256] = {0};
	char tv_mode[256] = {0};
	int conn_id = 0;
	struct tv_mode_info mode_info = {0};

	if (strncmp(edid_cmd, "list", strlen("list")) == 0) {
		sscanf(edid_cmd, "%[^:]:%d", cmd, &conn_id);
		get_connector_tv_mode_info(dev, conn_id, &mode_info);
		list_all_tv_mode_info(&mode_info);
	} else if (strncmp(edid_cmd, "get", strlen("get")) == 0) {
		sscanf(edid_cmd, "%[^:]:%d:%s", cmd, &conn_id, tv_mode);
		get_connector_tv_mode_info(dev, conn_id, &mode_info);
		list_specific_tv_mode_bitmap(&mode_info, tv_mode);
	}
}

static void process_tv_mode_cmd(struct kms_device *dev, char *tv_mode)
{
	int conn_id = -1;
	char tv_mode_info[256] = {0};

	sscanf(tv_mode, "%d:%s", &conn_id, tv_mode_info);
	set_tv_mode(dev, conn_id, tv_mode_info);
}

static void usage()
{
	fprintf(stderr, "\n Query options:\n\n");
	fprintf(stderr, "\t-v\tshow version\n");
	fprintf(stderr, "\t-c\tlist connectors info\n");
	fprintf(stderr, "\t-e\tget edid info\n");
	fprintf(stderr, "\t\t\tlist:connector_id -> to list all connector id\n");
	fprintf(stderr, "\t\t\tget:connector_id:tv_mode -> to list tv mode \"max bpc\" and \"RGB or YCbCr\" support");
	fprintf(stderr, "\n Control options:\n\n");
	fprintf(stderr, "\tchange tv mode: -s <connector_id>:widthxheight<@refrash>\n");
	fprintf(stderr, "\tproperty control: -w <obj_id>:<prop_name>:<value>\n");
	fprintf(stderr, "\tenable or disable display: -d <connector_id>:<0|1>\n");
	fprintf(stderr, "\tset plane mode: -p [V1, V2]:[low_delay_off, low_delay_decoder, low_delay_display, low_delay_decoder_display, low_delay_avsync, low_delay_decoder_avsync, low_delay_display_order]\n");
	fprintf(stderr, "\n");
}

#define KMS_IPC_VERSION "KMS_IPC 3.0.6"

static char optstr[] = "s:w:e:cvd:p:F";

int main(int argc, char **argv)
{
	int ret = -1;
	struct kms_device dev = {0};
	unsigned int args = 0;
    char *edid_cmd = NULL;
    int list_connectors = 0;
	char *tv_mode = NULL;
	int c = 0;
	struct property_info prop_info = {0};
	int show_version = 0;
	char *display_cmd = NULL;
	char *plane_mode = NULL;
	int offline_open = 0;

	opterr = 0;
	while ((c = getopt(argc, argv, optstr)) != -1) {
		args++;
		switch(c) {
			case 'v':
				show_version = 1;
				break;
			case 'e':
				edid_cmd = (char *)malloc(256);
				strcpy(edid_cmd, optarg);
				break;
			case 's':
				tv_mode = (char *)malloc(256);
				strcpy(tv_mode, optarg);
				break;
			case 'd':
				display_cmd = (char *)malloc(256);
				strcpy(display_cmd, optarg);
				break;
			case 'c':
				list_connectors = 1;
				break;
			case 'w':
				prop_info.param = realloc(prop_info.param, (prop_info.prop_count + 1) * sizeof(struct property_param));
				if (prop_info.param == NULL) {
					printf("memory allocation failed\n");
					return -1;
				}

				memset(&prop_info.param[prop_info.prop_count], 0, sizeof(struct property_param));

				struct property_param *param = &prop_info.param[prop_info.prop_count];
				if (sscanf(optarg, "%d:%32[^:]:%" SCNu64, &param->obj_id, param->name, &param->value) != 3) {
					printf("wrong property format\n");
					return -1;
				}

				prop_info.prop_count++;
				break;
			case 'p':
				plane_mode = (char *)malloc(256);
				strcpy(plane_mode, optarg);
				break;
			case 'F':
				offline_open = 1;
				args--;
				break;
			default:
				usage();
				return 0;
        }
    }

	if (show_version == 1)
		printf("Version: %s\n", KMS_IPC_VERSION);

	if (offline_open == 1)
		ret = kms_device_offline_init(&dev);
	else
		ret = kms_device_init(&dev);

	if (ret < 0) {
		printf("kms_device_init fail\n");
		return -1;
	}

	if (!args) {
		dump_drm_info(&dev);
		goto finish;
	}

	if (list_connectors) {
		struct connector_info conn_info = {0};
		get_connectors_info(&dev, &conn_info);
		printf("Connector list:\n");
		for (int i = 0; i < conn_info.conn_count; i++) {
			printf("ID:%d name:%s\n", conn_info.conn_id[i], conn_info.name[i]);
		}
		printf("\n");
		goto finish;
	}

	if (edid_cmd) {
		process_edid_cmd(&dev, edid_cmd);
		free(edid_cmd);
		goto finish;
	}

	if (plane_mode) {
		process_plane_mode(&dev, plane_mode);
		free(plane_mode);
		goto finish;
	}

	if (offline_open == 1 && (display_cmd || prop_info.prop_count || tv_mode)) {
		printf("The command isn't supported by offline setting\n");
		if (display_cmd)
			free(display_cmd);

		if (prop_info.prop_count)
			free(prop_info.param);

		if(tv_mode)
			free(tv_mode);

		goto finish;
	}

	if (display_cmd) {
		process_display_cmd(&dev, display_cmd);
		free(display_cmd);
		goto finish;
	}

	if (prop_info.prop_count > 0) {
		struct connector_info conn_info = {0};
		get_connectors_info(&dev, &conn_info);

// if set connector property, need to reset output
		for (int i = 0; i < conn_info.conn_count; i++) {
			for (int j = 0; j < prop_info.prop_count; j++) {
				struct property_param *param = &prop_info.param[i];
				if (param->obj_id == conn_info.conn_id[i]) {
					prop_info.conn_id = param->obj_id;
					prop_info.output_reset = 1;
				}
			}
		}

		set_tv_property(&dev, &prop_info);
		free(prop_info.param);
	}

	if (tv_mode) {
		process_tv_mode_cmd(&dev, tv_mode);
		free(tv_mode);
	}

finish:
	kms_device_uninit(&dev);
	return 0;
}
