#include <stdio.h>
#include <stdlib.h>
#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>
#include <string.h>
#include <inttypes.h>
#include <assert.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "rtk_edid.h"
#include "rtk_display_ctrl.h"
#include "rtk_drm_ioctl.h"

struct crtc {
	drmModeCrtc *crtc;
	drmModeObjectProperties *props;
	drmModePropertyRes **props_info;
	drmModeModeInfo *mode;
};

struct encoder {
	drmModeEncoder *encoder;
};

struct connector {
	drmModeConnector *connector;
	drmModeObjectProperties *props;
	drmModePropertyRes **props_info;
	char *name;
	int is_disabled;
	unsigned char edid_data[2048];
	int edid_len;
};

struct plane {
	drmModePlane *plane;
	drmModeObjectProperties *props;
	drmModePropertyRes **props_info;
};

struct resources {
	struct crtc *crtcs;
	int count_crtcs;
	struct encoder *encoders;
	int count_encoders;
	struct connector *connectors;
	int count_connectors;
	struct plane *planes;
	uint32_t count_planes;
	drmModeAtomicReq *req;
};

struct type_name {
	unsigned int type;
	const char *name;
};

static const char *util_lookup_type_name(unsigned int type,
                     const struct type_name *table,
                     unsigned int count)
{
	unsigned int i;

	for (i = 0; i < count; i++)
		if (table[i].type == type)
			return table[i].name;

	return NULL;
}

static const struct type_name encoder_type_names[] = {
	{ DRM_MODE_ENCODER_NONE, "none" },
	{ DRM_MODE_ENCODER_DAC, "DAC" },
	{ DRM_MODE_ENCODER_TMDS, "TMDS" },
	{ DRM_MODE_ENCODER_LVDS, "LVDS" },
	{ DRM_MODE_ENCODER_TVDAC, "TVDAC" },
	{ DRM_MODE_ENCODER_VIRTUAL, "Virtual" },
	{ DRM_MODE_ENCODER_DSI, "DSI" },
	{ DRM_MODE_ENCODER_DPMST, "DPMST" },
	{ DRM_MODE_ENCODER_DPI, "DPI" },
};

const char *util_lookup_encoder_type_name(unsigned int type)
{
	return util_lookup_type_name(type, encoder_type_names,
			ARRAY_SIZE(encoder_type_names));
}

static const struct type_name connector_status_names[] = {
	{ DRM_MODE_CONNECTED, "connected" },
	{ DRM_MODE_DISCONNECTED, "disconnected" },
	{ DRM_MODE_UNKNOWNCONNECTION, "unknown" },
};

const char *util_lookup_connector_status_name(unsigned int status)
{
	return util_lookup_type_name(status, connector_status_names,
			ARRAY_SIZE(connector_status_names));
}

static inline int64_t U642I64(uint64_t val)
{
	return (int64_t)*((int64_t *)&val);
}

static float mode_vrefresh(drmModeModeInfo *mode)
{
	unsigned int num, den;

	num = mode->clock;
	den = mode->htotal * mode->vtotal;

	if (mode->flags & DRM_MODE_FLAG_INTERLACE)
		num *= 2;
	if (mode->flags & DRM_MODE_FLAG_DBLSCAN)
		den *= 2;
	if (mode->vscan > 1)
		den *= mode->vscan;

	return num * 1000.00 / den;
}

#define bit_name_fn(res)                    \
const char * res##_str(int type) {              \
	unsigned int i;                     \
	const char *sep = "";                   \
	for (i = 0; i < ARRAY_SIZE(res##_names); i++) {     \
		if (type & (1 << i)) {              \
			printf("%s%s", sep, res##_names[i]);    \
				sep = ", ";             \
		}                       \
	}                           \
	return NULL;                        \
}

static const char *mode_type_names[] = {
	"builtin",
	"clock_c",
	"crtc_c",
	"preferred",
	"default",
	"userdef",
	"driver",
};

static bit_name_fn(mode_type)

static const char *mode_flag_names[] = {
	"phsync",
	"nhsync",
	"pvsync",
	"nvsync",
	"interlace",
	"dblscan",
	"csync",
	"pcsync",
	"ncsync",
	"hskew",
	"bcast",
	"pixmux",
	"dblclk",
	"clkdiv2"
};

static bit_name_fn(mode_flag)

static void dump_fourcc(uint32_t fourcc)
{
	char *name = drmGetFormatName(fourcc);
	printf(" %s", name);
	free(name);
}

static void dump_encoders(struct kms_device *dev)
{
	drmModeEncoder *encoder;
	int i;

	printf("Encoders:\n");
	printf("id\tcrtc\ttype\tpossible crtcs\tpossible clones\t\n");
	for (i = 0; i < dev->resources->count_encoders; i++) {
		encoder = dev->resources->encoders[i].encoder;
		if (!encoder)
			continue;

		printf("%d\t%d\t%s\t0x%08x\t0x%08x\n",
			encoder->encoder_id,
			encoder->crtc_id,
			util_lookup_encoder_type_name(encoder->encoder_type),
			encoder->possible_crtcs,
			encoder->possible_clones);
	}
	printf("\n");
}

static void dump_mode(drmModeModeInfo *mode, int index)
{
	printf("  #%i %s %.2f %d %d %d %d %d %d %d %d %d",
		index,
		mode->name,
		mode_vrefresh(mode),
		mode->hdisplay,
		mode->hsync_start,
		mode->hsync_end,
		mode->htotal,
		mode->vdisplay,
		mode->vsync_start,
		mode->vsync_end,
		mode->vtotal,
		mode->clock);

	printf(" flags: ");
	mode_flag_str(mode->flags);
	printf("; type: ");
	mode_type_str(mode->type);
	printf("\n");
}

static void dump_blob(struct kms_device *dev, uint32_t blob_id)
{
	uint32_t i;
	unsigned char *blob_data;
	drmModePropertyBlobPtr blob;

	blob = drmModeGetPropertyBlob(dev->fd, blob_id);
	if (!blob) {
		printf("\n");
		return;
	}

	blob_data = blob->data;

	for (i = 0; i < blob->length; i++) {
		if (i % 16 == 0)
			printf("\n\t\t\t");
		printf("%.2hhx", blob_data[i]);
	}
	printf("\n");

	drmModeFreePropertyBlob(blob);
}

static const char *modifier_to_string(uint64_t modifier)
{
	static char mod_string[4096];

	char *modifier_name = drmGetFormatModifierName(modifier);
	char *vendor_name = drmGetFormatModifierVendor(modifier);
	memset(mod_string, 0x00, sizeof(mod_string));

	if (!modifier_name) {
		if (vendor_name)
			snprintf(mod_string, sizeof(mod_string), "%s_%s",
				vendor_name, "UNKNOWN_MODIFIER");
		else
			snprintf(mod_string, sizeof(mod_string), "%s_%s",
				"UNKNOWN_VENDOR", "UNKNOWN_MODIFIER");
		/* safe, as free is no-op for NULL */
		free(vendor_name);
		return mod_string;
	}

	if (modifier == DRM_FORMAT_MOD_LINEAR) {
		snprintf(mod_string, sizeof(mod_string), "%s", modifier_name);
		free(modifier_name);
		free(vendor_name);
		return mod_string;
	}

	snprintf(mod_string, sizeof(mod_string), "%s_%s",
		vendor_name, modifier_name);

	free(modifier_name);
	free(vendor_name);
	return mod_string;
}

static void dump_in_formats(struct kms_device *dev, uint32_t blob_id)
{
	drmModeFormatModifierIterator iter = {0};
	drmModePropertyBlobPtr blob;
	uint32_t fmt = 0;

	printf("\t\tin_formats blob decoded:\n");
	blob = drmModeGetPropertyBlob(dev->fd, blob_id);
	if (!blob) {
		printf("\n");
		return;
	}

	while (drmModeFormatModifierBlobIterNext(blob, &iter)) {
		if (!fmt || fmt != iter.fmt) {
			printf("%s\t\t\t", !fmt ? "" : "\n");
			fmt = iter.fmt;
			dump_fourcc(fmt);
			printf(": ");
		}

		printf(" %s(0x%"PRIx64")", modifier_to_string(iter.mod), iter.mod);
	}

	printf("\n");

	drmModeFreePropertyBlob(blob);
}

static void dump_prop(struct kms_device *dev, drmModePropertyPtr prop,
              uint32_t prop_id, uint64_t value)
{
	int i;
	printf("\t%d", prop_id);
	if (!prop) {
		printf("\n");
		return;
	}

	printf(" %s:\n", prop->name);

	printf("\t\tflags:");
	if (prop->flags & DRM_MODE_PROP_PENDING)
		printf(" pending");
	if (prop->flags & DRM_MODE_PROP_IMMUTABLE)
		printf(" immutable");
	if (drm_property_type_is(prop, DRM_MODE_PROP_SIGNED_RANGE))
		printf(" signed range");
	if (drm_property_type_is(prop, DRM_MODE_PROP_RANGE))
		printf(" range");
	if (drm_property_type_is(prop, DRM_MODE_PROP_ENUM))
		printf(" enum");
	if (drm_property_type_is(prop, DRM_MODE_PROP_BITMASK))
		printf(" bitmask");
	if (drm_property_type_is(prop, DRM_MODE_PROP_BLOB))
		printf(" blob");
	if (drm_property_type_is(prop, DRM_MODE_PROP_OBJECT))
		printf(" object");
	printf("\n");

	if (drm_property_type_is(prop, DRM_MODE_PROP_SIGNED_RANGE)) {
		printf("\t\tvalues:");
		for (i = 0; i < prop->count_values; i++)
			printf(" %"PRId64, U642I64(prop->values[i]));
		printf("\n");
	}

	if (drm_property_type_is(prop, DRM_MODE_PROP_RANGE)) {
		printf("\t\tvalues:");
		for (i = 0; i < prop->count_values; i++)
			printf(" %"PRIu64, prop->values[i]);
		printf("\n");
	}

	if (drm_property_type_is(prop, DRM_MODE_PROP_ENUM)) {
		printf("\t\tenums:");
		for (i = 0; i < prop->count_enums; i++)
			printf(" %s=%"PRIu64, prop->enums[i].name,
				(uint64_t)prop->enums[i].value);
		printf("\n");
	} else if (drm_property_type_is(prop, DRM_MODE_PROP_BITMASK)) {
		printf("\t\tvalues:");
		for (i = 0; i < prop->count_enums; i++)
			printf(" %s=0x%llx", prop->enums[i].name,
				(1LL << prop->enums[i].value));
		printf("\n");
	} else {
		assert(prop->count_enums == 0);
	}

	if (drm_property_type_is(prop, DRM_MODE_PROP_BLOB)) {
		printf("\t\tblobs:\n");
		for (i = 0; i < prop->count_blobs; i++)
			dump_blob(dev, prop->blob_ids[i]);
		printf("\n");
	} else {
		assert(prop->count_blobs == 0);
	}

	printf("\t\tvalue:");
	if (drm_property_type_is(prop, DRM_MODE_PROP_BLOB))
		dump_blob(dev, value);
	else if (drm_property_type_is(prop, DRM_MODE_PROP_SIGNED_RANGE))
		printf(" %"PRId64"\n", value);
	else
		printf(" %"PRIu64"\n", value);

	if (strcmp(prop->name, "IN_FORMATS") == 0)
		dump_in_formats(dev, value);
}

static void dump_connectors(struct kms_device *dev)
{
	int i, j;
	printf("Connectors:\n");
	printf("id\tencoder\tstatus\t\tname\t\tsize (mm)\tmodes\tencoders\n");
	for (i = 0; i < dev->resources->count_connectors; i++) {
		struct connector *_connector = &dev->resources->connectors[i];
		drmModeConnector *connector = _connector->connector;
		if (!connector)
			continue;

		printf("%d\t%d\t%s\t%-15s\t%dx%d\t\t%d\t",
			connector->connector_id,
			connector->encoder_id,
			util_lookup_connector_status_name(connector->connection),
			_connector->name,
			connector->mmWidth, connector->mmHeight,
			connector->count_modes);

		for (j = 0; j < connector->count_encoders; j++)
			printf("%s%d", j > 0 ? ", " : "", connector->encoders[j]);
		printf("\n");

		if (connector->count_modes) {
			printf("  modes:\n");
			printf("\tindex name refresh (Hz) hdisp hss hse htot vdisp "
				"vss vse vtot\n");
			for (j = 0; j < connector->count_modes; j++)
				dump_mode(&connector->modes[j], j);
		}

		if (_connector->props) {
			printf("  props:\n");
			for (j = 0; j < (int)_connector->props->count_props; j++)
				dump_prop(dev, _connector->props_info[j],
					_connector->props->props[j],
					_connector->props->prop_values[j]);
		}
	}
	printf("\n");
}

static void dump_crtcs(struct kms_device *dev)
{
	int i;
	uint32_t j;
	printf("CRTCs:\n");
	printf("id\tfb\tpos\tsize\n");
	for (i = 0; i < dev->resources->count_crtcs; i++) {
		struct crtc *_crtc = &dev->resources->crtcs[i];
		drmModeCrtc *crtc = _crtc->crtc;
		if (!crtc)
			continue;

		printf("%d\t%d\t(%d,%d)\t(%dx%d)\n",
			crtc->crtc_id,
			crtc->buffer_id,
			crtc->x, crtc->y,
			crtc->width, crtc->height);
		dump_mode(&crtc->mode, 0);

		if (_crtc->props) {
			printf("  props:\n");
			for (j = 0; j < _crtc->props->count_props; j++)
				dump_prop(dev, _crtc->props_info[j],
					_crtc->props->props[j],
					_crtc->props->prop_values[j]);
		} else {
			printf("  no properties found\n");
		}
	}
	printf("\n");
}

static void dump_planes(struct kms_device *dev)
{
	unsigned int i, j;

	printf("Planes:\n");
	printf("id\tcrtc\tfb\tCRTC x,y\tx,y\tgamma size\tpossible crtcs\n");

	for (i = 0; i < dev->resources->count_planes; i++) {
		struct plane *plane = &dev->resources->planes[i];
		drmModePlane *ovr = plane->plane;
		if (!ovr)
			continue;

		printf("%d\t%d\t%d\t%d,%d\t\t%d,%d\t%-8d\t0x%08x\n",
			ovr->plane_id, ovr->crtc_id, ovr->fb_id,
			ovr->crtc_x, ovr->crtc_y, ovr->x, ovr->y,
			ovr->gamma_size, ovr->possible_crtcs);

		if (!ovr->count_formats)
			continue;

		printf("  formats:");
		for (j = 0; j < ovr->count_formats; j++)
			dump_fourcc(ovr->formats[j]);
		printf("\n");

		if (plane->props) {
			printf("  props:\n");
			for (j = 0; j < plane->props->count_props; j++)
				dump_prop(dev, plane->props_info[j],
					plane->props->props[j],
					plane->props->prop_values[j]);
		} else {
			printf("  no properties found\n");
		}
	}
	printf("\n");

	return;
}

static void free_resources(struct resources *res)
{
	int i;

	if (!res)
		return;

#define free_resource(_res, type, Type)                 \
	do {                                    \
		if (!(_res)->type##s)                       \
			break;                          \
		for (i = 0; i < (int)(_res)->count_##type##s; ++i) {    \
			if (!(_res)->type##s[i].type)               \
				break;                      \
			drmModeFree##Type((_res)->type##s[i].type);     \
		}                               \
		free((_res)->type##s);                      \
	} while (0)

#define free_properties(_res, type)                 \
	do {                                    \
		for (i = 0; i < (int)(_res)->count_##type##s; ++i) {    \
			unsigned int j;                                     \
			for (j = 0; j < res->type##s[i].props->count_props; ++j)\
				drmModeFreeProperty(res->type##s[i].props_info[j]);\
			free(res->type##s[i].props_info);           \
			drmModeFreeObjectProperties(res->type##s[i].props); \
		}                               \
	} while (0)

	free_properties(res, plane);
	free_resource(res, plane, Plane);

	free_properties(res, connector);
	free_properties(res, crtc);

	for (i = 0; i < res->count_connectors; i++)
		free(res->connectors[i].name);

	free_resource(res, connector, Connector);
	free_resource(res, encoder, Encoder);
	free_resource(res, crtc, Crtc);

	free(res);
}

static struct resources *get_resources(struct kms_device *dev)
{
	drmModeRes *_res;
	drmModePlaneRes *plane_res;
	struct resources *res;
	int i;

	res = calloc(1, sizeof(*res));
	if (res == 0)
		return NULL;

	drmSetClientCap(dev->fd, DRM_CLIENT_CAP_UNIVERSAL_PLANES, 1);

	_res = drmModeGetResources(dev->fd);
	if (!_res) {
		fprintf(stderr, "drmModeGetResources failed: %s\n", strerror(errno));
		free(res);
		return NULL;
	}

	res->count_crtcs = _res->count_crtcs;
	res->count_encoders = _res->count_encoders;
	res->count_connectors = _res->count_connectors;

	res->crtcs = calloc(res->count_crtcs, sizeof(*res->crtcs));
	res->encoders = calloc(res->count_encoders, sizeof(*res->encoders));
	res->connectors = calloc(res->count_connectors, sizeof(*res->connectors));

	if (!res->crtcs || !res->encoders || !res->connectors) {
		drmModeFreeResources(_res);
		goto error;
	}

#define get_resource(_res, __res, type, Type)                   \
	do {                                    \
		for (i = 0; i < (int)(_res)->count_##type##s; ++i) {    \
			uint32_t type##id = (__res)->type##s[i];            \
            (_res)->type##s[i].type =                           \
				drmModeGet##Type(dev->fd, type##id);            \
			if (!(_res)->type##s[i].type)                       \
				fprintf(stderr, "could not get %s %i: %s\n",    \
					#type, type##id,                            \
					strerror(errno));           \
		}                               \
	} while (0)

	get_resource(res, _res, crtc, Crtc);
	get_resource(res, _res, encoder, Encoder);
	get_resource(res, _res, connector, Connector);

	drmModeFreeResources(_res);

	/* Set the name of all connectors based on the type name and the per-type ID. */
	for (i = 0; i < res->count_connectors; i++) {
		struct connector *connector = &res->connectors[i];
		drmModeConnector *conn = connector->connector;
		int num;

		num = asprintf(&connector->name, "%s-%u",
		    drmModeGetConnectorTypeName(conn->connector_type),
		    conn->connector_type_id);
		if (num < 0)
			goto error;
	}

#define get_properties(_res, type, Type)                    \
    do {                                    \
		for (i = 0; i < (int)(_res)->count_##type##s; ++i) {    \
			struct type *obj = &res->type##s[i];            \
			unsigned int j;                     \
			obj->props =                        \
				drmModeObjectGetProperties(dev->fd, obj->type->type##_id, \
					DRM_MODE_OBJECT_##Type); \
			if (!obj->props) {                  \
				fprintf(stderr,                 \
					"could not get %s %i properties: %s\n", \
					#type, obj->type->type##_id,        \
					strerror(errno));           \
				continue;                   \
			}                           \
			obj->props_info = calloc(obj->props->count_props,   \
				sizeof(*obj->props_info)); \
			if (!obj->props_info)                   \
				continue;                   \
			for (j = 0; j < obj->props->count_props; ++j)       \
				obj->props_info[j] =                \
					drmModeGetProperty(dev->fd, obj->props->props[j]); \
		}                               \
	} while (0)

	get_properties(res, crtc, CRTC);
	get_properties(res, connector, CONNECTOR);

	for (i = 0; i < res->count_crtcs; ++i)
		res->crtcs[i].mode = &res->crtcs[i].crtc->mode;

	plane_res = drmModeGetPlaneResources(dev->fd);
	if (!plane_res) {
		fprintf(stderr, "drmModeGetPlaneResources failed: %s\n",
			strerror(errno));
		return res;
	}

	res->count_planes = plane_res->count_planes;

	res->planes = calloc(res->count_planes, sizeof(*res->planes));
	if (!res->planes) {
		drmModeFreePlaneResources(plane_res);
		goto error;
	}

	get_resource(res, plane_res, plane, Plane);
	drmModeFreePlaneResources(plane_res);
	get_properties(res, plane, PLANE);

	return res;

error:
	free_resources(res);
	return NULL;
}

struct property_arg {
	uint32_t obj_id;
	uint32_t obj_type;
	char name[DRM_PROP_NAME_LEN+1];
	uint32_t prop_id;
	uint64_t value;
	bool optional;
};

static int parse_property(struct property_arg *p, const char *arg)
{
	if (sscanf(arg, "%d:%32[^:]:%" SCNu64, &p->obj_id, p->name, &p->value) != 3)
		return -1;

	p->obj_type = 0;
	p->name[DRM_PROP_NAME_LEN] = '\0';

	return 0;
}

static bool set_property(struct kms_device *dev, struct property_arg *p)
{
	drmModeObjectProperties *props = NULL;
	drmModePropertyRes **props_info = NULL;
	const char *obj_type;
	int ret;
	int i;

	p->obj_type = 0;
	p->prop_id = 0;

#define find_object(_res, type, Type)                   \
	do {                                    \
		for (i = 0; i < (int)(_res)->count_##type##s; ++i) {    \
			struct type *obj = &(_res)->type##s[i];         \
			if (obj->type->type##_id != p->obj_id)          \
				continue;                   \
			p->obj_type = DRM_MODE_OBJECT_##Type;           \
			obj_type = #Type;                   \
			props = obj->props;                 \
			props_info = obj->props_info;               \
		}                               \
	} while(0)                              \

	find_object(dev->resources, crtc, CRTC);
	if (p->obj_type == 0)
		find_object(dev->resources, connector, CONNECTOR);
	if (p->obj_type == 0)
		find_object(dev->resources, plane, PLANE);
	if (p->obj_type == 0) {
		fprintf(stderr, "Object %i not found, can't set property\n",
			p->obj_id);
		return false;
	}
	if (!props) {
		fprintf(stderr, "%s %i has no properties\n",
			obj_type, p->obj_id);
		return false;
	}

	for (i = 0; i < (int)props->count_props; ++i) {
		if (!props_info[i])
			continue;
		if (strcmp(props_info[i]->name, p->name) == 0)
			break;
	}

	if (i == (int)props->count_props) {
		if (!p->optional)
			fprintf(stderr, "%s %i has no %s property\n",
				obj_type, p->obj_id, p->name);
		return false;
	}

	p->prop_id = props->props[i];

	ret = drmModeAtomicAddProperty(dev->resources->req, p->obj_id, p->prop_id, p->value);

	if (ret < 0)
		fprintf(stderr, "failed to set %s %i property %s to %" PRIu64 ": %s\n",
			obj_type, p->obj_id, p->name, p->value, strerror(-ret));

	return true;
}

static void add_property(struct kms_device *dev, uint32_t obj_id,
                   const char *name, uint64_t value)
{
	struct property_arg p;

	p.obj_id = obj_id;
	strcpy(p.name, name);
	p.value = value;

	set_property(dev, &p);
}

static int find_connector_prop_value(struct kms_device *dev, int connector_id, char *prop_name)
{
	int value = -1;
	for (int i = 0; i < dev->resources->count_connectors; i++) {
		struct connector *connector = &dev->resources->connectors[i];
		if (connector->connector->connector_id == connector_id) {
			for (int k = 0; k < connector->props->count_props; k++) {
				if (strncmp(connector->props_info[k]->name, prop_name, strlen(prop_name)) == 0) {
					value = connector->props->prop_values[k];
					break;
				}
			}
			break;
		}
	}
	return value;
}

enum kms_type {
	CONNECTOR_TYPE = 0,
	CRTC_TYPE,
	PLANE_TYPE,
	UNKNOWN_TYPE,
	KMS_TYPE_COUNT,
};

enum kms_cmd_type {
	CRTC_TV_MODE = 0,
	CRTC_DPMS_MODE = 1,
	CRTC_ACTIVE_RESET = 2,
	UNKNOWN_CMD_TYPE = 300,
	KMS_CMD_TYPE_COUNT,
};

struct kms_ipc_info {
	enum kms_type type;
	enum kms_cmd_type cmd_type;
	char cmd_str[128];
	int cmd_value;
};

#define KMS_IPC_SOCKET_PATH "/tmp/kms_ipc.sock"

void set_vo_enable(struct kms_device *dev, int conn_id, int enable) {
	int found = 0;
	struct kms_ipc_info info = {0};
	int socket_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
	struct sockaddr_un serveraddr;

	for (int i = 0; i < dev->resources->count_connectors; i++) {
		struct connector *_connector = &dev->resources->connectors[i];
		drmModeConnector *connector = _connector->connector;
		if (!connector)
			continue;

		if (connector->connector_id == conn_id){
			found = 1;
			break;
		}
	}

	if (found == 0) {
		printf("not found connector_id:%d\n", conn_id);
		return;
	}

	info.type = CRTC_TYPE;
	info.cmd_type = CRTC_DPMS_MODE;
	if (enable == 0)
		strcpy(info.cmd_str, "disable");
	else
		strcpy(info.cmd_str, "enable");

	info.cmd_value = find_connector_prop_value(dev, conn_id, "CRTC_ID");
	if (info.cmd_value < 0) {
		printf("connector_id:%d doesn't bind crtc\n", conn_id);
	}

	memset(&serveraddr,0,sizeof(serveraddr));
	socklen_t addrlen = sizeof(serveraddr);
	serveraddr.sun_family = AF_UNIX;
	strcpy(serveraddr.sun_path, KMS_IPC_SOCKET_PATH);
	sendto(socket_fd, &info, sizeof(struct kms_ipc_info), 0, (struct sockaddr*)&serveraddr,addrlen);
	shutdown(socket_fd, SHUT_RDWR);
	return;
}

int set_tv_mode(struct kms_device *dev, int conn_id, char *tv_mode)
{
	int found = 0;
	struct kms_ipc_info info = {0};
	int socket_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
	struct sockaddr_un serveraddr;

	for (int i = 0; i < dev->resources->count_connectors; i++) {
		struct connector *_connector = &dev->resources->connectors[i];
		drmModeConnector *connector = _connector->connector;
		if (!connector)
			continue;

		if (connector->connector_id == conn_id){
			found = 1;
			break;
		}
	}

	if (found == 0) {
		printf("not found connector_id:%d\n", conn_id);
		return -1;
	}

	info.type = CRTC_TYPE;
	info.cmd_type = CRTC_TV_MODE;
	strcpy(info.cmd_str, tv_mode);
	info.cmd_value = find_connector_prop_value(dev, conn_id, "CRTC_ID");
	if (info.cmd_value < 0) {
		printf("connector_id:%d doesn't bind crtc\n", conn_id);
	}

	memset(&serveraddr,0,sizeof(serveraddr));
	socklen_t addrlen = sizeof(serveraddr);
	serveraddr.sun_family = AF_UNIX;
	strcpy(serveraddr.sun_path, KMS_IPC_SOCKET_PATH);
	sendto(socket_fd, &info, sizeof(struct kms_ipc_info), 0, (struct sockaddr*)&serveraddr,addrlen);
	shutdown(socket_fd, SHUT_RDWR);
	return 0;
}

int set_tv_property(struct kms_device *dev, struct property_info *info)
{
	int crtc_id = -1;
	struct kms_ipc_info kms_info = {0};
	int socket_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
	struct sockaddr_un serveraddr;

	if (dev == NULL) {
		printf("kms_device is NULL\n");
		return -1;
	}

	if (dev->resources == NULL) {
		printf("dev resources is NULL\n");
		return -1;
	}

	if (info == NULL) {
		printf("property_info is NULL\n");
		return -1;
	}

	dev->resources->req = drmModeAtomicAlloc();

	for (int i = 0; i < info->prop_count; i++)
	{
		struct property_param *param = &info->param[i];
		add_property(dev, param->obj_id, param->name, param->value);
	}

	drmModeAtomicCommit(dev->fd, dev->resources->req, DRM_MODE_ATOMIC_ALLOW_MODESET, NULL);
	drmModeAtomicFree(dev->resources->req);

	if (info->output_reset) {
		crtc_id = find_connector_prop_value(dev, info->conn_id, "CRTC_ID");
		kms_info.type = CRTC_TYPE;
		kms_info.cmd_type = CRTC_ACTIVE_RESET;
		kms_info.cmd_value = crtc_id;

		memset(&serveraddr,0,sizeof(serveraddr));
		socklen_t addrlen = sizeof(serveraddr);
		serveraddr.sun_family = AF_UNIX;
		strcpy(serveraddr.sun_path, KMS_IPC_SOCKET_PATH);
		sendto(socket_fd, &kms_info, sizeof(struct kms_ipc_info), 0, (struct sockaddr*)&serveraddr,addrlen);
	}

	shutdown(socket_fd, SHUT_RDWR);
	return 0;
}

enum drm_device_ipc_cmd_type {
	CONN_ACTIVE = 0,
	DRM_DEVICE_CMD_TYPE_COUNT,
};

struct drm_device_ipc_info {
	enum drm_device_ipc_cmd_type cmd_type;
	char cmd_str[128];
	int cmd_value;
};

#define DRM_DEVICE_IPC_SOCKET_PATH "/tmp/drm_device.sock"

void set_display_enable(struct kms_device *dev, int conn_id, int enable) {
	int found = 0;
	struct drm_device_ipc_info info = {0};
	int socket_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
	struct sockaddr_un serveraddr;

	for (int i = 0; i < dev->resources->count_connectors; i++) {
		struct connector *_connector = &dev->resources->connectors[i];
		drmModeConnector *connector = _connector->connector;
		if (!connector)
			continue;

		if (connector->connector_id == conn_id){
			found = 1;
			break;
		}
	}

	if (found == 0) {
		printf("not found connector_id:%d\n", conn_id);
		return;
	}

	info.cmd_type = CONN_ACTIVE;
	if (enable == 0)
		strcpy(info.cmd_str, "disable");
	else
		strcpy(info.cmd_str, "enable");

	info.cmd_value = conn_id;
	if (info.cmd_value < 0) {
		printf("connector_id:%d doesn't bind crtc\n", conn_id);
	}

	memset(&serveraddr,0,sizeof(serveraddr));
	socklen_t addrlen = sizeof(serveraddr);
	serveraddr.sun_family = AF_UNIX;
	strcpy(serveraddr.sun_path, DRM_DEVICE_IPC_SOCKET_PATH);
	sendto(socket_fd, &info, sizeof(struct drm_device_ipc_info), 0, (struct sockaddr*)&serveraddr,addrlen);
	shutdown(socket_fd, SHUT_RDWR);
	return;
}


#define DRM_MASTER_MANAGER "/tmp/drm_master.sock"
enum command_type {
	GET_FILE_FD,
};

struct command_info {
	enum command_type type;
};

static int get_drm_master(void)
{
	int socket_fd = socket(AF_UNIX, SOCK_STREAM, 0);
	struct sockaddr_un serveraddr;
	struct command_info info = {0};
	struct msghdr socket_msg;
	struct cmsghdr *ctrl_msg;
	struct iovec iov;
	char buf[16];
	char ctrl_data[CMSG_SPACE(sizeof(int))];
	int ret;

	info.type = GET_FILE_FD;

	memset(&serveraddr,0,sizeof(serveraddr));
	serveraddr.sun_family = AF_UNIX;
	strcpy(serveraddr.sun_path, DRM_MASTER_MANAGER);

	ret = connect(socket_fd, (struct sockaddr *)&serveraddr, sizeof(serveraddr));
	if (ret < 0) {
		printf("fail to connect drm master\n");
		return -1;
	}

	ret = send(socket_fd, &info, sizeof(struct command_info), MSG_NOSIGNAL);
	if (ret < 0) {
		printf("fail to query drm master\n");
		return -1;
	}

	socket_msg.msg_name = NULL;
	socket_msg.msg_namelen = 0;
	iov.iov_base = buf;
	iov.iov_len = sizeof(buf);
	socket_msg.msg_iov = &iov;
	socket_msg.msg_iovlen = 1;

	socket_msg.msg_control = ctrl_data;
	socket_msg.msg_controllen = sizeof(ctrl_data);

	ret = recvmsg(socket_fd, &socket_msg, 0);
	if (ret < 0) {
		printf("fail to get drm master\n");
		return -1;
	}

	ctrl_msg = CMSG_FIRSTHDR(&socket_msg);
	shutdown(socket_fd, SHUT_RDWR);
	return *((int *)CMSG_DATA(ctrl_msg));
}

void dump_drm_info (struct kms_device *dev)
{
#define dump_resource(dev, res) dump_##res(dev)
	dump_resource(dev, encoders);
	dump_resource(dev, connectors);
	dump_resource(dev, crtcs);
	dump_resource(dev, planes);
}

void get_connectors_info(struct kms_device *dev, struct connector_info *conn_info)
{
	conn_info->conn_count = 0;

	for (int i = 0; i < dev->resources->count_connectors; i++) {
		struct connector *_connector = &dev->resources->connectors[i];
		drmModeConnector *connector = _connector->connector;
		if (!connector)
			continue;

		conn_info->conn_id[conn_info->conn_count] = connector->connector_id;
		strcpy(conn_info->name[conn_info->conn_count], _connector->name);
		conn_info->conn_count++;
		if (conn_info->conn_count >= MAX_CONNECTOR_COUNT) {
			printf("exceed max connector count:%d\n", conn_info->conn_count);
			break;
		}
    }
}

int get_connector_tv_mode_info(struct kms_device *dev, int conn_id, struct tv_mode_info *mode_info)
{
	int ret = 0;
	struct connector *_connector = NULL;
	drmModeConnector *connector = NULL;
	int found = 0;
	struct edid_info info = {0};

	for (int i = 0; i < dev->resources->count_connectors; i++) {
		_connector = &dev->resources->connectors[i];
		connector = _connector->connector;
		if (!connector)
			continue;

		if (conn_id == connector->connector_id) {
			found = 1;
			break;
		}
	}

	if (found == 0) {
		printf("can't find connector_id:%d\n", conn_id);
		return -1;
	}

	if (_connector->props) {
		for (int j = 0; j < (int)_connector->props->count_props; j++) {
			if (!strcmp(_connector->props_info[j]->name, "EDID")) {
				drmModePropertyBlobPtr blob;
				blob = drmModeGetPropertyBlob(dev->fd, _connector->props->prop_values[j]);
				memcpy(_connector->edid_data, blob->data, blob->length);
				_connector->edid_len = blob->length;
				drmModeFreePropertyBlob(blob);
			}
		}
	}

	ret = rtk_parse_edid(_connector->edid_data, _connector->edid_len, &info);
	if (ret < 0) {
		printf("can't parse edid\n");
		return -1;
	}

	struct video_data *data = &info.video;
	mode_info->tv_support_size = data->tx_support_size;

	for (int i = 0; i < data->tx_support_size; i++) {
		struct video_formats *formats = &data->tx_support[i];
		struct tv_mode_format *tv_format = &mode_info->tv_support[i];
		tv_format->vic = formats->vic;
		tv_format->rgb444 = formats->rgb444;
		tv_format->yuv422 = formats->yuv422;
		tv_format->yuv444 = formats->yuv444;
		tv_format->yuv420 = formats->yuv420;
		tv_format->_3d = formats->_3d;
		tv_format->fract_fps = formats->fract_fps;

		if (connector->count_modes) {
			for (int j = 0; j < connector->count_modes; j++) {
				drmModeModeInfo *mode = &connector->modes[j];
				char tv_mode[256] = {0};
				sprintf(tv_mode, "%dx%d@%d%s", mode->hdisplay, mode->vdisplay, (int)mode_vrefresh(mode), mode->flags & DRM_MODE_FLAG_INTERLACE ? "i": "");
				if (strncmp(tv_mode, rtk_vic_convert(tv_format->vic, 0), strlen(tv_mode)) == 0)
					tv_format->active = 1;

				if (tv_format->fract_fps) {
					memset(tv_mode, 0, 256);
					sprintf(tv_mode, "%dx%d@%.2f%s", mode->hdisplay, mode->vdisplay, mode_vrefresh(mode), mode->flags & DRM_MODE_FLAG_INTERLACE ? "i": "");
					if (strncmp(tv_mode, rtk_vic_convert(tv_format->vic, tv_format->fract_fps), strlen(tv_mode)) == 0)
						tv_format->active = 1;
				}
			}
		}
	}

	return 0;
}

void list_all_tv_mode_info(struct tv_mode_info *mode_info)
{
	char buf[2048] = {0};
	if (mode_info == NULL) {
		printf("%s mode_info is NULL\n", __func__);
		return;
	}

	sprintf(buf, "%5s%25s%15s%15s%15s%15s", "vic", "mode", "RGB444", "YUV422", "YUV444", "YUV420");
	printf("%s\n", buf);

	for (int i = 0; i < mode_info->tv_support_size; i++)
	{
		char rgb_444[64] = {0};
		char yuv_420[64] = {0};
		char yuv_444[64] = {0};
		char yuv_422[64] = {0};
		struct tv_mode_format *format = &mode_info->tv_support[i];
		rtk_color_depth_convert(format->rgb444, rgb_444);
		rtk_color_depth_convert(format->yuv422, yuv_422);
		rtk_color_depth_convert(format->yuv444, yuv_444);
		rtk_color_depth_convert(format->yuv420, yuv_420);
		if (format->active == 1) {
			printf("%5d%25s%15s%15s%15s%15s\n", format->vic, rtk_vic_convert(format->vic, 0), rgb_444, yuv_422, yuv_444, yuv_420);
			if (format->fract_fps) {
				printf("%5d%25s%15s%15s%15s%15s\n", format->vic, rtk_vic_convert(format->vic, format->fract_fps), rgb_444, yuv_422, yuv_444, yuv_420);
			}
		}
	}
}

void list_specific_tv_mode_bitmap(struct tv_mode_info *mode_info, char *tv_mode)
{
	if (mode_info == NULL) {
		printf("%s mode_info is NULL\n", __func__);
		return;
	}

	for (int i = 0; i < mode_info->tv_support_size; i++)
	{
		struct tv_mode_format *format = &mode_info->tv_support[i];
		if (strcmp(tv_mode, rtk_vic_convert(format->vic, 0)) == 0)
		{
			printf("%s --> vic:%d rgb444:0x%x yuv422:0x%x yuv444:0x%x yuv420:0x%x fract_act:%d\n", tv_mode, format->vic ,format->rgb444,
				format->yuv422, format->yuv444, format->yuv420, format->fract_fps);
		}
	
		if (format->fract_fps && strcmp(tv_mode, rtk_vic_convert(format->vic, 1)) == 0)
		{
			printf("%s --> vic:%d rgb444:0x%x yuv422:0x%x yuv444:0x%x yuv420:0x%x fract_act:%d\n", tv_mode, format->vic, format->rgb444,
				format->yuv422, format->yuv444, format->yuv420, format->fract_fps);
		}
	}
}

int set_plane_mode(struct kms_device *dev, char *vo_plane, char *mode)
{
	int ret = 0;
	struct drm_rtk_vo_plane plane = {0};
	struct rpc_config_channel_lowdelay param = {0};

	if (strcmp("V1", vo_plane) == 0)
		plane.vo_plane = VO_VIDEO_PLANE_V1;
	else if (strcmp("V2", vo_plane) == 0)
		plane.vo_plane = VO_VIDEO_PLANE_V2;
	else {
		printf("no this plane:%s\n", vo_plane);
		return -1;
	}

	ret = drmIoctl(dev->fd, DRM_IOCTL_RTK_GET_PLANE_ID, &plane);
	if (ret < 0) {
		printf("get plane:%s fail\n", vo_plane);
		return -1;
	}

	if (strcmp("low_delay_off", mode) == 0)
		param.mode = LOW_DELAY_OFF;
	else if (strcmp("low_delay_decoder", mode) == 0)
		param.mode = LOW_DELAY_DECODER;
	else if (strcmp("low_delay_display", mode) == 0)
		param.mode = LOW_DELAY_DISPLAY;
	else if (strcmp("low_delay_decoder_display", mode) == 0)
		param.mode = LOW_DELAY_DECODER_DISPLAY;
	else if (strcmp("low_delay_avsync", mode) == 0)
		param.mode = LOW_DELAY_AVSYNC;
	else if (strcmp("low_delay_decoder_avsync", mode) == 0)
		param.mode = LOW_DELAY_DECODER_AVSYNC;
	else if (strcmp("low_delay_display_order", mode) == 0)
		param.mode = LOW_DELAY_DISPLAY_ORDER;
	else {
		printf("mo this mode:%s\n", mode);
	}

	printf("set plane:%s:%d mode:%s:%d\n", vo_plane, plane.plane_id, mode, param.mode);

	param.plane_id = plane.plane_id;
	ret = drmIoctl(dev->fd, DRM_IOCTL_RTK_CONF_CHANNEL_LOWDELAY, &param);
	if (ret < 0) {
		printf("set plane:%s mode:%s fail\n", vo_plane, mode);
		return -1;
	}

	return 0;
}

int kms_device_offline_init(struct kms_device *dev)
{
	int ret = 0;
	dev->fd = drmOpen("realtek", NULL);
	if (dev->fd < 0) {
		fprintf(stderr, "no device found\n");
		ret = -1;
		goto error;
	}

	ret = drmSetClientCap(dev->fd, DRM_CLIENT_CAP_ATOMIC, 1);
	if (ret) {
		printf("no atomic modesetting support: %s\n", strerror(errno));
		ret = -1;
		goto error;
	}

	dev->resources = get_resources(dev);
	if (!dev->resources) {
		printf("fail to get drm resource\n");
		ret = -1;
		goto error;
	}

	return ret;
error:
	if (dev->fd >= 0)
		close(dev->fd);

	return ret;
}

int kms_device_init(struct kms_device *dev)
{
	int ret = 0;

	dev->fd = get_drm_master();
	if (dev->fd < 0) {
		printf("get invalid drm master fd from weston\n");
		ret = -1;
		goto error;
	}

	ret = drmSetClientCap(dev->fd, DRM_CLIENT_CAP_ATOMIC, 1);
	if (ret) {
		printf("no atomic modesetting support: %s\n", strerror(errno));
		ret = -1;
		goto error;
	}

	dev->resources = get_resources(dev);
	if (!dev->resources) {
		printf("fail to get drm resource\n");
		ret = -1;
		goto error;
	}

	return ret;
error:
	if (dev->fd >= 0)
		close(dev->fd);

	return ret;
}

void kms_device_uninit(struct kms_device *dev)
{
	if (dev->resources) {
		free_resources(dev->resources);
		dev->resources = NULL;
	}

	if (dev->fd >= 0) {
		close(dev->fd);
		dev->fd = -1;
	}
}
