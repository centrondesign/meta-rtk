#ifndef __RTK_DRM_IOCTL__
#define __RTK_DRM_IOCTL__
#include <inttypes.h>
#include <drm.h>
#define RTK_GET_PLANE_ID   0x4
#define RTK_CONF_CHANNEL_LOWDELAY 0x6
#define RTK_SET_DLSR_ENABLE 0x19

#define DRM_IOCTL_RTK_GET_PLANE_ID     DRM_IOWR( DRM_COMMAND_BASE + RTK_GET_PLANE_ID, struct drm_rtk_vo_plane)
#define DRM_IOCTL_RTK_CONF_CHANNEL_LOWDELAY     DRM_IOWR( DRM_COMMAND_BASE + RTK_CONF_CHANNEL_LOWDELAY, struct rpc_config_channel_lowdelay)
#define DRM_IOCTL_RTK_SET_DLSR_ENABLE       DRM_IOWR(DRM_COMMAND_BASE + RTK_SET_DLSR_ENABLE, uint32_t)

enum VIDEO_LOW_DELAY {
	LOW_DELAY_OFF = 0,
	LOW_DELAY_DECODER = 1,
	LOW_DELAY_DISPLAY = 2,
	LOW_DELAY_DECODER_DISPLAY = 3,
	LOW_DELAY_AVSYNC = 4,
	LOW_DELAY_DECODER_AVSYNC = 5,
	LOW_DELAY_DISPLAY_ORDER = 6,
	VO_LOW_DELAY_ERROR = 7,
};

enum VO_VIDEO_PLANE {
	VO_VIDEO_PLANE_V1,
	VO_VIDEO_PLANE_V2,
	VO_VIDEO_PLANE_SUB1,
	VO_VIDEO_PLANE_OSD1,
	VO_VIDEO_PLANE_OSD2,
	VO_VIDEO_PLANE_WIN1,
	VO_VIDEO_PLANE_WIN2,
	VO_VIDEO_PLANE_WIN3,
	VO_VIDEO_PLANE_WIN4,
	VO_VIDEO_PLANE_WIN5,
	VO_VIDEO_PLANE_WIN6,
	VO_VIDEO_PLANE_WIN7,
	VO_VIDEO_PLANE_WIN8,
	VO_VIDEO_PLANE_NONE,
};

struct drm_rtk_vo_plane {
	uint32_t plane_id;
	uint32_t vo_plane;
};

struct rpc_config_channel_lowdelay {
	enum VIDEO_LOW_DELAY mode;
	union {
		unsigned int plane_id;
		unsigned int instanceId;
	};
	unsigned int reserved[6];
};
#endif // end of __RTK_DRM_IOCTL__
