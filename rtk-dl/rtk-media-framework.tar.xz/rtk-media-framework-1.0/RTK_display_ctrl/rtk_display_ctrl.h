#ifndef __RTK_DISPLAY_CTRL__
#define __RTK_DISPLAY_CTRL__
#include <stdint.h>

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#endif

#define MAX_CONNECTOR_COUNT 10
#define MAX_STR_LEN 128
#define MAX_DRM_PROP_NAME_LEN 32
struct resources;

struct kms_device {
	int fd;
	struct resources *resources;
};

struct connector_info {
	int conn_count;
	char name[MAX_CONNECTOR_COUNT][MAX_STR_LEN];
	int conn_id[MAX_CONNECTOR_COUNT];
};

/**
 * struct tv_mode_formats - Color format and 3D support for specific VIC
 * @vic: Video ID Code
 * @rgb444: b'0-Support RGB444, b'1-RGB444/8bit, b'2-RGB444/10bit, b'3-RGB444/12bit
 * @yuv422: b'0-Support YUV422, b'1-YUV422/8bit, b'2-YUV422/10bit, b'3-YUV422/12bit
 * @yuv444: b'0-Support YUV444, b'1-YUV444/8bit, b'2-YUV444/10bit, b'3-YUV444/12bit
 * @yuv420: b'0-Support YUV420, b'1-YUV420/8bit, b'2-YUV420/10bit, b'3-YUV420/12bit
 * @_3d: b'0-Support 3D, b'1-FramePacking, b'2-TopAndBottom, b'3-SideBySideHalf
 * @fract_fps: b'0-Support fractional fps, b'1-Support 3D fractional fps
 */
struct tv_mode_format {
    unsigned char vic;
    unsigned char rgb444;
    unsigned char yuv422;
    unsigned char yuv444;
    unsigned char yuv420;
    unsigned char _3d;
    unsigned char fract_fps;
    unsigned char active;
};

/**
 * struct tv_mode_info
 * @tv_support: struct tv_mode_format
 * @tx_support_size:  Number of items in tx_support array
 */
#define MAX_TV_SUPPORT_COUNT 30
struct tv_mode_info {
    struct tv_mode_format tv_support[MAX_TV_SUPPORT_COUNT];
    unsigned int tv_support_size;
};

struct property_param {
	uint32_t obj_id;
	char name[MAX_DRM_PROP_NAME_LEN+1];
	uint64_t value;
};

struct property_info {
	int prop_count;
	int conn_id;
	int output_reset;
	struct property_param *param;
};

#ifdef __cplusplus
extern "C" {
#endif
int kms_device_init(struct kms_device *dev);
int kms_device_offline_init(struct kms_device *dev);
void kms_device_uninit(struct kms_device *dev);
void dump_drm_info(struct kms_device *dev);
void get_connectors_info(struct kms_device *dev, struct connector_info *conn_info);
int get_connector_tv_mode_info(struct kms_device *dev, int conn_id, struct tv_mode_info *mode_info);
void list_all_tv_mode_info(struct tv_mode_info *mode_info);
void list_specific_tv_mode_bitmap(struct tv_mode_info *mode_info, char *tv_mode);
int set_tv_mode(struct kms_device *dev, int conn_id, char *tv_mode);
int set_tv_property(struct kms_device *dev, struct property_info *info);
void set_vo_enable(struct kms_device *dev, int conn_id, int enable);
int set_plane_mode(struct kms_device *dev, char *vo_plane, char *mode);
void set_display_enable(struct kms_device *dev, int conn_id, int enable);
#ifdef __cplusplus
}
#endif

#endif // end of __RTK_DISPLAY_CTRL__
