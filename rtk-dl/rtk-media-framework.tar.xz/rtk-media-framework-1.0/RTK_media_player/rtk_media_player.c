#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "rtk_media_playback.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

int enable_control_thread = 0;
int enable_player_thread = 0;
int player_control_socket = -1;
pthread_mutex_t player_lock;
pthread_cond_t player_cond;

void *query_time_thread(void *data)
{
	RTK_MEDIA_PLAYBACK *playback = (RTK_MEDIA_PLAYBACK *)data;
	gint64 duration = -1;
	gint d_msec = -1;
	gint d_sec = -1;
	gint d_minutes = -1;
	gint d_hours = -1;
	while (enable_player_thread == 1) {
		if (playback->start_playing == TRUE)
		{
			if (duration == -1) {
				duration = playback_query_duration(playback)/1000000;
				d_msec = duration % 1000;
				d_sec = (duration/1000) % 60;
				d_minutes = (duration/1000)/60 % 60;
				d_hours = (duration/1000)/60/60;
			} else {
				gint64 current_position = playback_query_position(playback);
				if (current_position >= 0) {
					current_position /= 1000000;
					gint msec = current_position % 1000;
					gint sec = (current_position/1000) % 60;
					gint minutes = (current_position/1000)/60 % 60;
					gint hours = (current_position/1000)/60/60;
					printf("%02d:%02d:%02d.%03d/%02d:%02d:%02d.%03d\n", hours, minutes, sec, msec, d_hours, d_minutes, d_sec, d_msec);
				}
			}
		}
		usleep(500000);
	}
	pthread_exit(NULL);
}

void *player_start_thread(void *data)
{
	RTK_MEDIA_PLAYBACK *playback = (RTK_MEDIA_PLAYBACK *)data;
	playback = playback_start(playback, playback->file_path, "player1");
	pthread_exit(NULL);
}

void *player_control_thread(void *data)
{
	RTK_MEDIA_PLAYBACK *playback = (RTK_MEDIA_PLAYBACK *)data;
	struct sockaddr_un addr;
	struct sockaddr_un clientaddr;
	socklen_t addrlen = sizeof(clientaddr);
	int ret = -1;
	pthread_t player_thread;
	pthread_t time_thread;

	unlink(RTK_PLAYER_SOCKET_PATH);
	player_control_socket = socket(AF_UNIX,SOCK_DGRAM, 0);

	if (player_control_socket < 0) {
		printf("open socket fail\n");
		goto finish;
	}

	memset(&addr,0,sizeof(addr));
	addr.sun_family = AF_UNIX;
	strcpy(addr.sun_path, RTK_PLAYER_SOCKET_PATH);

	if (bind(player_control_socket ,(struct sockaddr*)&addr, sizeof(addr)) < 0) {
		printf("bind socket fail\n");
		goto finish;
	}

	while(enable_control_thread == 1) {
		RTK_PLAYER_CMD player_cmd = {0};
		ret = recvfrom(player_control_socket, &player_cmd, sizeof(RTK_PLAYER_CMD), 0, (struct sockaddr*)&clientaddr, &addrlen);
		if (ret < 0) {
			printf("recvfrom ret:%d\n", ret);
			continue;
		}

		switch(player_cmd.type)
		{
			case PLAYER_START:
				printf("player start:%s\n", player_cmd.str);
				memset(playback, 0, sizeof(RTK_MEDIA_PLAYBACK));
				strcpy(playback->file_path, player_cmd.str);
				enable_player_thread = 1;
				pthread_create(&player_thread, NULL, player_start_thread, playback);
				pthread_create(&time_thread, NULL, query_time_thread, playback);
				break;
			case PLAYER_STOP:
				printf("player stop\n");
				enable_player_thread = 0;
				playback_stop(playback);
				pthread_join(time_thread, NULL);
				pthread_join(player_thread, NULL);
				break;
			case PLAYER_PAUSE:
				printf("player pause\n");
				playback_pause(playback);
				break;
			case PLAYER_RESUME:
				printf("player resume\n");
				playback_resume(playback);
				break;
			case PLAYER_RATE:
				double rate = atof(player_cmd.str);
				printf("player rate:%f\n", rate);
				playback_rate(playback, rate);
				break;
			case PLAYER_SEEK:
				int seek = atoi(player_cmd.str);
				printf("player seek:%d\n", seek);
				playback_seek(playback, seek);
				break;
			case PLAYER_DUMP_DOT:
				printf("player dump dot\n");
				playback_dump_dot(playback);
				break;
			case PLAYER_SWITCH_AUDIO:
			{
				int index = atoi(player_cmd.str);
				printf("player switch audio index:%d\n", index);
				if (index >= playback->audio_count) {
					printf("index(%d) should be less than audio total count(%d)\n", index, playback->audio_count);
				} else {
					playback_switch_audio(playback, index);
				}
				break;
			}
			case PLAYER_SWITCH_SUBTITLE:
			{
				int index = atoi(player_cmd.str);
				printf("player switch subtitle index:%d\n", index);
				if (index >= playback->subtitle_count) {
					printf("index(%d) should be less than subtitle total count(%d)\n", index, playback->subtitle_count);
				} else {
					playback_switch_subtitle(playback, index);
				}
				break;
			}
			case PLAYER_EXIT:
				printf("player exit\n");
				if (enable_player_thread != 0) {
					enable_player_thread = 0;
					playback_stop(playback);
					pthread_join(time_thread, NULL);
					pthread_join(player_thread, NULL);
				}
				pthread_cond_broadcast(&player_cond);
				goto finish;
			default:
				break;
		}

		{
			int socket_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
			struct sockaddr_un serveraddr;

			memset(&serveraddr,0,sizeof(serveraddr));
			socklen_t s_addrlen = sizeof(serveraddr);
			serveraddr.sun_family = AF_UNIX;
			strcpy(serveraddr.sun_path, RTK_PLAYER_REPLY_SOCKET_PATH);
			char reply[128] = {0};
			strcpy(reply, "OK");
			sendto(socket_fd, reply, 128, MSG_NOSIGNAL, (struct sockaddr*)&serveraddr, s_addrlen);
		}
	}

finish:
	if (player_control_socket >= 0) {
		shutdown(player_control_socket, SHUT_RDWR);
		player_control_socket = -1;
	}

	pthread_exit(NULL);
}

int main(int argc, char **argv)
{
	pthread_t player_control;

	pthread_mutex_init(&player_lock, NULL);
	pthread_cond_init(&player_cond, NULL);

	enable_control_thread = 1;
	RTK_MEDIA_PLAYBACK *playback = (RTK_MEDIA_PLAYBACK *)malloc(sizeof(RTK_MEDIA_PLAYBACK));
	pthread_create(&player_control, NULL, player_control_thread, playback);

	pthread_mutex_lock(&player_lock);
	pthread_cond_wait(&player_cond, &player_lock);
	pthread_mutex_unlock(&player_lock);

	enable_control_thread = 0;
	if (player_control_socket >= 0) {
		shutdown(player_control_socket, SHUT_RDWR);
		player_control_socket = -1;
	}
	pthread_join(player_control, NULL);

	pthread_mutex_destroy(&player_lock);
	pthread_cond_destroy(&player_cond);
	free(playback);
}

