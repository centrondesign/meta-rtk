#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rtk_media_playback.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

static char optstr[] = "c:s:";

int main(int argc, char **argv)
{
	char *cmd = NULL;
	char *str = NULL;
	int c = 0;
	RTK_PLAYER_CMD player_cmd = {0};

	opterr = 0;
	while ((c = getopt(argc, argv, optstr)) != -1) {
		switch (c) {
			case 'c':
				cmd = (char *)malloc(128);
				strcpy(cmd, optarg);
				break;
			case 's':
				str = (char *)malloc(512);
				strcpy(str, optarg);
				break;
			default:
				break;
		}
	}

	if (cmd == NULL)
		return -1;

	if (!strcmp(cmd, "start")) {
		player_cmd.type = PLAYER_START;
		if (str == NULL) {
			printf("no carry file path\n");
			goto finish;
		}

		strcpy(player_cmd.str, str);
	} else if (!strcmp(cmd, "stop")) {
		player_cmd.type = PLAYER_STOP;
	} else if (!strcmp(cmd, "exit")) {
		player_cmd.type = PLAYER_EXIT;
	} else if (!strcmp(cmd, "pause")) {
		player_cmd.type = PLAYER_PAUSE;
	} else if (!strcmp(cmd, "resume")) {
		player_cmd.type = PLAYER_RESUME;
	} else if (!strcmp(cmd, "rate")) {
		player_cmd.type = PLAYER_RATE;

		if (str == NULL) {
			printf("no carry rate info\n");
			goto finish;
		}

		strcpy(player_cmd.str, str);
	} else if (!strcmp(cmd, "seek")) {
		player_cmd.type = PLAYER_SEEK;

		if (str == NULL) {
			printf("no carry seek info\n");
			goto finish;
		}

		strcpy(player_cmd.str, str);
	} else if (!strcmp(cmd, "dumpdot")) {
		player_cmd.type = PLAYER_DUMP_DOT;
	} else if (!strcmp(cmd, "switchaudio")) {
		player_cmd.type = PLAYER_SWITCH_AUDIO;
		if (str == NULL) {
			printf("no carry audio index\n");
			goto finish;
		}

		strcpy(player_cmd.str, str);
	} else if (!strcmp(cmd, "switchsubtitle")) {
		player_cmd.type = PLAYER_SWITCH_SUBTITLE;
		if (str == NULL) {
			printf("no carry subtitle index\n");
			goto finish;
		}

		strcpy(player_cmd.str, str);
	} else {
		goto finish;
	}

	int socket_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
	struct sockaddr_un serveraddr;

	memset(&serveraddr,0,sizeof(serveraddr));
	socklen_t s_addrlen = sizeof(serveraddr);
	serveraddr.sun_family = AF_UNIX;
	strcpy(serveraddr.sun_path, RTK_PLAYER_SOCKET_PATH);
	sendto(socket_fd, &player_cmd, sizeof(RTK_PLAYER_CMD), MSG_NOSIGNAL, (struct sockaddr*)&serveraddr,s_addrlen);
	shutdown(socket_fd, SHUT_RDWR);

// recv finish command
	if (strcmp(cmd, "exit"))
	{
		struct sockaddr_un addr;
		struct sockaddr_un clientaddr;
		socklen_t addrlen = sizeof(clientaddr);

		unlink(RTK_PLAYER_REPLY_SOCKET_PATH);
		memset(&addr,0,sizeof(addr));
		addr.sun_family = AF_UNIX;
		strcpy(addr.sun_path, RTK_PLAYER_REPLY_SOCKET_PATH);

		socket_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
		bind(socket_fd ,(struct sockaddr*)&addr, sizeof(addr));
		char reply[128] = {0};
		recvfrom(socket_fd, reply, 128, 0, (struct sockaddr*)&clientaddr, &addrlen);
		if (!strcmp(reply, "OK"))
			printf("reply OK\n");
		shutdown(socket_fd, SHUT_RDWR);
	}
finish:
	if (cmd)
		free(cmd);

	if (str)
		free(str);

	return 0;
}
