#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gst/video/gstvideometa.h>

#include "gstrtkassrender.h"
#include <gstrtkdmaallocator.h>
#include <gstrtksubtitlepool.h>
#include <string.h>

GST_DEBUG_CATEGORY_STATIC (gst_rtkass_render_debug);
GST_DEBUG_CATEGORY_STATIC (gst_rtkass_render_lib_debug);
#define GST_CAT_DEFAULT gst_rtkass_render_debug
#define DEFAULT_PROP_SILENT FALSE
#define DEFAULT_PROP_USECMA FALSE
/* Filter signals and props */
enum
{
  LAST_SIGNAL
};

enum
{
  PROP_0,
  PROP_ENABLE,
  PROP_EMBEDDEDFONTS,
  PROP_CLEAR,
  PROP_SILENT,
  PROP_USECMA,
  PROP_WAIT_TEXT
};

/* FIXME: video-blend.c doesn't support formats with more than 8 bit per
 * component (which get unpacked into ARGB64 or AYUV64) yet, such as:
 *  v210, v216, UYVP, GRAY16_LE, GRAY16_BE */
#define FORMATS "{ BGRx, RGBx, xRGB, xBGR, RGBA, BGRA, ARGB, ABGR, RGB, BGR, \
    I420, YV12, AYUV, YUY2, UYVY, v308, Y41B, Y42B, Y444, \
    NV12, NV21, A420, YUV9, YVU9, IYU1, GRAY8 }"

#define RTKASSRENDER_CAPS GST_VIDEO_CAPS_MAKE(FORMATS)

#define RTKASSRENDER_ALL_CAPS RTKASSRENDER_CAPS ";" \
    GST_VIDEO_CAPS_MAKE_WITH_FEATURES ("ANY", GST_VIDEO_FORMATS_ALL)

static GstStaticCaps sw_template_caps = GST_STATIC_CAPS (RTKASSRENDER_CAPS);

static GstStaticPadTemplate video_src_factory = GST_STATIC_PAD_TEMPLATE ("video_src",
    GST_PAD_SRC,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS (RTKASSRENDER_ALL_CAPS)
    );

static GstStaticPadTemplate text_src_factory = GST_STATIC_PAD_TEMPLATE ("text_src",
    GST_PAD_SRC,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS (RTKASSRENDER_ALL_CAPS)
    );

static GstStaticPadTemplate video_sink_factory =
GST_STATIC_PAD_TEMPLATE ("video_sink",
    GST_PAD_SINK,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS (RTKASSRENDER_ALL_CAPS)
    );

static GstStaticPadTemplate text_sink_factory =
    GST_STATIC_PAD_TEMPLATE ("text_sink",
    GST_PAD_SINK,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS ("application/x-ass; application/x-ssa")
    );

#define GST_RTKASS_RENDER_GET_LOCK(rtkass) (&GST_RTKASS_RENDER (rtkass)->lock)
#define GST_RTKASS_RENDER_GET_COND(rtkass) (&GST_RTKASS_RENDER (rtkass)->cond)
#define GST_RTKASS_RENDER_LOCK(rtkass)     (g_mutex_lock (GST_RTKASS_RENDER_GET_LOCK (rtkass)))
#define GST_RTKASS_RENDER_UNLOCK(rtkass)   (g_mutex_unlock (GST_RTKASS_RENDER_GET_LOCK (rtkass)))
#define GST_RTKASS_RENDER_WAIT(rtkass)     (g_cond_wait (GST_RTKASS_RENDER_GET_COND (rtkass), GST_RTKASS_RENDER_GET_LOCK (rtkass)))
#define GST_RTKASS_RENDER_SIGNAL(rtkass)   (g_cond_signal (GST_RTKASS_RENDER_GET_COND (rtkass)))
#define GST_RTKASS_RENDER_BROADCAST(rtkass)(g_cond_broadcast (GST_RTKASS_RENDER_GET_COND (rtkass)))

static void gst_rtkass_render_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec);
static void gst_rtkass_render_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec);

static void gst_rtkass_render_finalize (GObject * object);

static GstStateChangeReturn gst_rtkass_render_change_state (GstElement * element,
    GstStateChange transition);

#define gst_rtkass_render_parent_class parent_class
G_DEFINE_TYPE (GstRtkAssRender, gst_rtkass_render, GST_TYPE_ELEMENT);
#define _do_init \
  GST_DEBUG_CATEGORY_INIT (gst_rtkass_render_debug, "rtkassrender", \
      0, "RTKASS/SSA subtitle renderer");\
  GST_DEBUG_CATEGORY_INIT (gst_rtkass_render_lib_debug, "rtkassrender_library",\
      0, "RTKASS/SSA subtitle renderer library");
GST_ELEMENT_REGISTER_DEFINE_WITH_CODE (rtkassrender, "rtkassrender",
    GST_RANK_PRIMARY, GST_TYPE_RTKASS_RENDER, _do_init);

static GstCaps *gst_rtkass_render_get_videosink_caps (GstPad * pad,
    GstRtkAssRender * render, GstCaps * filter);
static GstCaps *gst_rtkass_render_get_video_src_caps (GstPad * pad,
    GstRtkAssRender * render, GstCaps * filter);

static gboolean gst_rtkass_render_setcaps_video (GstPad * pad,
    GstRtkAssRender * render, GstCaps * caps);
static gboolean gst_rtkass_render_setcaps_text (GstPad * pad,
    GstRtkAssRender * render, GstCaps * caps);

static GstFlowReturn gst_rtkass_render_chain_video (GstPad * pad,
    GstObject * parent, GstBuffer * buf);
static GstFlowReturn gst_rtkass_render_chain_text (GstPad * pad,
    GstObject * parent, GstBuffer * buf);

static gboolean gst_rtkass_render_event_video (GstPad * pad, GstObject * parent,
    GstEvent * event);
static gboolean gst_rtkass_render_event_text (GstPad * pad, GstObject * parent,
    GstEvent * event);
static gboolean gst_rtkass_render_event_video_src (GstPad * pad, GstObject * parent,
    GstEvent * event);
static gboolean gst_rtkass_render_event_text_src (GstPad * pad, GstObject * parent,
    GstEvent * event);

static gboolean gst_rtkass_render_query_video (GstPad * pad, GstObject * parent,
    GstQuery * query);
static gboolean gst_rtkass_render_query_video_src (GstPad * pad, GstObject * parent,
    GstQuery * query);
static gboolean gst_rtkass_render_query_text_src (GstPad * pad, GstObject * parent,
    GstQuery * query);

/* initialize the plugin's class */
static void
gst_rtkass_render_class_init (GstRtkAssRenderClass * klass)
{
  GObjectClass *gobject_class = (GObjectClass *) klass;
  GstElementClass *gstelement_class = (GstElementClass *) klass;

  gobject_class->set_property = gst_rtkass_render_set_property;
  gobject_class->get_property = gst_rtkass_render_get_property;
  gobject_class->finalize = gst_rtkass_render_finalize;

  g_object_class_install_property (gobject_class, PROP_ENABLE,
      g_param_spec_boolean ("enable", "Enable",
          "Enable rendering of subtitles", TRUE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_CLEAR,
      g_param_spec_boolean ("clear", "Clear",
          "Clear rendering of subtitles", FALSE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_SILENT,
      g_param_spec_boolean ("silent", "Silent",
          "Silent rendering of subtitles", FALSE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_USECMA,
      g_param_spec_boolean ("usecma", "Usecma",
          "Use cma for subtitle buffer", FALSE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_EMBEDDEDFONTS,
      g_param_spec_boolean ("embeddedfonts", "Embedded Fonts",
          "Extract and use fonts embedded in the stream", TRUE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_WAIT_TEXT,
      g_param_spec_boolean ("wait-text", "Wait Text",
          "Whether to wait for subtitles", TRUE,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  gstelement_class->change_state =
      GST_DEBUG_FUNCPTR (gst_rtkass_render_change_state);

  gst_element_class_add_static_pad_template (gstelement_class, &video_src_factory);
  gst_element_class_add_static_pad_template (gstelement_class, &text_src_factory);

  gst_element_class_add_static_pad_template (gstelement_class,
      &video_sink_factory);
  gst_element_class_add_static_pad_template (gstelement_class,
      &text_sink_factory);

  gst_element_class_set_static_metadata (gstelement_class, "RTKASS/SSA Render",
      "Mixer/Video/Overlay/Subtitle",
      "Renders RTKASS/SSA subtitles with librtkass",
      "Benjamin Schmitz <vortex@wolpzone.de>, "
      "Sebastian Dröge <sebastian.droege@collabora.co.uk>");
}

static void
_librtkass_message_cb (gint level, const gchar * fmt, va_list args,
    gpointer render)
{
  gchar *message = g_strdup_vprintf (fmt, args);

  if (level < 2)
    GST_CAT_ERROR_OBJECT (gst_rtkass_render_lib_debug, render, "%s", message);
  else if (level < 4)
    GST_CAT_WARNING_OBJECT (gst_rtkass_render_lib_debug, render, "%s", message);
  else if (level < 5)
    GST_CAT_INFO_OBJECT (gst_rtkass_render_lib_debug, render, "%s", message);
  else if (level < 6)
    GST_CAT_DEBUG_OBJECT (gst_rtkass_render_lib_debug, render, "%s", message);
  else
    GST_CAT_LOG_OBJECT (gst_rtkass_render_lib_debug, render, "%s", message);

  g_free (message);
}

static void
gst_rtkass_render_init (GstRtkAssRender * render)
{
  GST_DEBUG_OBJECT (render, "init");

  render->video_srcpad = gst_pad_new_from_static_template (&video_src_factory, "video_src");
  render->text_srcpad = gst_pad_new_from_static_template (&text_src_factory, "text_src");

  render->video_sinkpad =
      gst_pad_new_from_static_template (&video_sink_factory, "video_sink");
  render->text_sinkpad =
      gst_pad_new_from_static_template (&text_sink_factory, "text_sink");

  gst_pad_set_chain_function (render->video_sinkpad,
      GST_DEBUG_FUNCPTR (gst_rtkass_render_chain_video));
  gst_pad_set_chain_function (render->text_sinkpad,
      GST_DEBUG_FUNCPTR (gst_rtkass_render_chain_text));

  gst_pad_set_event_function (render->video_sinkpad,
      GST_DEBUG_FUNCPTR (gst_rtkass_render_event_video));
  gst_pad_set_event_function (render->text_sinkpad,
      GST_DEBUG_FUNCPTR (gst_rtkass_render_event_text));
  gst_pad_set_event_function (render->video_srcpad,
      GST_DEBUG_FUNCPTR (gst_rtkass_render_event_video_src));
  gst_pad_set_event_function (render->text_srcpad,
      GST_DEBUG_FUNCPTR (gst_rtkass_render_event_text_src));

  gst_pad_set_query_function (render->video_srcpad,
      GST_DEBUG_FUNCPTR (gst_rtkass_render_query_video_src));
  gst_pad_set_query_function (render->text_srcpad,
      GST_DEBUG_FUNCPTR (gst_rtkass_render_query_text_src));
  gst_pad_set_query_function (render->video_sinkpad,
      GST_DEBUG_FUNCPTR (gst_rtkass_render_query_video));

  GST_PAD_SET_PROXY_ALLOCATION (render->video_sinkpad);

  gst_element_add_pad (GST_ELEMENT (render), render->video_srcpad);
  gst_element_add_pad (GST_ELEMENT (render), render->text_srcpad);
  gst_element_add_pad (GST_ELEMENT (render), render->video_sinkpad);
  gst_element_add_pad (GST_ELEMENT (render), render->text_sinkpad);

  gst_video_info_init (&render->info);

  g_mutex_init (&render->lock);
  g_cond_init (&render->cond);

  render->renderer_init_ok = FALSE;
  render->track_init_ok = FALSE;
  render->enable = TRUE;
  render->embeddedfonts = TRUE;
  render->wait_text = FALSE;

  gst_segment_init (&render->video_segment, GST_FORMAT_TIME);
  gst_segment_init (&render->subtitle_segment, GST_FORMAT_TIME);

  g_mutex_init (&render->rtkass_mutex);
  render->rtkass_library = ass_library_init ();
  ass_set_message_cb (render->rtkass_library, _librtkass_message_cb, render);
  ass_set_extract_fonts (render->rtkass_library, 1);

  render->rtkass_renderer = ass_renderer_init (render->rtkass_library);
  if (!render->rtkass_renderer) {
    GST_WARNING_OBJECT (render, "cannot create renderer instance");
    g_assert_not_reached ();
  }

  render->rtkass_track = NULL;

  GstVideoInfo info;

  gst_video_info_set_format(&info, GST_VIDEO_FORMAT_BGRA, SOLID_WIDTH, SOLID_HEIGHT);
  render->text_caps  = gst_video_info_to_caps(&info);
  render->text_pool = gst_rtk_subtitle_pool_new();
  render->silent = DEFAULT_PROP_SILENT;
  render->usecma = DEFAULT_PROP_USECMA;
  render->preload_gap = 0;
  render->last_text_timestamp = GST_CLOCK_TIME_NONE;
  render->last_video_timestamp = GST_CLOCK_TIME_NONE;
  render->last_video_duration = GST_CLOCK_TIME_NONE;

  GST_DEBUG_OBJECT (render, "init complete");
}

static void
gst_rtkass_render_finalize (GObject * object)
{
  GstRtkAssRender *render = GST_RTKASS_RENDER (object);

  g_mutex_clear (&render->lock);
  g_cond_clear (&render->cond);

  if (render->rtkass_track) {
    ass_free_track (render->rtkass_track);
  }

  if (render->rtkass_renderer) {
    ass_renderer_done (render->rtkass_renderer);
  }

  if (render->rtkass_library) {
    ass_library_done (render->rtkass_library);
  }

  if (render->text_caps) {
    gst_caps_unref(render->text_caps);
    render->text_caps = NULL;
  }

  if (render->text_pool) {
    g_object_unref(render->text_pool);
    render->text_pool = NULL;
  }

  g_mutex_clear (&render->rtkass_mutex);

  G_OBJECT_CLASS (parent_class)->finalize (object);
}

static void
gst_rtkass_render_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec)
{
  GstRtkAssRender *render = GST_RTKASS_RENDER (object);
  GstFlowReturn ret = GST_FLOW_OK;

  GST_RTKASS_RENDER_LOCK (render);
  switch (prop_id) {
    case PROP_ENABLE:
      render->enable = g_value_get_boolean (value);
      break;
    case PROP_EMBEDDEDFONTS:
      render->embeddedfonts = g_value_get_boolean (value);
      g_mutex_lock (&render->rtkass_mutex);
      ass_set_extract_fonts (render->rtkass_library, render->embeddedfonts);
      g_mutex_unlock (&render->rtkass_mutex);
      break;
    case PROP_WAIT_TEXT:
      render->wait_text = g_value_get_boolean (value);
      break;
    case PROP_CLEAR:
      GstBuffer *clear_buffer;
      ret = gst_buffer_pool_acquire_buffer (render->text_pool, &clear_buffer, NULL);
      if (ret == GST_FLOW_OK) {
        GST_BUFFER_TIMESTAMP(clear_buffer) = render->last_text_timestamp;
        GST_BUFFER_DURATION(clear_buffer) = GST_CLOCK_TIME_NONE;
        gst_pad_push (render->text_srcpad, clear_buffer);
      }
      break;
    case PROP_SILENT:
      render->silent = g_value_get_boolean (value);
      if (render->silent == TRUE) {
        gst_buffer_pool_set_active (render->text_pool, FALSE);
        gst_rtk_subtitle_pool_reset_pool(render->text_pool);
      } else
        gst_buffer_pool_set_active (render->text_pool, TRUE);

      break;
    case PROP_USECMA:
      render->usecma = g_value_get_boolean (value);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
  GST_RTKASS_RENDER_UNLOCK (render);
}

static void
gst_rtkass_render_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec)
{
  GstRtkAssRender *render = GST_RTKASS_RENDER (object);

  GST_RTKASS_RENDER_LOCK (render);
  switch (prop_id) {
    case PROP_ENABLE:
      g_value_set_boolean (value, render->enable);
      break;
    case PROP_EMBEDDEDFONTS:
      g_value_set_boolean (value, render->embeddedfonts);
      break;
    case PROP_WAIT_TEXT:
      g_value_set_boolean (value, render->wait_text);
      break;
    case PROP_CLEAR:
    case PROP_SILENT:
    case PROP_USECMA:
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
  GST_RTKASS_RENDER_UNLOCK (render);
}

/* Called with lock held */
static void
gst_rtkass_render_pop_text (GstRtkAssRender * render)
{
  while (render->subtitle_pending) {
    GST_DEBUG_OBJECT (render, "releasing text buffer %p",
        render->subtitle_pending->data);
    gst_buffer_unref (render->subtitle_pending->data);
    render->subtitle_pending =
        g_slist_delete_link (render->subtitle_pending,
        render->subtitle_pending);
  }

  /* Let the text task know we used that buffer */
  GST_RTKASS_RENDER_BROADCAST (render);
}

static GstStateChangeReturn
gst_rtkass_render_change_state (GstElement * element, GstStateChange transition)
{
  GstRtkAssRender *render = GST_RTKASS_RENDER (element);
  GstStateChangeReturn ret;

  switch (transition) {
    case GST_STATE_CHANGE_PAUSED_TO_READY:
      GST_RTKASS_RENDER_LOCK (render);
      render->subtitle_flushing = TRUE;
      render->video_flushing = TRUE;
      gst_rtkass_render_pop_text (render);
      GST_RTKASS_RENDER_UNLOCK (render);
      break;
    case GST_STATE_CHANGE_PLAYING_TO_PAUSED:
    case GST_STATE_CHANGE_PAUSED_TO_PLAYING:
      if (!render->usecma) {
        render->preload_gap = 0;
        GstEvent *event = gst_event_new_gap(render->last_video_timestamp, render->last_video_duration);
        gst_pad_push_event(render->text_srcpad, event);
      }
      break;
    default:
      break;
  }

  ret = GST_ELEMENT_CLASS (parent_class)->change_state (element, transition);
  if (ret == GST_STATE_CHANGE_FAILURE)
    return ret;

  switch (transition) {
    case GST_STATE_CHANGE_PAUSED_TO_READY:
      g_mutex_lock (&render->rtkass_mutex);
      if (render->rtkass_track)
        ass_free_track (render->rtkass_track);
      render->rtkass_track = NULL;
      render->track_init_ok = FALSE;
      render->renderer_init_ok = FALSE;
      g_mutex_unlock (&render->rtkass_mutex);
      break;
    case GST_STATE_CHANGE_READY_TO_PAUSED:
      GST_RTKASS_RENDER_LOCK (render);
      render->subtitle_flushing = FALSE;
      render->video_flushing = FALSE;
      render->video_eos = FALSE;
      render->subtitle_eos = FALSE;
      gst_segment_init (&render->video_segment, GST_FORMAT_TIME);
      gst_segment_init (&render->subtitle_segment, GST_FORMAT_TIME);
      GST_RTKASS_RENDER_UNLOCK (render);
      break;
    default:
      break;
  }


  return ret;
}

static gboolean
gst_rtkass_render_query_video_src (GstPad * pad, GstObject * parent, GstQuery * query)
{
  gboolean res = FALSE;

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_CAPS:
    {
      GstCaps *filter, *caps;

      gst_query_parse_caps (query, &filter);
      caps = gst_rtkass_render_get_video_src_caps (pad, (GstRtkAssRender *) parent, filter);
      gst_query_set_caps_result (query, caps);
      gst_caps_unref (caps);
      res = TRUE;
      break;
    }
    default:
      res = gst_pad_query_default (pad, parent, query);
      break;
  }

  return res;
}

static gboolean
gst_rtkass_render_query_text_src (GstPad * pad, GstObject * parent, GstQuery * query)
{
  gboolean res = FALSE;
  GstRtkAssRender *render = GST_RTKASS_RENDER (parent);

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_CAPS:
    {
      gst_query_set_caps_result (query, render->text_caps);
      res = TRUE;
      break;
    }
    default:
      res = gst_pad_query_default (pad, parent, query);
      break;
  }

  return res;
}

static gboolean
gst_rtkass_render_event_video_src (GstPad * pad, GstObject * parent, GstEvent * event)
{
  GstRtkAssRender *render = GST_RTKASS_RENDER (parent);
  gboolean ret;

  GST_DEBUG_OBJECT (render, "received src event %" GST_PTR_FORMAT, event);

  /* FIXME: why not just always push it on text pad? */
  if (render->track_init_ok) {
    ret = gst_pad_push_event (render->video_sinkpad, gst_event_ref (event));
  } else {
    ret = gst_pad_push_event (render->video_sinkpad, event);
  }

  return ret;
}

static gboolean
gst_rtkass_render_event_text_src (GstPad * pad, GstObject * parent, GstEvent * event)
{
  GstRtkAssRender *render = GST_RTKASS_RENDER (parent);
  gboolean ret = FALSE;

  GST_DEBUG_OBJECT (render, "received src event %" GST_PTR_FORMAT, event);

  /* FIXME: why not just always push it on text pad? */
  if (render->track_init_ok) {
    ret = gst_pad_push_event (render->text_sinkpad, event);
  } 

  return ret;
}

/**
 * gst_rtkass_render_add_feature_and_intersect:
 *
 * Creates a new #GstCaps containing the (given caps +
 * given caps feature) + (given caps intersected by the
 * given filter).
 *
 * Returns: the new #GstCaps
 */
static GstCaps *
gst_rtkass_render_add_feature_and_intersect (GstCaps * caps,
    const gchar * feature, GstCaps * filter)
{
  int i, caps_size;
  GstCaps *new_caps;

  new_caps = gst_caps_copy (caps);

  caps_size = gst_caps_get_size (new_caps);
  for (i = 0; i < caps_size; i++) {
    GstCapsFeatures *features = gst_caps_get_features (new_caps, i);
    if (!gst_caps_features_is_any (features)) {
      gst_caps_features_add (features, feature);
    }
  }

  gst_caps_append (new_caps, gst_caps_intersect_full (caps,
          filter, GST_CAPS_INTERSECT_FIRST));

  return new_caps;
}

/**
 * gst_rtkass_render_intersect_by_feature:
 *
 * Creates a new #GstCaps based on the following filtering rule.
 *
 * For each individual caps contained in given caps, if the
 * caps uses the given caps feature, keep a version of the caps
 * with the feature and an another one without. Otherwise, intersect
 * the caps with the given filter.
 *
 * Returns: the new #GstCaps
 */
static GstCaps *
gst_rtkass_render_intersect_by_feature (GstCaps * caps,
    const gchar * feature, GstCaps * filter)
{
  int i, caps_size;
  GstCaps *new_caps;

  new_caps = gst_caps_new_empty ();

  caps_size = gst_caps_get_size (caps);
  for (i = 0; i < caps_size; i++) {
    GstStructure *caps_structure = gst_caps_get_structure (caps, i);
    GstCapsFeatures *caps_features =
        gst_caps_features_copy (gst_caps_get_features (caps, i));
    GstCaps *filtered_caps;
    GstCaps *simple_caps =
        gst_caps_new_full (gst_structure_copy (caps_structure), NULL);
    gst_caps_set_features (simple_caps, 0, caps_features);

    if (gst_caps_features_contains (caps_features, feature)) {
      gst_caps_append (new_caps, gst_caps_copy (simple_caps));

      gst_caps_features_remove (caps_features, feature);
      filtered_caps = gst_caps_ref (simple_caps);
    } else {
      filtered_caps = gst_caps_intersect_full (simple_caps, filter,
          GST_CAPS_INTERSECT_FIRST);
    }

    gst_caps_unref (simple_caps);
    gst_caps_append (new_caps, filtered_caps);
  }

  return new_caps;
}

static GstCaps *
gst_rtkass_render_get_videosink_caps (GstPad * pad, GstRtkAssRender * render,
    GstCaps * filter)
{
  GstPad *video_srcpad = render->video_srcpad;
  GstCaps *peer_caps = NULL, *caps = NULL, *rtkassrender_filter = NULL;

  if (filter) {
    /* filter caps + composition feature + filter caps
     * filtered by the software caps. */
    GstCaps *sw_caps = gst_static_caps_get (&sw_template_caps);
    rtkassrender_filter = gst_rtkass_render_add_feature_and_intersect (filter,
        GST_CAPS_FEATURE_META_GST_VIDEO_OVERLAY_COMPOSITION, sw_caps);
    gst_caps_unref (sw_caps);

    GST_DEBUG_OBJECT (render, "rtkassrender filter %" GST_PTR_FORMAT,
        rtkassrender_filter);
  }

  peer_caps = gst_pad_peer_query_caps (video_srcpad, rtkassrender_filter);

  if (rtkassrender_filter)
    gst_caps_unref (rtkassrender_filter);

  if (peer_caps) {

    GST_DEBUG_OBJECT (pad, "peer caps  %" GST_PTR_FORMAT, peer_caps);

    if (gst_caps_is_any (peer_caps)) {

      /* if peer returns ANY caps, return filtered src pad template caps */
      caps = gst_caps_copy (gst_pad_get_pad_template_caps (video_srcpad));
    } else {

      /* duplicate caps which contains the composition into one version with
       * the meta and one without. Filter the other caps by the software caps */
      GstCaps *sw_caps = gst_static_caps_get (&sw_template_caps);
      caps = gst_rtkass_render_intersect_by_feature (peer_caps,
          GST_CAPS_FEATURE_META_GST_VIDEO_OVERLAY_COMPOSITION, sw_caps);
      gst_caps_unref (sw_caps);
    }

    gst_caps_unref (peer_caps);

  } else {
    /* no peer, our padtemplate is enough then */
    caps = gst_pad_get_pad_template_caps (pad);
  }

  if (filter) {
    GstCaps *intersection = gst_caps_intersect_full (filter, caps,
        GST_CAPS_INTERSECT_FIRST);
    gst_caps_unref (caps);
    caps = intersection;
  }

  GST_DEBUG_OBJECT (render, "returning  %" GST_PTR_FORMAT, caps);

  return caps;
}

static GstCaps *
gst_rtkass_render_get_video_src_caps (GstPad * pad, GstRtkAssRender * render,
    GstCaps * filter)
{
  GstPad *sinkpad = render->video_sinkpad;
  GstCaps *peer_caps = NULL, *caps = NULL, *rtkassrender_filter = NULL;

  if (filter) {
    /* duplicate filter caps which contains the composition into one version
     * with the meta and one without. Filter the other caps by the software
     * caps */
    GstCaps *sw_caps = gst_static_caps_get (&sw_template_caps);
    rtkassrender_filter =
        gst_rtkass_render_intersect_by_feature (filter,
        GST_CAPS_FEATURE_META_GST_VIDEO_OVERLAY_COMPOSITION, sw_caps);
    gst_caps_unref (sw_caps);
  }

  peer_caps = gst_pad_peer_query_caps (sinkpad, rtkassrender_filter);

  if (rtkassrender_filter)
    gst_caps_unref (rtkassrender_filter);

  if (peer_caps) {

    GST_DEBUG_OBJECT (pad, "peer caps  %" GST_PTR_FORMAT, peer_caps);

    if (gst_caps_is_any (peer_caps)) {

      /* if peer returns ANY caps, return filtered sink pad template caps */
      caps = gst_caps_copy (gst_pad_get_pad_template_caps (sinkpad));

    } else {

      /* return upstream caps + composition feature + upstream caps
       * filtered by the software caps. */
      GstCaps *sw_caps = gst_static_caps_get (&sw_template_caps);
      caps = gst_rtkass_render_add_feature_and_intersect (peer_caps,
          GST_CAPS_FEATURE_META_GST_VIDEO_OVERLAY_COMPOSITION, sw_caps);
      gst_caps_unref (sw_caps);
    }

    gst_caps_unref (peer_caps);

  } else {
    /* no peer, our padtemplate is enough then */
    caps = gst_pad_get_pad_template_caps (pad);
  }

  if (filter) {
    GstCaps *intersection;

    intersection =
        gst_caps_intersect_full (filter, caps, GST_CAPS_INTERSECT_FIRST);
    gst_caps_unref (caps);
    caps = intersection;
  }

  GST_DEBUG_OBJECT (render, "returning  %" GST_PTR_FORMAT, caps);

  return caps;
}

static void
blit_bgra_premultiplied (GstRtkAssRender * render, ASS_Image * rtkass_image,
    guint8 * data, gint width, gint height, gint stride, gint x_off, gint y_off)
{
  guint counter = 0;
  gint alpha, r, g, b, k;
  const guint8 *src;
  guint8 *dst;
  gint x, y, w, h;
  gint dst_skip;
  gint src_skip;
  gint dst_x, dst_y;

  //memset (data, 0, stride * height);

  while (rtkass_image) {
    dst_x = rtkass_image->dst_x + x_off;
    dst_y = rtkass_image->dst_y + y_off;

    w = MIN (rtkass_image->w, width - dst_x);
    h = MIN (rtkass_image->h, height - dst_y);
    if (w <= 0 || h <= 0)
      goto next;

    alpha = 255 - (rtkass_image->color & 0xff);
    if (!alpha)
      goto next;

    r = ((rtkass_image->color) >> 24) & 0xff;
    g = ((rtkass_image->color) >> 16) & 0xff;
    b = ((rtkass_image->color) >> 8) & 0xff;

    src = rtkass_image->bitmap;
    dst = data + rtkass_image->dst_y * stride + rtkass_image->dst_x * 4;

    src_skip = rtkass_image->stride - w;
    dst_skip = stride - w * 4;

    for (y = 0; y < h; y++) {
      for (x = 0; x < w; x++) {
        if (src[0]) {
          k = src[0] * alpha / 255;
          if (dst[3] == 0) {
            dst[3] = k;
            dst[2] = (k * r) / 255;
            dst[1] = (k * g) / 255;
            dst[0] = (k * b) / 255;
          } else {
            dst[3] = k + (255 - k) * dst[3] / 255;
            dst[2] = (k * r + (255 - k) * dst[2]) / 255;
            dst[1] = (k * g + (255 - k) * dst[1]) / 255;
            dst[0] = (k * b + (255 - k) * dst[0]) / 255;
          }
        }
        src++;
        dst += 4;
      }
      src += src_skip;
      dst += dst_skip;
    }
  next:
    counter++;
    rtkass_image = rtkass_image->next;
  }
  GST_LOG_OBJECT (render, "amount of rendered rtkass_image: %u", counter);
}

static gboolean
gst_rtkass_render_can_handle_caps (GstCaps * incaps)
{
  static GstStaticCaps static_caps = GST_STATIC_CAPS (RTKASSRENDER_CAPS);
  gboolean ret;
  GstCaps *caps;

  caps = gst_static_caps_get (&static_caps);
  ret = gst_caps_is_subset (incaps, caps);
  gst_caps_unref (caps);

  return ret;
}

static void
gst_rtkass_render_update_render_size (GstRtkAssRender * render)
{
  gdouble video_aspect = (gdouble) render->info.width /
      (gdouble) render->info.height;
  gdouble window_aspect = (gdouble) render->window_width /
      (gdouble) render->window_height;

  /* render at the window size, with the video aspect ratio */
  if (video_aspect >= window_aspect) {
    render->rtkass_frame_width = render->window_width;
    render->rtkass_frame_height = render->window_width / video_aspect;
  } else {
    render->rtkass_frame_width = render->window_height * video_aspect;
    render->rtkass_frame_height = render->window_height;
  }
}

static gboolean
gst_rtkass_render_video_src_negotiate (GstRtkAssRender * render, GstCaps * caps)
{
  gboolean ret = TRUE;

  GST_DEBUG_OBJECT (render, "performing negotiation");

  /* Clear any pending reconfigure flag */
  gst_pad_check_reconfigure (render->video_srcpad);

  if (!caps)
    caps = gst_pad_get_current_caps (render->video_sinkpad);
  else
    gst_caps_ref (caps);

  if (!caps || gst_caps_is_empty (caps))
    goto no_format;

  ret = gst_rtkass_render_can_handle_caps (caps);

  if (ret) {
    GST_DEBUG_OBJECT (render, "Using caps %" GST_PTR_FORMAT, caps);
    ret = gst_pad_set_caps (render->video_srcpad, caps);
  }

  if (!ret) {
    GST_DEBUG_OBJECT (render, "negotiation failed, schedule reconfigure");
    gst_pad_mark_reconfigure (render->video_srcpad);
  } 

  gst_caps_unref (caps);

  if (!ret)
    gst_pad_mark_reconfigure (render->video_srcpad);

  return ret;

no_format:
  {
    if (caps)
      gst_caps_unref (caps);
    gst_pad_mark_reconfigure (render->video_srcpad);
    return FALSE;
  }
}

static gboolean
gst_rtkass_render_text_src_negotiate (GstRtkAssRender * render)
{
  gboolean ret = TRUE;

  GST_DEBUG_OBJECT (render, "performing negotiation");

  gst_pad_check_reconfigure (render->text_srcpad);

  if (!render->text_caps || gst_caps_is_empty (render->text_caps))
    goto no_format;

  gst_rtkass_render_update_render_size (render);

  ret = gst_rtkass_render_can_handle_caps (render->text_caps);

  if (ret) {
    GST_DEBUG_OBJECT (render, "Using caps %" GST_PTR_FORMAT, render->text_caps);
    ret = gst_pad_set_caps (render->text_srcpad, render->text_caps);
  }

  if (!ret) {
    GST_DEBUG_OBJECT (render, "negotiation failed, schedule reconfigure");
    gst_pad_mark_reconfigure (render->text_srcpad);
  }

  if (!ret)
    gst_pad_mark_reconfigure (render->text_srcpad);

  return ret;

no_format:
  {
    gst_pad_mark_reconfigure (render->text_srcpad);
    return FALSE;
  }
}


static gboolean
gst_rtkass_render_setcaps_video (GstPad * pad, GstRtkAssRender * render,
    GstCaps * caps)
{
  GstVideoInfo info;
  gboolean ret;

  if (!gst_video_info_from_caps (&info, caps))
    goto invalid_caps;

  render->info = info;
  if (render->info.width * render->info.height > 1920 * 1080)
  {
    render->window_width = render->info.width >> 1;
    render->window_height = render->info.height >> 1;
  } else {
    render->window_width = render->info.width;
    render->window_height = render->info.height;
  }

  ret = gst_rtkass_render_video_src_negotiate (render, caps);

  GstVideoInfo text_info;

  if (render->text_caps) {
     gst_caps_unref(render->text_caps);
     render->text_caps = NULL;
  }
  
  gst_video_info_set_format(&text_info, GST_VIDEO_FORMAT_BGRA, render->window_width, render->window_height);
  render->text_caps  = gst_video_info_to_caps(&text_info);

  ret = gst_rtkass_render_text_src_negotiate (render);

  GstStructure *structure;
  GstAllocator *alloc;

  structure = gst_buffer_pool_get_config (render->text_pool);
  gst_buffer_pool_config_set_params (structure, render->text_caps, 4 * render->window_width * render->window_height, 0, SOLID_TOTAL_BUFFER_COUNT);
  gst_buffer_pool_config_add_option (structure, GST_BUFFER_POOL_OPTION_RTK_SUBTITLE_META);

  alloc = gst_rtk_dma_allocator_new ();
  if(!render->usecma)
    gst_rtk_dma_allocator_set_heap(alloc, DMA_BUF_SYSTEM);

  gst_buffer_pool_config_set_allocator (structure, alloc, NULL);
  gst_buffer_pool_set_config (render->text_pool, structure);

  gst_object_unref(alloc);
  gst_buffer_pool_set_active (render->text_pool, TRUE);

  g_mutex_lock (&render->rtkass_mutex);
  ass_set_frame_size (render->rtkass_renderer,
      render->rtkass_frame_width, render->rtkass_frame_height);
  ass_set_storage_size (render->rtkass_renderer,
      render->window_width, render->window_height);
  ass_set_pixel_aspect (render->rtkass_renderer,
      (gdouble) render->info.par_n / (gdouble) render->info.par_d);
  ass_set_font_scale (render->rtkass_renderer, 1.0);
  ass_set_hinting (render->rtkass_renderer, ASS_HINTING_NONE);

  ass_set_fonts (render->rtkass_renderer, "Arial", "sans-serif", 1, NULL, 1);
  ass_set_fonts (render->rtkass_renderer, NULL, "Sans", 1, NULL, 1);
  ass_set_margins (render->rtkass_renderer, 0, 0, 0, 0);
  ass_set_use_margins (render->rtkass_renderer, 0);
  g_mutex_unlock (&render->rtkass_mutex);

  render->renderer_init_ok = TRUE;

  return ret;

  /* ERRORS */
invalid_caps:
  {
    GST_ERROR_OBJECT (render, "could not parse caps");
    return FALSE;
  }
}

static gboolean
gst_rtkass_render_setcaps_text (GstPad * pad, GstRtkAssRender * render,
    GstCaps * caps)
{
  GstStructure *structure;
  const GValue *value;
  GstBuffer *priv;
  GstMapInfo map;
  gboolean ret = FALSE;

  ret = gst_rtkass_render_text_src_negotiate (render);

  structure = gst_caps_get_structure (caps, 0);

  GST_DEBUG_OBJECT (render, "text pad linked with caps:  %" GST_PTR_FORMAT,
      caps);

  value = gst_structure_get_value (structure, "codec_data");

  g_mutex_lock (&render->rtkass_mutex);
  if (value != NULL) {
    priv = gst_value_get_buffer (value);
    g_return_val_if_fail (priv != NULL, FALSE);

    gst_buffer_map (priv, &map, GST_MAP_READ);

    if (!render->rtkass_track)
      render->rtkass_track = ass_new_track (render->rtkass_library);

    ass_process_codec_private (render->rtkass_track, (char *) map.data, map.size);

    gst_buffer_unmap (priv, &map);

    GST_DEBUG_OBJECT (render, "rtkass track created");

    render->track_init_ok = TRUE;

    ret = TRUE;
  } else if (!render->rtkass_track) {
    render->rtkass_track = ass_new_track (render->rtkass_library);

    render->track_init_ok = TRUE;

    ret = TRUE;
  }
  g_mutex_unlock (&render->rtkass_mutex);

  return ret;
}

static void
gst_rtkass_render_process_text (GstRtkAssRender * render, GstBuffer * buffer,
    GstClockTime running_time, GstClockTime duration)
{
  GstMapInfo map;
  gdouble pts_start, pts_end;

  pts_start = running_time;
  pts_start /= GST_MSECOND;
  pts_end = duration;
  pts_end /= GST_MSECOND;

  GST_DEBUG_OBJECT (render,
      "Processing subtitles with running time %" GST_TIME_FORMAT
      " and duration %" GST_TIME_FORMAT, GST_TIME_ARGS (running_time),
      GST_TIME_ARGS (duration));

  gst_buffer_map (buffer, &map, GST_MAP_READ);

  g_mutex_lock (&render->rtkass_mutex);
  ass_process_chunk (render->rtkass_track, (gchar *) map.data, map.size,
      pts_start, pts_end);
  g_mutex_unlock (&render->rtkass_mutex);

  gst_buffer_unmap (buffer, &map);
}

static GstFlowReturn
gst_rtkass_render_frame (GstRtkAssRender * render, ASS_Image * images, GstClockTime start, GstClockTime duration)
{
  GstVideoMeta *vmeta;
  GstMapInfo map;
  GstBuffer *buffer;
  ASS_Image *image;
  gint min_x, min_y;
  gint max_x, max_y;
  gint width, height;
  gint stride;
  gpointer data;
  GstFlowReturn ret = GST_FLOW_OK;

  min_x = G_MAXINT;
  min_y = G_MAXINT;
  max_x = 0;
  max_y = 0;

  /* find bounding box of all images, to limit the overlay rectangle size */
  for (image = images; image; image = image->next) {
    if (min_x > image->dst_x)
      min_x = image->dst_x;
    if (min_y > image->dst_y)
      min_y = image->dst_y;
    if (max_x < image->dst_x + image->w)
      max_x = image->dst_x + image->w;
    if (max_y < image->dst_y + image->h)
      max_y = image->dst_y + image->h;
  }

  width = MIN (max_x - min_x, render->rtkass_frame_width);
  height = MIN (max_y - min_y, render->rtkass_frame_height);

  GST_DEBUG_OBJECT (render, "render overlay rectangle %dx%d%+d%+d",
      width, height, min_x, min_y);

  ret = gst_buffer_pool_acquire_buffer (render->text_pool, &buffer, NULL);  
  if (ret != GST_FLOW_OK)
    return GST_FLOW_ERROR;
  vmeta = gst_buffer_get_video_meta(buffer);

  if (!gst_video_meta_map (vmeta, 0, &map, &data, &stride, GST_MAP_READWRITE)) {
    GST_ERROR_OBJECT (render, "Failed to map overlay buffer");
    return GST_FLOW_ERROR;
  }

//  memset(data, 0, (render->info.width * render->info.height * 4));
  blit_bgra_premultiplied (render, images, data, width, height, stride,
      -min_x, -min_y);
  gst_video_meta_unmap (vmeta, 0, &map);

  GST_BUFFER_TIMESTAMP (buffer) = start;
  GST_BUFFER_DURATION (buffer) = GST_CLOCK_TIME_NONE;

  render->last_text_timestamp = start;
  gst_pad_push(render->text_srcpad, buffer);

  return GST_FLOW_OK;
}



static GstFlowReturn
gst_rtkass_render_chain_video (GstPad * pad, GstObject * parent,
    GstBuffer * buffer)
{
  GstRtkAssRender *render = GST_RTKASS_RENDER (parent);
  GstFlowReturn ret = GST_FLOW_OK;
  gboolean in_seg = FALSE;
  guint64 start, stop, clip_start = 0, clip_stop = 0;
  ASS_Image *rtkass_image;
  guint n = 0;

  if (gst_pad_check_reconfigure (render->video_srcpad)) {
    if (!gst_rtkass_render_video_src_negotiate (render, NULL)) {
      gst_pad_mark_reconfigure (render->video_srcpad);
      if (GST_PAD_IS_FLUSHING (render->video_srcpad))
        goto flushing_no_unlock;
      else
        goto not_negotiated;
    }
  }

  if (!GST_BUFFER_TIMESTAMP_IS_VALID (buffer))
    goto missing_timestamp;

  /* ignore buffers that are outside of the current segment */
  start = GST_BUFFER_TIMESTAMP (buffer);

  if (!GST_BUFFER_DURATION_IS_VALID (buffer)) {
    stop = GST_CLOCK_TIME_NONE;
  } else {
    stop = start + GST_BUFFER_DURATION (buffer);
  }

  /* segment_clip() will adjust start unconditionally to segment_start if
   * no stop time is provided, so handle this ourselves */
  if (stop == GST_CLOCK_TIME_NONE && start < render->video_segment.start)
    goto out_of_segment;

  in_seg =
      gst_segment_clip (&render->video_segment, GST_FORMAT_TIME, start, stop,
      &clip_start, &clip_stop);

  if (!in_seg)
    goto out_of_segment;

  /* if the buffer is only partially in the segment, fix up stamps */
  if (clip_start != start || (stop != -1 && clip_stop != stop)) {
    GST_DEBUG_OBJECT (render, "clipping buffer timestamp/duration to segment");
    buffer = gst_buffer_make_writable (buffer);
    GST_BUFFER_TIMESTAMP (buffer) = clip_start;
    if (stop != -1)
      GST_BUFFER_DURATION (buffer) = clip_stop - clip_start;
  }

  /* now, after we've done the clipping, fix up end time if there's no
   * duration (we only use those estimated values internally though, we
   * don't want to set bogus values on the buffer itself) */
  if (stop == -1) {
    if (render->info.fps_n && render->info.fps_d) {
      GST_DEBUG_OBJECT (render, "estimating duration based on framerate");
      stop =
          start + gst_util_uint64_scale_int (GST_SECOND, render->info.fps_d,
          render->info.fps_n);
    } else {
      GST_WARNING_OBJECT (render, "no duration, rtkassuming minimal duration");
      stop = start + 1;         /* we need to rtkassume some interval */
    }
  }

wait_for_text_buf:

  GST_RTKASS_RENDER_LOCK (render);

  if (render->silent == TRUE) {
    gst_buffer_unref(buffer);
    GST_RTKASS_RENDER_UNLOCK (render);
    return GST_FLOW_OK;
  }

  if (render->video_flushing)
    goto flushing;

  if (render->video_eos)
    goto have_eos;

  if (render->renderer_init_ok && render->track_init_ok && render->enable) {
    /* Text pad linked, check if we have a text buffer queued */
    if (render->subtitle_pending) {
      GSList *subtitle_pending = render->subtitle_pending;
      GstClockTime text_start = GST_CLOCK_TIME_NONE;
      GstClockTime text_end = GST_CLOCK_TIME_NONE;
      GstClockTime text_running_time = GST_CLOCK_TIME_NONE;
      GstClockTime text_running_time_end = GST_CLOCK_TIME_NONE;
      GstClockTime vid_running_time, vid_running_time_end;
      gdouble timestamp;
      gint changed = 0;

      vid_running_time =
          gst_segment_to_running_time (&render->video_segment, GST_FORMAT_TIME,
          start);
      vid_running_time_end =
          gst_segment_to_running_time (&render->video_segment, GST_FORMAT_TIME,
          stop);

      GST_LOG_OBJECT (render, "V : %" GST_TIME_FORMAT " - %" GST_TIME_FORMAT,
          GST_TIME_ARGS (vid_running_time),
          GST_TIME_ARGS (vid_running_time_end));

      if (subtitle_pending == NULL)
        GST_LOG_OBJECT (render, "T : no pending subtitles");

      while (subtitle_pending != NULL) {
        ++n;

        /* if the text buffer isn't stamped right, pop it off the
         * queue and display it for the current video frame only */
        if (!GST_BUFFER_TIMESTAMP_IS_VALID (subtitle_pending->data) ||
            !GST_BUFFER_DURATION_IS_VALID (subtitle_pending->data)) {
          GSList *bad = subtitle_pending;
          GST_WARNING_OBJECT (render,
              "Got text buffer with invalid timestamp or duration %"
              GST_PTR_FORMAT, bad->data);
          gst_buffer_unref (bad->data);
          subtitle_pending = bad->next;
          render->subtitle_pending =
              g_slist_delete_link (render->subtitle_pending, bad);
          GST_RTKASS_RENDER_BROADCAST (render);
          continue;
        }

        text_start = GST_BUFFER_TIMESTAMP (subtitle_pending->data);
        text_end = text_start + GST_BUFFER_DURATION (subtitle_pending->data);

        /* If timestamp and duration are valid */
        text_running_time =
            gst_segment_to_running_time (&render->subtitle_segment,
            GST_FORMAT_TIME, text_start);
        text_running_time_end =
            gst_segment_to_running_time (&render->subtitle_segment,
            GST_FORMAT_TIME, text_end);

        GST_LOG_OBJECT (render, "T%u: %" GST_TIME_FORMAT " - "
            "%" GST_TIME_FORMAT, n, GST_TIME_ARGS (text_running_time),
            GST_TIME_ARGS (text_running_time_end));

        /* Text too old */
        if (text_running_time_end <= vid_running_time) {
          GSList *old = subtitle_pending;
          GST_DEBUG_OBJECT (render,
              "text buffer too old, popping %" GST_PTR_FORMAT, old->data);
          gst_buffer_unref (old->data);
          subtitle_pending = old->next;
          render->subtitle_pending =
              g_slist_delete_link (render->subtitle_pending, old);
          GST_RTKASS_RENDER_BROADCAST (render);
          continue;
        }

        if (render->need_process) {
          GST_DEBUG_OBJECT (render, "process text buffer");
          gst_rtkass_render_process_text (render, subtitle_pending->data,
              text_running_time, text_running_time_end - text_running_time);
        }

        subtitle_pending = subtitle_pending->next;
      }

      if (render->need_process) {
        render->need_process = FALSE;
      }

      GST_RTKASS_RENDER_UNLOCK (render);

      /* librtkass needs timestamps in ms */
      timestamp = vid_running_time / GST_MSECOND;

      g_mutex_lock (&render->rtkass_mutex);
      rtkass_image = ass_render_frame (render->rtkass_renderer, render->rtkass_track,
          timestamp, &changed);
      g_mutex_unlock (&render->rtkass_mutex);


      if (changed) {
        if (rtkass_image == NULL) {
          GstBuffer *clear_buffer;
          ret = gst_buffer_pool_acquire_buffer (render->text_pool, &clear_buffer, NULL);
          if (ret == GST_FLOW_OK) {
            GST_BUFFER_TIMESTAMP(clear_buffer) = render->last_text_timestamp;
            GST_BUFFER_DURATION(clear_buffer) = GST_CLOCK_TIME_NONE;
            gst_pad_push (render->text_srcpad, clear_buffer);
          }
        } else {
          gst_rtkass_render_frame(render, rtkass_image, vid_running_time, vid_running_time_end - vid_running_time);
        }
      }

      render->last_video_timestamp = GST_BUFFER_TIMESTAMP(buffer);
      render->last_video_duration = GST_BUFFER_DURATION(buffer);

      if (render->usecma) {
        if(!GST_CLOCK_TIME_IS_VALID (render->last_text_timestamp) || render->last_video_timestamp > render->last_text_timestamp) {
          GstEvent *gap_event = gst_event_new_gap(render->last_video_timestamp, render->last_video_duration);
          gst_pad_push_event(render->text_srcpad, gap_event);
        }
      }
      else if (render->preload_gap < 3) {
        GstEvent *gap_event = gst_event_new_gap(render->last_video_timestamp, render->last_video_duration);
        render->preload_gap++;
        gst_pad_push_event(render->text_srcpad, gap_event);
      }

      ret = gst_pad_push (render->video_srcpad, buffer);
      subtitle_pending = render->subtitle_pending;
      while (subtitle_pending != NULL) {

        text_start = GST_BUFFER_TIMESTAMP (subtitle_pending->data);
        text_end = text_start + GST_BUFFER_DURATION (subtitle_pending->data);

        text_running_time_end =
            gst_segment_to_running_time (&render->video_segment,
            GST_FORMAT_TIME, text_end);

        if (text_running_time_end <= vid_running_time_end) {
          GSList *old = subtitle_pending;
          GST_DEBUG_OBJECT (render,
              "finished text buffer, popping %" GST_PTR_FORMAT, old->data);
          GST_RTKASS_RENDER_LOCK (render);
          gst_buffer_unref (old->data);
          subtitle_pending = old->next;
          render->subtitle_pending =
              g_slist_delete_link (render->subtitle_pending, old);
          GST_RTKASS_RENDER_BROADCAST (render);
          GST_RTKASS_RENDER_UNLOCK (render);
          render->need_process = TRUE;
          if (g_slist_length (render->subtitle_pending) == 0) {
            render->need_process = FALSE;
          }
        } else {
          subtitle_pending = subtitle_pending->next;
        }
      }
    } else {
      gboolean wait_for_text_buf = TRUE;

      if (render->subtitle_eos)
        wait_for_text_buf = FALSE;

      if (!render->wait_text)
        wait_for_text_buf = FALSE;

      /* Text pad linked, but no text buffer available - what now? */
      if (render->subtitle_segment.format == GST_FORMAT_TIME) {
        GstClockTime text_start_running_time, text_last_stop_running_time;
        GstClockTime vid_running_time;

        vid_running_time =
            gst_segment_to_running_time (&render->video_segment,
            GST_FORMAT_TIME, GST_BUFFER_TIMESTAMP (buffer));
        text_start_running_time =
            gst_segment_to_running_time (&render->subtitle_segment,
            GST_FORMAT_TIME, render->subtitle_segment.start);
        text_last_stop_running_time =
            gst_segment_to_running_time (&render->subtitle_segment,
            GST_FORMAT_TIME, render->subtitle_segment.position);

        if ((GST_CLOCK_TIME_IS_VALID (text_start_running_time) &&
                vid_running_time < text_start_running_time) ||
            (GST_CLOCK_TIME_IS_VALID (text_last_stop_running_time) &&
                vid_running_time < text_last_stop_running_time)) {
          wait_for_text_buf = FALSE;
        }
      }

      if (wait_for_text_buf) {
        GST_DEBUG_OBJECT (render, "no text buffer, need to wait for one");
        GST_RTKASS_RENDER_WAIT (render);
        GST_DEBUG_OBJECT (render, "resuming");
        GST_RTKASS_RENDER_UNLOCK (render);
        goto wait_for_text_buf;
      } else {
        GST_RTKASS_RENDER_UNLOCK (render);
        GST_LOG_OBJECT (render, "no need to wait for a text buffer");

        render->last_video_timestamp = GST_BUFFER_TIMESTAMP(buffer);
        render->last_video_duration = GST_BUFFER_DURATION(buffer);

        if (render->usecma) {
          if(!GST_CLOCK_TIME_IS_VALID (render->last_text_timestamp) || render->last_video_timestamp > render->last_text_timestamp) {
            GstEvent *gap_event = gst_event_new_gap(render->last_video_timestamp, render->last_video_duration);
            gst_pad_push_event(render->text_srcpad, gap_event);
          }
        }
        else if (render->preload_gap < 3) {
          GstEvent *gap_event = gst_event_new_gap(render->last_video_timestamp, render->last_video_duration);
          render->preload_gap++;
          gst_pad_push_event(render->text_srcpad, gap_event);
        }

        ret = gst_pad_push (render->video_srcpad, buffer);
      }
    }
  } else {
    GST_LOG_OBJECT (render, "rendering disabled, doing buffer prtkassthrough");

    GST_RTKASS_RENDER_UNLOCK (render);

    render->last_video_timestamp = GST_BUFFER_TIMESTAMP(buffer);
    render->last_video_duration = GST_BUFFER_DURATION(buffer);

    if (render->usecma) {
        if(!GST_CLOCK_TIME_IS_VALID (render->last_text_timestamp) || render->last_video_timestamp > render->last_text_timestamp) {
          GstEvent *gap_event = gst_event_new_gap(render->last_video_timestamp, render->last_video_duration);
          gst_pad_push_event(render->text_srcpad, gap_event);
        }
    } else if (render->preload_gap < 3) {
      GstEvent *gap_event = gst_event_new_gap(render->last_video_timestamp, render->last_video_duration);
      render->preload_gap++;
      gst_pad_push_event(render->text_srcpad, gap_event);
    }

    ret = gst_pad_push (render->video_srcpad, buffer);
    return ret;
  }

  GST_DEBUG_OBJECT (render, "leaving chain for buffer %p ret=%d", buffer, ret);

  /* Update last_stop */
  render->video_segment.position = clip_start;

  return ret;

missing_timestamp:
  {
    GST_WARNING_OBJECT (render, "buffer without timestamp, discarding");
    gst_buffer_unref (buffer);
    return GST_FLOW_OK;
  }
not_negotiated:
  {
    GST_DEBUG_OBJECT (render, "not negotiated");
    gst_buffer_unref (buffer);
    return GST_FLOW_NOT_NEGOTIATED;
  }
flushing:
  {
    GST_RTKASS_RENDER_UNLOCK (render);
  }
flushing_no_unlock:
  {
    GST_DEBUG_OBJECT (render, "flushing, discarding buffer");
    gst_buffer_unref (buffer);
    return GST_FLOW_FLUSHING;
  }
have_eos:
  {
    GST_RTKASS_RENDER_UNLOCK (render);
    GST_DEBUG_OBJECT (render, "eos, discarding buffer");
    gst_buffer_unref (buffer);
    return GST_FLOW_EOS;
  }
out_of_segment:
  {
    GST_DEBUG_OBJECT (render, "buffer out of segment, discarding");
    gst_buffer_unref (buffer);
    return GST_FLOW_OK;
  }
}

static GstFlowReturn
gst_rtkass_render_chain_text (GstPad * pad, GstObject * parent, GstBuffer * buffer)
{
  GstFlowReturn ret = GST_FLOW_OK;
  GstRtkAssRender *render = GST_RTKASS_RENDER (parent);
  gboolean in_seg = FALSE;
  guint64 clip_start = 0, clip_stop = 0;

  GST_DEBUG_OBJECT (render, "entering chain for buffer %" GST_PTR_FORMAT,
      buffer);

  GST_RTKASS_RENDER_LOCK (render);

  if (render->silent == TRUE) {
    gst_buffer_unref(buffer);
    GST_RTKASS_RENDER_UNLOCK (render);
    return GST_FLOW_OK;
  }

  if (render->subtitle_flushing) {
    GST_RTKASS_RENDER_UNLOCK (render);
    ret = GST_FLOW_FLUSHING;
    GST_LOG_OBJECT (render, "text flushing");
    goto beach;
  }

  if (render->subtitle_eos) {
    GST_RTKASS_RENDER_UNLOCK (render);
    ret = GST_FLOW_EOS;
    GST_LOG_OBJECT (render, "text EOS");
    goto beach;
  }

  if (G_LIKELY (GST_BUFFER_TIMESTAMP_IS_VALID (buffer))) {
    GstClockTime stop;

    if (G_LIKELY (GST_BUFFER_DURATION_IS_VALID (buffer)))
      stop = GST_BUFFER_TIMESTAMP (buffer) + GST_BUFFER_DURATION (buffer);
    else
      stop = GST_CLOCK_TIME_NONE;

    in_seg = gst_segment_clip (&render->subtitle_segment, GST_FORMAT_TIME,
        GST_BUFFER_TIMESTAMP (buffer), stop, &clip_start, &clip_stop);
  } else {
    in_seg = TRUE;
  }

  if (in_seg) {
    if (GST_BUFFER_TIMESTAMP_IS_VALID (buffer))
      GST_BUFFER_TIMESTAMP (buffer) = clip_start;
    else if (GST_BUFFER_DURATION_IS_VALID (buffer))
      GST_BUFFER_DURATION (buffer) = clip_stop - clip_start;

    if (GST_BUFFER_TIMESTAMP_IS_VALID (buffer))
      render->subtitle_segment.position = clip_start;

    GST_DEBUG_OBJECT (render, "New buffer arrived %" GST_PTR_FORMAT, buffer);
    render->subtitle_pending = g_slist_append (render->subtitle_pending,
        gst_buffer_ref (buffer));
    render->need_process = TRUE;

    /* in case the video chain is waiting for a text buffer, wake it up */
    GST_RTKASS_RENDER_BROADCAST (render);
  }

  GST_RTKASS_RENDER_UNLOCK (render);

beach:
  GST_DEBUG_OBJECT (render, "leaving chain for buffer %p", buffer);

  gst_buffer_unref (buffer);
  return ret;
}

static void
gst_rtkass_render_handle_tag_sample (GstRtkAssRender * render, GstSample * sample)
{
  static const gchar *mimetypes[] = {
    "application/x-font-ttf",
    "application/x-font-otf",
    "application/x-truetype-font",
    "application/vnd.ms-opentype",
    "font/ttf",
    "font/otf",
    "font/sfnt",
    "font/collection"
  };
  static const gchar *extensions[] = {
    ".otf",
    ".ttf",
    ".ttc"
  };

  GstBuffer *buf;
  const GstStructure *structure;
  gboolean valid_mimetype, valid_extension;
  guint i;
  const gchar *mimetype, *filename;

  buf = gst_sample_get_buffer (sample);
  structure = gst_sample_get_info (sample);

  if (!buf || !structure)
    return;

  filename = gst_structure_get_string (structure, "filename");
  if (!filename)
    return;

  valid_mimetype = FALSE;
  valid_extension = FALSE;

  mimetype = gst_structure_get_string (structure, "mimetype");
  if (mimetype) {
    for (i = 0; i < G_N_ELEMENTS (mimetypes); i++) {
      if (strcmp (mimetype, mimetypes[i]) == 0) {
        valid_mimetype = TRUE;
        break;
      }
    }
  }

  if (!valid_mimetype) {
    guint len = strlen (filename);
    const gchar *extension = filename + len - 4;
    for (i = 0; i < G_N_ELEMENTS (extensions); i++) {
      if (g_ascii_strcasecmp (extension, extensions[i]) == 0) {
        valid_extension = TRUE;
        break;
      }
    }
  }

  if (valid_mimetype || valid_extension) {
    GstMapInfo map;

    g_mutex_lock (&render->rtkass_mutex);
    gst_buffer_map (buf, &map, GST_MAP_READ);
    ass_add_font (render->rtkass_library, (gchar *) filename,
        (gchar *) map.data, map.size);
    gst_buffer_unmap (buf, &map);
    GST_DEBUG_OBJECT (render, "registered new font %s", filename);
    g_mutex_unlock (&render->rtkass_mutex);
  }
}

static void
gst_rtkass_render_handle_tags (GstRtkAssRender * render, GstTagList * taglist)
{
  guint tag_size;

  if (!taglist)
    return;

  tag_size = gst_tag_list_get_tag_size (taglist, GST_TAG_ATTACHMENT);
  if (tag_size > 0 && render->embeddedfonts) {
    guint index;
    GstSample *sample;

    GST_DEBUG_OBJECT (render, "TAG event has attachments");

    for (index = 0; index < tag_size; index++) {
      if (gst_tag_list_get_sample_index (taglist, GST_TAG_ATTACHMENT, index,
              &sample)) {
        gst_rtkass_render_handle_tag_sample (render, sample);
        gst_sample_unref (sample);
      }
    }
  }
}

static gboolean
gst_rtkass_render_event_video (GstPad * pad, GstObject * parent, GstEvent * event)
{
  gboolean ret = FALSE;
  GstRtkAssRender *render = GST_RTKASS_RENDER (parent);

  GST_DEBUG_OBJECT (pad, "received video event %" GST_PTR_FORMAT, event);

  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_CAPS:
    {
      GstCaps *caps;

      gst_event_parse_caps (event, &caps);
      ret = gst_rtkass_render_setcaps_video (pad, render, caps);
      gst_event_unref (event);
      break;
    }
    case GST_EVENT_SEGMENT:
    {
      GstSegment segment;

      GST_DEBUG_OBJECT (render, "received new segment");

      gst_event_copy_segment (event, &segment);

      if (segment.format == GST_FORMAT_TIME) {
        GST_DEBUG_OBJECT (render, "VIDEO SEGMENT now: %" GST_SEGMENT_FORMAT,
            &render->video_segment);

        render->video_segment = segment;

        GST_DEBUG_OBJECT (render, "VIDEO SEGMENT after: %" GST_SEGMENT_FORMAT,
            &render->video_segment);
        ret = gst_pad_push_event(render->video_srcpad, event);
      } else {
        GST_ELEMENT_WARNING (render, STREAM, MUX, (NULL),
            ("received non-TIME newsegment event on video input"));
        ret = FALSE;
        gst_event_unref (event);
      }
      break;
    }
    case GST_EVENT_TAG:
    {
      GstTagList *taglist = NULL;

      /* tag events may contain attachments which might be fonts */
      GST_DEBUG_OBJECT (render, "got TAG event");

      gst_event_parse_tag (event, &taglist);
      gst_rtkass_render_handle_tags (render, taglist);
      ret = gst_pad_push_event(render->video_srcpad, event);
      break;
    }
    case GST_EVENT_EOS:
      GST_RTKASS_RENDER_LOCK (render);
      GST_INFO_OBJECT (render, "video EOS");
      render->video_eos = TRUE;
      GST_RTKASS_RENDER_UNLOCK (render);
      ret = gst_pad_push_event(render->video_srcpad, event);
      break;
    case GST_EVENT_FLUSH_START:
      GST_RTKASS_RENDER_LOCK (render);
      GST_INFO_OBJECT (render, "video flush start");
      render->video_flushing = TRUE;
      GST_RTKASS_RENDER_BROADCAST (render);
      GST_RTKASS_RENDER_UNLOCK (render);
      ret = gst_pad_push_event(render->video_srcpad, event);
      break;
    case GST_EVENT_FLUSH_STOP:
      GST_RTKASS_RENDER_LOCK (render);
      GST_INFO_OBJECT (render, "video flush stop");
      render->video_flushing = FALSE;
      render->video_eos = FALSE;
      gst_segment_init (&render->video_segment, GST_FORMAT_TIME);
      GST_RTKASS_RENDER_UNLOCK (render);
      ret = gst_pad_push_event(render->video_srcpad, event);
      break;
    default:
      ret = gst_pad_event_default (pad, parent, event);
      break;
  }

  return ret;
}

static gboolean
gst_rtkass_render_query_video (GstPad * pad, GstObject * parent, GstQuery * query)
{
  gboolean res = FALSE;

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_CAPS:
    {
      GstCaps *filter, *caps;

      gst_query_parse_caps (query, &filter);
      caps =
          gst_rtkass_render_get_videosink_caps (pad, (GstRtkAssRender *) parent,
          filter);
      gst_query_set_caps_result (query, caps);
      gst_caps_unref (caps);
      res = TRUE;
      break;
    }
    default:
      res = gst_pad_query_default (pad, parent, query);
      break;
  }

  return res;
}

static gboolean
gst_rtkass_render_event_text (GstPad * pad, GstObject * parent, GstEvent * event)
{
  gboolean ret = FALSE;
  GstRtkAssRender *render = GST_RTKASS_RENDER (parent);

  GST_DEBUG_OBJECT (pad, "received text event %" GST_PTR_FORMAT, event);

  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_CAPS:
    {
      GstCaps *caps;

      gst_event_parse_caps (event, &caps);
      ret = gst_rtkass_render_setcaps_text (pad, render, caps);
      gst_event_unref (event);
      break;
    }
    case GST_EVENT_SEGMENT:
    {
      GstSegment segment;

      GST_RTKASS_RENDER_LOCK (render);
      render->subtitle_eos = FALSE;
      GST_RTKASS_RENDER_UNLOCK (render);

      gst_event_copy_segment (event, &segment);

      GST_RTKASS_RENDER_LOCK (render);
      if (segment.format == GST_FORMAT_TIME) {
        GST_DEBUG_OBJECT (render, "TEXT SEGMENT now: %" GST_SEGMENT_FORMAT,
            &render->subtitle_segment);

        render->subtitle_segment = segment;

        GST_DEBUG_OBJECT (render,
            "TEXT SEGMENT after: %" GST_SEGMENT_FORMAT,
            &render->subtitle_segment);
      } else {
        GST_ELEMENT_WARNING (render, STREAM, MUX, (NULL),
            ("received non-TIME newsegment event on subtitle input"));
      }

      ret = gst_pad_push_event(render->text_srcpad, event);
      /* wake up the video chain, it might be waiting for a text buffer or
       * a text segment update */
      GST_RTKASS_RENDER_BROADCAST (render);
      GST_RTKASS_RENDER_UNLOCK (render);
      break;
    }
    case GST_EVENT_GAP:{
      GstClockTime start, duration;

      gst_event_parse_gap (event, &start, &duration);
      if (GST_CLOCK_TIME_IS_VALID (duration))
        start += duration;
      /* we do not expect another buffer until after gap,
       * so that is our position now */
      GST_RTKASS_RENDER_LOCK (render);
      render->subtitle_segment.position = start;

      /* wake up the video chain, it might be waiting for a text buffer or
       * a text segment update */
      GST_RTKASS_RENDER_BROADCAST (render);
      GST_RTKASS_RENDER_UNLOCK (render);
      //ret = gst_pad_push_event(render->text_srcpad, event);
      gst_event_unref(event);
      break;
    }
    case GST_EVENT_FLUSH_STOP:
      g_mutex_lock (&render->rtkass_mutex);
      if (render->rtkass_track) {
        ass_flush_events (render->rtkass_track);
      }
      g_mutex_unlock (&render->rtkass_mutex);
      GST_RTKASS_RENDER_LOCK (render);
      GST_INFO_OBJECT (render, "text flush stop");
      render->subtitle_flushing = FALSE;
      render->subtitle_eos = FALSE;
      gst_rtkass_render_pop_text (render);
      gst_segment_init (&render->subtitle_segment, GST_FORMAT_TIME);
      GST_RTKASS_RENDER_UNLOCK (render);
      ret = gst_pad_push_event(render->text_srcpad, event);
      break;
    case GST_EVENT_FLUSH_START:
      render->preload_gap = 0;
      GST_DEBUG_OBJECT (render, "text flush start");
      GST_RTKASS_RENDER_LOCK (render);
      render->subtitle_flushing = TRUE;
      GST_RTKASS_RENDER_BROADCAST (render);
      GST_RTKASS_RENDER_UNLOCK (render);
      ret = gst_pad_push_event(render->text_srcpad, event);
      break;
    case GST_EVENT_EOS:
      GST_RTKASS_RENDER_LOCK (render);
      render->subtitle_eos = TRUE;
      GST_INFO_OBJECT (render, "text EOS");
      /* wake up the video chain, it might be waiting for a text buffer or
       * a text segment update */
      GST_RTKASS_RENDER_BROADCAST (render);
      GST_RTKASS_RENDER_UNLOCK (render);
      ret = gst_pad_push_event(render->text_srcpad, event);
      break;
    case GST_EVENT_TAG:
    {
      GstTagList *taglist = NULL;

      /* tag events may contain attachments which might be fonts */
      GST_DEBUG_OBJECT (render, "got TAG event");

      gst_event_parse_tag (event, &taglist);
      gst_rtkass_render_handle_tags (render, taglist);
      ret = gst_pad_push_event(render->text_srcpad, event);
      break;
    }
    default:
      ret = gst_pad_event_default (pad, parent, event);
      break;
  }

  return ret;
}

static gboolean
plugin_init (GstPlugin * plugin)
{
  return GST_ELEMENT_REGISTER (rtkassrender, plugin);
}

#ifndef VERSION
#define VERSION "0.0.FIXME"
#endif
#ifndef PACKAGE
#define PACKAGE "FIXME_package"
#endif
#ifndef PACKAGE_NAME
#define PACKAGE_NAME "FIXME_package_name"
#endif
#ifndef GST_PACKAGE_ORIGIN
#define GST_PACKAGE_ORIGIN "http://FIXME.org/"
#endif

GST_PLUGIN_DEFINE (GST_VERSION_MAJOR,
    GST_VERSION_MINOR,
    rtkassrender,
    "RTKASS/SSA subtitle renderer",
    plugin_init, VERSION, "LGPL", PACKAGE_NAME, GST_PACKAGE_ORIGIN)
