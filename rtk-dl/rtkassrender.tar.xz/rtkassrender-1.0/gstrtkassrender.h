#ifndef __GST_RTKASS_RENDER_H__
#define __GST_RTKASS_RENDER_H__

#include <gst/gst.h>
#include <gst/video/video.h>

#include <ass/ass.h>
#include <ass/ass_types.h>

G_BEGIN_DECLS

#if !defined(LIBASS_VERSION) || LIBASS_VERSION < 0x00907010
#define ASS_Library ass_library_t
#define ASS_Renderer ass_renderer_t
#define ASS_Track ass_track_t
#define ASS_Image ass_image_t
#endif

#define GST_TYPE_RTKASS_RENDER (gst_rtkass_render_get_type())
#define GST_RTKASS_RENDER(obj) (G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_RTKASS_RENDER,GstRtkAssRender))
#define GST_RTKASS_RENDER_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST((klass),GST_TYPE_RTKASS_RENDER,GstRtkAssRenderClass))
#define GST_RTKASS_RENDER_GET_CLASS(obj) (G_TYPE_INSTANCE_GET_CLASS ((obj), \
    GST_TYPE_RTKASS_RENDER, GstRtkAssRenderClass))
#define GST_IS_RTKASS_RENDER(obj) (G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_TYPE_RTKASS_RENDER))
#define GST_IS_RTKASS_RENDER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass),GST_TYPE_RTKASS_RENDER))

typedef struct _GstRtkAssRender GstRtkAssRender;
typedef struct _GstRtkAssRenderClass GstRtkAssRenderClass;

#define SOLID_TOTAL_BUFFER_COUNT 16
#define SOLID_WIDTH 1280
#define SOLID_HEIGHT 720

struct _GstRtkAssRender
{
  GstElement element;

  GstPad *video_sinkpad, *text_sinkpad, *video_srcpad, *text_srcpad;

  /* properties */
  gboolean enable, embeddedfonts;
  gboolean wait_text;

  /* <private> */
  GMutex lock;
  GCond cond;

  GstSegment video_segment;
  gboolean video_flushing;
  gboolean video_eos;
  gboolean usecma;

  GstVideoInfo info;

  GSList *subtitle_pending;
  gboolean subtitle_flushing;
  gboolean subtitle_eos;
  GstSegment subtitle_segment;

  GMutex rtkass_mutex;
  ASS_Library *rtkass_library;
  ASS_Renderer *rtkass_renderer;
  ASS_Track *rtkass_track;
  gint rtkass_frame_width, rtkass_frame_height;

  gboolean renderer_init_ok, track_init_ok;
  gboolean need_process;

  /* overlay stuff */
  guint window_width, window_height;
  GstCaps *text_caps;
  GstBufferPool *text_pool;
  gboolean silent;
  gint preload_gap;
  GstClockTime last_text_timestamp;
  GstClockTime last_video_timestamp;
  GstClockTime last_video_duration;
};

struct _GstRtkAssRenderClass
{
  GstElementClass parent_class;
};

GType gst_rtkass_render_get_type (void);

GST_ELEMENT_REGISTER_DECLARE (rtkassrender);

G_END_DECLS

#endif
