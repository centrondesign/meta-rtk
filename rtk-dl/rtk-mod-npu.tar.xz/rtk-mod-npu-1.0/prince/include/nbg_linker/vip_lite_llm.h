/****************************************************************************
*
*    Copyright 2017 - 2025 Vivante Corporation, Santa Clara, California.
*    All Rights Reserved.
*
*    Permission is hereby granted, free of charge, to any person obtaining
*    a copy of this software and associated documentation files (the
*    'Software'), to deal in the Software without restriction, including
*    without limitation the rights to use, copy, modify, merge, publish,
*    distribute, sub license, and/or sell copies of the Software, and to
*    permit persons to whom the Software is furnished to do so, subject
*    to the following conditions:
*
*    The above copyright notice and this permission notice (including the
*    next paragraph) shall be included in all copies or substantial
*    portions of the Software.
*
*    THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND,
*    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
*    IN NO EVENT SHALL VIVANTE AND/OR ITS SUPPLIERS BE LIABLE FOR ANY
*    CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
*    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
*    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#ifndef _VIP_LITE_LLM_H
#define _VIP_LITE_LLM_H

#include "vip_lite_common.h"
#include "vip_lite.h"

/* \brief The header file expose APIs for running Large language model with VIPLite
*/

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _vip_llm_task* vip_llm_task;

/* \brief The list of properties of a llm_task.
  * \ingroup llm_task
 */
typedef enum _vip_llm_task_property_e {
    /* query llm_task */
    /*!< \brief The llm_task profling data, the returned value is vip_inference_profile_t */
    VIP_LLM_TASK_PROP_PROFILING = 0,

} vip_llm_task_property_e;

/*
@brief set input buffer for network or change network input buffer.
@param index The index of network inputs.
@param input The input buffer of network.
@param offset The offset on input based on origin buffer.
       for llm, app could allocate a large buffer, and use the part of buffer as input or output.
       such as kv output come from kv cache.
*/
VIP_API
vip_status_e vip_llm_set_input(IN vip_network network, IN vip_uint32_t index, IN vip_buffer input,
                               IN vip_uint32_t offset);

/*
@brief set output buffer for network or change network output buffer.
@param index The index of network outputs.
@param output The output buffer of network.
@param offset The offset on output based on origin buffer.
       for llm, app could allocate a large buffer, and use the part of buffer as output or output.
       such as kv output come from kv cache.
*/
VIP_API
vip_status_e vip_llm_set_output(IN vip_network network, IN vip_uint32_t index, IN vip_buffer output,
                                IN vip_uint32_t offset);

/*
@brief Create a vip_llm_task object to run multiple tasks(network) and
       without interrupt between each networkc.
@param count The maximum number of tasks supports by this llm task.
@param llm_task Return vip_llm_task object be created.
*/
VIP_API
vip_status_e vip_llm_create_task(IN vip_uint32_t count, OUT vip_llm_task* llm_task);

/*
@brief Destroy llm task object which created by vip_llm_create_task.
@param llm task vip_group object.
*/
VIP_API
vip_status_e vip_llm_destroy_task(IN vip_llm_task llm_task);

/*
@brief add a vip_network object into llm_task.
@param llm_task object, network be added into llm_task.
@param network vip_network added into llm_task.
*/
VIP_API
vip_status_e vip_llm_add_network(IN vip_llm_task llm_task, IN vip_network network);

/*
@brief query task information.
@param llm task vip_llm_task object
*/
VIP_API
vip_status_e vip_llm_query_task(IN vip_llm_task llm_task, IN vip_enum property, OUT void* value);

/*
@brief run tasks in llm task. ony issue a interrupt after tasks complete.
@param llm task vip_llm_task object
*/
VIP_API
vip_status_e vip_llm_run_task(IN vip_llm_task llm_task);

#ifdef __cplusplus
}
#endif

#endif
