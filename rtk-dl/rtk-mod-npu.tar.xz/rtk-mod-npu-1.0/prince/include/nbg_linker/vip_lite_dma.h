/****************************************************************************
*
*    Copyright 2017 - 2025 Vivante Corporation, Santa Clara, California.
*    All Rights Reserved.
*
*    Permission is hereby granted, free of charge, to any person obtaining
*    a copy of this software and associated documentation files (the
*    'Software'), to deal in the Software without restriction, including
*    without limitation the rights to use, copy, modify, merge, publish,
*    distribute, sub license, and/or sell copies of the Software, and to
*    permit persons to whom the Software is furnished to do so, subject
*    to the following conditions:
*
*    The above copyright notice and this permission notice (including the
*    next paragraph) shall be included in all copies or substantial
*    portions of the Software.
*
*    THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND,
*    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
*    IN NO EVENT SHALL VIVANTE AND/OR ITS SUPPLIERS BE LIABLE FOR ANY
*    CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
*    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
*    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#ifndef _VIP_LITE_DMA_H
#define _VIP_LITE_DMA_H

/* \brief The header file expose APIs for T3D DMA
*/
#include <vip_lite_common.h>
#include "vip_lite.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum _vip_flexa_dma_property_e {
    /*!< \brief set DMA5 physical address. the value shoule be vip_address_t data type */
    VIP_DMA_PROP_SET_DMA5_ADDR = 1,
    /*!< \brief set DMA6 physical address. the value shoule be vip_address_t data type */
    VIP_DMA_PROP_SET_DMA6_ADDR = 2,
    /*!< \brief set DMA7 physical address. the value shoule be vip_address_t data type */
    VIP_DMA_PROP_SET_DMA7_ADDR = 3,
    /*!< \brief set DMA8 physical address. the value shoule be vip_address_t data type */
    VIP_DMA_PROP_SET_DMA8_ADDR = 4,
    /*!< \brief set DMA VIP_DMA_IN_ISP_OCM_PSI parameters the value shoule be vip_set_flexa_dma_param_t data type */
    /*
        CircularBufferSize = circular_num * MemTensorStride;
        segmentSize = WordSize * SubtensorXSize * SubtensorYSize * SubtensorZSize;
    */
    VIP_DMA_PROP_SET_DMA5_PARAM = 5,
    /*!< \brief set DMA VIP_DMA_POSTOUT_OCM_ISP parameters the value shoule be vip_set_flexa_dma_param_t data type */
    VIP_DMA_PROP_SET_DMA7_PARAM = 6,
    /*!< \brief set DMA VIP_DMA_DDR_DECOMPRESS parameters the value shoule be vip_set_dma_param_t data type */
    VIP_DMA_PROP_SET_DMA6_PARAM = 7,
    /*!< \brief set DMA VIP_DMA_COMPRESS_DDR parameters the value shoule be vip_set_dma_param_t data type */
    VIP_DMA_PROP_SET_DMA8_PARAM = 8,

    /*!< \brief SET VIP_DMA_ISP_PATTERN_GENERATOR and VIP_DMA_ISP_CHECKSUM_GENERATOR DMA params.
                value shoule be vip_pattern_generator_t data type */
    VIP_DMA_PROP_SET_ISP_EMULATION_PARAMS = 13,
    /*!< \brief set bypass denoise post process.
        can be bypass denoise when NBG is supported Denoise postprocess.
        the value shoule be vip_bool_e data type
    */
    /*VIP_DMA_PROP_SET_BYPASS_DENOISE_POST     = 14,*/
    /*!< \brief set compress mode. the value shoule be vip_compress_param_t data type */
    VIP_DMA_PROP_SET_COMPRESS_MODE = 15,

    /*!< \brief set source of reference frame. the value shoule be vip_bool_e data type
            vip_bool_e *value is vip_true_e,  generate first reference frame by hardware DMA6.
            vip_bool_e *value is vip_false_e, read from ddr. */
    VIP_DMA_PROP_SET_GEN_REF_FRAME = 16,

    /*!< \brief set denoise post process param. the value shoule be vip_denoise_post_process_t data type */
    VIP_DMA_PROP_SET_DENOISE_POST_PARAM = 17,
    /*!< \brief SET VIP_DMA11_ISP_PATTERN_GENERATOR DMA params.
                value shoule be vip_pattern_generator_t data type */
    VIP_DMA_PROP_SET_ISP_EMULATION_PARAMS_DUAL = 18,
    /*!< \brief set DMA5 physical address. the value shoule be vip_buffer_t data type */
    VIP_DMA_PROP_SET_DMA5_BUFFER = 19,
    /*!< \brief set DMA6 physical address. the value shoule be vip_buffer_t data type */
    VIP_DMA_PROP_SET_DMA6_BUFFER = 20,
    /*!< \brief set DMA7 physical address. the value shoule be vip_buffer_t data type */
    VIP_DMA_PROP_SET_DMA7_BUFFER = 21,
    /*!< \brief set DMA8 physical address. the value shoule be vip_buffer_t data type */
    VIP_DMA_PROP_SET_DMA8_BUFFER = 22,
    /*!< \brief set continue mode, the value is vip_bool_e date type, vip_true_e indicate enable continue mode */
    VIP_DMA_PROP_SET_CONTINUE_MODE = 23,

    /*!< \brief query dma5's parameters. the returned value is vip_flexa_dma_query_info_t </tt> */
    VIP_DMA_PROP_QUERY_DMA5_PARAM = 100,
    /*!< \brief query dma7's parameters. the returned value is vip_flexa_dma_query_info_t </tt> */
    VIP_DMA_PROP_QUERY_DMA7_PARAM = 101,
    /*!< \brief query dma6's parameters. the returned value is vip_dma_query_info_t </tt> */
    VIP_DMA_PROP_QUERY_DMA6_PARAM = 102,
    /*!< \brief query dma8's parameters. the returned value is vip_dma_query_info_t </tt> */
    VIP_DMA_PROP_QUERY_DMA8_PARAM = 103,
    /*!< \brief query isp emulation checksum result. the returned value is vip_checksum_generator_t </tt> */
    VIP_DMA_PROP_QUERY_ISPEMU_CHECKSUM = 104,
    /*!< \brief query flexa dma hw status. the returned value is vip_flexa_dma_hardware_status_t </tt> */
    VIP_DMA_PROP_QUERY_FLEXA_DMA_HW_STATUS = 105,
} vip_flexa_dma_property_e;

/* set isp emulation param */
typedef struct _vip_pattern_generator {
    /* set by appliaction */
    vip_uint32_t init_red;
    vip_uint32_t incX_red;
    vip_uint32_t incY_red;
    vip_uint32_t init_green;
    vip_uint32_t incX_green;
    vip_uint32_t incY_green;
    vip_uint32_t init_blue;
    vip_uint32_t incX_blue;
    vip_uint32_t incY_blue;

    vip_uint32_t checksum_expected_red;
    vip_uint32_t checksum_expected_green;
    vip_uint32_t checksum_expected_blue;
} vip_pattern_generator_t;

/* query isp emulation param */
typedef struct _vip_checksum_generator {
    vip_uint32_t actual_checksum_red;
    vip_uint32_t actual_checksum_green;
    vip_uint32_t actual_checksum_blue;
    vip_uint32_t mismatch_checksum_red;
    vip_uint32_t mismatch_checksum_green;
    vip_uint32_t mismatch_checksum_blue;
} vip_checksum_generator_t;

typedef struct __vip_flexa_dma_core_status
{
    vip_uint32_t dma0_busy:1;
    vip_uint32_t dma1_busy:1;
    vip_uint32_t dma2_busy:1;
    vip_uint32_t dma3_busy:1;
    vip_uint32_t dma4_busy:1;
    vip_uint32_t fe_busy:1;
    vip_uint32_t nn_busy:1;
    vip_uint32_t ppu_busy:1;
    vip_uint32_t mc_busy:1;
    vip_uint32_t dma0_frame_compl:1;
    vip_uint32_t dma1_frame_compl:1;
    vip_uint32_t dma2_frame_compl:1;
    vip_uint32_t dma3_frame_compl:1;
    vip_uint32_t dma4_frame_compl:1;
    vip_uint32_t sync_error:1;
    vip_uint32_t shadow_prepared:5;
    vip_uint32_t reserved:12;
} vip_flexa_dma_core_status_t;

typedef struct _vip_flexa_dma_hardware_status {
    vip_flexa_dma_core_status_t *core_status;
    vip_uint32_t dma5_busy:1; /* indicate that dma5 busy or not */
    vip_uint32_t dma6_busy:1;
    vip_uint32_t dma7_busy:1;
    vip_uint32_t dma8_busy:1;
    vip_uint32_t dma9_busy:1;
    vip_uint32_t dma10_busy:1;
    vip_uint32_t dma11_busy:1;
    vip_uint32_t matrix_busy:1;

    vip_uint32_t dma5_frame_compl:1;
    vip_uint32_t dma6_frame_compl:1;
    vip_uint32_t dma7_frame_compl:1;
    vip_uint32_t dma8_frame_compl:1;
    vip_uint32_t ext_sync_error:1;
    vip_uint32_t ext_shadow_prepard:10; /* bit0:dma5, dma1:dma6....dma5:dma11 */

    vip_uint32_t reserved:9; /* reserved bits */

    vip_uint32_t pu_ack; /* pu_req to pu_ack Maximum Cycle Count */
    vip_uint32_t cu_ack; /* cu_req to cu_ack Maximum Cycle Count */
    vip_uint32_t pr_ack; /* pr_req to pr_ack Maximum Cycle Count */
    vip_uint32_t cr_ack;

    vip_uint32_t flexa_dma_raw_status;
    vip_uint32_t flexa_dma_raw_status2;
    vip_uint32_t overlap_check;
} vip_flexa_dma_hardware_status_t;

/*
DMA SBI information be query
*/
typedef struct _vip_flexa_dma_query_info {
    vip_uint32_t mem_Xsize;
    vip_uint32_t mem_Ysize;
    vip_uint32_t mem_Zsize;
    vip_uint32_t word_size;
    /*
        CircularBufferSize = circular_num * MemTensorStride;
        segmentSize = WordSize * SubtensorXSize * SubtensorYSize * SubtensorZSize;
    */
    vip_uint32_t mem_stride;
    vip_uint32_t mem_Ystride;
    vip_uint32_t mem_circular_bufsize;

    vip_uint32_t Sub_Xsize;
    vip_uint32_t Sub_Ysize;
    vip_uint32_t Sub_Zsize;

    vip_uint32_t minimum_circular_num;
    /* 1 indicates the dma is enabled */
    vip_uint8_t enable;
} vip_flexa_dma_query_info_t;

/*
DMA5 and DMA7 parameters be set.
*/
typedef struct _vip_set_flexa_dma_param_t {
    /* the number of Y line for segment buffer.
      segment_buffer_size = WordSize * Sub_Xsize * Sub_Ysize(segment_num) * Sub_Zsize
      segment_num supports value: 1, 2, 4, 8, 16
    */
    vip_uint32_t segment_num;
    /* the number of Y line for circular buffer
      circular_buffer_size = mem_stride * mem_Ystride(circular_num);
    */
    vip_uint32_t circular_num;
} vip_set_flexa_dma_param_t;

/* \brief The list of property of query SBI
 */
typedef enum _vip_flexa_dma_sw_sbi_query_property_e
{
    /*!< \brief None query type </tt> */
    VIP_SBI_PROP_QUERY_NONE              = 0,
    /*!< \brief SBI_pr_ack. the returned value is vip_uint32_t </tt> */
    VIP_SBI_PROP_QUERY_PR                = 1,
    /*!< \brief SBI_pu_ack. the returned value is vip_uint32_t </tt> */
    VIP_SBI_PROP_QUERY_PU                = 2,
    /*!< \brief SBI_cr_ack. the returned value is vip_uint32_t </tt> */
    VIP_SBI_PROP_QUERY_CR                = 3,
    /*!< \brief SBI_pu_ack. the returned value is vip_uint32_t </tt> */
    VIP_SBI_PROP_QUERY_CU                = 4,
    /*!< \brief SBI_RdFrameStart. the returned value is vip_uint32_t
            Show the status of the NPU2ISP_frame_start signal </tt> */
    VIP_SBI_PROP_QUERY_FRAME_START       = 5,
    /*!< \brief SBI_pr_req. the returned value is vip_uint32_t </tt> */
    VIP_SBI_PROP_QUERY_PR_REQ            = 6,
    /*!< \brief SBI_pu_req. the returned value is vip_uint32_t </tt> */
    VIP_SBI_PROP_QUERY_PU_REQ            = 7,
    /*!< \brief SBI_cr_req. the returned value is vip_uint32_t </tt> */
    VIP_SBI_PROP_QUERY_CR_REQ            = 8,
    /*!< \brief SBI_cu_req. the returned value is vip_uint32_t </tt> */
    VIP_SBI_PROP_QUERY_CU_REQ            = 9,
    /*!< \brief NPU to ISP disconnect. the returned value is vip_uint32_t </tt> */
    VIP_SBI_PROP_QUERY_NPU2ISP_DISC_REQ  = 10,
    /*!< \brief ISP to NPU disconnect. the returned value is vip_uint32_t </tt> */
    VIP_SBI_PROP_QUERY_ISP2NPU_DISC_REQ  = 11,
    /*!< \brief ISP to NPU frame start. the returned value is vip_uint32_t </tt> */
    VIP_SBI_PROP_QUERY_FRAME_START_REQ   = 12,

    /*!< \brief For 2nd input of SBI </tt> */
    /*!< \brief SBI_pr_ack. the returned value is vip_uint32_t </tt> */
    VIP_DUAL_SBI_PROP_QUERY_PR                = 13,
    /*!< \brief SBI_pu_ack. the returned value is vip_uint32_t </tt> */
    VIP_DUAL_SBI_PROP_QUERY_PU                = 14,
    /*!< \brief SBI_cr_ack. the returned value is vip_uint32_t </tt> */
    VIP_DUAL_SBI_PROP_QUERY_CR                = 15,
    /*!< \brief SBI_pu_ack. the returned value is vip_uint32_t </tt> */
    VIP_DUAL_SBI_PROP_QUERY_CU                = 16,
    /*!< \brief SBI_RdFrameStart. the returned value is vip_uint32_t
            Show the status of the NPU2ISP_frame_start signal </tt> */
    VIP_DUAL_SBI_PROP_QUERY_FRAME_START       = 17,
    /*!< \brief SBI_pr_req. the returned value is vip_uint32_t </tt> */
    VIP_DUAL_SBI_PROP_QUERY_PR_REQ            = 18,
    /*!< \brief SBI_pu_req. the returned value is vip_uint32_t </tt> */
    VIP_DUAL_SBI_PROP_QUERY_PU_REQ            = 19,
    /*!< \brief SBI_cr_req. the returned value is vip_uint32_t </tt> */
    VIP_DUAL_SBI_PROP_QUERY_CR_REQ            = 20,
    /*!< \brief SBI_cu_req. the returned value is vip_uint32_t </tt> */
    VIP_DUAL_SBI_PROP_QUERY_CU_REQ            = 21,
    /*!< \brief NPU to ISP disconnect. the returned value is vip_uint32_t </tt> */
    VIP_DUAL_SBI_PROP_QUERY_NPU2ISP_DISC_REQ  = 22,
    /*!< \brief ISP to NPU disconnect. the returned value is vip_uint32_t </tt> */
    VIP_DUAL_SBI_PROP_QUERY_ISP2NPU_DISC_REQ  = 23,
    /*!< \brief ISP to NPU frame start. the returned value is vip_uint32_t </tt> */
    VIP_DUAL_SBI_PROP_QUERY_FRAME_START_REQ   = 24,

    VIP_SBI_PROP_QUERY_MAX,
} vip_flexa_dma_sw_sbi_query_property_e;

/* \brief The list of property of setting SBI
 */
typedef enum _vip_flexa_dma_sw_sbi_set_property_e
{
    /*!< \brief None set type </tt> */
    VIP_SBI_PROP_SET_NONE          = 0,
    /*!< \brief SBI_pr_req. the value shoule be vip_uint32_t data type </tt> */
    VIP_SBI_PROP_SET_PR            = 1,
    /*!< \brief SBI_pu_req. the value shoule be vip_uint32_t data type </tt> */
    VIP_SBI_PROP_SET_PU            = 2,
    /*!< \brief SBI_cr_req. the value shoule be vip_uint32_t data type </tt> */
    VIP_SBI_PROP_SET_CR            = 3,
    /*!< \brief SBI_pu_req. the value shoule be vip_uint32_t data type </tt> */
    VIP_SBI_PROP_SET_CU            = 4,
    /*!< \brief NPU to ISP disconnect. the value shoule be vip_uint32_t data type
        0: connects to ISP
        1: connects software-controlled registers
        This is needed before using the SBI_Wr field for software control
        2: connects to pattern generator </tt> */
    VIP_SBI_PROP_SET_NPU2ISP_DISC  = 5,
    /*!< \brief ISP to NPU  disconnect. the value shoule be vip_uint32_t data type
        0: connects to ISP
        1: connects software-controlled registers
        This is needed before using the SBI_Rd field for software control
        2: connects to checksum generator </tt> */
    VIP_SBI_PROP_SET_ISP2NPU_DISC  = 6,
    /*!< \brief SBI_WrFrameStart. the value shoule be vip_uint32_t data type
        1 to indicate start of a frame </tt> */
    VIP_SBI_PROP_SET_FRAME_START   = 7,

    /*!< \brief For 2nd input of SBI </tt> */
    /*!< \brief SBI_pr_req. the value shoule be vip_uint32_t data type </tt> */
    VIP_DUAL_SBI_PROP_SET_PR            = 8,
    /*!< \brief SBI_pu_req. the value shoule be vip_uint32_t data type </tt> */
    VIP_DUAL_SBI_PROP_SET_PU            = 9,
    /*!< \brief SBI_cr_req. the value shoule be vip_uint32_t data type </tt> */
    VIP_DUAL_SBI_PROP_SET_CR            = 10,
    /*!< \brief SBI_pu_req. the value shoule be vip_uint32_t data type </tt> */
    VIP_DUAL_SBI_PROP_SET_CU            = 11,
    /*!< \brief NPU to ISP disconnect. the value shoule be vip_uint32_t data type
        0: connects to ISP
        1: connects software-controlled registers
        This is needed before using the SBI_Wr field for software control
        2: connects to pattern generator </tt> */
    VIP_DUAL_SBI_PROP_SET_NPU2ISP_DISC  = 12,
    /*!< \brief ISP to NPU  disconnect. the value shoule be vip_uint32_t data type
        0: connects to ISP
        1: connects software-controlled registers
        This is needed before using the SBI_Rd field for software control
        2: connects to checksum generator </tt> */
    VIP_DUAL_SBI_PROP_SET_ISP2NPU_DISC  = 13,
    /*!< \brief SBI_WrFrameStart. the value shoule be vip_uint32_t data type
        1 to indicate start of a frame </tt> */
    VIP_DUAL_SBI_PROP_SET_FRAME_START   = 14,

    VIP_SBI_PROP_SET_MAX,
} vip_flexa_dma_sw_sbi_set_property_e;

#if defined(_WIN32)
typedef enum _vip_ack_set_property_e
{
    VIP_ACK_PROP_SET_NONE             = 0,
    VIP_ACK_PROP_SET_PR               = 1,
    VIP_ACK_PROP_SET_PU               = 2,
    VIP_ACK_PROP_SET_CR               = 3,
    VIP_ACK_PROP_SET_CU               = 4,
    VIP_ACK_PROP_SET_FRAME_START      = 5,
    VIP_ACK_PROP_SET_DUAL_PR          = 6,
    VIP_ACK_PROP_SET_DUAL_PU          = 7,
    VIP_ACK_PROP_SET_MAX,
} vip_ack_set_property_e;

/*
@brief set flexa DMA ACK property.
@param property The property be set. see vip_flexa_dma_property_e.
@param value The set data.
*/
VIP_API
vip_status_e vip_set_flexa_dma_ack(vip_ack_set_property_e property, vip_int32_t value);
#endif

/*
@brief set single flexa DMA property.
@param network The network object which created by vip_create_network().
@param property The property be set. see vip_flexa_dma_property_e.
@param value The set data.
*/
VIP_API
vip_status_e vip_set_flexa_dma(IN vip_network network, IN vip_flexa_dma_property_e property, IN void* value);

/*
@brief query dma information.
@param network The network object which created by vip_create_network().
@param The dma property be set. see vip_flexa_dma_sw_sbi_query_property_e.
@param dma_info:
       (1) query dma param: see vip_flexa_dma_query_info_t
       (2) query ispemu checksum: see vip_checksum_generator_t
       (3) query dma hw status: see vip_flexa_dma_hardware_status_t.
*/
VIP_API
vip_status_e vip_query_flexa_dma(IN vip_network network, IN vip_flexa_dma_property_e property,
                                 OUT void* dma_info);

/*
@brief query flexa dma sw sbi.
@param The flexa dma sw sbi property be set. see vip_flexa_dma_sw_sbi_query_property_e.
@param flexa_dma_sw_sbi the flexa dma sw sbi value read by reg.
*/
VIP_API
vip_status_e vip_query_flexa_dma_sw_sbi(IN vip_flexa_dma_sw_sbi_query_property_e property,
                                        OUT void* flexa_dma_sw_sbi);

/*
@brief set flexa DMA SBI property.
@param property The flexa dma sbi property be set. see vip_flexa_dma_sw_sbi_set_property_e.
@param value The set data.
*/
VIP_API
vip_status_e vip_set_flexa_dma_sw_sbi(IN vip_flexa_dma_sw_sbi_set_property_e property, IN vip_uint32_t value);
#ifdef __cplusplus
}
#endif
#endif
