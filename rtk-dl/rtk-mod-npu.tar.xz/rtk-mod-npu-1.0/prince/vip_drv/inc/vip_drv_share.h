/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

/*
  These defines are sharing with user space and kernel space souce code.
  It's can be included by toth user space and vip-drv space.
*/

#ifndef _VIP_DRV_SHARE_H
#define _VIP_DRV_SHARE_H
#include <vip_lite_config.h>

#if vpmdENABLE_RESERVE_PHYSICAL
#define MAX_WRAP_USER_PHYSICAL_TABLE_SIZE 512
#else
#define MAX_WRAP_USER_PHYSICAL_TABLE_SIZE 16384
#endif

/* vip-drv interface command ID. */
typedef enum _vipdrv_intrface {
    VIPDRV_INTRFACE_INIT = 0,
    VIPDRV_INTRFACE_DESTROY = 1,
    VIPDRV_INTRFACE_READ_REG = 2,
    VIPDRV_INTRFACE_WRITE_REG = 3,
    VIPDRV_INTRFACE_WAIT_TASK = 4,
    VIPDRV_INTRFACE_SUBMIT_TASK = 5,
    VIPDRV_INTRFACE_ALLOCATION = 6,
    VIPDRV_INTRFACE_DEALLOCATION = 7,
    VIPDRV_INTRFACE_NOT_USED = 8,   /* NOT USED FIELD */
    VIPDRV_INTRFACE_NOT_USED_1 = 9, /* NOT USED FIELD */
    VIPDRV_INTRFACE_QUERY_DATABASE = 10,
    VIPDRV_INTRFACE_OPERATE_CACHE = 11,
    VIPDRV_INTRFACE_WRAP_USER_MEMORY = 12,
    VIPDRV_INTRFACE_NOT_USED_2 = 13,
    VIPDRV_INTRFACE_NOT_USED_3 = 14,
    VIPDRV_INTRFACE_POWER_MANAGEMENT = 15,
    VIPDRV_INTRFACE_WRAP_USER_PHYSICAL = 16,
    VIPDRV_INTRFACE_NOT_USED_4 = 17,
    VIPDRV_INTRFACE_WRAP_USER_FD = 18,
    VIPDRV_INTRFACE_NOT_USED_5 = 19,
    VIPDRV_INTRFACE_QUERY_PROFILING = 20,
    VIPDRV_INTRFACE_QUERY_DRIVER_STATUS = 21,
    VIPDRV_INTRFACE_QUERY_MMU_INFO = 22,
    VIPDRV_INTRFACE_MAP_USER_LOGICAL = 23,
    VIPDRV_INTRFACE_UNMAP_USER_LOGICAL = 24,
    VIPDRV_INTRFACE_CANCEL_TASK = 25,
    VIPDRV_INTRFACE_QUERY_REGISTER_DUMP = 26,
    VIPDRV_INTRFACE_CREATE_TASK = 27,
    VIPDRV_INTRFACE_SET_TASK_PROPERTY = 28,
    VIPDRV_INTRFACE_DESTROY_TASK = 29,
    VIPDRV_INTRFACE_WRAP_VIDEO_MEMORY = 30,
    VIPDRV_INTRFACE_QUERY_TASK = 31,
    VIPDRV_INTRFACE_QUERY_DEVICE_INFO = 32,
    VIPDRV_INTRFACE_LOCK_VIDEO_MEMORY = 33,
    VIPDRV_INTRFACE_MAX,
} vipdrv_intrface_e;

/* user space can specify video memory allocation flag */
typedef enum _vipdrv_video_mem_alloc_flag {
    VIPDRV_VIDEO_MEM_ALLOC_NONE = 0x000,
    /* physical contiguous. */
    VIPDRV_VIDEO_MEM_ALLOC_CONTIGUOUS = 0x001,
    /* need 32bit address. limit virtual when mmu enable, or physical */
    VIPDRV_VIDEO_MEM_ALLOC_4GB_ADDR = 0x002,
    /* following flag is extra action */
    /* if mmaped VIP's MMU page table, this page is read only for NPU */
    VIPDRV_VIDEO_MEM_ALLOC_NPU_READ_ONLY = 0x010,
    /* without mmaped VIP's MMU page table */
    VIPDRV_VIDEO_MEM_ALLOC_NO_MMU_PAGE = 0x020,
    /* allocate none-cache video memory */
    VIPDRV_VIDEO_MEM_ALLOC_NONE_CACHE = 0x100,
    /* need map user space logical address */
    VIPDRV_VIDEO_MEM_ALLOC_MAP_USER = 0x200,
    /* need map kernel space logical address */
    VIPDRV_VIDEO_MEM_ALLOC_MAP_KERNEL = 0x400,
    /* indicate this memory is for mmu page */
    VIPDRV_VIDEO_MEM_ALLOC_MMU_PAGE_MEM = 0x800,
} vipdrv_video_mem_alloc_flag_e;

typedef enum _vipdrv_power_property_e {
    VIPDRV_POWER_PROPERTY_NONE = 0x0000,
    /*!< \brief specify the VIP frequency */
    VIPDRV_POWER_PROPERTY_SET_FREQUENCY = 0x0001,
    /*!< \brief power off VIP hardware */
    VIPDRV_POWER_PROPERTY_OFF = 0x0002,
    /*!< \brief power on VIP hardware */
    VIPDRV_POWER_PROPERTY_ON = 0x0004,
    /*!< \brief stop VIP perform network */
    VIPDRV_POWER_PROPERTY_STOP = 0x0008,
    /*!< \brief start VIP perform network */
    VIPDRV_POWER_PROPERTY_START = 0x0010,
    VIPDRV_POWER_DISABLE_TIMER = 0x10000,
    VIPDRV_POWER_ENABLE_TIMER = 0x20000,
} vipdrv_power_property_e;

typedef enum _vipdrv_cache_type {
    VIPDRV_CACHE_NONE = 0,
    VIPDRV_CACHE_FLUSH = 1,
    VIPDRV_CACHE_CLEAN = 2,
    VIPDRV_CACHE_INVALID = 3,
    VIPDRV_CACHE_MAX = 4,
} vipdrv_cache_type_e;

typedef enum _vipdrv_work_mode_event {
    VIPDRV_WORK_MODE_NORMAL = 0,
    VIPDRV_WORK_MODE_SECURITY = 1,
} vipdrv_work_mode_e;

#if vpmdENABLE_CAPTURE || (vpmdENABLE_HANG_DUMP > 1)
typedef enum _vipdrv_register_dump_type {
    VIPDRV_REGISTER_DUMP_READ = 0x00,
    VIPDRV_REGISTER_DUMP_WRITE = 0x01,
    VIPDRV_REGISTER_DUMP_WAIT = 0x02,
    VIPDRV_REGISTER_DUMP_SUBSYS = 0x04,
    VIPDRV_REGISTER_DUMP_UNKNOWN = 0x04
} vipdrv_register_dump_type_e;
#endif

typedef enum _vipdrv_task_property_e {
    VIPDRV_TASK_PROP_CMD_INFO = 0,
    VIPDRV_TASK_PROP_PATCH_INFO = 1,
    VIPDRV_TASK_PROP_PATCH_INFO_DUP = 2,
    VIPDRV_TASK_PROP_ATTRIBUTE = 3,
    VIPDRV_TASK_PROP_TIMEOUT = 4,
    VIPDRV_TASK_PROP_FEATURE_BIT = 5,
    VIPDRV_TASK_PROP_FLEXA_DMA = 6,
} vipdrv_task_property_e;

typedef enum _vipdrv_task_cmd_type_e {
    VIPDRV_TASK_CMD_SUBTASK = 0,
    VIPDRV_TASK_CMD_INIT = 1,
    VIPDRV_TASK_CMD_PRELOAD = 2,
} vipdrv_task_cmd_type_e;

typedef enum _vipdrv_task_patch_type_e {
    VIPDRV_TASK_PATCH_SYNC = 0,
    VIPDRV_TASK_PATCH_CHIP = 1,
} vipdrv_task_patch_type_e;

typedef struct _vipdrv_initialize {
    vip_uint32_t video_mem_size;
    vip_uint32_t version;
} vipdrv_initialize_t;

typedef struct _vipdrv_allocation {
    vip_uint64_t logical;   /* the logical address in user space */
    vip_uint32_t mem_id;    /* id of the video memory in vip-drv */
    vip_address_t physical; /* the VIP physical or virtual addess */
    vip_size_t size;
    vip_uint32_t align;
    vip_uint32_t alloc_flag;   /* see vipdrv_video_mem_alloc_flag_e */
    vip_uint32_t device_index; /* indicate created for which device */
    vip_uint64_t device_vis;   /* indicate which device can access this memory */
    vip_uint8_t specified;     /* specify the VIP virtual or physical address. */
    vip_uint32_t task_id;      /* specify the task id to use related mmu page */
} vipdrv_allocation_t;

typedef struct _vipdrv_deallocation {
    vip_uint32_t mem_id; /* the id of video memory in vip-drv */
} vipdrv_deallocation_t;

typedef struct _vipdrv_lock_video_mem {
    vip_uint32_t mem_id;    /* id of the video memory in vip-drv */
    vip_address_t physical; /* the VIP physical or virtual addess */
    vip_size_t size;
    vip_uint32_t align;
    vip_uint32_t alloc_flag;   /* see vipdrv_video_mem_alloc_flag_e */
    vip_uint32_t device_index; /* indicate created for which device */
    vip_uint64_t device_vis;   /* indicate which device can access this memory */
    vip_uint32_t task_id;      /* specify the task id to use related mmu page */
} vipdrv_lock_video_mem_t;

typedef struct _vipdrv_wrap_user_memory {
    /* user space logical address */
    vip_uint64_t logical;
    /* the id of video memory */
    vip_uint32_t mem_id;
    /* The type of this VIP buffer memory. see vip_buffer_from_user_mem_type_e*/
    vip_uint32_t memory_type;
    /* the size of wrap memory */
    vip_size_t size;
    /* indicate which device can access this memory */
    vip_uint64_t device_vis;
    /* indicate created for which device */
    vip_uint32_t device_index;
    /* the VIP physical or virtual addess */
    vip_address_t virtual_addr;
} vipdrv_wrap_user_memory_t;

typedef struct _vipdrv_wrap_user_fd {
    /* user space logical address */
    vip_uint32_t fd;
    /* The type of this VIP buffer memory. see vip_buffer_from_fd_type_e*/
    vip_uint32_t memory_type;
    /* the size of wrap memory */
    vip_size_t size;
    /* indicate which device can access this memory */
    vip_uint64_t device_vis;
    /* indicate created for which device */
    vip_uint32_t device_index;
    /* the VIP physical or virtual addess */
    vip_address_t virtual_addr;
    /* the id of the video memory */
    vip_uint32_t mem_id;
    /* user space logical base address */
    vip_uint64_t logical;
} vipdrv_wrap_user_fd_t;

typedef struct _vipdrv_wrap_user_physical {
    /*If memory_type is VIP_BUFFER_FROM_PHY_TYPE_HOST, the physical_table is CPU physical.
      If memory_type is VIP_BUFFER_FROM_PHY_TYPE_DEVICE, the physical_table is NPU physical*/
    vip_address_t physical_table[MAX_WRAP_USER_PHYSICAL_TABLE_SIZE];
    /* the size of physical table each element */
    vip_size_t size_table[MAX_WRAP_USER_PHYSICAL_TABLE_SIZE];
    /* the number of physical table element */
    vip_uint32_t physical_num;
    /* the type of this VIP buffer memory. see vip_buffer_from_phy_type_e */
    vip_uint32_t memory_type;
    /* indicate which device can access this memory */
    vip_uint64_t device_vis;
    /* indicate created for which device */
    vip_uint32_t device_index;
    /* the id of video memory */
    vip_uint32_t mem_id;
    /* the VIP physical or virtual addess */
    vip_address_t virtual_addr;
    /* the logical address in user space */
    vip_uint64_t logical;
    /* see vipdrv_video_mem_alloc_flag_e */
    vip_uint32_t alloc_flag;
} vipdrv_wrap_user_physical_t;

typedef struct _vipdrv_wrap_videomemory {
    vip_uint32_t src_mem_id;   /* id of the source video memory in vip-drv */
    vip_uint32_t task_id;      /* specify the task id to use related mmu page */
    vip_uint32_t device_index; /* indicate created for which device */
    vip_uint64_t logical;      /* the logical address in user space */
    vip_uint32_t mem_id;       /* id of the video memory in vip-drv */
    vip_address_t physical;    /* the VIP physical or virtual addess */
} vipdrv_wrap_videomemory_t;

typedef struct _vipdrv_map_user_logical {
    vip_uint64_t logical; /* the logical address in user space */
    vip_uint32_t mem_id;
} vipdrv_map_user_logical_t;

typedef struct _vipdrv_unmap_user_logical {
    /* the id of video memory user space should be unmap */
    vip_uint32_t mem_id;
} vipdrv_unmap_user_logical_t;

typedef struct _vipdrv_reg {
    vip_uint32_t dev_index;  /* the index of device */
    vip_uint32_t core_index; /* the index hardware core in device */
    vip_uint32_t reg;        /* register address */
    vip_uint32_t data;       /* read/wrote data of the register */
} vipdrv_reg_t;

typedef struct _vipdrv_query_address_info {
    /* the user space logical address of wait-link buffer */
    vip_uint64_t waitlink_logical;
    /* the physical address of wait-link buffer */
    vip_uint32_t waitlink_physical;
    /* the size of wait-link buffer */
    vip_uint32_t waitlink_size;
} vipdrv_query_address_info_t;

typedef struct _vipdrv_query_database {
    vip_uint32_t vip_sram_base;
    /* the size of vip-sram for per-core */
    vip_uint32_t vip_sram_size[vipdMP_NUM];
    /* mmu enabled: the VIP's virtual address, mmu disabled: the VIP's physical address */
    vip_virtual_t axi_sram_base;
    vip_uint32_t axi_sram_size[vipdMAX_DEVICE_NUM];
#if vpmdENABLE_SYS_MEMORY_HEAP
    /* the size of system heap */
    vip_uint32_t sys_heap_size;
#endif
    /* hardware customer ID */
    vip_uint32_t hw_cid;
    /* the logical vip device number */
    vip_uint32_t device_count;
    /* the hardware type */
    vip_uint32_t hw_type;
} vipdrv_query_database_t;

typedef struct _vipdrv_query_driver_status {
    vip_uint32_t device_index;
    /* the number of user space commit command buffer */
    vip_uint32_t commit_count;

    /* hardware initialize commands. init states command in vipdrv */
    vip_uint32_t init_cmd_handle;
    vip_uint32_t init_cmd_size;
    vip_address_t init_cmd_physical;
} vipdrv_query_driver_status_t;

typedef struct _vipdrv_operate_cache {
    /* the if of video memory should be flushed */
    vip_uint32_t mem_id;
    /* operate CPU cache type, flush/clean/invalid */
    vipdrv_cache_type_e type;
} vipdrv_operate_cache_t;

typedef struct _vipdrv_power_management {
    /* see vip_power_property_e */
    vip_enum property;
    /* only for property is VIP_POWER_PROPERTY_SET_FREQUENCY.
        other property, fscale_percent is useless */
    vip_uint8_t fscale_percent;
    vip_uint32_t device_index;
} vipdrv_power_management_t;

#define MAX_STLB_MEM_CNT 16
typedef struct _vipdrv_query_mmu_info {
    vip_uint32_t entry_mem_id;
    vip_uint32_t mtlb_mem_id;
    vip_uint32_t stlb_mem_id[MAX_STLB_MEM_CNT];
    vip_uint32_t entry_size;
    vip_uint32_t mtlb_size;
    vip_size_t stlb_size[MAX_STLB_MEM_CNT];
    vip_physical_t entry_physical;
    vip_physical_t mtlb_physical;
    vip_physical_t stlb_physical[MAX_STLB_MEM_CNT];
    vip_uint32_t device_index;
    vip_uint32_t task_id;
} vipdrv_query_mmu_info_t;

typedef struct _vipdrv_query_profiling {
    vip_uint32_t task_id;
    vip_uint32_t subtask_index;
    /* return values cycle */
    vip_uint32_t total_cycle[vipdMP_NUM];
    vip_uint32_t total_idle_cycle[vipdMP_NUM];
    /* return bw */
    vip_uint32_t total_read[vipdMP_NUM];
    vip_uint32_t total_write[vipdMP_NUM];
    vip_uint32_t total_read_ocb[vipdMP_NUM];
    vip_uint32_t total_write_ocb[vipdMP_NUM];
    /* inference_time xxx us */
    vip_uint32_t inference_time;
} vipdrv_query_profiling_t;

typedef struct _vipdrv_query_register_dump {
    vip_physical_t physical;
    vip_uint32_t mem_id;
    vip_uint32_t count;
} vipdrv_query_register_dump_t;

typedef struct _vipdrv_query_device_info {
    /* the index of device info should be query */
    vip_uint32_t device_index;
    /* A bitmap indicates that this device can share video memory with which devices */
    vip_uint64_t share_mem_device_vis;

    /* the  numbers of core for this device */
    vip_uint32_t core_count;
    /* the core id for this device */
    vip_uint32_t core_id[vipdMP_NUM];
} vipdrv_query_device_info_t;

#define TASK_NAME_LENGTH 16
typedef struct _vipdrv_create_task_param {
    /* the id of task, return a unique task id after creating task */
    vip_uint32_t task_id;
    /* the name of task */
    vip_char_t task_name[TASK_NAME_LENGTH];
    /* the maximium count of sub task */
    vip_uint32_t subtask_count;
} vipdrv_create_task_param_t;

typedef struct _vipdrv_destroy_task_param {
    vip_uint32_t task_id;
} vipdrv_destroy_task_param_t;

typedef struct _vipdrv_query_task_param {
    vip_uint32_t task_id;
    /* return parameters */
    vip_uint32_t core_index;
} vipdrv_query_task_param_t;

typedef struct _vipdrv_set_task_property {
    /* the id of task should be set property */
    vip_uint32_t task_id;
    /* the property of task, vipdrv_task_property_e */
    vip_uint32_t property;
    /* the index of the subtask */
    vip_uint32_t index;
    union {
        struct {
            /* cmd type, vipdrv_task_cmd_type_e */
            vip_uint32_t type;
            /* a mem_id of video memory for command */
            vip_uint32_t cmd_id;
            /* the real size of command for subtask */
            vip_uint32_t size;
            /* the patch count of current command */
            vip_uint32_t patch_count;
            /* the index of core for the subtask default runs on */
            vip_uint32_t core_index;
        } cmd_info;

        struct {
            /* patch type, vipdrv_task_patch_type_e */
            vip_uint32_t type;
            /* the patch index */
            vip_uint32_t patch_index;
            /* the size of command will be patched */
            vip_uint32_t size;
            /* the index of core in all used cores */
            vip_uint32_t core_index;
            /* the core count of this patch uses */
            vip_uint32_t core_count;
            /* the offset in command */
            vip_uint32_t offset;
        } patch_info;

        struct {
            /* the id of task should be set property */
            vip_uint32_t task_id;
            /* the index of the subtask */
            vip_uint32_t index;
        } dup_info;

        struct {
            /* 0: cnn_profile is disabled, 1: enabled */
            vip_uint32_t cnn_profile:1;
            /* 1: bypass trigger hardware */
            vip_uint32_t bypass_sbmit:1;
            /* 1: preload coeff to vip-sram */
            vip_uint32_t preload_vipsram:1;
        } feature_bit;

        struct {
            vip_uint64_t cycle;
            /* the size of vip-sram used by the task */
            vip_uint32_t vip_sram_size;
        } attr;
        vip_uint64_t value_info;
    } param;
} vipdrv_set_task_property_t;

typedef struct _vipdrv_submit_task_param {
    vip_uint32_t task_id;
    vip_uint32_t subtask_index;
    vip_uint32_t subtask_cnt;
    vip_uint32_t device_index;
    vip_uint32_t core_index;
    vip_uint32_t core_cnt;
#if vpmdENABLE_PREEMPTION
    vip_uint8_t priority;
#endif
    vip_uint8_t need_schedule;
} vipdrv_submit_task_param_t;

typedef struct _vipdrv_wait_task_param {
    vip_uint32_t task_id;
    vip_uint32_t subtask_index;
    vip_uint32_t timeout;
} vipdrv_wait_task_param_t;

typedef struct _vipdrv_cancel_task_param {
    vip_uint32_t task_id;
    vip_uint32_t subtask_index;
} vipdrv_cancel_task_param_t;

typedef enum _vip_hardware_feature_e {
    VIP_FEATURE_JOB_CANCEL = 0,
    VIP_FEATURE_MMU_PDMODE = 1,
    VIP_FEATURE_FREQ_SCALE = 2,
    VIP_FEATURE_NN_ERROR_DETECT = 3,
    VIP_FEATURE_KENERL_DESC = 4,
    VIP_FEATURE_NN_TRANS_PHASE2 = 5,
    VIP_FEATURE_NN_CORE_CNT = 6,
    VIP_FEATURE_TP_CORE_CNT = 7,
    VIP_FEATURE_VIPSRAM_WIDTH = 8,
    VIP_FEATURE_LATENCY_HIDING_FULL_AXI_BW = 9,
    VIP_FEATURE_MIN_AXI_BURST_SIZE = 10,
    VIP_FEATURE_DDR_KERNEL_BURST_SIZE = 11,
    VIP_FEATURE_AXI_BUS_WIDTH = 12,
    VIP_FEATURE_OCB_COUNTER = 13,
    VIP_FEATURE_NN_PROBE = 14,
    VIP_FEATURE_SH_CONFORMANCE_BRUTEFORCE = 15,
    VIP_FEATURE_MMU = 16,
    VIP_FEATURE_MMU_40VA = 17,
    VIP_FEATURE_NN_XYDP0 = 18,
    VIP_FEATURE_VIPSRAM_SHARE = 19,
    VIP_FEATURE_VIPSRAM_SIZE = 20,
    VIP_FEATURE_NN_COMMAND_SIZE = 21,
    VIP_FEATURE_UNIQUE_ID = 22,
    VIP_FEATURE_CHIP_REVISION = 23,
    VIP_FEATURE_MAX
} vip_hardware_feature_e;

#if (vpmdENABLE_DEBUG_LOG >= 0)
static const vip_char_t ioctl_cmd_string[VIPDRV_INTRFACE_MAX + 1][48] = {
            "VIPDRV_INIT",
            "VIPDRV_DESTROY",             /* 1 */
            "VIPDRV_READ_REG",            /* 2 */
            "VIPDRV_WRITE_REG",           /* 3 */
            "VIPDRV_WAIT_TASK",           /* 4 */
            "VIPDRV_SUBMIT_TASK",         /* 5 */
            "VIPDRV_ALLOCATION",          /* 6 */
            "VIPDRV_DEALLOCATION",        /* 7 */
            "VIPDRV_NOT_USED",            /* 8 */
            "VIPDRV_NOT_USED",            /* 9 */
            "VIPDRV_QUERY_DATABASE",      /* 10 */
            "VIPDRV_OPERATE_CACHE",       /* 11 */
            "VIPDRV_WRAP_USER_MEMORY",    /* 12 */
            "VIPDRV_NOT_USED",            /* 13 */
            "VIPDRV_NOT_USED",            /* 14 */
            "VIPDRV_POWER_MANAGEMENT",    /* VIPDRV_INTRFACE_POWER_MANAGEMENT */
            "VIPDRV_WRAP_USER_PHYSICAL",  /* VIPDRV_INTRFACE_WRAP_USER_PHYSICAL */
            "VIPDRV_NOT_USED",            /* 17 */
            "VIPDRV_WRAP_USER_FD",        /* 18 */
            "VIPDRV_NOT_USED",            /* 19 */
            "VIPDRV_QUERY_PROFILING",     /* 20 */
            "VIPDRV_QUERY_DRIVER_STATUS", /* 21 */
            "VIPDRV_QUERY_MMU_INFO",      /* 22 */
            "VIPDRV_MAP_USER_LOGICAL",    /* 23 */
            "VIPDRV_UNMAP_USER_LOGICAL",  /* 24 */
            "VIPDRV_CANCEL",              /* 25 */
            "VIPDRV_QUERY_REGISTER_DUMP", /* 26 */
            "VIPDRV_CREATE_TASK",         /* 27 */
            "VIPDRV_SET_TASK_PROPERTY",   /* 28 */
            "VIPDRV_DESTROY_TASK",        /* 29 */
            "VIPDRV_WRAP_VIDEO_MEMORY",   /* 30 */
            "VIPDRV_QUERY_TASK",          /* 31 */
            "VIPDRV_QUERY_DEVICE_INFO",   /* 32 */
            "VIPDRV_LOCK_VIDEO_MEMORY",   /* 33 */
            "VIPDRV_INTRFACE_MAX"};
#endif
#endif
