/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#include <vip_drv_device.h>
#if vpmdENABLE_POWER_MANAGEMENT
#include <vip_drv_pm.h>
#endif
#include <vip_drv_video_memory.h>
#include <vip_drv_context.h>
#if vpmdENABLE_MMU
#include <vip_drv_mmu.h>
#endif

/*
@brief Get hardware object from device.
*/
vipdrv_hardware_t* vipdrv_get_hardware(vipdrv_device_t* device, vip_uint32_t core_index)
{
    vipdrv_hardware_t* hardware = VIP_NULL;

    if (core_index < device->hardware_count) {
        hardware = &device->hardware[core_index];
    } else {
        PRINTK_E("get hw%d from dev%d, total core_cnt=%d\n", core_index, device->device_index,
                 device->hardware_count);
    }

    return hardware;
}

vipdrv_device_t* vipdrv_get_device(vip_uint32_t device_index)
{
    vipdrv_device_t* device = VIP_NULL;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);

    if (device_index < context->device_count) {
        device = &context->device[device_index];
    } else {
        PRINTK_E("get device%d, total dev_cnt=%d\n", device_index, context->device_count);
    }

    return device;
}

vip_status_e vipdrv_device_hw_reset(vipdrv_device_t* device)
{
    vip_status_e status = VIP_SUCCESS;

    VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)
    status = vipdrv_hw_reset(hw);
    if (status != VIP_SUCCESS) {
        PRINTK_E("software reset hardware, status=%d.\n", status);
        vipGoOnError(status);
    }
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_END

onError:
    return status;
}

vip_status_e vipdrv_device_hw_init(vipdrv_device_t* device)
{
    vip_status_e status = VIP_SUCCESS;

    VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)
#if vpmdENABLE_POWER_MANAGEMENT
#if vpmdPOWER_OFF_TIMEOUT
    vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_DISABLE_TIMER, VIP_NULL);
#endif
    vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_ON, VIP_NULL);
#endif

    status = vipdrv_hw_init(hw);
    if (status != VIP_SUCCESS) {
        PRINTK_E("hardware initialize, status=%d.\n", status);
        vipGoOnError(status);
    }

#if vpmdENABLE_POWER_MANAGEMENT
    vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_OFF, VIP_NULL);
#if vpmdPOWER_OFF_TIMEOUT
    vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_ENABLE_TIMER, VIP_NULL);
#endif
#endif
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_END

onError:
    return status;
}

/*
@brief To run any initial commands after clock on / power on.
    remap SRAM, configure USC, configure debug mode.
*/
vip_status_e vipdrv_device_prepare_initcmd(vipdrv_device_t* device)
{
    vipdrv_context_t* context = device->context;
    vip_uint32_t cmd_size = sizeof(vip_uint32_t) * (22);
    vip_uint32_t* logical = VIP_NULL;
    vip_uint32_t buf_size = 0;
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t count = 0;
    vip_uint32_t reg_data = 0;
    vip_uint32_t alloc_flag = VIPDRV_VIDEO_MEM_ALLOC_MAP_KERNEL | VIPDRV_VIDEO_MEM_ALLOC_CONTIGUOUS |
                              VIPDRV_VIDEO_MEM_ALLOC_4GB_ADDR | VIPDRV_VIDEO_MEM_ALLOC_NPU_READ_ONLY;
    vip_physical_t physical_tmp = 0;
    vip_uint32_t axi_sram_size = 0;
    vip_uint32_t vip_sram_size = vipdrv_context_query_featureDB(VIP_FEATURE_VIPSRAM_SIZE);
    vip_uint32_t i = 0;
    vip_address_t axi_sram_address = 0;
    vipdrv_mmu_id_t mmu_id = {0};
    vip_uint8_t share_vip_sram_offset = 0;

    if (vip_true_e == vipdrv_context_query_featureDB(VIP_FEATURE_NN_XYDP0)) {
#if vpmdENABLE_MMU
        axi_sram_address = context->axi_sram_address;
#else
        axi_sram_address = context->axi_sram_physical;
#endif
    } else {
        axi_sram_address = context->axi_sram_physical;
    }
    if ((context->core_count > 1) &&
        (vip_true_e == vipdrv_context_query_featureDB(VIP_FEATURE_VIPSRAM_SHARE))) {
        share_vip_sram_offset = 1;
    }

#if !vpmdENABLE_VIDEO_MEMORY_CACHE
    alloc_flag |= VIPDRV_VIDEO_MEM_ALLOC_NONE_CACHE;
#endif
    PRINTK_I("start prepare init commands\n");

    for (i = 0; i < context->device_count; i++) {
        axi_sram_size += context->axi_sram_size[i];
    }
    if (axi_sram_size > 0) {
        cmd_size += sizeof(vip_uint32_t) * 4;
        if (0xff00000000 & (axi_sram_address + axi_sram_size)) {
            cmd_size += sizeof(vip_uint32_t) * 2;
        }
    }
    if (vip_sram_size > 0) {
        cmd_size += sizeof(vip_uint32_t) * 2;
    }
    if (1 == share_vip_sram_offset) {
        cmd_size += sizeof(vip_uint32_t) * context->core_count * 6;
    }
    if (vipdrv_context_query_featureDB(VIP_FEATURE_TP_CORE_CNT)) {
        cmd_size += sizeof(vip_uint32_t) * 16;
    }

    buf_size = cmd_size + APPEND_COMMAND_SIZE;
    buf_size = VIP_ALIGN(buf_size, vpmdCPU_CACHE_LINE_SIZE);
#if vpmdENABLE_MMU
    mmu_id = gen_mmu_id(0, 0, device->mem_prop->index);
#endif
    vipOnError(vipdrv_mem_allocate_videomemory(buf_size, &device->init_command.mem_id, (void**)&logical,
                                               &physical_tmp, vipdMEMORY_ALIGN_SIZE, alloc_flag, mmu_id,
                                               (vip_uint64_t)1 << device->device_index, 0));
    PRINTK_D("dev%d init cmd mem_id=0x%x size=%u pa=0x%"PRIx64"\n", device->device_index,
             device->init_command.mem_id, buf_size, physical_tmp);
    vipdrv_os_zero_memory(logical, buf_size);
    device->init_command.logical = (void*)logical;
    device->init_command.physical = (vip_uint32_t)physical_tmp;
    device->init_command.size = buf_size;

    logical[count++] = 0x0801028A;
    logical[count++] = 0x00000011;
    logical[count++] = 0x08010E13;
    logical[count++] = 0x00000002;
    logical[count++] = 0x08010E12; /* nn/tp debug register */
    reg_data = VIP_SETBIT(0, 16, 1) | VIP_SETBIT(0, 27, 1) | VIP_SETBIT(0, 28, 1);
    logical[count++] = reg_data;

    if (vipdrv_context_query_featureDB(VIP_FEATURE_TP_CORE_CNT)) {
        logical[count++] = 0x08010E55;
        logical[count++] = VIP_SETBIT(0, 16, 1) | VIP_SETBITS(0, 24, 25, 3) | 0x0;
        logical[count++] = 0x08010E55;
        logical[count++] = VIP_SETBIT(0, 16, 1) | VIP_SETBITS(0, 24, 25, 3) | 0x1;
        logical[count++] = 0x08010E55;
        logical[count++] = VIP_SETBIT(0, 16, 1) | VIP_SETBITS(0, 24, 25, 3) | 0x2;
        logical[count++] = 0x08010E55;
        logical[count++] = VIP_SETBIT(0, 16, 1) | VIP_SETBITS(0, 24, 25, 3) | 0x3;
        logical[count++] = 0x08010E55;
        logical[count++] = VIP_SETBIT(0, 16, 1) | VIP_SETBITS(0, 24, 25, 3) | 0x4;
        logical[count++] = 0x08010E55;
        logical[count++] = VIP_SETBIT(0, 16, 1) | VIP_SETBITS(0, 24, 25, 3) | 0x5;
        logical[count++] = 0x08010E55;
        logical[count++] = VIP_SETBIT(0, 16, 1) | VIP_SETBITS(0, 24, 25, 3) | 0x6;
        logical[count++] = 0x08010E55;
        logical[count++] = VIP_SETBIT(0, 16, 1) | VIP_SETBITS(0, 24, 25, 3) | 0x7;
    }

    logical[count++] = 0x08010E21;
    logical[count++] = 0x00020000;
    logical[count++] = 0x08010e02;
    logical[count++] = 0x00000701;
    logical[count++] = 0x48000000;
    logical[count++] = 0x00000701;
    logical[count++] = 0x0801022c;
    logical[count++] = 0x0000001f;

    if (1 == share_vip_sram_offset) {
        vip_uint32_t offset = 0;
        for (i = 0; i < context->core_count; i++) {
            logical[count++] = 0x68000000 | (1 << i);
            logical[count++] = 0x0;
            logical[count++] = 0x080169BA;
            logical[count++] = offset;
            logical[count++] = 0x6800FFFF;
            logical[count++] = 0;
            offset += vip_sram_size / context->core_count;
        }
    }
    if (VIP_HARDWARE_LLM == context->hw_type) {
        logical[count++] = 0x08017B41;
        logical[count++] = context->vip_sram_address;
    } else {
        logical[count++] = 0x08010e4e;
        logical[count++] = context->vip_sram_address;
    }
    if (axi_sram_size > 0) {
        vipdrv_address_value_t axi_value_start, axi_value_end;
        vip_address_t axi_sram_address_end = axi_sram_address + axi_sram_size;
        axi_value_start.low = axi_value_end.low = 0;
        axi_value_start.high = axi_value_end.high = 0;
        vipdrv_os_copy_memory(&axi_value_start, &axi_sram_address, sizeof(vip_address_t));
        vipdrv_os_copy_memory(&axi_value_end, &axi_sram_address_end, sizeof(vip_address_t));
        logical[count++] = 0x08010e4f;
        logical[count++] = axi_value_start.low;
        logical[count++] = 0x08010e50;
        logical[count++] = axi_value_end.low + axi_sram_size;
        if (0xff00000000 & (axi_sram_address + axi_sram_size)) {
            vip_uint32_t tmp = 0;
            logical[count++] = 0x08010e59;
            tmp = VIP_SETBITS(tmp, 8, 15, axi_value_start.high);
            tmp = VIP_SETBITS(tmp, 16, 23, axi_value_end.high);
            logical[count++] = tmp;
        }
    }
    logical[count++] = 0x08010e02;
    logical[count++] = 0x30000701;
    logical[count++] = 0x48000000;
    logical[count++] = 0x30000701;
    logical[count++] = 0x10000000;
    logical[count++] = 0;
    cmd_size = count * sizeof(vip_uint32_t);
    device->init_command_size = cmd_size;

    if (cmd_size > buf_size) {
        PRINTK_E("init commands, size is overflow\n");
        vipGoOnError(VIP_ERROR_OUT_OF_MEMORY);
    }

#if vpmdENABLE_VIDEO_MEMORY_CACHE
    vipdrv_mem_flush_cache(device->init_command.mem_id, VIPDRV_CACHE_FLUSH);
#endif
onError:
    return status;
}

vip_status_e vipdrv_device_wait_idle(vipdrv_device_t* device, vip_uint32_t timeout, vip_uint8_t is_fast)
{
    vip_status_e status = VIP_SUCCESS;

    VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)
#if vpmdENABLE_POWER_MANAGEMENT
    if (VIPDRV_POWER_ON & hw->pwr_management.state)
#endif
    {
#if vpmdENABLE_CLOCK_SUSPEND
        vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_ON, VIP_NULL);
#endif
        /* hardware is idle status, power off hardware immediately */
        status |= vipdrv_hw_wait_idle(hw, timeout, is_fast, EXPECT_IDLE_VALUE_ALL_MODULE);
#if vpmdENABLE_CLOCK_SUSPEND
        vipdrv_pm_send_evnt(hw, VIPDRV_PWR_EVNT_CLK_OFF, VIP_NULL);
#endif
        if (status != VIP_SUCCESS) {
            PRINTK_E("error, VIP not going to idle.\n");
        }
    }
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_END
    return status;
}
