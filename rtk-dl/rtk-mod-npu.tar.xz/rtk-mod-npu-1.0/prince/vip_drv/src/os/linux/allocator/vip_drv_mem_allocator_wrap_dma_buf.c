/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#undef VIPDRV_LOG_ZONE
#define VIPDRV_LOG_ZONE VIPDRV_LOG_ZONE_VIDEO_MEMORY

#include <linux/dma-buf.h>
#include <linux/dma-mapping.h>

#include "vip_drv_mem_allocator.h"
#include "vip_drv_video_memory.h"
#include "vip_drv_mem_allocator_common.h"
#include "vip_drv_vipcore_device.h"

vip_status_e allocator_init_wrap_dma_buf(vipdrv_allocator_t* allocator, vip_char_t* name,
                                         vipdrv_allocator_type_e type);

static vip_status_e vipdrv_wrap_dma_buf_map_kernel_logical(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_ERROR_NOT_SUPPORTED;
    PRINTK_E("not support map kernel logical wrap dma buffer\n");
    return status;
}

static vip_status_e vipdrv_wrap_dma_buf_unmap_kernel_logical(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    ptr->kerl_logical = VIP_NULL;
    ptr->mem_flag &= ~VIPDRV_MEM_FLAG_MAP_KERNEL_LOGICAL;
    return status;
}

static vip_status_e vipdrv_wrap_dma_buf_map_user_logical(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vipdrv_allocator_t* allocator = ptr->allocator;
    vip_uint32_t device_index = vipdrv_mem_get_devindex(handle->device_vis);
    vip_physical_t physical = allocator->callback.phy_vip2cpu(device_index, ptr->physical_table[0]);
    vip_uint32_t page_offset = GET_PAGE_OFFSET(physical);
    void* user_logical = VIP_NULL;
    struct page** pages = VIP_NULL;
    vip_uint32_t page_count = 0;

    vipdrv_get_page_count(ptr, &page_count);
    vipOnError(vipdrv_os_allocate_memory(sizeof(struct page*) * page_count, (void**)&pages));
    vipdrv_os_zero_memory(pages, sizeof(struct page*) * page_count);
    vipOnError(vipdrv_fill_pages(ptr, pages));
    /* May need to be modified if the memory properties of dma-buf */
    vipOnError(vipdrv_map_user(page_count, pages, &user_logical, vip_true_e));

    ptr->user_logical = (void*)((vip_uint8_t*)user_logical + page_offset);
    ptr->mem_flag |= VIPDRV_MEM_FLAG_MAP_USER_LOGICAL;
    ptr->pid = vipdrv_os_get_pid();
    vipdrv_os_free_memory(pages);
    return status;
onError:
    PRINTK_E("map user logical wrap dma buffer\n");
    if (VIP_NULL != pages) {
        vipdrv_os_free_memory(pages);
        pages = VIP_NULL;
    }
    return status;
}

static vip_status_e vipdrv_wrap_dma_buf_unmap_user_logical(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vip_uint32_t page_count = 0;

    if (ptr->pid == vipdrv_os_get_pid()) {
        vipdrv_get_page_count(ptr, &page_count);
        vipdrv_unmap_user(page_count,
                          VIPDRV_UINT64_TO_PTR(VIPDRV_PTR_TO_UINT64(ptr->user_logical) & PAGE_MASK));
        ptr->user_logical = VIP_NULL;
        ptr->mem_flag &= ~VIPDRV_MEM_FLAG_MAP_USER_LOGICAL;
        ptr->pid = 0;
    }

    return status;
}

#if vpmdENABLE_FLUSH_CPU_CACHE
static vip_status_e vipdrv_wrap_dma_buf_flush_cache(vipdrv_video_mem_phy_handle_t* handle, vip_uint8_t type)
{
    vip_status_e status = VIP_SUCCESS;

    return status;
}
#endif

static vip_status_e vipdrv_wrap_dma_buf_mem_alloc(vipdrv_video_mem_phy_handle_t* handle,
                                                  vipdrv_alloc_param_ptr param)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_phy_device_t* phy_dev = vipdrv_get_phy_device(MULTI_DEVICE_ENABLE_ID);
    vipdrv_allocator_wrapfd_param_t* wrap_param = (vipdrv_allocator_wrapfd_param_t*)param;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vipdrv_allocator_t* allocator = ptr->allocator;
    vip_uint32_t page_count = 0;
    vipdrv_dma_buf_info_t* import = VIP_NULL;
    struct scatterlist* s = VIP_NULL;
    struct sg_table* sgt = VIP_NULL;
    vip_uint32_t count = 0;
    vip_uint32_t i = 0;
    vip_uint32_t dmabuf_size = 0;
    vip_bool_e physical_contiguous = vip_true_e;
    vip_physical_t* cpu_physical = VIP_NULL;
    vip_uint32_t fd = wrap_param->fd;
    vip_uint32_t device_index = vipdrv_mem_get_devindex(handle->device_vis);
    ptr->size = wrap_param->size;

    vipOnError(vipdrv_os_allocate_memory(sizeof(vipdrv_dma_buf_info_t), (void**)&import));
    import->dma_buf = dma_buf_get(fd);
    if (IS_ERR_OR_NULL(import->dma_buf)) {
        PRINTK_E("wrap fd dma_buf_get, fd=%d\n", fd);
        vipGoOnError(VIP_ERROR_IO);
    }
    dma_buf_put(import->dma_buf);

    get_dma_buf(import->dma_buf);

    import->dma_attachment = dma_buf_attach(import->dma_buf, phy_dev->device);
    if (!import->dma_attachment) {
        PRINTK_E("wrap fd dma_buf_attach\n");
        vipGoOnError(VIP_ERROR_IO);
    }

    sgt = import->sgt = dma_buf_map_attachment(import->dma_attachment, DMA_BIDIRECTIONAL);
    if (IS_ERR_OR_NULL(import->sgt)) {
        PRINTK_E("wrap fd dma_buf_map_attachment\n");
        vipGoOnError(VIP_ERROR_IO);
    }

    /* Get number of pages. */
    for_each_sg(sgt->sgl, s, sgt->orig_nents, i)
    {
        page_count += (sg_dma_len(s) + (vip_uint32_t)(sg_dma_address(s) & (~PAGE_MASK)) + PAGE_SIZE - 1) /
                      PAGE_SIZE;
        PRINTK_D("dmabuf[%d] address=0x%"PRIx64", size=0x%x\n", count, sg_dma_address(s), sg_dma_len(s));
        count++;
        dmabuf_size += sg_dma_len(s);
    }
    count = 0;

    if (ptr->size > dmabuf_size) {
        PRINTK_E("wrap user fd=%d, dmabug size %d is small than request %lld\n", fd, dmabuf_size, ptr->size);
        vipGoOnError(VIP_ERROR_OUT_OF_MEMORY);
    }
    ptr->size = dmabuf_size;

    PRINTK_D("import dma-buf page_count=%d\n", page_count);
    vipOnError(vipdrv_os_allocate_memory(sizeof(vip_physical_t) * page_count, (void**)&ptr->physical_table));
    vipdrv_os_zero_memory(ptr->physical_table, sizeof(vip_physical_t) * page_count);
    vipOnError(vipdrv_os_allocate_memory(sizeof(vip_physical_t) * page_count, (void**)&cpu_physical));
    vipdrv_os_zero_memory(cpu_physical, sizeof(vip_physical_t) * page_count);
    vipOnError(vipdrv_os_allocate_memory(sizeof(vip_size_t) * page_count, (void**)&ptr->size_table));
    vipdrv_os_zero_memory(ptr->size_table, sizeof(vip_size_t) * page_count);

    /* Fill page array. */
    i = 0;
    for_each_sg(sgt->sgl, s, sgt->orig_nents, i)
    {
        vip_physical_t address = sg_dma_address(s);
        vip_uint32_t size = sg_dma_len(s);

        while (size) {
            vip_uint32_t tmp = PAGE_SIZE - (address & (~PAGE_MASK));
            tmp = size < tmp ? size : tmp;

            cpu_physical[count] = address;
            ptr->size_table[count] = tmp;

            address += tmp;
            size -= tmp;
            count++;
        }
    }

    for (i = 1; i < count; i++) {
        if (__phys_to_pfn(cpu_physical[i]) != (__phys_to_pfn(cpu_physical[i - 1]) + 1)) {
            physical_contiguous = vip_false_e;
            break;
        }
    }

    if (physical_contiguous) {
        /* all physical memory is contiguous */
        ptr->size_table[0] = dmabuf_size;
        ptr->physical_num = 1;
    } else {
        ptr->physical_num = count;
    }

    for (i = 0; i < ptr->physical_num; i++) {
        ptr->physical_table[i] = allocator->callback.phy_cpu2vip(device_index, cpu_physical[i]);
    }

    ptr->alloc_handle = (void*)import;
    ptr->mem_flag |= VIPDRV_MEM_FLAG_NONE_CACHE;

    PRINTK_D("wrap user fd=%d, dma_buf=0x%"PRPx", physical_num=%d, physical base=0x%"PRIx64", "
             "size=0x%llx, flag=0x%x\n",
             fd, import->dma_buf, ptr->physical_num, ptr->physical_table[0], ptr->size, ptr->mem_flag);

    vipdrv_os_free_memory((void*)cpu_physical);
    return status;

onError:
    if (VIP_NULL != ptr->physical_table) {
        vipdrv_os_free_memory(ptr->physical_table);
        ptr->physical_table = VIP_NULL;
    }
    if (VIP_NULL != ptr->size_table) {
        vipdrv_os_free_memory(ptr->size_table);
        ptr->size_table = VIP_NULL;
    }
    if (VIP_NULL != import) {
        if (!IS_ERR_OR_NULL(import->sgt)) {
            dma_buf_unmap_attachment(import->dma_attachment, import->sgt, DMA_BIDIRECTIONAL);
        }
        if (import->dma_attachment) {
            dma_buf_detach(import->dma_buf, import->dma_attachment);
        }
        if (!(IS_ERR_OR_NULL(import->dma_buf))) {
            dma_buf_put(import->dma_buf);
        }
        vipdrv_os_free_memory(import);
    }
    if (VIP_NULL != cpu_physical) {
        vipdrv_os_free_memory(cpu_physical);
        cpu_physical = VIP_NULL;
    }
    PRINTK_E("wrap user fd=%d, size=0x%llx\n", fd, ptr->size);
    return status;
}

static vip_status_e vipdrv_wrap_dma_buf_mem_free(vipdrv_video_mem_phy_handle_t* handle)
{
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vipdrv_dma_buf_info_t* import = (vipdrv_dma_buf_info_t*)ptr->alloc_handle;

    if (VIP_NULL == ptr->physical_table) {
        return VIP_SUCCESS;
    }

    if (ptr->user_logical) {
        vipdrv_wrap_dma_buf_unmap_user_logical(handle);
    }

    vipdrv_os_free_memory(ptr->physical_table);
    ptr->physical_table = VIP_NULL;

    if (VIP_NULL != ptr->size_table) {
        vipdrv_os_free_memory(ptr->size_table);
        ptr->size_table = VIP_NULL;
    }
    if (VIP_NULL != import) {
        if (!IS_ERR_OR_NULL(import->sgt)) {
            dma_buf_unmap_attachment(import->dma_attachment, import->sgt, DMA_BIDIRECTIONAL);
        }
        if (import->dma_attachment) {
            dma_buf_detach(import->dma_buf, import->dma_attachment);
        }
        if (!(IS_ERR_OR_NULL(import->dma_buf))) {
            dma_buf_put(import->dma_buf);
        }
        vipdrv_os_free_memory(import);
    }

    return VIP_SUCCESS;
}

/*
@brief convert CPU physical to VIP physical.
@param cpu_physical. the physical address of CPU domain.
*/
static vip_physical_t vipdrv_dma_buf_phy_cpu2vip(vip_uint32_t device_index, vip_physical_t cpu_physical)
{
    vip_physical_t vip_hysical = cpu_physical;
    return vip_hysical;
}

/*
@brief convert VIP physical to CPU physical.
@param vip_physical. the physical address of VIP domain.
*/
static vip_physical_t vipdrv_dma_buf_phy_vip2cpu(vip_uint32_t device_index, vip_physical_t vip_physical)
{
    vip_physical_t cpu_hysical = vip_physical;
    return cpu_hysical;
}

/*
wrap allocator:
    Wrap the memory specified via fd so that NPU can access the memory.
    Wrap the memory specified by vip_create_buffer_from_fd() API.
    Only supports dma-buf.
*/
vip_status_e allocator_init_wrap_dma_buf(vipdrv_allocator_t* allocator, vip_char_t* name,
                                         vipdrv_allocator_type_e type)
{
    if (VIP_NULL == allocator) {
        return VIP_ERROR_INVALID_ARGUMENTS;
    }
    allocator->mem_flag = VIPDRV_MEM_FLAG_NONE;
    allocator->name = name;
    allocator->alctor_type = type;
    allocator->device_vis = ~(vip_uint64_t)0;
    allocator->callback.map_kernel_logical = vipdrv_wrap_dma_buf_map_kernel_logical;
    allocator->callback.unmap_kernel_logical = vipdrv_wrap_dma_buf_unmap_kernel_logical;
    allocator->callback.map_user_logical = vipdrv_wrap_dma_buf_map_user_logical;
    allocator->callback.unmap_user_logical = vipdrv_wrap_dma_buf_unmap_user_logical;
#if vpmdENABLE_FLUSH_CPU_CACHE
    allocator->callback.flush_cache = vipdrv_wrap_dma_buf_flush_cache;
#endif
    allocator->callback.allocate = vipdrv_wrap_dma_buf_mem_alloc;
    allocator->callback.free = vipdrv_wrap_dma_buf_mem_free;
    allocator->callback.phy_vip2cpu = vipdrv_dma_buf_phy_vip2cpu;
    allocator->callback.phy_cpu2vip = vipdrv_dma_buf_phy_cpu2vip;

    return VIP_SUCCESS;
}
