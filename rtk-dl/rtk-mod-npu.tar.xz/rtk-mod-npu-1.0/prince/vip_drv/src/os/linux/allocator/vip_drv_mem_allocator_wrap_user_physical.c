/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#undef VIPDRV_LOG_ZONE
#define VIPDRV_LOG_ZONE VIPDRV_LOG_ZONE_VIDEO_MEMORY

#include <vip_drv_mem_allocator.h>
#include <vip_drv_video_memory.h>
#include "vip_drv_mem_allocator_common.h"
#include "vip_drv_vipcore_driver.h"

vip_status_e allocator_init_wrap_user_physical(vipdrv_allocator_t* allocator, vip_char_t* name,
                                               vipdrv_allocator_type_e type);

static vip_status_e vipdrv_wrap_physical_map_kernel_logical(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vipdrv_allocator_t* allocator = ptr->allocator;
    vip_physical_t physical = allocator->callback.phy_vip2cpu(vipdrv_mem_get_devindex(ptr->device_vis),
                                                              ptr->physical_table[0]);
    vip_uint32_t offset = physical - (physical & PAGE_MASK);
    void* logical = VIP_NULL;
    vip_uint8_t* prt_tmp = VIP_NULL;
    struct page** pages = VIP_NULL;
    vip_bool_e no_cache = (VIPDRV_MEM_FLAG_NONE_CACHE & ptr->mem_flag) ? vip_true_e : vip_false_e;
    vip_uint32_t page_count = 0;

    vipdrv_get_page_count(ptr, &page_count);
    vipOnError(vipdrv_os_allocate_memory(sizeof(struct page*) * page_count, (void**)&pages));
    vipdrv_os_zero_memory(pages, sizeof(struct page*) * page_count);
    vipOnError(vipdrv_fill_pages(ptr, pages));
    vipOnError(vipdrv_map_kernel_page(page_count, pages, &logical, no_cache));
    vipdrv_os_free_memory(pages);

    prt_tmp = (vip_uint8_t*)logical;
    ptr->kerl_logical = (void*)(prt_tmp + offset);
    ptr->mem_flag |= VIPDRV_MEM_FLAG_MAP_KERNEL_LOGICAL;
    return status;
onError:
    PRINTK_E("to map kernel logical wrap physical\n");
    return status;
}

static vip_status_e vipdrv_wrap_physical_unmap_kernel_logical(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vipdrv_unmap_kernel_page(VIPDRV_UINT64_TO_PTR(VIPDRV_PTR_TO_UINT64(ptr->kerl_logical) & PAGE_MASK));
    ptr->kerl_logical = VIP_NULL;
    ptr->mem_flag &= ~VIPDRV_MEM_FLAG_MAP_KERNEL_LOGICAL;

    return status;
}

static vip_status_e vipdrv_wrap_physical_map_user_logical(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vipdrv_allocator_t* allocator = ptr->allocator;
    vip_physical_t physical = allocator->callback.phy_vip2cpu(vipdrv_mem_get_devindex(ptr->device_vis),
                                                              ptr->physical_table[0]);
    vip_uint32_t page_offset = GET_PAGE_OFFSET(physical);
    void* user_logical = VIP_NULL;
    struct page** pages = VIP_NULL;
    vip_bool_e no_cache = (VIPDRV_MEM_FLAG_NONE_CACHE & ptr->mem_flag) ? vip_true_e : vip_false_e;
    vip_uint32_t page_count = 0;

    vipdrv_get_page_count(ptr, &page_count);
    vipOnError(vipdrv_os_allocate_memory(sizeof(struct page*) * page_count, (void**)&pages));
    vipdrv_os_zero_memory(pages, sizeof(struct page*) * page_count);
    vipOnError(vipdrv_fill_pages(ptr, pages));
    vipOnError(vipdrv_map_user(page_count, pages, &user_logical, no_cache));
    vipdrv_os_free_memory(pages);

    ptr->user_logical = (void*)((vip_uint8_t*)user_logical + page_offset);
    ptr->mem_flag |= VIPDRV_MEM_FLAG_MAP_USER_LOGICAL;
    ptr->pid = vipdrv_os_get_pid();

    return status;
onError:
    PRINTK_E("map user logical wrap physical\n");
    if (VIP_NULL != pages) {
        vipdrv_os_free_memory(pages);
        pages = VIP_NULL;
    }
    return status;
}

static vip_status_e vipdrv_wrap_physical_unmap_user_logical(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vip_uint32_t page_count = 0;

    if (ptr->pid == vipdrv_os_get_pid()) {
        vipdrv_get_page_count(ptr, &page_count);
        vipdrv_unmap_user(page_count,
                          VIPDRV_UINT64_TO_PTR(VIPDRV_PTR_TO_UINT64(ptr->user_logical) & PAGE_MASK));
        ptr->user_logical = VIP_NULL;
        ptr->mem_flag &= ~VIPDRV_MEM_FLAG_MAP_USER_LOGICAL;
        ptr->pid = 0;
    }

    return status;
}

#if vpmdENABLE_FLUSH_CPU_CACHE
static vip_status_e vipdrv_wrap_physical_flush_cache(vipdrv_video_mem_phy_handle_t* handle, vip_uint8_t type)
{
    vip_status_e status = VIP_SUCCESS;
#if vpmdENABLE_VIDEO_MEMORY_CACHE
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    if (0x00 == (VIPDRV_MEM_FLAG_NONE_CACHE & ptr->mem_flag)) {
        status = flush_cache_pages(ptr->flush_handle, type);
    }
#endif
    return status;
}
#endif

static vip_status_e vipdrv_wrap_physical_mem_alloc(vipdrv_video_mem_phy_handle_t* handle,
                                                   vipdrv_alloc_param_ptr param)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    vipdrv_allocator_t* allocator = ptr->allocator;
    vip_size_t total_size = 0;
    vip_uint32_t i = 0;
    vipdrv_allocator_wrapphy_param_t* wrap_param = (vipdrv_allocator_wrapphy_param_t*)param;
    vip_uint32_t physical_num = wrap_param->phy_num;
    vip_uint32_t page_offset = wrap_param->phy_table[0] - (wrap_param->phy_table[0] & PAGE_MASK);
    struct page** pages = VIP_NULL;
    vip_uint32_t page_count = 0;
    vip_uint32_t device_index = vipdrv_mem_get_devindex(ptr->device_vis);

    ptr->physical_num = physical_num;
    vipOnError(vipdrv_os_allocate_memory(sizeof(vip_physical_t) * physical_num,
                                         (void**)&ptr->physical_table));
    vipOnError(vipdrv_os_allocate_memory(sizeof(vip_size_t) * physical_num, (void**)&ptr->size_table));
    vipdrv_os_zero_memory(ptr->physical_table, sizeof(vip_physical_t) * physical_num);
    vipdrv_os_zero_memory(ptr->size_table, sizeof(vip_size_t) * physical_num);

    /* check physical table is valid */
    for (i = 0; i < ptr->physical_num; i++) {
        if (wrap_param->physical_type == VIP_BUFFER_FROM_PHY_TYPE_HOST) {
            ptr->physical_table[i] = allocator->callback.phy_cpu2vip(device_index, wrap_param->phy_table[i]);
        }
        /* not need convert physical if physical address is come from Device(NPU) */
        if (wrap_param->physical_type == VIP_BUFFER_FROM_PHY_TYPE_DEVICE) {
            ptr->physical_table[i] = wrap_param->phy_table[i];
        }
        ptr->size_table[i] = wrap_param->size_table[i];
        total_size += wrap_param->size_table[i];

        if (0 != i) {
            if (ptr->physical_table[i] % PAGE_SIZE) {
                PRINTK_E("physical index %d: start addr 0x%x not align to 0x%x\n", i, ptr->physical_table[i],
                         PAGE_SIZE);
                vipGoOnError(VIP_ERROR_INVALID_ARGUMENTS);
            }
        }
        if ((ptr->physical_num - 1) != i) {
            if ((ptr->physical_table[i] + ptr->size_table[i]) % PAGE_SIZE) {
                PRINTK_E("physical index %d: end addr 0x%x not align to 0x%x\n", i,
                         ptr->physical_table[i] + ptr->size_table[i], PAGE_SIZE);
                vipGoOnError(VIP_ERROR_INVALID_ARGUMENTS);
            }
        }
    }
    ptr->size = total_size;

    if (0x00 == (VIPDRV_MEM_FLAG_NONE_CACHE & ptr->mem_flag)) {
        vipdrv_get_page_count(ptr, &page_count);
        vipOnError(vipdrv_os_allocate_memory(sizeof(struct page*) * page_count, (void**)&pages));
        vipdrv_os_zero_memory(pages, sizeof(struct page*) * page_count);
        vipOnError(vipdrv_fill_pages(ptr, pages));

        vipOnError(flush_cache_init_pages(&ptr->flush_handle, pages, page_count, page_offset,
                                          page_count << PAGE_SHIFT));

        vipdrv_os_free_memory(pages);
    }
    return status;
onError:
    flush_cache_destroy_pages(ptr->flush_handle);
    ptr->flush_handle = VIP_NULL;
    if (VIP_NULL != ptr->physical_table) {
        vipdrv_os_free_memory(ptr->physical_table);
        ptr->physical_table = VIP_NULL;
    }
    if (VIP_NULL != ptr->size_table) {
        vipdrv_os_free_memory(ptr->size_table);
        ptr->size_table = VIP_NULL;
    }
    if (VIP_NULL != pages) {
        vipdrv_os_free_memory(pages);
    }
    return status;
}

static vip_status_e vipdrv_wrap_physical_mem_free(vipdrv_video_mem_phy_handle_t* handle)
{
    vipdrv_video_mem_phy_handle_t* ptr = handle;

    if (ptr->user_logical) {
        vipdrv_wrap_physical_unmap_user_logical(handle);
    }

    if (VIP_NULL != ptr->size_table) {
        vipdrv_os_free_memory((void*)ptr->size_table);
        ptr->size_table = VIP_NULL;
    }

    flush_cache_destroy_pages(ptr->flush_handle);
    ptr->flush_handle = VIP_NULL;

    if (VIP_NULL != ptr->physical_table) {
        vipdrv_os_free_memory((void*)ptr->physical_table);
        ptr->physical_table = VIP_NULL;
    }

    return VIP_SUCCESS;
}

vip_status_e allocator_init_wrap_user_physical(vipdrv_allocator_t* allocator, vip_char_t* name,
                                               vipdrv_allocator_type_e type)
{
    if (VIP_NULL == allocator) {
        return VIP_ERROR_INVALID_ARGUMENTS;
    }
    allocator->mem_flag = VIPDRV_MEM_FLAG_NONE;
    allocator->name = name;
    allocator->alctor_type = type;
    allocator->device_vis = ~(vip_uint64_t)0;
    allocator->callback.allocate = vipdrv_wrap_physical_mem_alloc;
    allocator->callback.free = vipdrv_wrap_physical_mem_free;
    allocator->callback.map_kernel_logical = vipdrv_wrap_physical_map_kernel_logical;
    allocator->callback.unmap_kernel_logical = vipdrv_wrap_physical_unmap_kernel_logical;
    allocator->callback.map_user_logical = vipdrv_wrap_physical_map_user_logical;
    allocator->callback.unmap_user_logical = vipdrv_wrap_physical_unmap_user_logical;
#if vpmdENABLE_FLUSH_CPU_CACHE
    allocator->callback.flush_cache = vipdrv_wrap_physical_flush_cache;
#endif
    allocator->callback.phy_vip2cpu = vipdrv_drv_get_cpuphysical;
    allocator->callback.phy_cpu2vip = vipdrv_drv_get_vipphysical;

    return VIP_SUCCESS;
}
