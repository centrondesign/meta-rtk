/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#ifndef _VIP_DRV_VIPCORE_DRIVER_H
#define _VIP_DRV_VIPCORE_DRIVER_H

#include <vip_lite_config.h>
#include <vip_drv_vipcore_type.h>
#include "vip_drv_vipcore_device.h"
#if vpmdENABLE_DEBUGFS
#include <vip_drv_os_debug.h>
#endif

struct _vipdrv_vipcore_driver_t {
    vipdrv_vipcore_device_t vipcore_dev;
    vipdrv_vipcore_vendor_t* vipcore_vendor;

    struct platform_device* device;
    struct platform_driver* driver;

    vip_uint32_t open_device_count;
};

/*
@brief get kdriver object.
*/
vipdrv_vipcore_driver_t* vipdrv_get_vipcore_driver(void);

/*
@brief do some initialize in this function.
@param, vip_memsizem, the size of video memory heap.
*/
vip_status_e vipdrv_drv_init(vip_uint32_t video_memsize);

/*
@brief do some un-initialize in this function.
*/
vip_status_e vipdrv_drv_exit(void);

/*
 Get the video memory config information
*/
vip_status_e vipdrv_drv_get_memory_config(vipdrv_vendor_memory_config_t* memory_info);

/*
 Get the video memory config information
 1. the size of system memory used by vip_hal.
 2. reserve_physical is a video memory, used by vip_create_network_from_physical() api in nbg_linker.
 3. heap info is used for video memory heap basic information.
*/
vip_status_e vipdrv_drv_get_hardware_info(vipdrv_hardware_info_t* info);

/*
@brief Set power on/off and clock on/off
@param device_index, the index of logical device.
@param core_index, the core index in logical device.
@param state, power status. refer to vipdrv_power_status_e.
*/
vip_status_e vipdrv_drv_set_power_clk(vip_uint32_t device_index, vip_uint32_t core_index, vip_uint32_t state);

/*
@brief convert VIP physical to CPU physical.
@param param, the physical address of VIP domain.
*/
vip_physical_t vipdrv_drv_get_cpuphysical(vip_uint32_t device_index, vip_physical_t vip_physical);

/*
@brief convert CPU physical to VIP physical.
@param param, the physical address of CPU domain.
*/
vip_physical_t vipdrv_drv_get_vipphysical(vip_uint32_t device_index, vip_physical_t cpu_physical);

#endif
