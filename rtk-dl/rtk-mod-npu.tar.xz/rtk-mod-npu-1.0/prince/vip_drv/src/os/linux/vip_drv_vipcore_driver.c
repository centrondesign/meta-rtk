/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#include <linux/pagemap.h>
#include <linux/seq_file.h>
#include <linux/mman.h>
#include <asm/atomic.h>
#include <linux/dma-mapping.h>
#include <linux/slab.h>
#include <linux/workqueue.h>
#include <linux/irqflags.h>
#include <linux/vmalloc.h>
#include <linux/io.h>
#include <linux/kernel.h>
#include <linux/clk.h>
#include <linux/clk-provider.h>
#include <linux/delay.h>
#include <linux/device.h>
#include <linux/slab.h>
#include <linux/miscdevice.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/signal.h>
#include <linux/interrupt.h>
#include <linux/vmalloc.h>
#include <linux/dma-mapping.h>
#include <linux/kthread.h>
#include <linux/pagemap.h>
#include <linux/mman.h>
#ifdef CONFIG_COMPAT
#include <asm/compat.h>
#endif
#include <linux/platform_device.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <linux/dma-mapping.h>
#include <linux/math64.h>
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 16, 0))
#include <linux/stdarg.h>
#else
#include <stdarg.h>
#endif
#include <linux/time.h>
#include <linux/mm.h>
#include <linux/debugfs.h>
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 6, 0))
#include <linux/cma.h>
#endif
#if defined(USE_LINUX_PCIE_DEVICE)
#include <linux/pci.h>
#endif

#include "vip_drv_pm.h"
#include "vip_drv_debug.h"
#include "vip_drv_os.h"
#include "vip_drv_os_port.h"
#include "vip_lite_version.h"
#include "vip_drv_video_memory.h"
#include "vip_drv_interface.h"
#include "vip_drv_context.h"
#include "vip_drv_vipcore_driver.h"
#include "vip_drv_vipcore_vendor.h"
#include "vip_drv_vipcore_device.h"
#include "vip_drv_mem_allocator.h"
#if vpmdENABLE_DEBUGFS
#include <vip_drv_os_debug.h>
#endif

/* Default size 2M for system memory heap, access by CPU only
   The size of system memory heap for one CPU process */
#define SYSTEM_MEMORY_HEAP_SIZE (2 << 20)

#define MIN_VIDEO_MEMORY_SIZE (4 * 1024)

/*
  Linux insmod parameters.
  These parameter need to be configured according to your chip and system enviroment
*/
static ulong registerMemBase[vipdMAX_CORE] = {[0 ... vipdMAX_CORE - 1] = 0};
module_param_array(registerMemBase, ulong, NULL, 0644);
MODULE_PARM_DESC(registerMemBase, "AHB register base physical address of vip multi-core");

static vip_uint32_t registerMemSize[vipdMAX_CORE] = {[0 ... vipdMAX_CORE - 1] = 0};
module_param_array(registerMemSize, uint, NULL, 0644);
MODULE_PARM_DESC(registerMemSize, "AHB register memory size of vip multi-core");

static vip_uint32_t irqLine[vipdMAX_CORE] = {[0 ... vipdMAX_CORE - 1] = 0};
module_param_array(irqLine, uint, NULL, 0644);
MODULE_PARM_DESC(irqLine, "irq line number of vip multi-core");

static ulong contiguousSize[VIDEO_MEMORY_HEAP_MAX_CNT] = {[0 ... VIDEO_MEMORY_HEAP_MAX_CNT - 1] = 0};
module_param_array(contiguousSize, ulong, NULL, 0644);
MODULE_PARM_DESC(contiguousSize, "defalut video memory heap size");

static ulong contiguousBase[VIDEO_MEMORY_HEAP_MAX_CNT] = {[0 ... VIDEO_MEMORY_HEAP_MAX_CNT - 1] = 0};
module_param_array(contiguousBase, ulong, NULL, 0644);
MODULE_PARM_DESC(contiguousBase, "the base pyhsical address of video memory heap");

/*
   After reserved this contiguous phyiscal, driver fill mmu page table in vip_init stages,
   when application call create_buffer_form_physical don't fill mmu page table again.
   so speed up API calls. This feature is avaliable when set vpmdENABLE_RESERVE_PHYSICAL to 1.
*/
static vip_uint32_t reservePhysicalSize = 0;
module_param(reservePhysicalSize, uint, 0644);
MODULE_PARM_DESC(reservePhysicalSize, "the size of contiguous physical memory, "
                                      "it is only used for <create_buffer_form_physical> API");

static ulong reservePhysicalBase = 0;
module_param(reservePhysicalBase, ulong, 0644);
MODULE_PARM_DESC(reservePhysicalBase, "the base address of contiguous physical memory, "
                                      "it is only used for <create_buffer_form_physical> API");

static vip_uint32_t AXISramSize[vipdMAX_CORE] = {[0 ... vipdMAX_CORE - 1] = 0};
module_param_array(AXISramSize, uint, NULL, 0644);
MODULE_PARM_DESC(AXISramSize, "the size of AXI SRAM");

static ulong AXISramBaseAddress = 0;
module_param(AXISramBaseAddress, ulong, 0644);
MODULE_PARM_DESC(AXISramBaseAddress, "the npu physical base address of AXI SRAM");

static vip_uint32_t VIPSramBaseAddress = 0;
module_param(VIPSramBaseAddress, uint, 0644);
MODULE_PARM_DESC(VIPSramBaseAddress, "the base address of VIP SRAM");

static DEFINE_MUTEX(set_power_mutex);

/* Global variable for vipcore driver */
vipdrv_vipcore_driver_t* kdriver = VIP_NULL;

vipdrv_vipcore_driver_t* vipdrv_get_vipcore_driver(void)
{
    return kdriver;
}

/* used insmod command line to initialize vipcore vendor parameters*/
static vip_status_e drv_init_vendor_params(vipdrv_vipcore_vendor_t* vipcore_vendor)
{
    vip_uint32_t dev_index = 0;

    /*the params init need refine, some insmod args is for all phy device core */
    for (dev_index = 0; dev_index < vipcore_vendor->device_count; dev_index++) {
        vipdrv_vendor_device_t* device = &vipcore_vendor->device[dev_index];
        vip_uint32_t index = 0;

        device->axi_sram_base = AXISramBaseAddress;
        device->vip_sram_base = VIPSramBaseAddress;

#if vpmdENABLE_VIDEO_MEMORY_HEAP
        for (index = 0; index < VIDEO_MEMORY_HEAP_MAX_CNT; index++) {
            if (contiguousSize[index] > 0) {
                device->heap_memsize[index] = (vip_uint64_t)contiguousSize[index];
                device->heap_physical[index] = (vip_physical_t)contiguousBase[index];
                device->heap_name[index] = ALLOCATOR_NAME_HEAP_EXCLUSIVE;
                PRINTK("vipcore, insmod heap%d  physical=0x%"PRIx64", size=0x%x, name=%s\n", index,
                       contiguousBase[index], contiguousSize[index], device->heap_name[index]);
            } else {
                device->heap_name[index] = "";
            }
        }
#endif
#if vpmdENABLE_RESERVE_PHYSICAL
        device->reserve_physical_base = reservePhysicalBase;
        device->reserve_physical_size = reservePhysicalSize;
#endif

        for (index = 0; index < vipdMAX_CORE; index++) {
            device->axi_sram_size[index] = AXISramSize[index];
            device->irq_line[index] = irqLine[index];
            device->register_physical[index] = registerMemBase[index];
            device->register_size[index] = registerMemSize[index];
        }
    }

    return VIP_SUCCESS;
}

/* sanity check vipcore vendor parameters */
static vip_int32_t drv_check_vendor_param(vipdrv_vipcore_vendor_t* vipcore_vendor)
{
    vip_uint32_t i = 0;

    if (VIP_NULL == vipcore_vendor) {
        PRINTK("vipcore, vipcore vendor is NULL\n");
        goto onError;
    }
    if (vipcore_vendor->device_count <= 0) {
        PRINTK("vipcore, vipcore vendor deice cnt is 0");
        goto onError;
    }

    for (i = 0; i < vipcore_vendor->device_count; i++) {
        vipdrv_vendor_device_t* device = &vipcore_vendor->device[i];
        if (VIP_NULL == device->ops) {
            PRINTK("vipcore, device%d device->ops is NULL\n", i);
            goto onError;
        }
        if (VIP_NULL == device->ops->power_on) {
            PRINTK("vipcore, device%d ops->power_on is NULL\n", i);
            goto onError;
        }
        if (VIP_NULL == device->ops->power_off) {
            PRINTK("vipcore, device%d ops->power_off is NULL\n", i);
            goto onError;
        }
        if (VIP_NULL == device->ops->phy_cpu2vip) {
            PRINTK("vipcore, device%d ops->phy_cpu2vip is NULL\n", i);
            goto onError;
        }
        if (VIP_NULL == device->ops->phy_vip2cpu) {
            PRINTK("vipcore, device%d ops->phy_cpu2vip is NULL\n", i);
            goto onError;
        }
        if (VIP_NULL == device->vipcore_vendor) {
            PRINTK("vipcore, device%d vipcore_vendor is NULL\n", i);
            goto onError;
        }
    }

    return 0;
onError:
    return -1;
}

/* callback vendor function to adject vipcore_vendor parameters */
static vip_int32_t drv_adjust_vendor_params(vipdrv_vipcore_vendor_t* vipcore_vendor)
{
    vip_uint32_t index = 0;
    vip_int32_t ret = 0;

    for (index = 0; index < vipcore_vendor->device_count; index++) {
        vipdrv_vendor_device_t* device = &vipcore_vendor->device[index];
        if (!device->ops) {
            PRINTK_E("dev%d vendor ops is NULL\n");
            continue;
        }
        if (device->ops->param_adjust) {
            ret = device->ops->param_adjust(device);
            if (ret < 0) {
                PRINTK_E("device%d param adjust\n", device->index);
                continue;
            }
        }
    }

    return ret;
}

static vip_int32_t drv_unadjust_params(vipdrv_vipcore_vendor_t* vipcore_vendor)
{
    vip_uint32_t index = 0;

    for (index = 0; index < vipcore_vendor->device_count; index++) {
        vipdrv_vendor_device_t* device = &vipcore_vendor->device[index];
        if (!device->ops) {
            continue;
        }
        if (device->ops->param_unadjust) {
            device->ops->param_unadjust(device);
        }
    }

    return 0;
}

static vip_int32_t drv_init_vipcore_device(vipdrv_vipcore_device_t* vipcore_dev)
{
    vip_int32_t ret = 0;

    vipcore_dev->registered = 0;
    vipcore_dev->sys_heap_size = SYSTEM_MEMORY_HEAP_SIZE;

    return ret;
}

static vip_int32_t drv_check_vendor_device_params(vipdrv_vendor_device_t* device)
{
    vip_int32_t ret = 0;
    vip_uint32_t i = 0;
    vip_uint32_t total_core = 0;
    vip_uint32_t core_count = device->core_count;
    vip_uint32_t axi_sram_size = 0;

    if (device->core_count > vipdMAX_CORE) {
        PRINTK("vipcore, device%d core count=%d large than max=%d\n", device->index, device->core_count,
               vipdMAX_CORE);
        return -1;
    }
    if (0 == device->core_count) {
        PRINTK("vipcore, device%d core count is 0\n", device->index);
        return -1;
    }

    for (i = 0; i < device->core_count; i++) {
        axi_sram_size += device->axi_sram_size[i];
        if (0 == device->register_physical[i]) {
            core_count = min(i, core_count);
            PRINTK_E("register physical break core count core%d\n", i);
            break;
        }
        if (0 == device->register_size[i]) {
            core_count = min(i, core_count);
            PRINTK_E("register size break core count core%d\n", i);
            break;
        }
        if (VIP_NULL == device->register_base[i]) {
            core_count = min(i, core_count);
            PRINTK_E("register base break core count core%d\n", i);
            break;
        }
        if (0 == device->irq_line[i]) {
            core_count = min(i, core_count);
            PRINTK_E("irq line break core count core%d\n", i);
            break;
        }
    }

    if (core_count != device->core_count) {
        PRINTK_E("warning update core count from %d to %d\n", device->core_count, core_count);
        device->core_count = core_count;
    }
    for (i = 0; i < vipdMAX_CORE; i++) {
        if (device->device_core_number[i] > 0) {
            total_core += device->device_core_number[i];
            if (total_core > device->core_count) {
                device->device_core_number[i] = device->core_count;
            }
            PRINTK("vipcore, vendor_device=%d, logical_device=%d, core_count=%d\n", device->index, i,
                   device->device_core_number[i]);
        } else {
            break;
        }
    }

    if (0 == device->core_count) {
        ret = -1;
        PRINTK_E("device core count is 0\n");
    }

    return ret;
}

static void drv_exit(void)
{
    /* Check for valid device. */
    if (VIP_NULL == kdriver) {
        PRINTK("vipcore, kdriver is NULL, return\n");
        return;
    }

    drv_destroy_device(&kdriver->vipcore_dev);
}

static vip_int32_t drv_init(vipdrv_vipcore_vendor_t* vipcore_vendor)
{
    vip_int32_t ret = 0;
    vip_uint32_t index = 0;

    PRINTK("vipcore, drv_init start...\n");

    drv_init_vipcore_device(&kdriver->vipcore_dev);

    for (index = 0; index < vipcore_vendor->device_count; index++) {
        if (drv_check_vendor_device_params(&vipcore_vendor->device[index]) < 0) {
            PRINTK("vipcore, fail to check vendor device params\n");
            return -1;
        }
    }

    ret = drv_construct_device(kdriver->vipcore_vendor, &kdriver->vipcore_dev);
    if (ret < 0) {
        PRINTK_E("construct device");
        goto error;
    }

    PRINTK("VIPLite driver version %d.%d.%d.%s\n", VERSION_MAJOR, VERSION_MINOR, VERSION_SUB_MINOR,
           VERSION_PATCH);
    PRINTK("insmod viplite driver successfully\n");

    return 0;
error:
    drv_exit();
    return -1;
}

#if vpmdENABLE_VIDEO_MEMORY_HEAP
static vip_uint64_t drv_mem_get_deviceVis(vipdrv_vipcore_device_t* vipcore_dev, vip_uint32_t dev_idx)
{
    vip_uint32_t logi_idx = 0;
    vip_uint64_t device_vis = 0;

    for (logi_idx = 0; logi_idx < vipcore_dev->logi_dev_cnt; logi_idx++) {
        vipdrv_logi_device_t* logi_dev = &vipcore_dev->logi_dev[logi_idx];
        vipdrv_phy_device_t* phy_dev = logi_dev->phy_dev;
        if (phy_dev->index == dev_idx) {
            device_vis |= 1 << logi_dev->index;
        }
    }

    return device_vis;
}

/*
Check new heap info is overlap with exist heap info
@param phy_dev, the object of physical device, which include the exist heap info.
@param physical, the cpu physical of new heap info.
@param size, the size of new heap info.
@param heap_index, OUT, the index of found heap info.

return value:
    0: in heap info in NOT overlap with exist heap info, and it is a new heap info.
    1: in heap info is overlap with exist heap info
    2: found a same info in the exist heap info list
*/
static vip_int32_t drv_heap_overlap_check(vipdrv_vipcore_device_t* vipcore_dev, vip_physical_t physical,
                                          vip_uint64_t size, vip_uint32_t* heap_index)
{
    vip_status_e status = VIP_SUCCESS;
    vip_int32_t index = 0;
    vip_uint32_t dev_idx = 0;

    for (index = 0; index < vipcore_dev->heap_count; index++) {
        vip_physical_t cpu_phy = 0, mem_size = 0;
        vipdrv_videomem_heap_info_t* heap = &vipcore_dev->heap_infos[index];
        mem_size = heap->vip_memsize;
        dev_idx = vipdrv_mem_get_devindex(heap->device_vis);
        cpu_phy = vipdrv_drv_get_cpuphysical(dev_idx, heap->vip_physical);

        if ((physical == cpu_phy) && (size == mem_size)) {
            *heap_index = index;
            return 2;
        }

        status = vipdrv_memory_overlap_check(physical, size, cpu_phy, mem_size);
        if (status != VIP_SUCCESS) {
            *heap_index = index;
            PRINTK_F("heap_%d overlap cpy_phy=0x%"PRIx64", size=0x%"PRIx64"\n", index, cpu_phy, mem_size);
            return 1;
        }
    }

    return 0;
}

static vip_int32_t drv_prepare_video_memory(vipdrv_vipcore_device_t* vipcore_dev)
{
    vip_status_e status = VIP_SUCCESS;
    vip_int32_t ret = 0;
    vip_uint32_t i = 0;
    vip_uint32_t heap_cnt = 0;
    vip_uint32_t dev_idx = 0;
    vip_uint32_t size = 0;

    if (0 == vipcore_dev->logi_dev_cnt) {
        PRINTK_E("logical dev cnt is 0, should prepare dev before\n");
        return -1;
    }
    if (0 == VIDEO_MEMORY_HEAP_MAX_CNT) {
        PRINTK_E("VIDEO_MEMORY_HEAP_MAX_CNT is 0\n");
        return -1;
    }

    size = sizeof(vipdrv_videomem_heap_info_t) * vipcore_dev->phy_dev_cnt * VIDEO_MEMORY_HEAP_MAX_CNT;
    status = vipdrv_os_allocate_memory(size, (void**)&vipcore_dev->heap_infos);
    if (status != VIP_SUCCESS) {
        PRINTK_E("alloc memory for phy_dev\n");
        return -1;
    }
    vipdrv_os_zero_memory(vipcore_dev->heap_infos, size);

    for (dev_idx = 0; dev_idx < vipcore_dev->phy_dev_cnt; dev_idx++) {
        vipdrv_phy_device_t* phy_dev = &vipcore_dev->phy_dev[dev_idx];
        vipdrv_vendor_device_t* vendor_dev = phy_dev->vendor;
        for (i = 0; i < VIDEO_MEMORY_HEAP_MAX_CNT; i++) {
            vip_uint32_t heap_index = 0;
            vip_uint64_t device_vis = 0;
            if ((vendor_dev->heap_memsize[i] < MIN_VIDEO_MEMORY_SIZE) ||
                (VIP_NULL == vendor_dev->heap_name[i]) || (0 == vendor_dev->heap_physical[i])) {
                continue;
            }
            if ((vendor_dev->heap_physical[i] & (vipdMEMORY_HAEAP_BASE_ADDRESS_ALIGN - 1)) != 0) {
                PRINTK_E("dev% heap%d cpu_phy=0x%"PRIx64" not align\n", dev_idx, i,
                         vendor_dev->heap_physical[i]);
                continue;
            }

            ret = drv_heap_overlap_check(vipcore_dev, vendor_dev->heap_physical[i],
                                         vendor_dev->heap_memsize[i], &heap_index);
            if (ret == 1) {
                PRINTK_E("dev%d heap%d  physical=0x%"PRIx64", size=0x%"PRIx64" overlap with heap_%d\n",
                         dev_idx, i, vendor_dev->heap_physical[i], vendor_dev->heap_memsize[i], heap_index);
                continue;
            }

            device_vis = drv_mem_get_deviceVis(vipcore_dev, phy_dev->index);

            /* same heap info, only need update deviceVis mapping bit */
            if (ret == 2) {
                vipcore_dev->heap_infos[heap_index].device_vis |= device_vis;
                PRINTK_F("found same heap_%d physical=0x%"PRIx64", size=0x%" PRIx64
                         ". update deviceVis=0x%x\n",
                         heap_index, vendor_dev->heap_physical[i], vendor_dev->heap_memsize[i],
                         vipcore_dev->heap_infos[heap_index].device_vis);
                continue;
            }

            if (0 == vipdrv_os_strcmp(ALLOCATOR_NAME_HEAP_EXCLUSIVE, vendor_dev->heap_name[i])) {
                /* map reserved memory in boot time */
                struct resource* region = VIP_NULL;
                region = request_mem_region(vendor_dev->heap_physical[i], vendor_dev->heap_memsize[i],
                                            "vip_reserved");
                if (region == NULL) {
                    PRINTK("vipcore, warning request mem region, address=0x%"PRIx64", size=0x%"PRIx64"\n",
                           vendor_dev->heap_physical[i], vendor_dev->heap_memsize[i]);
                }
            }

            vipcore_dev->heap_infos[heap_cnt].vip_physical =
                        vendor_dev->ops->phy_cpu2vip(vendor_dev, vendor_dev->heap_physical[i]);
            vipcore_dev->heap_infos[heap_cnt].vip_memsize = vendor_dev->heap_memsize[i];
            vipcore_dev->heap_infos[heap_cnt].name = vendor_dev->heap_name[i];
            vipcore_dev->heap_infos[heap_cnt].ops.phy_cpu2vip = vipdrv_drv_get_vipphysical;
            vipcore_dev->heap_infos[heap_cnt].ops.phy_vip2cpu = vipdrv_drv_get_cpuphysical;
            vipcore_dev->heap_infos[heap_cnt].device_vis |= device_vis;
            PRINTK_F("dev%d heap_idx=%d cpu physical=0x%"PRIx64", size=0x%"PRIx64"\n", dev_idx, heap_cnt,
                     vendor_dev->heap_physical[i], vendor_dev->heap_memsize[i]);

            heap_cnt++;
            vipcore_dev->heap_count = heap_cnt;
        }
    }

    /* show heap infos */
    for (i = 0; i < vipcore_dev->heap_count; i++) {
        vipdrv_videomem_heap_info_t* heap = &vipcore_dev->heap_infos[i];
        PRINTK_F("vipcore, heap_idx=%d, name=%s, vip_phy=0x%"PRIx64", size=0x%"PRIx64" dev_vis=0x%x\n", i,
                 heap->name, heap->vip_physical, heap->vip_memsize, heap->device_vis);
    }

    PRINTK_D("video memory heap count=%d\n", heap_cnt);
    return ret;
}

static vip_int32_t drv_unprepare_video_memory(vipdrv_vipcore_device_t* vipcore_dev)
{
    vip_uint32_t i = 0;
    vipdrv_videomem_heap_info_t* heap_info = VIP_NULL;

    for (i = 0; i < vipcore_dev->heap_count; i++) {
        heap_info = &vipcore_dev->heap_infos[i];
        if (VIP_NULL == heap_info) {
            continue;
        }
        if (heap_info->name != VIP_NULL) {
            if (0 == vipdrv_os_strcmp(ALLOCATOR_NAME_HEAP_EXCLUSIVE, heap_info->name)) {
                release_mem_region(heap_info->vip_physical, heap_info->vip_memsize);
            }
        }
        heap_info->vip_memsize = 0;
        heap_info->vip_physical = 0;
    }

    if (vipcore_dev->heap_infos != VIP_NULL) {
        vipdrv_os_free_memory(vipcore_dev->heap_infos);
        vipcore_dev->heap_infos = VIP_NULL;
    }
    vipcore_dev->heap_count = 0;

    return 0;
}
#endif

vip_physical_t vipdrv_drv_get_cpuphysical(vip_uint32_t device_index, vip_physical_t vip_physical)
{
    vip_physical_t cpu_physical = 0;
    vipdrv_vendor_device_t* device = VIP_NULL;

    if (device_index >= kdriver->vipcore_dev.logi_dev_cnt) {
        PRINTK_E("get cpu_phy dev idx=%d large than max=%d\n", device_index,
                 kdriver->vipcore_dev.logi_dev_cnt);
        VIPDRV_DUMP_STACK();
        return cpu_physical;
    }

    device = kdriver->vipcore_dev.logi_dev[device_index].phy_dev->vendor;
    if (device->ops->phy_vip2cpu) {
        cpu_physical = device->ops->phy_vip2cpu(device, vip_physical);
    }

    return cpu_physical;
}

vip_physical_t vipdrv_drv_get_vipphysical(vip_uint32_t device_index, vip_physical_t cpu_physical)
{
    vip_physical_t vip_physical = 0;
    vipdrv_vendor_device_t* device = VIP_NULL;

    if (device_index >= kdriver->vipcore_dev.logi_dev_cnt) {
        PRINTK_E("get vip_phy dev idx=%d large than max=%d\n", device_index,
                 kdriver->vipcore_dev.logi_dev_cnt);
        VIPDRV_DUMP_STACK();
        return vip_physical;
    }

    device = kdriver->vipcore_dev.logi_dev[device_index].phy_dev->vendor;
    if (device->ops->phy_cpu2vip) {
        vip_physical = device->ops->phy_cpu2vip(device, cpu_physical);
    }

    return vip_physical;
}

/*
 Get the video memory config information
 1. the size of system memory used by vip_hal.
 2. reserve_physical is a video memory, used by vip_create_network_from_physical() api in nbg_linker.
 3. heap info is used for video memory heap basic information.
*/
vip_status_e vipdrv_drv_get_memory_config(vipdrv_vendor_memory_config_t* memory_info)
{
    vipdrv_vipcore_device_t* vipcore_dev = &kdriver->vipcore_dev;
    if (VIP_NULL == memory_info) {
        PRINTK_E("get video memory info param is NULL\n");
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

#if vpmdENABLE_VIDEO_MEMORY_HEAP
    memory_info->heap_count = vipcore_dev->heap_count;
    memory_info->heap_infos = vipcore_dev->heap_infos;
#endif

#if vpmdENABLE_RESERVE_PHYSICAL
    memory_info->reserve_phy_base = vipcore_dev->phy_dev[0].vendor->reserve_physical_base;
    memory_info->reserve_phy_size = vipcore_dev->phy_dev[0].vendor->reserve_physical_size;
#endif

#if vpmdENABLE_SYS_MEMORY_HEAP
    memory_info->sys_heap_size = vipcore_dev->sys_heap_size;
#endif

    return VIP_SUCCESS;
}

/*
@brief Get all hardware basic information.
*/
vip_status_e vipdrv_drv_get_hardware_info(vipdrv_hardware_info_t* info)
{
    vip_uint32_t idx = 0;
    vipdrv_logi_device_t* logi_dev = VIP_NULL;

    if (VIP_NULL == info) {
        PRINTK_E("get hardware memory info param is NULL\n");
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    info->device_count = kdriver->vipcore_dev.logi_dev_cnt;
    info->device_info = kdriver->vipcore_dev.logi_infos;

    /* get maybe updated info */
    for (idx = 0; idx < info->device_count; idx++) {
        logi_dev = &kdriver->vipcore_dev.logi_dev[idx];
        if (logi_dev != VIP_NULL) {
            info->device_info[idx].core_fscale_percent = logi_dev->core_fscale_percent;
        }
    }

    return VIP_SUCCESS;
}

/*
@brief Set power on/off and clock on/off
@param device_index, the index of logical device.
@param core_index, the core index in logical device.
@param state, power status. refer to vipdrv_power_status_e.
*/
vip_status_e vipdrv_drv_set_power_clk(vip_uint32_t device_index, vip_uint32_t core_index, vip_uint32_t state)
{
    vip_status_e status = VIP_SUCCESS;
    vip_int32_t ret = 0;
    vipdrv_logi_device_t* logi_dev = VIP_NULL;
    vipdrv_phy_device_t* phy_dev = VIP_NULL;
    vip_uint32_t phy_core_idx = 0;
    vipdrv_phy_core_t* phy_core = VIP_NULL;

    if (device_index >= kdriver->vipcore_dev.logi_dev_cnt) {
        PRINTK_E("set power dev-idx=%d large than max=%d\n", device_index, kdriver->vipcore_dev.logi_dev_cnt);
        return VIP_ERROR_FAILURE;
    }
    logi_dev = &kdriver->vipcore_dev.logi_dev[device_index];
    phy_dev = logi_dev->phy_dev;
    phy_core_idx = logi_dev->core_start_index + core_index;

    if (phy_core_idx > phy_dev->phy_core_cnt) {
        PRINTK_E("set power dev-idx=%d, %d large than phy-core cnt=%d\n", device_index, phy_core_idx,
                 phy_dev->phy_core_cnt);
        return VIP_ERROR_FAILURE;
    }
    phy_core = &phy_dev->phy_core[phy_core_idx];

    mutex_lock(&set_power_mutex);

    if (state == VIPDRV_POWER_ON) {
        if (state != phy_core->power_status) {
            PRINTK_D("power on vip dev%d core%d.\n", phy_dev->index, phy_core_idx);
            ret = phy_dev->vendor->ops->power_on(phy_dev->vendor, phy_core_idx);
            if (ret < 0) {
                PRINTK_E("vipcore, fail to init device, ret=%d\n", ret);
                status = VIP_ERROR_FAILURE;
            }
            phy_core->power_status = VIPDRV_POWER_ON;
        }
    } else if (state == VIPDRV_POWER_OFF) {
        if (state != phy_core->power_status) {
            PRINTK_D("power off vip dev%d core%d.\n", phy_dev->index, phy_core_idx);
            ret = phy_dev->vendor->ops->power_off(phy_dev->vendor, phy_core_idx);
            if (ret < 0) {
                PRINTK_E("vipcore, fail to uninit device, ret=%d\n", ret);
                status = VIP_ERROR_FAILURE;
            }
            phy_core->power_status = VIPDRV_POWER_OFF;
        }
    } else {
        PRINTK("vipcore, no this state=%d in set power clk\n", state);
        status = VIP_ERROR_FAILURE;
    }

    mutex_unlock(&set_power_mutex);

    return status;
}

/*
@brief do some initialize in this function.
@param, vip_memsizem, the size of video memory heap.
*/
vip_status_e vipdrv_drv_init(vip_uint32_t video_memsize)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t core_idx = 0;
    vip_uint32_t logi_idx = 0;
    vip_uint32_t dev_idx = 0;
    PRINTK_D("linux kernel version=0x%x\n", LINUX_VERSION_CODE);

    /* 1. allocate vendor heap memory */
    for (dev_idx = 0; dev_idx < kdriver->vipcore_vendor->device_count; dev_idx++) {
        status = vipdrv_vendor_allocate_heap(&kdriver->vipcore_vendor->device[dev_idx]);
        if (status != VIP_SUCCESS) {
            PRINTK_E("allocate vendor heap\n");
            return status;
        }
    }

    /* 2. init video memory heap */
#if vpmdENABLE_VIDEO_MEMORY_HEAP
    {
        vip_int32_t ret = drv_prepare_video_memory(&kdriver->vipcore_dev);
        if (ret < 0) {
            PRINTK_E("prepare video memory\n");
            status = VIP_ERROR_IO;
            goto err_free_vendor_heap;
        }
    }
#else
    PRINTK("video memory heap is disabled\n");
#endif

    /* power on all VIP cores */
    for (logi_idx = 0; logi_idx < kdriver->vipcore_dev.logi_dev_cnt; logi_idx++) {
        vipdrv_logi_device_t* logi_dev = &kdriver->vipcore_dev.logi_dev[logi_idx];
        for (core_idx = 0; core_idx < logi_dev->core_cnt; core_idx++) {
            status = vipdrv_drv_set_power_clk(logi_idx, core_idx, VIPDRV_POWER_ON);
            if (status != VIP_SUCCESS) {
                PRINTK("vipcore, fail to power on logic dev%d:%d\n", logi_idx, core_idx);
                goto err_unprepare_video_memory;
            }
        }
    }

    return status;

err_unprepare_video_memory:
#if vpmdENABLE_VIDEO_MEMORY_HEAP
    drv_unprepare_video_memory(&kdriver->vipcore_dev);
#endif
err_free_vendor_heap:
    for (dev_idx = 0; dev_idx < kdriver->vipcore_vendor->device_count; dev_idx++) {
        vipdrv_vendor_free_heap(&kdriver->vipcore_vendor->device[dev_idx]);
    }
    return status;
}

/*
@brief do some un-initialize in this function.
*/
vip_status_e vipdrv_drv_exit(void)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t core_idx = 0;
    vip_uint32_t logi_idx = 0;
    vip_uint32_t dev_idx = 0;

    /* power off all VIP cores */
    for (logi_idx = 0; logi_idx < kdriver->vipcore_dev.logi_dev_cnt; logi_idx++) {
        vipdrv_logi_device_t* logi_dev = &kdriver->vipcore_dev.logi_dev[logi_idx];
        for (core_idx = 0; core_idx < logi_dev->core_cnt; core_idx++) {
            status = vipdrv_drv_set_power_clk(logi_idx, core_idx, VIPDRV_POWER_OFF);
            if (status != VIP_SUCCESS) {
                PRINTK("vipcore, fail to power off logic dev%d:%d\n", logi_idx, core_idx);
            }
        }
    }

    /* destory video memory heap */
#if vpmdENABLE_VIDEO_MEMORY_HEAP
    {
        vip_int32_t ret = drv_unprepare_video_memory(&kdriver->vipcore_dev);
        if (ret < 0) {
            PRINTK_E("unprepare video memory\n");
            return VIP_ERROR_IO;
        }
    }
#else
    PRINTK("video memory heap is disabled\n");
#endif

    /* free vendor heap memory */
    for (dev_idx = 0; dev_idx < kdriver->vipcore_vendor->device_count; dev_idx++) {
        status = vipdrv_vendor_free_heap(&kdriver->vipcore_vendor->device[dev_idx]);
        if (status != VIP_SUCCESS) {
            PRINTK_E("free vendor heap\n");
            return status;
        }
    }

    return status;
}

/* Linux platform device driver */
static vip_int32_t vipdrv_platform_probe(struct platform_device* pdev)
{
    vip_int32_t ret = 0;
    vipdrv_vipcore_vendor_t* vipcore_vendor = kdriver->vipcore_vendor;

    /* defalut device, we use vendor device for management resource */
    kdriver->device = pdev;

    PRINTK("vipcore, platform_device pdev=0x%p\n", pdev);

    /* initialize vipcore vendor from insmod module paramters */
    drv_init_vendor_params(vipcore_vendor);

    /* callback to vendor adjust parameters */
    ret = drv_adjust_vendor_params(vipcore_vendor);
    if (ret < 0) {
        return -1;
    }

    ret = drv_init(vipcore_vendor);
    if (ret < 0) {
        PRINTK_E("vipcore, fail to drv init\n");
        return -1;
    }

    return ret;
}

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 11, 0))
static void vipdrv_platform_remove(struct platform_device* pdev)
#else
static vip_int32_t vipdrv_platform_remove(struct platform_device* pdev)
#endif
{
    vipdrv_vipcore_vendor_t* vipcore_vendor = kdriver->vipcore_vendor;
    drv_exit();
    drv_unadjust_params(vipcore_vendor);
#if (LINUX_VERSION_CODE < KERNEL_VERSION(6, 11, 0))
    return 0;
#endif
}

static void vipdrv_platform_shutdown(struct platform_device* pdev)
{
    vipdrv_platform_remove(pdev);
}

static vip_int32_t vipdrv_platform_suspend(struct platform_device* pdev, pm_message_t state)
{
#if vpmdENABLE_SUSPEND_RESUME
    PRINTK_I("system suspend...\n");
    vipdrv_pm_suspend();
#endif

    return 0;
}

static vip_int32_t vipdrv_platform_resume(struct platform_device* pdev)
{
    vip_int32_t ret = 0;
#if vpmdENABLE_SUSPEND_RESUME
    vip_status_e status = VIP_SUCCESS;
    PRINTK_I("system resume...\n");
    status = vipdrv_pm_resume();
    if (status != VIP_SUCCESS) {
        PRINTK("vipcore, fail to do pm init hardware status=%d\n", status);
        ret = -1;
        goto end;
    }
end:
#endif
    return ret;
}

#if defined(CONFIG_PM) && LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 30)
#ifdef CONFIG_PM_SLEEP
static int vipdrv_system_suspend(struct device* dev)
{
    pm_message_t state = {0};
    return vipdrv_platform_suspend(to_platform_device(dev), state);
}

static int vipdrv_system_resume(struct device* dev)
{
    return vipdrv_platform_resume(to_platform_device(dev));
}

static const struct dev_pm_ops vipdrv_dev_pm_ops = {
            SET_SYSTEM_SLEEP_PM_OPS(vipdrv_system_suspend, vipdrv_system_resume)};
#endif
#endif

static struct platform_driver vipdrv_platform_driver = {.probe = vipdrv_platform_probe,
                                                        .remove = vipdrv_platform_remove,
                                                        .suspend = vipdrv_platform_suspend,
                                                        .resume = vipdrv_platform_resume,
                                                        .shutdown = vipdrv_platform_shutdown,
                                                        .driver = {
                                                                    .owner = THIS_MODULE,
                                                                    .name = DEVICE_NAME,
#if defined(CONFIG_PM) && LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 30)
#ifdef CONFIG_PM_SLEEP
                                                                    .pm = &vipdrv_dev_pm_ops,
#endif
#endif
                                                        }};

static vip_int32_t __init module_drv_init(void)
{
    vip_int32_t ret = 0;

    /* Create device structure. */
    kdriver = kmalloc(sizeof(vipdrv_vipcore_driver_t), GFP_KERNEL);
    if (kdriver == NULL) {
        PRINTK("vipcore, kmalloc failed for driver device.\n");
        return -1;
    }
    /* Zero structure. */
    memset(kdriver, 0, sizeof(vipdrv_vipcore_driver_t));

    PRINTK("vipcore, module drv init\n");

    ret = vipdrv_vipcore_vendor_init(&kdriver->vipcore_vendor);
    if (ret < 0) {
        PRINTK(KERN_ERR "vipcore, check vipcore vendor init fail ret=%d\n", ret);
        goto onError;
    }

    ret = drv_check_vendor_param(kdriver->vipcore_vendor);
    if (ret < 0) {
        PRINTK(KERN_ERR "vipcore, check vipcore vendor fail\n");
        goto onError;
    }

    kdriver->driver = &vipdrv_platform_driver;

    ret = drv_platform_device_register(&vipdrv_platform_driver);
    if (ret < 0) {
        PRINTK(KERN_ERR "vipcore, platform device register failed.\n");
        return -ENODEV;
    }
    ret = platform_driver_register(&vipdrv_platform_driver);
    if (ret < 0) {
        PRINTK(KERN_ERR "vipcore, platform driver register failed.\n");
        return -ENODEV;
    }

    return ret;

onError:
    if (kdriver != VIP_NULL) {
        if (kdriver->vipcore_vendor != VIP_NULL) {
            vipdrv_vipcore_vendor_uninit(kdriver->vipcore_vendor);
        }
        kfree(kdriver);
        kdriver = VIP_NULL;
    }
    return -ENODEV;
}

static void __exit module_drv_exit(void)
{
    drv_platform_device_unregister();

    platform_driver_unregister(&vipdrv_platform_driver);

    if (kdriver != VIP_NULL) {
        if (kdriver->vipcore_vendor != VIP_NULL) {
            vipdrv_vipcore_vendor_uninit(kdriver->vipcore_vendor);
        }
        kfree(kdriver);
        kdriver = VIP_NULL;
    }
    PRINTK("vipcore, module drv exit\n");
}

module_init(module_drv_init)
module_exit(module_drv_exit)

MODULE_AUTHOR("VeriSilicon Corporation");
MODULE_DESCRIPTION("NPU driver");
MODULE_LICENSE("Dual MIT/GPL");
