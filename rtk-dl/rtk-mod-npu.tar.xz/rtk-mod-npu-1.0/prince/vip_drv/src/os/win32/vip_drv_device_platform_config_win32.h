/******************************************************************************\
|* Copyright (c) 2017-2021 by Vivante Corporation.  All Rights Reserved.      *|
|*                                                                            *|
|* The material in this file is confidential and contains trade secrets of    *|
|* of Vivante Corporation.  This is proprietary information owned by Vivante  *|
|* Corporation.  No part of this work may be disclosed, reproduced, copied,   *|
|* transmitted, or used in any way for any purpose, without the express       *|
|* written permission of Vivante Corporation.                                 *|
|*                                                                            *|
\******************************************************************************/

#ifndef _VIP_DRV_DEVICE_PLATFORM_CONFIG_H
#define _VIP_DRV_DEVICE_PLATFORM_CONFIG_H
#include <vip_lite_config.h>

#define HEAP_CNT 2

/* the contiguous memory base address,we need disable MMU when use it.*/
static vip_address_t vipdCONTIGUOUS_BASE[HEAP_CNT] = {0xA0000000, 0xC0000000};

static vip_address_t VIDEO_MEMORY_HEAP_SIZE[HEAP_CNT] = {(vip_address_t)1 << 29, (vip_address_t)1 << 30};

/* default size 32M for system memory heap, access by CPU only */
#define SYSTEM_MEMORY_HEAP_SIZE (32 << 20)

/* the core number of VIP */
#define vpmdCORE_COUNT 1

/* the logic devices number and core number for each logical device.
 * we need configure this after create nbg files.
 * for example: LOGIC_DEVICES_WITH_CORE[8] = {2,2,4,0,0,0,0,0}.
 * indicate device[0] and device[1] have 2 cores, device[2] have 4 cores.
 * the others devices not available, each device have different core index.
*/
static vip_uint32_t LOGIC_DEVICES_WITH_CORE[4] = {1, 1, 1, 1};

/* the size of VIP SRAM */
static const vip_uint32_t VIP_SRAM_SIZE[4] = {0xA00000, 0xA00000, 0xA00000, 0xA00000};

#define VIP_SRAM_BASE_ADDRESS 0x400000

/* the size of AXI SRAM */
static const vip_uint32_t AXI_SRAM_SIZE[4] = {0xA00000, 0xA00000, 0xA00000, 0xA00000};

#define AXI_SRAM_BASE_ADDRESS 0x8000000

#define RESERVE_PHY_BASE_ADDRESS 0x20000000
#define RESERVE_PHY_SIZE         0x40000000

#endif
