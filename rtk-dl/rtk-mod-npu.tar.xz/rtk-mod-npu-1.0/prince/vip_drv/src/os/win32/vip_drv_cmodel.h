/******************************************************************************\
|* Copyright (c) 2017-2025 by Vivante Corporation.  All Rights Reserved.      *|
|*                                                                            *|
|* The material in this file is confidential and contains trade secrets of    *|
|* of Vivante Corporation.  This is proprietary information owned by Vivante  *|
|* Corporation.  No part of this work may be disclosed, reproduced, copied,   *|
|* transmitted, or used in any way for any purpose, without the express       *|
|* written permission of Vivante Corporation.                                 *|
|*                                                                            *|
\******************************************************************************/

#ifndef _VIP_DRV_CMODEL_H
#define _VIP_DRV_CMODEL_H

#include <crtdefs.h>
#ifdef __cplusplus
#define externC extern "C"
#else
#define externC
#endif

typedef char cmBool;
typedef unsigned char cmUInt8;
typedef unsigned int cmUInt32;
typedef unsigned long long cmUInt64;
typedef size_t cmSize;

//#define CM_PAGE_SHIFT 12 /* 4k page */
#define CM_PAGE_SHIFT 20 /* 1M page */
#define CM_PAGE_SIZE  (1 << CM_PAGE_SHIFT)

typedef struct cmMemoryInfo {
    cmUInt8* logical;
    cmUInt64 physical;
    size_t bytes;
} cmMemoryInfo;

typedef void (*IRQ_HANDLER)(void* context);

externC int CModelConstructor(cmSize Memory);
externC void CModelDestructor(void);
externC void CModelWriteRegister(cmUInt32 Core, cmUInt32 Address, cmUInt32 Data);
externC cmUInt32 CModelReadRegister(cmUInt32 Core, cmUInt32 Address);
externC cmMemoryInfo* CModelAllocate(cmSize Bytes, cmSize Address, cmBool Contiguous);
externC void CModelFree(cmMemoryInfo* Memory);
externC cmUInt64 CModelPhysical(void* Logical);
externC void* CModelLogical(cmUInt64 Physical);
cmUInt32 CModelGetCoreCount(void);
externC cmBool CModelWaitInterrupt(cmUInt32 MillseSeconds);
externC cmBool CModelRegisterIrq(cmUInt32 Core, IRQ_HANDLER handler, void* private_data);

#endif
