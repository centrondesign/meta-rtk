/******************************************************************************\
|* Copyright (c) 2017-2025 by Vivante Corporation.  All Rights Reserved.      *|
|*                                                                            *|
|* The material in this file is confidential and contains trade secrets of    *|
|* of Vivante Corporation.  This is proprietary information owned by Vivante  *|
|* Corporation.  No part of this work may be disclosed, reproduced, copied,   *|
|* transmitted, or used in any way for any purpose, without the express       *|
|* written permission of Vivante Corporation.                                 *|
|*                                                                            *|
\******************************************************************************/

#ifndef _VIP_DRV_ALLOCATOR_ARRAY_H
#define _VIP_DRV_ALLOCATOR_ARRAY_H

#include <vip_drv_type.h>
#include <vip_drv_mem_allocator.h>

extern vip_status_e allocator_init_win32(vipdrv_allocator_t* allocator, vip_char_t* name,
                                         vipdrv_allocator_type_e type);

static vipdrv_allocator_desc_t video_mem_allocator_array[] = {
            {"heap-reserved", allocator_init_win32, VIPDRV_ALLOCATOR_TYPE_VIDO_HEAP},
            {"dyn-continue", allocator_init_win32, VIPDRV_ALLOCATOR_TYPE_DYN_ALLOC},
            {"wrap-user-phy", allocator_init_win32, VIPDRV_ALLOCATOR_TYPE_WRAP_USER_PHYSICAL},
};
#endif
