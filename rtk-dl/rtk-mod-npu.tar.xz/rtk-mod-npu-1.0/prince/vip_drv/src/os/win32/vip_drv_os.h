/******************************************************************************\
|* Copyright (c) 2017-2021 by Vivante Corporation.  All Rights Reserved.      *|
|*                                                                            *|
|* The material in this file is confidential and contains trade secrets of    *|
|* of Vivante Corporation.  This is proprietary information owned by Vivante  *|
|* Corporation.  No part of this work may be disclosed, reproduced, copied,   *|
|* transmitted, or used in any way for any purpose, without the express       *|
|* written permission of Vivante Corporation.                                 *|
|*                                                                            *|
\******************************************************************************/

#ifndef _VIP_DRV_EMULATOR_H
#define _VIP_DRV_EMULATOR_H

#include <vip_drv_share.h>

#define MAX_SRAM_SIZE (8 << 20)

vip_status_e CallEmulator(vipdrv_intrface_e Command, void* Data);

#endif
