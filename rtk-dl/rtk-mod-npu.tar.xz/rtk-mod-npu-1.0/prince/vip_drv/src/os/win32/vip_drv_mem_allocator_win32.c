/******************************************************************************\
|* Copyright (c) 2017-2025 by Vivante Corporation.  All Rights Reserved.      *|
|*                                                                            *|
|* The material in this file is confidential and contains trade secrets of    *|
|* of Vivante Corporation.  This is proprietary information owned by Vivante  *|
|* Corporation.  No part of this work may be disclosed, reproduced, copied,   *|
|* transmitted, or used in any way for any purpose, without the express       *|
|* written permission of Vivante Corporation.                                 *|
|*                                                                            *|
\******************************************************************************/

#include <vip_drv_mem_allocator.h>
#include <vip_drv_context.h>
#include "vip_drv_cmodel.h"

static vip_status_e vipdrv_os_map_kernel_logical(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    void* logical = VIP_NULL;
    cmUInt64 physical = 0;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    physical = ptr->physical_table[0];

    ptr->kerl_logical = (vip_uint8_t*)CModelLogical(physical);
    if (VIP_NULL == ptr->kerl_logical) {
        status = VIP_ERROR_FAILURE;
    } else {
        ptr->mem_flag |= VIPDRV_MEM_FLAG_MAP_KERNEL_LOGICAL;
    }

    return status;
}

static vip_status_e vipdrv_os_unmap_kernel_logical(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;

    ptr->kerl_logical = VIP_NULL;
    ptr->mem_flag &= ~VIPDRV_MEM_FLAG_MAP_KERNEL_LOGICAL;

    return status;
}

static vip_status_e vipdrv_os_map_user_logical(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    void* logical = VIP_NULL;
    cmUInt64 physical = 0;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    physical = ptr->physical_table[0];

    ptr->user_logical = (vip_uint8_t*)CModelLogical(physical);
    if (VIP_NULL == ptr->user_logical) {
        status = VIP_ERROR_FAILURE;
    } else {
        ptr->pid = vipdrv_os_get_pid();
        ptr->mem_flag |= VIPDRV_MEM_FLAG_MAP_USER_LOGICAL;
    }

    return status;
}

static vip_status_e vipdrv_os_unmap_user_logical(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;

    ptr->user_logical = VIP_NULL;
    ptr->mem_flag &= ~VIPDRV_MEM_FLAG_MAP_USER_LOGICAL;
    ptr->pid = 0;
    return status;
}

#if vpmdENABLE_FLUSH_CPU_CACHE
static vip_status_e vipdrv_flush_cache(vipdrv_video_mem_phy_handle_t* handle, vip_uint8_t type)
{
    vip_status_e status = VIP_SUCCESS;

    return status;
}
#endif

static vip_status_e vipdrv_os_mem_alloc(vipdrv_video_mem_phy_handle_t* handle, vipdrv_alloc_param_ptr param)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    if (VIPDRV_ALLOCATOR_TYPE_DYN_ALLOC & ptr->allocator_type) {
        vipdrv_allocator_alloc_param_t* alloc_param = (vipdrv_allocator_alloc_param_t*)param;
        cmMemoryInfo* mem = VIP_NULL;
        ptr->size = alloc_param->size;
        ptr->align = alloc_param->align;
        ptr->mem_flag = alloc_param->mem_flag;
        mem = CModelAllocate(ptr->size, -1, vip_true_e);
        PRINTK("alloc syn memory handle=%p\n", mem);

        vipOnError(vipdrv_os_allocate_memory(sizeof(vip_physical_t) * 1, (void**)&ptr->physical_table));
        vipOnError(vipdrv_os_allocate_memory(sizeof(vip_size_t) * 1, (void**)&ptr->size_table));

        ptr->user_logical = VIP_NULL;
        ptr->kerl_logical = VIP_NULL;
        ptr->alloc_handle = mem;

        ptr->physical_table[0] = (vip_physical_t)mem->physical;
        ptr->size_table[0] = VIP_ALIGN(ptr->size, CM_PAGE_SIZE);
        ptr->physical_num = 1; /* map contigous memory, only one page */

        ptr->mem_flag |= VIPDRV_MEM_FLAG_CONTIGUOUS;
    } else if (VIPDRV_ALLOCATOR_TYPE_WRAP_USER_PHYSICAL & ptr->allocator_type) {
        vipdrv_allocator_wrapphy_param_t* wrap_param = (vipdrv_allocator_wrapphy_param_t*)param;
        cmMemoryInfo* mem = VIP_NULL;
        if (wrap_param->phy_num > 1) {
            PRINTK_E("not support warp more than one physical address.\n");
            return VIP_ERROR_NOT_SUPPORTED;
        }
        if (wrap_param->phy_table[0] == 0 || wrap_param->size_table[0] == 0) {
            PRINTK_E("warp physical address or size is zero.\n");
            return VIP_ERROR_INVALID_ARGUMENTS;
        }
        ptr->size = wrap_param->size_table[0];
        ptr->align = 64;
        PRINTK("wrap user physical memory handle=%p\n", mem);

        vipOnError(vipdrv_os_allocate_memory(sizeof(vip_physical_t) * 1, (void**)&ptr->physical_table));
        vipOnError(vipdrv_os_allocate_memory(sizeof(vip_size_t) * 1, (void**)&ptr->size_table));

        ptr->user_logical = VIP_NULL;
        ptr->kerl_logical = VIP_NULL;
        ptr->alloc_handle = mem;

        ptr->physical_table[0] = wrap_param->phy_table[0];
        ptr->size_table[0] = wrap_param->size_table[0];
        ptr->physical_num = 1;

        ptr->mem_flag = VIPDRV_MEM_FLAG_CONTIGUOUS;
    }
onError:
    return status;
}

static vip_status_e vipdrv_os_mem_free(vipdrv_video_mem_phy_handle_t* handle)
{
    vipdrv_video_mem_phy_handle_t* ptr = handle;
    if (ptr->kerl_logical) {
        vipdrv_os_unmap_kernel_logical(handle);
    }

    if (ptr->user_logical) {
        vipdrv_os_unmap_user_logical(handle);
    }

    if (VIPDRV_ALLOCATOR_TYPE_DYN_ALLOC & ptr->allocator_type) {
        vipdrv_os_free_memory(ptr->physical_table);
        vipdrv_os_free_memory(ptr->size_table);
        PRINTK("free syn memory handle=%p\n", ptr->alloc_handle);
        CModelFree((cmMemoryInfo*)ptr->alloc_handle);
    }

    return VIP_SUCCESS;
}

static vip_physical_t phy_vip2cpu(vip_uint32_t device_index, vip_physical_t cpu_physical)
{
    return cpu_physical;
}

static vip_physical_t phy_cpu2vip(vip_uint32_t device_index, vip_physical_t vip_physical)
{
    return vip_physical;
}

vip_status_e allocator_init_win32(vipdrv_allocator_t* allocator, vip_char_t* name,
                                  vipdrv_allocator_type_e type)
{
    allocator->mem_flag = VIPDRV_MEM_FLAG_CONTIGUOUS | VIPDRV_MEM_FLAG_4GB_ADDR_PA;
    allocator->name = name;
    allocator->alctor_type = type;
    allocator->device_vis = ~(vip_uint64_t)0;
    allocator->callback.map_kernel_logical = vipdrv_os_map_kernel_logical;
    allocator->callback.unmap_kernel_logical = vipdrv_os_unmap_kernel_logical;
    allocator->callback.map_user_logical = vipdrv_os_map_user_logical;
    allocator->callback.unmap_user_logical = vipdrv_os_unmap_user_logical;
#if vpmdENABLE_FLUSH_CPU_CACHE
    allocator->callback.flush_cache = vipdrv_flush_cache;
#endif
    allocator->callback.allocate = vipdrv_os_mem_alloc;
    allocator->callback.free = vipdrv_os_mem_free;
    allocator->callback.phy_vip2cpu = phy_vip2cpu;
    allocator->callback.phy_cpu2vip = phy_cpu2vip;

    return VIP_SUCCESS;
}
