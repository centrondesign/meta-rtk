/******************************************************************************\
|* Copyright (c) 2017-2025 by Vivante Corporation.  All Rights Reserved.      *|
|*                                                                            *|
|* The material in this file is confidential and contains trade secrets of    *|
|* of Vivante Corporation.  This is proprietary information owned by Vivante  *|
|* Corporation.  No part of this work may be disclosed, reproduced, copied,   *|
|* transmitted, or used in any way for any purpose, without the express       *|
|* written permission of Vivante Corporation.                                 *|
|*                                                                            *|
\******************************************************************************/

/*
   This "HW" implementations are platform dependent. e.g., cmodel, Linux, RTOS are different.
*/
#include "vip_drv_os_port.h"
#include <vip_drv_device_platform_config_win32.h>
#include "vip_drv_cmodel.h"
#include "vip_drv_hardware.h"
#include "vip_drv_interface.h"
#include "vip_drv_os.h"
#include "vip_drv_mem_heap.h"
#include "vip_drv_context.h"
#include <windows.h>
#include <stdio.h>
#define VIPDRV_INFINITE 0xFFFFFFFF

#define CMODEL_MEMORY_SIZE (128ULL << 30)

#define VIPDRV_INTERNAL

vip_uint32_t vip_reg[vipdMP_NUM];
#if vpmdENABLE_VIDEO_MEMORY_HEAP
vipdrv_videomem_heap_info_t heap_info[HEAP_CNT] = {0};
#endif

vip_uint32_t logi_dev_cnt = 0;
vipdrv_device_info_t* logi_infos = VIP_NULL;
vip_uint8_t irq_map[vipdMP_NUM];

typedef struct _core {
    /* HW required objects. */
    volatile vip_uint32_t irq_event;
    HANDLE semaphore;
    vip_uint32_t core_id;
    vipdrv_atomic irq_count;
} core_t;

typedef struct _context {
    void* contiguous[HEAP_CNT];
    core_t cores[vpmdCORE_COUNT];
    void* axi_sram;
    void* reserve_mem;
} context_t;

static context_t s_Context = {0};

#define GET_CONTEXT() context_t* context = &s_Context

void irq_handler(void* data)
{
    // Check whether it's VIP's interrupt.
    vip_uint32_t irq_value = 0;
    core_t* core = (core_t*)data;
    GET_CONTEXT();
    irq_value = CModelReadRegister(core->core_id, 0x00010);

    if (irq_value != 0) {
        core->irq_event |= irq_value;
        vipdrv_os_inc_atomic(core->irq_count);
        context->cores[irq_map[core->core_id]].irq_event |= IRQ_VALUE_FLAG;
        ReleaseSemaphore(context->cores[irq_map[core->core_id]].semaphore, 1, NULL);
    }
}

void InitEmulator();
void DestroyEmulator();

vip_bool_e WINAPI DllMain(IN HINSTANCE Instance, IN DWORD Reason, IN LPVOID Reserved)
{
    switch (Reason) {
    case DLL_PROCESS_ATTACH:
        InitEmulator();
        break;

    case DLL_PROCESS_DETACH:
        DestroyEmulator();
        break;
    }

    return vip_true_e;
}

/*
@ brief
    Start up the HW, and prepare the memory for driver to use.
*/
VIPDRV_INTERNAL void InitEmulator()
{
    return;
}

VIPDRV_INTERNAL
void DestroyEmulator()
{
    vip_uint32_t i = 0;
    GET_CONTEXT();

    for (i = 0; i < vpmdCORE_COUNT; i++) {
        vipdrv_os_destroy_atomic(context->cores[i].irq_count);
        /* Release the signal object. */
        ReleaseSemaphore(context->cores[i].semaphore, 1, NULL);
        CloseHandle(context->cores[i].semaphore);
    }

    for (i = 0; i < HEAP_CNT; i++) {
        if (context->contiguous[i] != NULL) {
            CModelFree((cmMemoryInfo*)context->contiguous[i]);
            context->contiguous[i] = NULL;
        }
    }
    if (context->axi_sram != NULL) {
        CModelFree((cmMemoryInfo*)context->axi_sram);
        context->axi_sram = NULL;
    }
    if (VIP_NULL != context->reserve_mem) {
        CModelFree((cmMemoryInfo*)context->reserve_mem);
        context->reserve_mem = NULL;
    }

    /* Destroy the C-Model. */
    CModelDestructor();

    return;
}

/*
 Get the video memory config information
*/
vip_status_e vipdrv_drv_get_memory_config(vipdrv_vendor_memory_config_t* memory_info)
{
    vip_uint32_t i = 0;

    if (VIP_NULL == memory_info) {
        PRINTK_E("get video memory info param is NULL\n");
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

#if vpmdENABLE_VIDEO_MEMORY_HEAP
    memory_info->heap_count = 2;
    memory_info->heap_infos = heap_info;

    PRINTK("video memory heap base=0x%"PRIx64", size=0x%x\n", memory_info->heap_infos[0].vip_physical,
           memory_info->heap_infos[0].vip_memsize);
#endif

#if vpmdENABLE_RESERVE_PHYSICAL
    memory_info->reserve_phy_base = RESERVE_PHY_BASE_ADDRESS;
    memory_info->reserve_phy_size = RESERVE_PHY_SIZE;
#endif

    return VIP_SUCCESS;
}

/*
@brief Get all hardware basic information.
*/
vip_status_e vipdrv_drv_get_hardware_info(vipdrv_hardware_info_t* info)
{
    if (VIP_NULL == info) {
        PRINTK_E("get hardware memory info param is NULL\n");
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    info->device_count = logi_dev_cnt;
    info->device_info = logi_infos;

    return VIP_SUCCESS;
}

vip_status_e vipdrv_drv_set_power_clk(vip_uint32_t dev, vip_uint32_t core, vip_uint32_t state)
{
    return VIP_SUCCESS;
}

/*
@ brief
    Read a register.
*/
vip_status_e vipdrv_os_read_reg(volatile void* reg_base, vip_uint32_t Address, vip_uint32_t* Data)
{
    *Data = CModelReadRegister(*(vip_uint32_t*)reg_base, Address);
    return VIP_SUCCESS;
}

/*
@ brief
    Write a register.
*/
vip_status_e vipdrv_os_write_reg(volatile void* reg_base, vip_uint32_t Address, vip_uint32_t Data)
{
    CModelWriteRegister(*(vip_uint32_t*)reg_base, Address, Data);

#if vpmdENABLE_AHB_LOG
    PRINTK("@[register.write 0x%05X 0x%08X]\n", Address, Data);
#endif

    /* only for linux emulator signal sync, not used on FPGA and silicon */
    if (0x003A4 == Address) {
        vipdrv_os_delay(500);
    }

    return VIP_SUCCESS;
}

/*
@ brief
    Wait for interrupt.
*/
vip_status_e vipdrv_os_wait_interrupt(IN void* irq_queue, IN volatile vip_uint32_t* volatile irq_flag,
                                      IN vip_uint32_t TimeOut, IN vip_uint32_t Mask)
{
    vip_status_e error = VIP_SUCCESS;
    HANDLE* wait_queue = (HANDLE*)irq_queue;
    DWORD result = 0;

    result = WaitForSingleObject(*wait_queue, (DWORD)TimeOut);
    switch (result) {
    case WAIT_OBJECT_0:
        error = VIP_SUCCESS;
        break;
    case WAIT_TIMEOUT:
        error = VIP_ERROR_TIMEOUT;
        break;

    default:
        error = VIP_ERROR_IO;
        break;
    }

    return error;
}

vip_status_e vipdrv_os_wakeup_interrupt(IN void* irq_queue)
{
    vip_status_e status = VIP_SUCCESS;
    HANDLE* wait_queue = (HANDLE*)irq_queue;

    ReleaseSemaphore(*wait_queue, 1, NULL);

    return status;
}

vip_status_e CallEmulator(vipdrv_intrface_e Command, void* Data)
{
    return vipdrv_interface_call(Command, Data);
}

static vip_int32_t drv_prepare_logical_device_info(void)
{
    GET_CONTEXT();
#define SRAM_ALIGN_GAP (10 * 1024 * 1024)

    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t i = 0, j = 0, core_cnt = 0, irq_index = 0;
    cmMemoryInfo* axi = VIP_NULL;
    vip_uint32_t device_core_number[vpmdCORE_COUNT] = {0};
    vip_uint32_t logi_idx = 0;
    vip_uint32_t core_start_index = 0;

    /* calculate logical device */
    {
        vip_uint32_t* core_pre_device_ptr = LOGIC_DEVICES_WITH_CORE;
        vip_int32_t index_buf = 0, core_num = 0, iter = 0, sum_core = 0;
        vip_bool_e record = vip_false_e;
        vip_char_t* buf = getenv("LOGIC_DEVICES_WITH_CORE");
        if (VIP_NULL != buf) {
            while (buf[index_buf]) {
                if ('0' <= buf[index_buf] && '9' >= buf[index_buf]) {
                    core_num = 10 * core_num + buf[index_buf] - '0';
                    record = vip_true_e;
                } else {
                    if (record) {
                        /* core number after 0 is invalid */
                        /* {2,1,0,4,0,0,0,0}. indicate that driver supports 2 logical device */
                        if (0 == core_num)
                            break;

                        if (vpmdCORE_COUNT > iter) {
                            device_core_number[iter++] = core_num;
                            sum_core += core_num;
                        } else {
                            /* too many device */
                            iter++;
                            break;
                        }
                    }
                    record = vip_false_e;
                    core_num = 0;
                }
                index_buf++;
            }

            if (0 >= sum_core) {
                /* 1 core at least */
                PRINTK_E("\n[ENV CONFIG CORE COUNT FAIL] set 1 core at least\n\n");
            } else if (vpmdCORE_COUNT < sum_core) {
                /* too many core */
                PRINTK_E("\n[ENV CONFIG CORE COUNT FAIL] total core number should be less than %d\n\n",
                         vpmdCORE_COUNT);
            } else if (vpmdCORE_COUNT < iter) {
                PRINTK_E("\n[ENV CONFIG CORE COUNT FAIL] device number should be less than %d\n\n",
                         vpmdCORE_COUNT);
            } else {
                core_pre_device_ptr = device_core_number;
            }
        }

        for (iter = 0; iter < vpmdCORE_COUNT; iter++) {
            device_core_number[iter] = core_pre_device_ptr[iter];
        }
    }

    for (i = 0; i < vipdMP_NUM; i++) {
        if (0 == device_core_number[i]) {
            break;
        }
        logi_dev_cnt++;

        for (j = 0; j < device_core_number[i]; j++) {
            irq_map[core_cnt++] = irq_index;
#if !vpmdTASK_PARALLEL_ASYNC
            irq_index++;
#endif
        }
#if vpmdTASK_PARALLEL_ASYNC
        irq_index += device_core_number[i];
#endif
    }

    if (0 == logi_dev_cnt) {
        PRINTK_E("logical device cnt is 0\n");
        return -1;
    }
    PRINTK_E("logical device cnt is %d\n", logi_dev_cnt);

    vipdrv_os_allocate_memory(sizeof(vipdrv_device_info_t) * logi_dev_cnt, (void**)&logi_infos);
    if (VIP_NULL == logi_infos) {
        PRINTK_E("alloc device info buffer\n");
        return -1;
    }

    for (logi_idx = 0; logi_idx < logi_dev_cnt; logi_idx++) {
        vip_uint32_t core = 0;
        vipdrv_device_info_t* info = &logi_infos[logi_idx];
        info->core_count = device_core_number[logi_idx];

        if (context->axi_sram) {
            axi = (cmMemoryInfo*)context->axi_sram;
            info->axi_sram_base = axi->physical;
        }
        if (context->axi_sram) {
            axi = (cmMemoryInfo*)context->axi_sram;
            info->axi_sram_base = axi->physical;
        }
        info->vip_sram_base = VIP_SRAM_BASE_ADDRESS;

        for (core = 0; core < info->core_count; core++) {
            vip_reg[core + core_start_index] = core + core_start_index;
            info->vip_reg[core] = (void*)&vip_reg[core + core_start_index];
            info->irq_queue[core] = (void*)&context->cores[core + core_start_index].semaphore;
            info->irq_value[core] = &context->cores[core + core_start_index].irq_event;
            info->axi_sram_size[core] = AXI_SRAM_SIZE[core + core_start_index];
            info->irq_count[core] = &context->cores[core + core_start_index].irq_count;
            info->core_id[core] = core + core_start_index;
        }
        core_start_index += info->core_count;

        PRINTK("axi-sram=0x%08x, size=0x%x\n", info->axi_sram_base, info->axi_sram_size);
    }

    return 0;
}

static vip_int32_t drv_unprepare_logical_device_info(void)
{
    vipdrv_os_free_memory(logi_infos);
    logi_infos = VIP_NULL;

    return 0;
}

vip_status_e vipdrv_os_init(vip_uint32_t no_used)
{
    vip_uint32_t i = 0;
    vip_uint32_t video_mem_size = VIDEO_MEMORY_HEAP_SIZE[0];
    vip_address_t video_mem_base = vipdCONTIGUOUS_BASE[0];
    vip_uint32_t axi_mem_size = 0;
    vip_address_t axi_mem_base = AXI_SRAM_BASE_ADDRESS;
    vip_uint32_t axi_mem_size_default = 0;
    GET_CONTEXT();

    for (i = 0; i < vpmdCORE_COUNT; i++) {
        axi_mem_size_default += AXI_SRAM_SIZE[i];
    }
    axi_mem_size = axi_mem_size_default;

    if (0 >= axi_mem_size || (CMODEL_MEMORY_SIZE - VIP_SRAM_SIZE[0]) < axi_mem_size) {
        PRINTK_E("axi_mem_size param is invalid, use default param.\n");
        axi_mem_size = axi_mem_size_default;
    }

    if (0 >= axi_mem_base) {
        PRINTK_E("axi_mem_base param is invalid, use default param.\n");
        axi_mem_base = AXI_SRAM_BASE_ADDRESS;
    }

    if ((VIP_SRAM_SIZE[0] + VIP_SRAM_BASE_ADDRESS > (vip_uint32_t)axi_mem_base) &&
        (axi_mem_base + axi_mem_size) > VIP_SRAM_BASE_ADDRESS) {
        PRINTK_E("axi sram overlap with vip sram, use default param.\n");
        axi_mem_size = axi_mem_size_default;
        axi_mem_base = AXI_SRAM_BASE_ADDRESS;
    }

    if (0 >= video_mem_size || (CMODEL_MEMORY_SIZE - VIP_SRAM_SIZE[0] - axi_mem_size) < video_mem_size) {
        PRINTK_E("video_mem_size param is invalid, use default param.\n");
        video_mem_size = VIDEO_MEMORY_HEAP_SIZE[0];
    }

    if (0 >= video_mem_base) {
        PRINTK_E("video_mem_base param is invalid, use default param.\n");
        video_mem_base = vipdCONTIGUOUS_BASE[0];
    }

    if ((VIP_SRAM_SIZE[0] + VIP_SRAM_BASE_ADDRESS > (vip_uint32_t)video_mem_base) &&
        (video_mem_base + video_mem_size) > VIP_SRAM_BASE_ADDRESS) {
        PRINTK_E("video memory overlap with vip sram, use default param.\n");
        video_mem_size = VIDEO_MEMORY_HEAP_SIZE[0];
        video_mem_base = vipdCONTIGUOUS_BASE[0];
    }

    if ((axi_mem_base + axi_mem_size > (vip_uint32_t)video_mem_base) &&
        (video_mem_base + video_mem_size) > axi_mem_base) {
        PRINTK_E("video memory overlap with axi sram, use default param.\n");
        video_mem_size = VIDEO_MEMORY_HEAP_SIZE[0];
        video_mem_base = vipdCONTIGUOUS_BASE[0];
    }

    /* Construct Cmodel object: acquire the memory pool. */
    CModelConstructor(CMODEL_MEMORY_SIZE);
    CModelAllocate(VIP_SRAM_SIZE[0] + VIP_SRAM_BASE_ADDRESS, 0, TRUE);
    if (0 < axi_mem_size) {
        context->axi_sram = CModelAllocate(axi_mem_size, axi_mem_base, TRUE);
    }
    context->contiguous[0] = CModelAllocate(video_mem_size, video_mem_base, TRUE);
    context->contiguous[1] = CModelAllocate(VIDEO_MEMORY_HEAP_SIZE[1], vipdCONTIGUOUS_BASE[1], TRUE);

#if vpmdENABLE_RESERVE_PHYSICAL
    context->reserve_mem = CModelAllocate(RESERVE_PHY_SIZE, RESERVE_PHY_BASE_ADDRESS, TRUE);
#endif

    for (i = 0; i < vpmdCORE_COUNT; i++) {
        context->cores[i].core_id = i;
        vipdrv_os_create_atomic(&context->cores[i].irq_count);
        /* Register irq handler. */
        CModelRegisterIrq(i, irq_handler, &context->cores[i]);

        /* Create the semaphore to setup irq handler loop. */
        {
            DWORD pid = GetCurrentProcessId();
            char pname[100] = {0};
            char aid[100] = {0};
            _itoa(pid, aid, 10);
            sprintf(pname, "Local\\GPU_IRQ_%s_%d", aid, i);

            context->cores[i].semaphore = CreateSemaphore(NULL, 0, 1, pname);
        }
    }
#if vpmdENABLE_VIDEO_MEMORY_HEAP
    for (i = 0; i < HEAP_CNT; i++) {
        heap_info[i].name = "heap-reserved";
        heap_info[i].vip_physical = (vip_address_t)((cmMemoryInfo*)context->contiguous[i])->physical;
        heap_info[i].vip_memsize = (vip_size_t)((cmMemoryInfo*)context->contiguous[i])->bytes;
        heap_info[i].ops.phy_cpu2vip = VIP_NULL;
        heap_info[i].ops.phy_vip2cpu = VIP_NULL;
        heap_info[i].device_vis = ~(vip_uint64_t)0;
    }
#endif

    drv_prepare_logical_device_info();

    return VIP_SUCCESS;
}

vip_status_e vipdrv_os_close(void)
{
    drv_unprepare_logical_device_info();

    return VIP_SUCCESS;
}

void vipdrv_os_delay(vip_uint32_t ms)
{
    Sleep((DWORD)ms);
}

void vipdrv_os_udelay(IN vip_uint32_t us)
{
    vip_uint32_t ms = us / 1000 + 1;
    Sleep((DWORD)ms);
}

vip_uint64_t vipdrv_os_get_time()
{
    return GetTickCount64() * 1000;
}

vip_status_e vipdrv_os_allocate_memory(IN vip_size_t size, OUT void** memory)
{
    vip_status_e error = VIP_SUCCESS;

    if (size > 0) {
        *memory = malloc(size);
        if (*memory == VIP_NULL) {
            error = VIP_ERROR_OUT_OF_MEMORY;
        }
    } else {
        error = VIP_ERROR_INVALID_ARGUMENTS;
    }

    return error;
}

vip_status_e vipdrv_os_free_memory(IN void* memory)
{
    if (memory != VIP_NULL) {
        free(memory);
    }
    return VIP_SUCCESS;
}

vip_status_e vipdrv_os_print(vip_log_level level, const char* Msg, ...)
{
    vip_status_e error = VIP_SUCCESS;
    char strbuf[256] = {'\0'};
    va_list arg;
    va_start(arg, Msg);
    vsnprintf(strbuf, 256, Msg, arg);
    va_end(arg);

    printf("%s", strbuf);

    return error;
}

vip_status_e vipdrv_os_snprint(vip_char_t* Buffer, vip_uint32_t Size, const vip_char_t* Msg, ...)
{
    vip_status_e error = VIP_SUCCESS;

    va_list arg;
    va_start(arg, Msg);
    vsnprintf(Buffer, Size, Msg, arg);
    va_end(arg);

    return error;
}

/*
@ brief
    set memory to zero.
*/
vip_status_e vipdrv_os_zero_memory(IN void* memory, IN vip_size_t size)
{
    if (!memory) {
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    memset(memory, 0, size);

    return VIP_SUCCESS;
}

/*
@brief copy src memory to dst memory.
@param dst, Destination memory.
@param src. Source memory
@param size, the size of memory should be copy.
*/
vip_status_e vipdrv_os_copy_memory(IN void* dst, IN const void* src, IN vip_size_t size)
{
    if ((VIP_NULL == src) || (VIP_NULL == dst)) {
        PRINTK("copy memory, parameter is NULL, size: %d bytes\n", size);
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    memcpy(dst, src, size);

    return VIP_SUCCESS;
}

/* memory barrier function */
vip_status_e vipdrv_os_memorybarrier(void)
{
    return VIP_SUCCESS;
}

vip_status_e vipdrv_os_create_mutex(vipdrv_mutex* mutex)
{
    vip_status_e status = VIP_SUCCESS;

    *mutex = CreateMutex(VIP_NULL, vip_false_e, VIP_NULL);
    return status;
}

vip_status_e vipdrv_os_lock_mutex(vipdrv_mutex mutex)
{
    vip_status_e status = VIP_SUCCESS;
    if (mutex == VIP_NULL) {
        return VIP_ERROR_OUT_OF_MEMORY;
    }

    WaitForSingleObject(mutex, VIPDRV_INFINITE);

    return status;
}

vip_status_e vipdrv_os_unlock_mutex(vipdrv_mutex mutex)
{
    vip_status_e status = VIP_SUCCESS;
    if (mutex == VIP_NULL) {
        return VIP_ERROR_OUT_OF_MEMORY;
    }

    ReleaseMutex(mutex);

    return status;
}

vip_status_e vipdrv_os_destroy_mutex(vipdrv_mutex mutex)
{
    vip_status_e status = VIP_SUCCESS;
    if (mutex == VIP_NULL) {
        PRINTK("destroy, mutex is NULL\n");
        return VIP_ERROR_OUT_OF_MEMORY;
    }

    CloseHandle(mutex);

    return status;
}

vip_status_e vipdrv_os_create_thread(vipdrv_thread_func func, vip_ptr parm, vip_char_t* name,
                                     vipdrv_thread* handle)
{
    if ((handle != VIP_NULL) && (func != VIP_NULL)) {
        *handle = CreateThread(VIP_NULL, 0, (LPTHREAD_START_ROUTINE)func, parm, 0, VIP_NULL);
        if (*handle == VIP_NULL) {
            PRINTK("create thread\n");
            return VIP_ERROR_IO;
        }
    } else {
        PRINTK("create thread. parameter is NULL\n");
        if (handle != VIP_NULL) {
            *handle = VIP_NULL;
        }
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    return VIP_SUCCESS;
}

vip_status_e vipdrv_os_destroy_thread(vipdrv_thread handle)
{
    if (handle != VIP_NULL) {
        CloseHandle(handle);
    } else {
        PRINTK("destroy thread");
        return VIP_ERROR_IO;
    }

    return VIP_SUCCESS;
}

vip_status_e vipdrv_os_create_signal(vipdrv_signal* handle)
{
    vip_status_e error = VIP_SUCCESS;

    *handle = CreateEvent(VIP_NULL, vip_true_e, vip_false_e, VIP_NULL);

    return error;
}

vip_status_e vipdrv_os_wait_signal(vipdrv_signal handle, vip_uint32_t timeout)
{
    vip_status_e error = VIP_SUCCESS;

    if (WAIT_TIMEOUT == WaitForSingleObject(handle, (DWORD)timeout)) {
        return VIP_ERROR_TIMEOUT;
    }

    return error;
}

vip_status_e vipdrv_os_set_signal(vipdrv_signal handle, vip_bool_e state)
{
    vip_status_e error = VIP_SUCCESS;

    if (state == vip_true_e) {
        SetEvent(handle);
    } else {
        ResetEvent(handle);
    }

    return error;
}

vip_status_e vipdrv_os_destroy_signal(vipdrv_signal handle)
{
    vip_status_e error = VIP_SUCCESS;

    CloseHandle(handle);

    return error;
}

/*
@brief Create a atomic.
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_create_atomic(vipdrv_atomic* atomic)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t* c_atomic = VIP_NULL;
    vipIsNULL(atomic);

    status = vipdrv_os_allocate_memory(sizeof(vip_uint32_t), (void**)&c_atomic);
    if (status != VIP_SUCCESS) {
        PRINTK_E("allocate memory for atomic\n");
        return VIP_ERROR_IO;
    }

    /* Initialize the atomic */
    *c_atomic = 0;
    *atomic = (vip_ptr)c_atomic;

onError:
    return status;
}

/*
@brief Destroy a atomic which create in vipdrv_os_create_atomic
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_destroy_atomic(vipdrv_atomic atomic)
{
    vip_status_e status = VIP_SUCCESS;
    vipIsNULL(atomic);

    vipdrv_os_free_memory(atomic);

onError:
    return status;
}

/*
@brief Set the 32-bit value protected by an atomic.
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_set_atomic(vipdrv_atomic atomic, vip_uint32_t value)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t* data = (vip_uint32_t*)atomic;
    vipIsNULL(atomic);

    *data = value;

onError:
    return status;
}

/*
@brief Get the 32-bit value protected by an atomic.
@param atomic, create atomic pointer.
*/
vip_uint32_t vipdrv_os_get_atomic(vipdrv_atomic atomic)
{
    vip_uint32_t* data = (vip_uint32_t*)atomic;

    if (VIP_NULL == atomic) {
        PRINTK_E("get atomic is NULL\n");
        return VIP_NULL;
    }

    return *data;
}

/*
@brief Increase the 32-bit value protected by an atomic.
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_inc_atomic(vipdrv_atomic atomic)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t* data = (vip_uint32_t*)atomic;
    vipIsNULL(atomic);

    *data += 1;

onError:
    return status;
}

/*
@brief Decrease the 32-bit value protected by an atomic.
@param atomic, create atomic pointer.
*/
vip_status_e vipdrv_os_dec_atomic(vipdrv_atomic atomic)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t* data = (vip_uint32_t*)atomic;
    vipIsNULL(atomic);

    *data -= 1;

onError:
    return status;
}

vip_status_e vipdrv_os_create_timer(vipdrv_timer_func func, vip_ptr param, vip_uint32_t time_out,
                                    vipdrv_timer* timer)
{
    return VIP_SUCCESS;
}

vip_status_e vipdrv_os_start_timer(vipdrv_timer timer)
{
    return VIP_SUCCESS;
}

vip_status_e vipdrv_os_stop_timer(vipdrv_timer timer)
{
    return VIP_SUCCESS;
}

vip_status_e vipdrv_os_destroy_timer(vipdrv_timer timer)
{
    return VIP_SUCCESS;
}

vip_uint32_t vipdrv_os_get_pid(void)
{
    vip_uint32_t pid = 0;

    pid = (vip_uint32_t)GetCurrentProcessId();
    return pid;
}

vip_uint32_t vipdrv_os_get_tid(void)
{
    vip_uint32_t tid = 0;

    tid = (vip_uint32_t)GetCurrentThreadId();
    return tid;
}

vip_int32_t vipdrv_os_strcmp(const vip_char_t* s1, const vip_char_t* s2)
{
    return strcmp(s1, s2);
}
