/******************************************************************************\
|* Copyright (c) 2017-2025 by Vivante Corporation.  All Rights Reserved.      *|
|*                                                                            *|
|* The material in this file is confidential and contains trade secrets of    *|
|* of Vivante Corporation.  This is proprietary information owned by Vivante  *|
|* Corporation.  No part of this work may be disclosed, reproduced, copied,   *|
|* transmitted, or used in any way for any purpose, without the express       *|
|* written permission of Vivante Corporation.                                 *|
|*                                                                            *|
\******************************************************************************/

#define NEW_CMODEL_PIPE

#ifdef NEW_CMODEL_PIPE
#include <stdarg.h>
#include "aqcm.hpp"
#include <windows.h>
#include <handleapi.h>
#include "vip_drv_cmodel.h"
#include <vip_drv_device_platform_config_win32.h>

extern "C" {
#include <vip_drv_os_port.h>
#include <vip_drv_os.h>
}

/* Customized memory object for cmodel. */
class CMemory : public aqMemoryBase {
  protected:
    size_t m_PageCount;
    void** m_PageMap;
    HANDLE m_Critical;

  public:
    CMemory(size_t TotalMemory)
    {
        // Allocate the memory.
        m_PageCount = TotalMemory >> CM_PAGE_SHIFT;
        m_PageMap = new void*[m_PageCount];
        memset(m_PageMap, 0, sizeof(void*) * m_PageCount);
        PRINTK("cmodel: total video memory size=0x%x\n", TotalMemory);

        // Initialize the mutex.
        m_Critical = CreateMutex(NULL, FALSE, "memory_mutex");
    }

    virtual ~CMemory(void)
    {
        // Free the memory.
        delete[] m_PageMap;

        // Destroy the mutex.
        CloseHandle(m_Critical);
    }

    virtual U32 GetMemorySize(void)
    {
        // Return memory size.
        return static_cast<U32>(m_PageCount << CM_PAGE_SHIFT);
    }

    virtual bool SetMemorySize(U32 MemorySize)
    {
        return false;
    }

    virtual U32 Read(cmtPADDRESS Address)
    {
        void* logical;
        U32 data = 0;

        if (0 == Address) {
            PRINTK("cmodel: read address 0\n");
        }

        // Get logical pointer.
        logical = GetLogical(Address);
        if (logical != NULL) {
            // Read data from the memory.
            data = *reinterpret_cast<U32*>(logical);
        }

        // Return the data.
        return data;
    }

    virtual void Write(cmtPADDRESS Address, U04 Mask, U32 Data)
    {
        void* logical;

        if (0 == Address) {
            PRINTK("cmodel: write address 0\n");
        }

        // Get logical pointer.
        logical = GetLogical(Address);
        if (logical != NULL) {
            // Dispatch on mask.
            switch (Mask) {
            case 0x1:
                // Lower 8-bit write.
                reinterpret_cast<U08*>(logical)[0] = static_cast<U08>(GETBITS(Data, 7, 0));
                break;

            case 0x2:
                // Mid-lower 8-bit write.
                reinterpret_cast<U08*>(logical)[1] = static_cast<U08>(GETBITS(Data, 15, 8));
                break;

            case 0x4:
                // Mid-upper 8-bit write.
                reinterpret_cast<U08*>(logical)[2] = static_cast<U08>(GETBITS(Data, 23, 16));
                break;

            case 0x8:
                // Upper 8-bit write.
                reinterpret_cast<U08*>(logical)[3] = static_cast<U08>(GETBITS(Data, 31, 24));
                break;

            case 0x3:
                // Lower 16-bit write.
                reinterpret_cast<U16*>(logical)[0] = static_cast<U16>(GETBITS(Data, 15, 0));
                break;

            case 0xC:
                // Upper 16-bit write.
                reinterpret_cast<U16*>(logical)[1] = static_cast<U16>(GETBITS(Data, 31, 16));
                break;

            case 0xF:
                // 32-bit write.
                reinterpret_cast<U32*>(logical)[0] = Data;
                break;

            default:
                if (Mask & 0x1) {
                    // Write bits [7:0].
                    reinterpret_cast<U08*>(logical)[0] = static_cast<U08>(GETBITS(Data, 7, 0));
                }
                if (Mask & 0x2) {
                    // Write bits [15:8].
                    reinterpret_cast<U08*>(logical)[1] = static_cast<U08>(GETBITS(Data, 15, 8));
                }
                if (Mask & 0x4) {
                    // Write bits [23:16].
                    reinterpret_cast<U08*>(logical)[2] = static_cast<U08>(GETBITS(Data, 23, 16));
                }
                if (Mask & 0x8) {
                    // Write bits [31:24].
                    reinterpret_cast<U08*>(logical)[3] = static_cast<U08>(GETBITS(Data, 31, 24));
                }
                break;
            }
        }
    }

    virtual void* GetMemoryAddress(void) const
    {
        return NULL;
    }

    size_t GetPage(cmtPADDRESS Physical)
    {
        return Physical >> CM_PAGE_SHIFT;
    }

    cmtPADDRESS CalPhysical(size_t page)
    {
        return (cmtPADDRESS)page << CM_PAGE_SHIFT;
    }

    void* GetLogical(cmtPADDRESS Physical)
    {
        // Convert physical address to page index.
        U32 page = (U32)GetPage(Physical);
        if (page >= m_PageCount) {
            // Page is out-of-bounds.
            PRINTK("cmodel: fail get logical memory out of boundary m_PageCount=%d, page=%d\n", m_PageCount,
                   page);
            return NULL;
        }

        // Get logical address.
        void* logical = m_PageMap[page];
        if (logical == NULL) {
            // Page is not allocated.
            PRINTK("cmodel: fail get logical logical is NULL\n");
            return NULL;
        }

        // Add page offset to logical address.
        return static_cast<U08*>(logical) + (Physical & (CM_PAGE_SIZE - 1));
    }

    cmtPADDRESS GetPhysical(void* Logical)
    {
        // Cast the pointer to byte-addressable memory.
        U08* address = static_cast<cmUInt8*>(Logical);

        for (cmSize i = 0; i < m_PageCount; i++) {
            // Get mapped address.
            U08* map = static_cast<U08*>(m_PageMap[i]);

            // Check if the pointer is inside this mapped page.
            if ((address >= map) && (address < map + CM_PAGE_SIZE)) {
                // Return physical address for this pointer.
                return CalPhysical(i) + (address - map);
            }
        }

        PRINTK("cmodel: fail get physical not found\n");

        // Invalid address.
        return ~0U;
    }

    cmMemoryInfo* AllocateContiguous(size_t Bytes, size_t Address)
    {
        // Compute number of required pages.
        size_t pages = (Bytes + CM_PAGE_SIZE - 1) >> CM_PAGE_SHIFT;

        // Out of memory.
        if (pages > m_PageCount) {
            PRINTK("Allocate Contiguous[%ld] is bigger than m_PageCount[%ld].\n", pages, m_PageCount);
            return NULL;
        }

        // Create a new memory info structure.
        cmMemoryInfo* memory = new cmMemoryInfo;
        if (memory == NULL) {
            // Out of memory.
            PRINTK("Allocate Contiguous fail can't new memory new cmMemoryInfo\n");
            return NULL;
        }

        // Allocate a new memory blob.
        U08* logical = NULL;
        if (0 != Address) { /* vipsram */
            logical = new U08[pages << CM_PAGE_SHIFT];
            if (logical == NULL) {
                // Delete the memory info structure.
                delete memory;
                PRINTK("Allocate Contiguous fail can't new memory new page\n");
                // Out of memory.
                return NULL;
            }
        } else {
            logical = (U08*)(memory);
        }

        // Lock the mutex.
        WaitForSingleObject(m_Critical, INFINITE); //pthread_mutex_lock(&m_Critical);

        if (-1 != Address) {
            size_t start_page = Address >> CM_PAGE_SHIFT;
            size_t i = 0;

            for (i = start_page; i < start_page + pages; i++) {
                if (m_PageMap[i] != NULL) {
                    break;
                }
            }

            if (i == start_page + pages) {
                // Process all pages in the range.
                for (i = 0; i < pages; i++) {
                    // Map the pages.
                    m_PageMap[start_page + i] = static_cast<void*>(logical + (i << CM_PAGE_SHIFT));
                }

                // Unlock the mutex.
                ReleaseMutex(m_Critical); //pthread_mutex_unlock(&m_Critical);

                // Fill in the memory information.
                memory->physical = CalPhysical(start_page);
                memory->logical = logical;
                memory->bytes = pages << CM_PAGE_SHIFT;

                // Return the memory info structure.
                return memory;
            }
        } else {
            // Process all pages.
            for (size_t i = 0; i < m_PageCount - pages; i++) {
                // Check if there are enough free pages.
                size_t j;
                for (j = 0; j < pages; j++) {
                    if (m_PageMap[i + j] != NULL) {
                        // Page is in use, break loop.
                        i += j;
                        break;
                    }
                }

                // Check if this range is large enough.
                if (j == pages) {
                    // Process all pages in the range.
                    for (j = 0; j < pages; j++) {
                        // Map the pages.
                        m_PageMap[i + j] = static_cast<void*>(logical + (j << CM_PAGE_SHIFT));
                    }

                    // Unlock the mutex.
                    ReleaseMutex(m_Critical); //pthread_mutex_unlock(&m_Critical);

                    // Fill in the memory information.
                    memory->physical = CalPhysical(i);
                    memory->logical = logical;
                    memory->bytes = pages << CM_PAGE_SHIFT;

                    // Return the memory info structure.
                    return memory;
                }
            }
        }

        // Unlock the mutex.
        ReleaseMutex(m_Critical); //pthread_mutex_unlock(&m_Critical);

        // Delete the memory blob.
        delete[] logical;

        // Delete the memory info structure.
        delete memory;
        PRINTK("cmodel: fail to allocate contiguous memory\n");

        // Out of memory.
        return NULL;
    }

    cmMemoryInfo* Allocate(size_t Bytes)
    {
        // Compute the required number of pages.
        size_t pages = (Bytes + CM_PAGE_SIZE - 1) >> CM_PAGE_SHIFT;

        // Create a new memory info structure.
        cmMemoryInfo* memory = new cmMemoryInfo;
        if (memory == NULL) {
            // Out of memory.
            PRINTK("Allocate fail can't new memory new cmMemoryInfo\n");
            return NULL;
        }

        // Allocate a new memory blob.
        U08* logical = new U08[pages << CM_PAGE_SHIFT];
        if (logical == NULL) {
            // Delete the memory info structure.
            delete memory;
            PRINTK("Allocate fail can't new memory new page\n");

            // Out of memory.
            return NULL;
        }

        // Fill in the memory info structure.
        memory->logical = logical;
        memory->bytes = pages << CM_PAGE_SHIFT;

        // Lock the mutex.
        WaitForSingleObject(m_Critical, INFINITE); // pthread_mutex_lock(&m_Critical);

        // Process all pages.
        size_t j = 0;
        for (size_t i = 0; (i < m_PageCount) && (pages > 0); i++) {
            // Test if page is empty.
            if (m_PageMap[i] == NULL) {
                // Test if this is the first page.
                if (j == 0) {
                    // Set physiucal memory.
                    memory->physical = CalPhysical(i);
                }

                // Set localgical address for page.
                m_PageMap[i] = logical + j;

                // Next logical address.
                j += 1 << CM_PAGE_SHIFT;

                // Decrease the number of pages.
                pages--;
            }
        }

        // Unlock the mutex.
        ReleaseMutex(m_Critical);

        // Test if we are out of memory.
        if (pages > 0) {
            if (j) {
                // Free the allocated memory.
                Free(memory);
            } else {
                // Delete loglcal memory.
                delete logical;

                // Delete the memory info structure.
                delete memory;
            }
            PRINTK("cmodel: fail to allocate memory\n");

            // Out of memory.
            return NULL;
        }

        // Return the memory info pointer.
        return memory;
    }

    void Free(cmMemoryInfo* Memory)
    {
        // Compute the number of pages and the initial page.
        size_t pages = Memory->bytes >> CM_PAGE_SHIFT;
        size_t page = GetPage(Memory->physical);

        // Set range of logical memory.
        U08* start = static_cast<U08*>(Memory->logical);
        U08* end = start + Memory->bytes;

        // Lock the mutex.
        WaitForSingleObject(m_Critical, INFINITE);

        // Check if the starting page is valid.
        if (page < m_PageCount) {
            // Process all pages.
            for (size_t i = page; pages > 0;) {
                // Check if the current page is in the logical memory range.
                if (m_PageMap[i] >= start && m_PageMap[i] < end) {
                    // Mark page as empty.
                    m_PageMap[i] = NULL;

                    // Decrease the number of pages.
                    pages--;
                }

                // Increase the page index and test for overflow.
                if (++i >= m_PageCount) {
                    // Wrap to page 0.
                    i = 0;
                } else if ((i == page) && (pages > 0)) {
                    // No more pages found.
                    break;
                }
            }
        }

        // Unlock the mutex.
        ReleaseMutex(m_Critical);

        // Delete the logical memory.
        delete Memory->logical;

        // Delete the memory info structure.
        delete Memory;
    }
};

class CModelWrapper {
  public:
    CModelWrapper(UINT32 ChipID = 0) : chipID(ChipID), cmodelThreadRunning(FALSE)
    {
        DWORD pid = GetCurrentProcessId();
        char pname[100] = {0};
        char aid[100] = {0};
        char id[10] = {0};
        _itoa(pid, aid, 10);
        _itoa(ChipID, id, 10);

        cmodel = new cmoTopLevel(FALSE, TRUE, chipID);
        sprintf(pname, "Local\\wait_%s_%s", aid, id);
        waitSignal = CreateSemaphore(NULL, 0, 1, pname);
        memset(pname, 0, sizeof(pname));
        sprintf(pname, "Local\\irq_%s_%s", aid, id);
        interruptSemaphore = CreateSemaphore(NULL, 0, 1, pname);
        memset(pname, 0, sizeof(pname));
        sprintf(pname, "Local\\cmodel_%s_%s", aid, id);
        cmodelSemaphore = CreateSemaphore(NULL, 0, 1, pname);
        interruptSuspended = 0;
    }

    ~CModelWrapper()
    {
        CloseHandle(waitSignal);
        CloseHandle(cmodelSemaphore);

        delete cmodel;
    }

    cmoTopLevel* cmodel;
    UINT32 chipID;
    HANDLE waitSignal;
    HANDLE interruptSemaphore;
    HANDLE cmodelSemaphore;
    bool cmodelThreadQuit;
    bool interruptQuit;
    bool interruptSuspended;
    HANDLE interruptThread;
    HANDLE cmodelThread;
    volatile bool cmodelThreadRunning;
    void (*irq_handler)(void* data);
    void* pdata; //Private data.
};

typedef CModelWrapper* CModelWrapperPtr;

static CModelWrapperPtr* wrappers = NULL;

static INT32 nWrapper = vpmdCORE_COUNT;

aqMemoryBase* _SystemMemory = NULL;

static void CModelWait(IN void* Context, IN U32 CommandDelay)
{
    CModelWrapperPtr wrapper = static_cast<CModelWrapperPtr>(Context);
    WaitForSingleObject(wrapper->waitSignal, CommandDelay);
}

BOOL CModelRelease(IN U32 Core)
{
    if (NULL != wrappers[Core]) {
        return ReleaseSemaphore(wrappers[Core]->waitSignal, 1, NULL);
    }

    return false;
}

static void CModelInterrupt(IN void* Context)
{
    CModelWrapperPtr wrapper = static_cast<CModelWrapperPtr>(Context);

    /* Kick off interrupt thread. */
    ReleaseSemaphore(wrapper->interruptSemaphore, 1, NULL);
}

DWORD WINAPI CModelThread(void* Context)
{
    CModelWrapperPtr wrapper = static_cast<CModelWrapperPtr>(Context);

    wrapper->cmodelThreadRunning = true;

    for (;;) {
        WaitForSingleObject(wrapper->cmodelSemaphore, (DWORD)~0);

        if (wrapper->cmodelThreadQuit) {
            break;
        }
        Sleep(100);
        wrapper->cmodel->Execute();
    }

    return NULL;
}

DWORD WINAPI InterruptThread(void* Context)
{
    CModelWrapperPtr wrapper = static_cast<CModelWrapperPtr>(Context);

    for (;;) {
        WaitForSingleObject(wrapper->interruptSemaphore, (DWORD)~0);
        if (wrapper->interruptQuit) {
            break;
        }

        // Wait for end of critical section.
        while (wrapper->interruptSuspended)
            ;

        //Handle interrupt.
        if (wrapper->irq_handler != NULL) {
            (*wrapper->irq_handler)(wrapper->pdata);
        }
    }

    return 0;
}

int CModelConstructor(cmSize Size)
{
    INT32 i = 0;
    /* Create memory. */
    _SystemMemory = new CMemory(Size);

    nWrapper = CModelGetCoreCount();

    /* Build C-Models. */
    wrappers = new CModelWrapperPtr[nWrapper];

    cmsCALLBACKS callbacks;
    memset(&callbacks, 0, sizeof(callbacks));
    callbacks.Interrupt = CModelInterrupt;
    callbacks.Abort = NULL;
    callbacks.Wait = CModelWait;

    for (i = 0; i < nWrapper; i++) {
        wrappers[i] = new CModelWrapper(i);
        /* Set call-back functions. */
        wrappers[i]->cmodel->RegisterCallback(wrappers[i], callbacks);

        /* Create interrupt threads. */
        wrappers[i]->interruptQuit = false;
        wrappers[i]->interruptThread = CreateThread(NULL, 0, InterruptThread, wrappers[i], 0, NULL);

        /* Create C-Model threads. */
        wrappers[i]->cmodelThreadQuit = false;
        wrappers[i]->cmodelThread = CreateThread(NULL, 0, CModelThread, wrappers[i], 0, NULL);
    }

    /* Success. */
    return 0;
}

cmMemoryInfo* CModelAllocate(size_t Bytes, size_t Address, cmBool Contiguous)
{
    return ((CMemory*)_SystemMemory)->AllocateContiguous(Bytes, Address);
}

void CModelDestructor()
{
    INT32 i = 0;
    CModelWrapperPtr wrapper = NULL;
    for (i = 0; i < nWrapper; i++) {
        wrapper = wrappers[i];
        /* Destroy the interrupt thread. */
        wrapper->interruptQuit = true;

        ReleaseSemaphore(wrapper->interruptSemaphore, 1, NULL);
        CloseHandle(wrapper->interruptThread);
        CloseHandle(wrapper->interruptSemaphore);

        /* Destroy the C-Model thread. */
        wrapper->cmodelThreadQuit = true;
        ReleaseSemaphore(wrapper->waitSignal, 1, NULL);
        ReleaseSemaphore(wrapper->cmodelSemaphore, 1, NULL);
        CloseHandle(wrapper->cmodelThread);

        /* Destroy the C-Model. */
        delete wrapper;
    }
    delete _SystemMemory;
    _SystemMemory = NULL;

    /* Success. */
}

void CModelPrint(const char* Message, ...)
{
#ifdef gcdCMODEL_LOG_FILE
    static FILE* f;
    if (f == NULL) {
        f = fopen(gcdCMODEL_LOG_FILE, "a");
    }
    if (strcmp(Message, "$$$FLUSH$$$\n") == 0) {
        fclose(f);
        f = NULL;
    } else {
        va_list arguments;
        va_start(arguments, Message);
        vfprintf(f, Message, arguments);
        va_end(arguments);
    }
#else
    va_list args;
    va_start(args, Message);

    char buffer[1024];
    vsprintf_s(buffer, Message, args);

    OutputDebugString(buffer);

    va_end(args);
#endif
}

void CModelWriteRegister(IN UINT32 Core, IN UINT32 Address, IN UINT32 Data)
{
    if (NULL != wrappers[Core]) {
        /* Write the register to the C-Model. */
        wrappers[Core]->cmodel->WriteRegister(Address, Data);

/* Test for special registers. */
#if gcdSECURITY_ROBUSTNESS
        if (Address == GCREG_CMD_BUFFER_AHB_CTRL_Address)
#else
        if (Address == AQ_CMD_BUFFER_CTRL_Address)
#endif
        {
            /* Run the C-Model. */
            while (!wrappers[Core]->cmodelThreadRunning)
                ;
            {
                /* Run the C-Model. */
                ReleaseSemaphore(wrappers[Core]->cmodelSemaphore, 1, NULL);
            }
        }
    }
}

UINT32 CModelReadRegister(IN UINT32 Core, IN UINT32 Address)
{
    UINT32 data = 0;
    if (NULL != wrappers[Core]) {
        data = wrappers[Core]->cmodel->ReadRegister(Address);
    }
    return data;
}

cmBool CModelRegisterIrq(IN UINT32 Core, IRQ_HANDLER handler, void* private_data)
{
    if (NULL != wrappers[Core]) {
        wrappers[Core]->irq_handler = handler;
        wrappers[Core]->pdata = private_data;
    }

    return 1;
}

bool CModelInterruptSuspend(IN UINT32 Core, IN bool Suspend)
{
    if (NULL != wrappers[Core]) {
        wrappers[Core]->interruptSuspended = Suspend;
    }

    return true;
}

void CModelFree(IN cmMemoryInfo* Memory)
{
    ((CMemory*)_SystemMemory)->Free(Memory);
}

cmUInt64 CModelPhysical(IN void* Logical)
{
    return ((CMemory*)_SystemMemory)->GetPhysical(Logical);
}

void* CModelLogical(IN cmUInt64 Physical)
{
    return ((CMemory*)_SystemMemory)->GetLogical(Physical);
}

cmUInt32 CModelGetCoreCount(void)
{
    return gcdCORE_COUNT;
}

#endif
