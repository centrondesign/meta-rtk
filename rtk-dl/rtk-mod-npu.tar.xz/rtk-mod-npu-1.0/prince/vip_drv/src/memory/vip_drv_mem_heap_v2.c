/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#undef VIPDRV_LOG_ZONE
#define VIPDRV_LOG_ZONE VIPDRV_LOG_ZONE_VIDEO_MEMORY

#include <vip_drv_mem_heap.h>
#if vpmdENABLE_VIDEO_MEMORY_HEAP && (vpmdENABLE_MMU && !VIDEO_MEMORY_HEAP_MAP_MMU)
#include <vip_drv_context.h>
#include <vip_drv_mmu.h>

#define FACTOR_PER_LEVEL     16
#define EXPAND_CONTAINER_CNT 32

typedef enum _heap_block_type {
    HEAP_BLOCK_256B = 0,
    HEAP_BLOCK_4K = 1,
    HEAP_BLOCK_64K = 2,
    HEAP_BLOCK_1M = 3,
    HEAP_BLOCK_16M = 4,
    HEAP_BLOCK_MAX,
} heap_block_type_e;

#define BLOCK_HEAD 1
#define BLOCK_TAIL 2
typedef struct _vipdrv_heap_block {
    struct _vipdrv_heap_block* p;
    struct _vipdrv_heap_block* q;
    vip_uint8_t type;
    vip_uint8_t root:2; /* 0: not root; 1: head; 2: tail */
    vip_uint8_t __unuse:6;
    vip_uint16_t bitmap;
    vip_uint32_t index;
} vipdrv_heap_block_t;

typedef vipdrv_heap_block_t heap_block_container_t[FACTOR_PER_LEVEL];

typedef struct _vipdrv_heap_extra {
    vipdrv_heap_block_t* block_list[HEAP_BLOCK_MAX];
    heap_block_container_t* idle_container;
    vip_uint32_t block_memory_cnt;
    void** block_memory;
    vip_address_t physical[HEAP_BLOCK_MAX * 2];
#if vpmdENABLE_MULTIPLE_TASK
    vipdrv_mutex mutex;
#endif
} vipdrv_heap_extra_t;

typedef struct _block_prop {
    vip_uint32_t size;
    vip_uint32_t align;
    vip_uint32_t shift;
    vip_char_t* name;
} block_prop_t;

static block_prop_t get_block_prop(heap_block_type_e type)
{
    block_prop_t prop = {0};
    prop.name = "None";
    switch (type) {
    case HEAP_BLOCK_256B: {
        prop.size = 0x100;
        prop.align = 0x100;
        prop.shift = 8;
        prop.name = "256B page";
    } break;

    case HEAP_BLOCK_4K: {
        prop.size = 0x1000;
        prop.align = 0x1000;
        prop.shift = 12;
        prop.name = "4K page";
    } break;

    case HEAP_BLOCK_64K: {
        prop.size = 0x10000;
        prop.align = 0x10000;
        prop.shift = 16;
        prop.name = "64K page";
    } break;

    case HEAP_BLOCK_1M: {
        prop.size = 0x100000;
        prop.align = 0x100000;
        prop.shift = 20;
        prop.name = "1M page";
    } break;

    case HEAP_BLOCK_16M: {
        prop.size = 0x1000000;
        prop.align = 0x1000000;
        prop.shift = 24;
        prop.name = "16M page";
    } break;

    default:
        break;
    }

    return prop;
}

static vip_address_t get_physical(vipdrv_heap_extra_t* extra, vipdrv_heap_block_t* block)
{
    block_prop_t prop = get_block_prop(block->type);
    if (block->root) {
        return extra->physical[(block->root - 1) * HEAP_BLOCK_MAX + block->type] + prop.size * block->index;
    }
    return get_physical(extra, block->p) + prop.size * block->index;
}

static heap_block_container_t* get_container(vipdrv_heap_extra_t* extra)
{
    heap_block_container_t* container = VIP_NULL;
    if (VIP_NULL == extra->idle_container) {
        vip_status_e status = VIP_SUCCESS;
        vip_uint32_t i = 0;
        void** block_memory = VIP_NULL;
        status = vipdrv_os_allocate_memory(sizeof(heap_block_container_t) * EXPAND_CONTAINER_CNT,
                                           (void**)&container);
        if (VIP_SUCCESS != status) {
            return VIP_NULL;
        }
        vipdrv_os_zero_memory(container, sizeof(heap_block_container_t) * EXPAND_CONTAINER_CNT);
        status = vipdrv_os_allocate_memory(sizeof(void*) * (extra->block_memory_cnt + 1),
                                           (void**)&block_memory);
        if (VIP_SUCCESS != status) {
            vipdrv_os_free_memory(container);
            return VIP_NULL;
        }
        vipdrv_os_zero_memory(block_memory, sizeof(void*) * (extra->block_memory_cnt + 1));
        PRINTK_D("expand container of heap\n");

        if (VIP_NULL != extra->block_memory) {
            vipdrv_os_copy_memory(block_memory, extra->block_memory, sizeof(void*) * extra->block_memory_cnt);
            vipdrv_os_free_memory(extra->block_memory);
        }
        extra->block_memory = block_memory;
        extra->block_memory[extra->block_memory_cnt] = (void*)container;
        extra->block_memory_cnt += 1;

        for (i = 0; i < EXPAND_CONTAINER_CNT - 1; i++) {
            container[i][0].q = &container[i + 1][0];
        }
        extra->idle_container = &container[0];
    }
    container = extra->idle_container;
    extra->idle_container = (heap_block_container_t*)container[0]->q;

    return container;
}

static vip_status_e put_container(vipdrv_heap_extra_t* extra, heap_block_container_t* container)
{
    vip_status_e status = VIP_SUCCESS;
    vipAssert(VIP_NULL != container, "heap container is null");
    container[0]->q = (vipdrv_heap_block_t*)extra->idle_container;
    extra->idle_container = container;

onError:
    return status;
}

static vip_status_e vipdrv_alloc_mgt_heap_uninit(vipdrv_allocator_t* allocator)
{
    vipdrv_alloc_mgt_heap_t* heap = (vipdrv_alloc_mgt_heap_t*)allocator;
    vipdrv_heap_extra_t* extra = (vipdrv_heap_extra_t*)heap->extra;

    if (VIP_NULL != extra) {
        vip_uint32_t i = 0;
#if vpmdENABLE_MULTIPLE_TASK
        if (VIP_NULL != extra->mutex) {
            vipdrv_os_destroy_mutex(extra->mutex);
            extra->mutex = VIP_NULL;
        }
#endif

        for (i = 0; i < extra->block_memory_cnt; i++) {
            vipdrv_os_free_memory(extra->block_memory[i]);
        }
        vipdrv_os_free_memory(extra->block_memory);

        vipdrv_os_free_memory(extra);
        heap->extra = VIP_NULL;
    }

    return VIP_SUCCESS;
}

static vip_uint32_t cal_block_cnt(vip_physical_t physical, vip_uint64_t size, heap_block_type_e type)
{
    vip_uint32_t cnt = 0;
    block_prop_t prop = get_block_prop(type);
    vip_uint32_t size_head = VIP_ALIGN(physical, prop.align) - physical;
    vip_uint64_t size_tail = 0;
    size_head = size_head > size ? size : size_head;
    size -= size_head;
    size_tail = size & (prop.align - 1);
    size -= size_tail;
    cnt += size / prop.size;
    if (HEAP_BLOCK_256B != type) {
        if (size_head) {
            cnt += cal_block_cnt(physical, size_head, type - 1);
        }
        if (size_tail) {
            cnt += cal_block_cnt(physical + size_head + size, size_tail, type - 1);
        }
    }
    return cnt;
}

static vip_uint32_t fill_block(vip_physical_t physical, vip_uint64_t size, heap_block_type_e type,
                               vipdrv_heap_extra_t* extra, vipdrv_heap_block_t* block, vip_uint8_t root_type)
{
    vip_uint32_t cnt = 0;
    block_prop_t prop = get_block_prop(type);
    vip_uint32_t size_head = VIP_ALIGN(physical, prop.align) - physical;
    vip_uint64_t size_tail = 0;
    vip_uint32_t i = 0;
    size_head = size_head > size ? size : size_head;
    size -= size_head;
    size_tail = size & (prop.align - 1);
    size -= size_tail;
    cnt += size / prop.size;
    for (i = 0; i < cnt; i++) {
        block[i].type = type;
        block[i].index = i;
        block[i].root = root_type;
        block[i].q = extra->block_list[type];
        extra->block_list[type] = &block[i];
    }
    extra->physical[(root_type - 1) * HEAP_BLOCK_MAX + type] = physical + size_head;

    if (HEAP_BLOCK_256B != type) {
        if (size_head) {
            cnt += fill_block(physical, size_head, type - 1, extra, block + cnt, BLOCK_HEAD);
        }
        if (size_tail) {
            cnt += fill_block(physical + size_head + size, size_tail, type - 1, extra, block + cnt,
                              BLOCK_TAIL);
        }
    }

    return cnt;
}

static vip_status_e split_block(vipdrv_heap_extra_t* extra, heap_block_type_e type)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_heap_block_t* block_parent = VIP_NULL;
    vipdrv_heap_block_t* block = VIP_NULL;
    vip_uint32_t i = 0;
    if (VIP_NULL != extra->block_list[type]) {
        return VIP_SUCCESS;
    }

    if (HEAP_BLOCK_16M == type) {
        return VIP_ERROR_OUT_OF_MEMORY;
    }

    if (VIP_NULL == extra->block_list[type + 1]) {
        vipOnError(split_block(extra, type + 1));
    }
    block = (vipdrv_heap_block_t*)get_container(extra);
    if (VIP_NULL == block) {
        vipOnError(VIP_ERROR_OUT_OF_MEMORY);
    }

    block_parent = extra->block_list[type + 1];
    extra->block_list[type + 1] = block_parent->q;
    block_parent->q = VIP_NULL;

    for (i = 0; i < FACTOR_PER_LEVEL; i++) {
        block[i].bitmap = 0;
        block[i].index = i;
        block[i].p = block_parent;
        if (i != FACTOR_PER_LEVEL - 1) {
            block[i].q = &block[i + 1];
        } else {
            block[i].q = VIP_NULL;
        }
        block[i].root = 0;
        block[i].type = type;
    }
    extra->block_list[type] = &block[0];

onError:
    return status;
}

static vip_status_e put_heap_blocks(vipdrv_heap_extra_t* extra, vipdrv_heap_block_t* block)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_heap_block_t* next = VIP_NULL;
    while (VIP_NULL != block) {
        next = block->q;

        block->q = extra->block_list[block->type];
        extra->block_list[block->type] = block;
        if (VIP_NULL != block->p) {
            block->p->bitmap &= ~(1 << block->index);
            if (0 == block->p->bitmap) {
                vipdrv_heap_block_t* parent = block->p;
                vipdrv_heap_block_t* last = VIP_NULL;
                vip_uint32_t cnt = 0;
                heap_block_container_t* container = VIP_NULL;
                block = extra->block_list[block->type];
                while (VIP_NULL != block) {
                    if (block->p == parent) {
                        cnt += 1;
                        if (0 == block->index) {
                            container = (heap_block_container_t*)block;
                        }
                        if (VIP_NULL != last) {
                            last->q = block->q;
                        } else {
                            extra->block_list[block->type] = block->q;
                        }
                    } else {
                        last = block;
                    }
                    block = block->q;
                }
                vipAssert(FACTOR_PER_LEVEL == cnt, "GC block cnt=0x%x", cnt);
                put_container(extra, container);
                put_heap_blocks(extra, parent);
            }
        }

        block = next;
    }

onError:
    return status;
}

static vip_status_e get_heap_blocks(vipdrv_heap_extra_t* extra, heap_block_type_e type, vip_uint64_t size,
                                    vipdrv_heap_block_t** res)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_heap_block_t* block = VIP_NULL;
    vip_uint32_t cnt = VIP_ALIGN(size, get_block_prop(type).size) >> get_block_prop(type).shift;

    if (cnt && VIP_NULL == extra->block_list[type]) {
        split_block(extra, type);
    }
    while (cnt && VIP_NULL != extra->block_list[type]) {
        block = extra->block_list[type];
        extra->block_list[type] = block->q;
        block->q = *res;
        *res = block;
        vipAssert(0 == block->bitmap, "block bitmap=0x%x", block->bitmap);
        cnt -= 1;
        while (VIP_NULL != block->p) {
            if (block->p->bitmap & (1 << block->index)) {
                break;
            }
            block->p->bitmap |= (1 << block->index);
            block = block->p;
        }
        if (cnt && VIP_NULL == extra->block_list[type]) {
            split_block(extra, type);
        }
    }

onError:
    if (0 != cnt) {
        put_heap_blocks(extra, *res);
        *res = VIP_NULL;
    }

    return status;
}

static vip_status_e vipdrv_alloc_mgt_heap_alloc(vipdrv_video_mem_phy_handle_t* handle,
                                                vipdrv_alloc_param_ptr param)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_alloc_mgt_heap_t* heap = VIP_NULL;
    vipdrv_alloc_mgt_t* alloc_mgt = VIP_NULL;
    vipdrv_allocator_alloc_param_t* alloc_param = (vipdrv_allocator_alloc_param_t*)param;
    vip_uint64_t size = 0;
    vip_uint32_t align = 0;
    vipdrv_heap_extra_t* extra = VIP_NULL;
    heap_block_type_e type = HEAP_BLOCK_MAX;
    vipdrv_heap_block_t* block = VIP_NULL;
    vip_uint32_t cnt = 0;
    block_prop_t prop = {0};
    vip_uint32_t margin = 0;

    if (VIP_NULL == handle || VIP_NULL == param) {
        PRINTK_E("heap alloc, memory parameter is NULL\n");
        return VIP_ERROR_FAILURE;
    }
    heap = (vipdrv_alloc_mgt_heap_t*)handle->allocator;
    extra = (vipdrv_heap_extra_t*)heap->extra;
    alloc_mgt = &heap->allocator_mgt;
    align = alloc_param->align;
    size = alloc_param->size;
    handle->mem_flag = alloc_param->mem_flag;

    if (0 == heap->total_size) {
        return VIP_ERROR_FAILURE;
    }

#if vpmdENABLE_MULTIPLE_TASK
    status = vipdrv_os_lock_mutex(extra->mutex);
    if (status != VIP_SUCCESS) {
        PRINTK_E("lock video memory heap mutex\n");
        return VIP_ERROR_IO;
    }
#endif

    if (heap->free_bytes < alloc_param->size) {
        PRINTK_D("free size=0x%"PRIx64" is not enough\n", heap->free_bytes);
        vipGoOnError(VIP_ERROR_IO);
    }

    if (alloc_param->specified) {
        if (alloc_param->virtual) {
            switch (vipdrv_mmu_get_page_type(size)) {
            case VIPDRV_MMU_16M_PAGE:
                margin = vipdMMU_PAGE_16M_SIZE - 1;
                break;
            case VIPDRV_MMU_1M_PAGE:
                margin = vipdMMU_PAGE_1M_SIZE - 1;
                break;
            case VIPDRV_MMU_64K_PAGE:
                margin = vipdMMU_PAGE_64K_SIZE - 1;
                break;
            default:
                margin = vipdMMU_PAGE_4K_SIZE - 1;
            }
            margin = alloc_param->address & margin;
        } else {
            PRINTK_E("not support specify physical\n");
            vipGoOnError(VIP_ERROR_NOT_SUPPORTED);
        }
    }

    if ((VIPDRV_MEM_FLAG_CONTIGUOUS & alloc_param->mem_flag) == VIPDRV_MEM_FLAG_CONTIGUOUS) {
        vip_uint32_t i = 0;
        for (i = 0; i < HEAP_BLOCK_MAX; i++) {
            prop = get_block_prop(i);
            if (prop.size >= size && prop.align >= align) {
                type = i;
                break;
            }
        }
        if (i == HEAP_BLOCK_MAX) {
            PRINTK_D("allocate contiguous memory, size=0x%"PRIx64", align=0x%x\n", size, align);
            vipOnError(VIP_ERROR_IO);
        }
    } else if ((VIPDRV_MEM_FLAG_16M_CONTIGUOUS & alloc_param->mem_flag) == VIPDRV_MEM_FLAG_16M_CONTIGUOUS) {
        type = HEAP_BLOCK_16M;
    } else if ((VIPDRV_MEM_FLAG_1M_CONTIGUOUS & alloc_param->mem_flag) == VIPDRV_MEM_FLAG_1M_CONTIGUOUS) {
        type = HEAP_BLOCK_1M;
    } else if ((VIPDRV_MEM_FLAG_64K_CONTIGUOUS & alloc_param->mem_flag) == VIPDRV_MEM_FLAG_64K_CONTIGUOUS) {
        type = HEAP_BLOCK_64K;
    } else {
        block_prop_t prop = get_block_prop(HEAP_BLOCK_256B);
        if (alloc_param->specified) {
            type = HEAP_BLOCK_4K;
        } else {
            if (prop.align >= align && prop.size >= size) {
                type = HEAP_BLOCK_256B;
            } else {
                type = HEAP_BLOCK_4K;
            }
        }
    }
    prop = get_block_prop(type);
    cnt = VIP_ALIGN(size + margin, prop.size) >> prop.shift;
    vipOnError(vipdrv_os_allocate_memory(sizeof(vip_physical_t) * cnt, (void*)&handle->physical_table));
    vipOnError(vipdrv_os_allocate_memory(sizeof(vip_size_t) * cnt, (void*)&handle->size_table));

    get_heap_blocks(extra, type, size + margin, &block);
    if (VIP_NULL == block) {
        PRINTK_D("allocate(size=0x%"PRIx64", align=0x%x) %s from heap fail\n", size, align,
                 get_block_prop(type).name);
        vipGoOnError(VIP_ERROR_IO);
    }
    handle->alloc_handle = (void*)block;

    cnt = 0;
    while (VIP_NULL != block) {
        if (0 == cnt) {
            handle->size_table[cnt] = prop.size - margin;
            handle->physical_table[cnt] = get_physical(extra, block) + margin;
        } else {
            handle->size_table[cnt] = prop.size;
            handle->physical_table[cnt] = get_physical(extra, block);
        }
        cnt += 1;
        block = block->q;
    }
    heap->free_bytes -= VIP_ALIGN(size, prop.size);
    handle->allocator_type = VIPDRV_ALLOCATOR_TYPE_VIDO_HEAP;
    handle->size = alloc_param->size;
    handle->align = align;
    handle->physical_num = cnt;
    /* call the alloc func define in allocator  */
    status = alloc_mgt->base_callback.allocate(handle, param);
    if (status != VIP_SUCCESS) {
        PRINTK_E("heap alloc size=%d status=%d\n", size, status);
        vipOnError(status);
    }
    handle->mem_flag |= alloc_mgt->allocator.mem_flag;

#if vpmdENABLE_MULTIPLE_TASK
    vipdrv_os_unlock_mutex(extra->mutex);
#endif
    return status;
onError:
    if (VIP_NULL != handle->physical_table) {
        vipdrv_os_free_memory(handle->physical_table);
        handle->physical_table = VIP_NULL;
    }
    if (VIP_NULL != handle->size_table) {
        vipdrv_os_free_memory(handle->size_table);
        handle->size_table = VIP_NULL;
    }
#if vpmdENABLE_MULTIPLE_TASK
    vipdrv_os_unlock_mutex(extra->mutex);
#endif

    return status;
}

static vip_status_e vipdrv_alloc_mgt_heap_free(vipdrv_video_mem_phy_handle_t* handle)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_alloc_mgt_heap_t* heap = VIP_NULL;
    vipdrv_alloc_mgt_t* alloc_mgt = VIP_NULL;
    vipdrv_heap_extra_t* extra = VIP_NULL;
    vipdrv_heap_block_t* block = VIP_NULL;

    if (handle == VIP_NULL) {
        PRINTK_E("free heap memory\n");
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    if (VIP_NULL == handle->physical_table) {
        return VIP_SUCCESS;
    }

    heap = (vipdrv_alloc_mgt_heap_t*)handle->allocator;
    extra = (vipdrv_heap_extra_t*)heap->extra;
    alloc_mgt = &heap->allocator_mgt;
    block = (vipdrv_heap_block_t*)handle->alloc_handle;
    if (0 == heap->total_size) {
        return VIP_SUCCESS;
    }

#if vpmdENABLE_MULTIPLE_TASK
    status = vipdrv_os_lock_mutex(extra->mutex);
    if (status != VIP_SUCCESS) {
        PRINTK_E("lock video memory heap mutex\n");
        return VIP_ERROR_FAILURE;
    }
#endif

#if vpmdENABLE_FLUSH_CPU_CACHE
    /* flush cache before free this video memory to
       avoid cpu write-back when this memory has been used by others */
    if (handle->allocator->callback.flush_cache) {
        handle->allocator->callback.flush_cache(handle, VIPDRV_CACHE_FLUSH);
    }
#endif

    alloc_mgt->base_callback.free(handle);
    if (VIP_NULL != handle->physical_table) {
        vipdrv_os_free_memory(handle->physical_table);
        handle->physical_table = VIP_NULL;
    }
    if (VIP_NULL != handle->size_table) {
        vipdrv_os_free_memory(handle->size_table);
        handle->size_table = VIP_NULL;
    }

    heap->free_bytes += handle->physical_num * get_block_prop(block->type).size;
    put_heap_blocks(extra, block);

#if vpmdENABLE_MULTIPLE_TASK
    status = vipdrv_os_unlock_mutex(extra->mutex);
    if (status != VIP_SUCCESS) {
        PRINTK_E("unlock video memory heap mutex\n");
    }
#endif

    return status;
}

vip_status_e vipdrv_alloc_mgt_heap_init(vipdrv_alloc_mgt_heap_t* heap, vipdrv_videomem_heap_info_t* heap_info)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_heap_extra_t* extra = VIP_NULL;
    vip_uint32_t cnt = 0;
    vipdrv_heap_block_t* block = VIP_NULL;
    void** block_memory = VIP_NULL;
    block_prop_t prop = get_block_prop(HEAP_BLOCK_256B);
    vip_uint32_t size_head = VIP_ALIGN(heap_info->vip_physical, prop.align) - heap_info->vip_physical;
    vip_uint64_t size_tail = (heap_info->vip_memsize - size_head) & (prop.align - 1);

    vipOnError(vipdrv_os_allocate_memory(sizeof(vipdrv_heap_extra_t), (void**)&extra));
    vipdrv_os_zero_memory((void*)extra, sizeof(vipdrv_heap_extra_t));

    vipOnError(vipdrv_os_allocate_memory(sizeof(void*) * (extra->block_memory_cnt + 1),
                                         (void**)&block_memory));
    vipdrv_os_zero_memory((void*)block_memory, sizeof(void*));

    /*
      divide heap into memory block and those block are root block.
      |256B|...|256B|4K|...|4K|64K|...|64K|1M|...|1M|16M|...|16M|1M|...|1M|64K|...|64K|4K|...|4K|256B|...|256B|
    */
    cnt = cal_block_cnt(heap_info->vip_physical, heap_info->vip_memsize, HEAP_BLOCK_16M);
    vipOnError(vipdrv_os_allocate_memory(sizeof(vipdrv_heap_block_t) * cnt, (void**)&block));
    vipdrv_os_zero_memory(block, sizeof(vipdrv_heap_block_t) * cnt);

    heap->physical = heap_info->vip_physical + size_head;
    heap->total_size = heap_info->vip_memsize - size_head - size_tail;
    heap->virtual = heap->physical;
    heap->free_bytes = heap->total_size;

    if (0 == heap->total_size) {
        vipGoOnError(VIP_SUCCESS);
    }

    if ((heap->physical + heap->total_size) > 0x100000000) {
        heap->allocator_mgt.allocator.mem_flag &= ~VIPDRV_MEM_FLAG_4GB_ADDR_PA;
    } else {
        heap->allocator_mgt.allocator.mem_flag |= VIPDRV_MEM_FLAG_4GB_ADDR_PA;
    }
    vipdrv_os_copy_memory(&heap->allocator_mgt.base_callback, &heap->allocator_mgt.allocator.callback,
                          sizeof(vipdrv_allocator_callback_t));
    heap->allocator_mgt.allocator.callback.uninit = vipdrv_alloc_mgt_heap_uninit;
    heap->allocator_mgt.allocator.callback.allocate = vipdrv_alloc_mgt_heap_alloc;
    heap->allocator_mgt.allocator.callback.free = vipdrv_alloc_mgt_heap_free;
    /* overwirte phy_cpu2vip/phy_vip2cpu callback if these callback are defines */
    if (heap_info->ops.phy_cpu2vip) {
        heap->allocator_mgt.allocator.callback.phy_cpu2vip = heap_info->ops.phy_cpu2vip;
        PRINTK_D("overwrite heap callback.phy_cpu2vip\n");
    }
    if (heap_info->ops.phy_vip2cpu) {
        heap->allocator_mgt.allocator.callback.phy_vip2cpu = heap_info->ops.phy_vip2cpu;
        PRINTK_D("overwrite heap callback.phy_vip2cpu\n");
    }
    heap->allocator_mgt.allocator.alctor_type = VIPDRV_ALLOCATOR_TYPE_VIDO_HEAP;
    heap->allocator_mgt.allocator.device_vis = heap_info->device_vis;

#if vpmdENABLE_MULTIPLE_TASK
    status |= vipdrv_os_create_mutex(&extra->mutex);
    if (status != VIP_SUCCESS) {
        PRINTK_E("create mutex for video heap\n");
        return VIP_ERROR_FAILURE;
    }
#endif
    heap->extra = extra;
    extra->block_memory = block_memory;
    extra->block_memory[extra->block_memory_cnt] = (void*)block;
    extra->block_memory_cnt += 1;
    fill_block(heap_info->vip_physical, heap_info->vip_memsize, HEAP_BLOCK_16M, extra, block, BLOCK_HEAD);
    return status;
onError:
    if (VIP_NULL != block_memory) {
        vipdrv_os_free_memory(block_memory);
    }
    if (VIP_NULL != block) {
        vipdrv_os_free_memory(block);
    }
    if (VIP_NULL != extra) {
#if vpmdENABLE_MULTIPLE_TASK
        if (VIP_NULL != extra->mutex) {
            vipdrv_os_destroy_mutex(extra->mutex);
            extra->mutex = VIP_NULL;
        }
#endif
        vipdrv_os_free_memory(extra);
    }
    return status;
}

vip_status_e vipdrv_heap_dump(vipdrv_alloc_mgt_heap_t* heap)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_heap_extra_t* extra = heap->extra;
    vip_uint32_t i = 0;
    vipdrv_heap_block_t* block = VIP_NULL;

    for (i = 0; i < HEAP_BLOCK_MAX; i++) {
        vip_uint32_t cnt = 0;
        block = extra->block_list[i];
        while (VIP_NULL != block) {
            cnt += 1;
            block = block->q;
        }
        PRINTK("%s idle block cnt=%u\n", get_block_prop(i).name, cnt);
    }
    PRINTK("heap %s free bytes=0x%"PRIx64"\n", heap->allocator_mgt.allocator.name, heap->free_bytes);

    return status;
}
#endif
