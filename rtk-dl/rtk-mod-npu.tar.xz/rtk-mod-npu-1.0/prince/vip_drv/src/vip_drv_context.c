/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/

#include <vip_drv_context.h>
#include <vip_drv_vipcore_driver.h>
#include <vip_drv_debug.h>
#include <vip_drv_task_descriptor.h>
#include <vip_feature_database.h>
#include <vipllm_feature_database.h>

/* vip drv context object. */
vipdrv_context_t vipDrvContext = {0};

/*
@brief Get vip-drv context object.
*/
void* vipdrv_get_context(vipdrv_context_property_e prop)
{
    vipdrv_context_t* context = &vipDrvContext;
    switch (prop) {
    case VIPDRV_CONTEXT_PROP_ALL:
        return (void*)context;
    case VIPDRV_CONTEXT_PROP_CID:
        return (void*)&context->chip_cid;
    case VIPDRV_CONTEXT_PROP_TASK_DESC:
        return (void*)&context->tskDesc_database;
#if vpmdTASK_QUEUE_USED
    case VIPDRV_CONTEXT_PROP_TCB:
        return (void*)&context->tskTCB_hashmap;
#endif
    case VIPDRV_CONTEXT_PROP_INITED:
        return (void*)&context->initialize;
    case VIPDRV_CONTEXT_PROP_DEVICE_CNT:
        return (void*)&context->device_count;
    case VIPDRV_CONTEXT_PROP_HARDWARE_CNT:
        return (void*)&context->core_count;
    default:
        break;
    }

    return VIP_NULL;
}

static vip_status_e vipdrv_device_init(vipdrv_context_t* context)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_hardware_info_t hw_info = {0};
    vipdrv_vendor_memory_config_t mem_config = {0};
    vip_uint32_t i = 0;

    status = vipdrv_drv_get_hardware_info(&hw_info);
    if (status != VIP_SUCCESS) {
        PRINTK_E("get hardware information, status=%d.\n", status);
        vipGoOnError(status);
    }
    context->device_count = hw_info.device_count;
    if (0 == context->device_count) {
        PRINTK_E("device init dev cnt is 0\n");
        vipGoOnError(VIP_ERROR_INVALID_ARGUMENTS);
    } else if ((context->device_count > (sizeof(vip_uint64_t) * 8)) ||
               (context->device_count > vipdMAX_DEVICE_NUM)) {
        PRINTK_E("max support %d device, device_count=%d\n", (sizeof(vip_uint64_t) * 8),
                 context->device_count);
        vipGoOnError(VIP_ERROR_NOT_SUPPORTED);
    }

#if vpmdFLEXA_DMA
#if vpmdENABLE_MULTIPLE_TASK
    status = vipdrv_os_create_mutex(&context->subsys_reg_mutex);
    if (status != VIP_SUCCESS) {
        PRINTK_E("create mutex for register memory\n");
        vipGoOnError(VIP_ERROR_IO);
    }
#endif
#endif
    status = vipdrv_drv_get_memory_config(&mem_config);
    if (status != VIP_SUCCESS) {
        PRINTK_E("get memory config, status=%d.\n", status);
        vipGoOnError(status);
    }

    /* use logical device 0 to construct these data */
    {
        vipdrv_device_info_t* device_info = &hw_info.device_info[0];
#if !vpmdENABLE_MMU
        context->axi_sram_address = (vip_virtual_t)device_info->axi_sram_base;
#endif
        context->axi_sram_physical = device_info->axi_sram_base;
        context->vip_sram_address = device_info->vip_sram_base;

#if vpmdFLEXA_DMA
        context->subsys_reg_base = device_info->subsys_reg_base;
        VIPDRV_CHECK_NULL(context->subsys_reg_base);
#endif

        PRINTK_D("axi sram address=0x%x, vipsram address=0x%08x\n", context->axi_sram_physical,
                 context->vip_sram_address);
#if vpmdENABLE_SYS_MEMORY_HEAP
        context->sys_heap_size = mem_config.sys_heap_size;
#endif
#if vpmdENABLE_RESERVE_PHYSICAL
        context->reserve_phy_base = mem_config.reserve_phy_base;
        context->reserve_phy_size = mem_config.reserve_phy_size;
#endif
        for (i = 0; i < device_info->core_count; i++) {
            context->axi_sram_size[i] = device_info->axi_sram_size[i];
            PRINTK_D("core %d axi sram size=0x%08x\n", i, context->axi_sram_size[i]);
            if (0 != context->axi_sram_size[i] % vipdMEMORY_ALIGN_SIZE) {
                PRINTK_E("core %d axi sram size=0x%08x is not %d align\n", i, context->axi_sram_size[i],
                         vipdMEMORY_ALIGN_SIZE);
                vipGoOnError(VIP_ERROR_FAILURE);
            }
        }
    }

    vipOnError(vipdrv_os_allocate_memory(sizeof(vipdrv_device_t) * context->device_count,
                                         (void**)&context->device));
    vipdrv_os_zero_memory(context->device, sizeof(vipdrv_device_t) * context->device_count);

    /* init vip-drv device */
    for (i = 0; i < context->device_count; i++) {
        vipdrv_device_info_t* device_info = &hw_info.device_info[i];
        vipdrv_device_t* device = &context->device[i];

        context->core_count += device_info->core_count;

        device->device_index = i;
        device->context = context;
        device->hardware_count = device_info->core_count;

        if (device->hardware_count > vipdMP_NUM) {
            PRINTK_E("dev_%d core count=%d large than max=%d\n", device->hardware_count, vipdMP_NUM);
            vipGoOnError(VIP_ERROR_NOT_SUPPORTED);
        }
        PRINTK_D("device_index=%d, this device core count=%d\n", i, device->hardware_count);
        vipOnError(vipdrv_os_allocate_memory(sizeof(vipdrv_hardware_t) * device->hardware_count,
                                             (void**)&device->hardware));
        vipdrv_os_zero_memory(device->hardware, sizeof(vipdrv_hardware_t) * device->hardware_count);

        VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(device)
#if vpmdTASK_PARALLEL_ASYNC
        if (0 == hw_index) {
            device->irq_queue = device_info->irq_queue[hw_index];
            device->irq_value = device_info->irq_value[hw_index];
        }
#endif

#if vpmdENABLE_RECOVERY
        hw->recovery_times = MAX_RECOVERY_TIMES;
#endif
        hw->core_id = device_info->core_id[hw_index];
        hw->core_index = hw_index;
        hw->device = device;
        hw->reg_base = device_info->vip_reg[hw_index];
        hw->init_done = vip_false_e;
        VIPDRV_CHECK_NULL(hw->reg_base);
        hw->irq_value = device_info->irq_value[hw_index];
        *hw->irq_value = 0;
        VIPDRV_CHECK_NULL(hw->irq_value);
#if !vpmdENABLE_POLLING
        hw->irq_queue = device_info->irq_queue[hw_index];
        VIPDRV_CHECK_NULL(hw->irq_queue);
        hw->irq_count = device_info->irq_count[hw_index];
        VIPDRV_CHECK_NULL(hw->irq_count);
#endif
#if vpmdENABLE_MULTIPLE_TASK
        status = vipdrv_os_create_mutex(&hw->reg_mutex);
        if (status != VIP_SUCCESS) {
            PRINTK_E("create mutex for register memory\n");
            vipGoOnError(VIP_ERROR_IO);
        }
#endif

#if vpmdENABLE_FLEXA_DMA_DUMP
        if (0 == hw_index) {
            context->flexa_dma_irq_queue = hw_info.device_info->flexa_dma_irq_queue[hw_index];
            context->flexa_dma_irq = hw_info.device_info->flexa_dma_irq[hw_index];
        }
#endif

#if vpmdENABLE_POWER_MANAGEMENT
        if (0 == device_info->core_fscale_percent || 100 < device_info->core_fscale_percent) {
            device_info->core_fscale_percent = 100;
        }
        hw->core_fscale_percent = (vip_uint8_t)device_info->core_fscale_percent;
#endif

        PRINTK_D("  dev_id=%d, core_id=%d, core_index=%d, core_fscale_percent=%d\n", i, hw->core_id,
                 hw->core_index, device_info->core_fscale_percent);

        vipOnError(vipdrv_os_allocate_memory(sizeof(vip_uint32_t) * TASK_HISTORY_RECORD_COUNT,
                                             (void**)&hw->previous_task_id));
        vipdrv_os_zero_memory(hw->previous_task_id, sizeof(vip_uint32_t) * TASK_HISTORY_RECORD_COUNT);
        vipOnError(vipdrv_os_allocate_memory(sizeof(vip_uint32_t) * TASK_HISTORY_RECORD_COUNT,
                                             (void**)&hw->previous_subtask_index));
        vipdrv_os_zero_memory(hw->previous_subtask_index, sizeof(vip_uint32_t) * TASK_HISTORY_RECORD_COUNT);
        VIPDRV_LOOP_HARDWARE_IN_DEVICE_END
    }

    PRINTK_D("total core count=%d, total device=%d\n", context->core_count, context->device_count);

onError:
    return status;
}

static vip_status_e vipdrv_device_uninit(vipdrv_context_t* context)
{
    VIPDRV_LOOP_DEVICE_START
    if (VIP_NULL == dev->hardware) {
        PRINTK_E("uninit device%d hardware\n", dev_index);
        continue;
    }
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(dev)
    if (hw != VIP_NULL) {
#if vpmdENABLE_MULTIPLE_TASK
        if (hw->reg_mutex != VIP_NULL) {
            vipdrv_os_destroy_mutex(hw->reg_mutex);
        }
#endif
        if (VIP_NULL != hw->previous_task_id) {
            vipdrv_os_free_memory(hw->previous_task_id);
            hw->previous_task_id = VIP_NULL;
        }
        if (VIP_NULL != hw->previous_subtask_index) {
            vipdrv_os_free_memory(hw->previous_subtask_index);
            hw->previous_subtask_index = VIP_NULL;
        }
    }
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_END
    vipdrv_os_free_memory(dev->hardware);
    dev->hardware = VIP_NULL;
    VIPDRV_LOOP_DEVICE_END

    if (context->device != VIP_NULL) {
        vipdrv_os_free_memory(context->device);
        context->device = VIP_NULL;
    }
    return VIP_SUCCESS;
}

vip_status_e vipdrv_context_init(vipdrv_context_t* context)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t index = 0;
    vip_uint32_t i = 0;

#if vpmdENABLE_DEBUG_LOG > 3
    vipdrv_dump_options();
#endif

    vipOnError(vipdrv_hashmap_init(&context->process_id, 8, 0, "process-ID", VIP_NULL, VIP_NULL, VIP_NULL));
    vipdrv_hashmap_insert(&context->process_id, (vip_uint64_t)vipdrv_os_get_pid(), &index);
    status = vipdrv_device_init(context);
    if (status != VIP_SUCCESS) {
        PRINTK_E("device init status=%d\n", status);
        vipGoOnError(status);
    }

    vipOnError(vipdrv_task_desc_init());

    vipOnError(vipdrv_task_tcb_init());
    PRINTK_D("tskTCB init done...\n");

    vipOnError(vipdrv_task_init());

    VIPDRV_LOOP_DEVICE_START
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(dev)
    status = vipdrv_os_create_atomic(&hw->idle);
    if (status != VIP_SUCCESS) {
        PRINTK_E("create atomic for vip idle\n");
        vipGoOnError(VIP_ERROR_IO);
    }
    vipdrv_os_set_atomic(hw->idle, vip_true_e);

#if vpmdENABLE_POWER_MANAGEMENT
    hw->disable_clock_suspend = 0;
#endif
#if vpmdENABLE_CLOCK_SUSPEND
    hw->clock_suspended = vip_false_e;
#endif
#if vpmdFLEXA_DMA
    vipdrv_flexa_dma_hw_reset(hw);
#endif
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_END
    VIPDRV_LOOP_DEVICE_END

    /* Read feature database */
    vipOnError(vipdrv_context_select_featureDB(context));

    /* init vip-sram size from feature database */
    if (VIP_HARDWARE_NN == context->hw_type) {
        for (i = 0; i < context->core_count; i++) {
            context->vip_sram_size[i] = context->feature_db.vip_database->vip_sram_size;
            PRINTK_D("hw%d vip sram size=0x%x\n", i, context->vip_sram_size[i]);
        }
    } else if (VIP_HARDWARE_LLM == context->hw_type) {
        context->vip_sram_size[0] = context->feature_db.vipllm_database->a_buffer_size;
    }

    return status;
onError:
    PRINTK_E("context init status=%d\n", status);
    return status;
}

vip_status_e vipdrv_context_uninit(vipdrv_context_t* context)
{
    vip_status_e status = VIP_SUCCESS;

    vipdrv_task_uninit();

    vipdrv_task_tcb_uninit();

    vipdrv_task_desc_uninit();
    VIPDRV_LOOP_DEVICE_START
    VIPDRV_LOOP_HARDWARE_IN_DEVICE_START(dev)
    if (hw->idle != VIP_NULL) {
        vipdrv_os_destroy_atomic(hw->idle);
        hw->idle = VIP_NULL;
    }

#if vpmdENABLE_FLEXA_DMA_DUMP
    vipdrv_uninit_flexa_dma_dump_thread(hw);
#endif

    VIPDRV_LOOP_HARDWARE_IN_DEVICE_END
    VIPDRV_LOOP_DEVICE_END
#if vpmdFLEXA_DMA
#if vpmdENABLE_MULTIPLE_TASK
    if (VIP_NULL != context->subsys_reg_mutex) {
        vipdrv_os_destroy_mutex(context->subsys_reg_mutex);
    }
#endif
#endif

    vipdrv_hashmap_destroy(&context->process_id);
    vipdrv_device_uninit(context);

    return status;
}

vip_status_e vipdrv_context_select_featureDB(vipdrv_context_t* context)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t i = 0;

    /* Read hardware information */
    vipdrv_hw_read_info();

    for (i = 0; i < sizeof(vip_chip_info) / sizeof(vip_hw_feature_db_t); i++) {
        if (context->chip_cid == vip_chip_info[i].pid) {
            context->feature_db.vip_database = &vip_chip_info[i];
            context->hw_type = VIP_HARDWARE_NN;
            break;
        }
    }
    if (VIP_NULL == context->feature_db.vip_database) {
        for (i = 0; i < sizeof(vipllm_chip_info) / sizeof(vipllm_hw_feature_db_t); i++) {
            if (context->chip_cid == vipllm_chip_info[i].pid) {
                context->feature_db.vipllm_database = &vipllm_chip_info[i];
                context->hw_type = VIP_HARDWARE_LLM;
                break;
            }
        }
        if (VIP_NULL == context->feature_db.vipllm_database) {
            status = VIP_ERROR_FAILURE;
            PRINTK_E("did not find feature database for 0x%x\n", context->chip_cid);
        }
    }
    if ((VIP_HARDWARE_NN != context->hw_type) && (VIP_HARDWARE_LLM != context->hw_type)) {
        PRINTK_E("vip hardware type is invalid type=%d\n", context->hw_type);
        vipGoOnError(VIP_ERROR_NOT_SUPPORTED);
    }

onError:
    return status;
}

vip_uint32_t vipdrv_context_query_featureDB(vip_hardware_feature_e feature)
{
    vip_uint32_t database = vip_false_e;
    vipdrv_context_t* context = &vipDrvContext;

    if (VIP_HARDWARE_NN == context->hw_type) {
        vip_hw_feature_db_t* vip_database = context->feature_db.vip_database;
        if (VIP_NULL == vip_database) {
            PRINTK_E("vip nn feature db is null\n");
            return vip_false_e;
        }
        switch (feature) {
        case VIP_FEATURE_JOB_CANCEL:
#if !(defined(_WIN32) || defined(LINUXEMULATOR))
            if (vip_database->job_cancel) {
                database = vip_true_e;
            }
#endif
            break;
        case VIP_FEATURE_MMU_PDMODE:
#if !(defined(_WIN32) || defined(LINUXEMULATOR))
            if (vip_database->mmu_pd_mode) {
                database = vip_true_e;
            }
#endif
            break;
        case VIP_FEATURE_FREQ_SCALE:
#if vpmdENABLE_USER_CONTROL_POWER
            database = vip_database->export_clkdiv2 ? vip_false_e : vip_true_e;
#endif
            break;
        case VIP_FEATURE_NN_ERROR_DETECT:
            database = vip_database->nn_error_detect ? vip_true_e : vip_false_e;
            break;
        case VIP_FEATURE_OCB_COUNTER:
            database = vip_database->ocb_counter ? vip_true_e : vip_false_e;
            break;
        case VIP_FEATURE_SH_CONFORMANCE_BRUTEFORCE:
            database = vip_database->sh_conformance ? vip_true_e : vip_false_e;
            break;
        case VIP_FEATURE_MMU:
            database = vip_database->remove_mmu ? vip_false_e : vip_true_e;
            break;
        case VIP_FEATURE_MMU_40VA:
            if (40 == vip_database->va_bits) {
                database = vip_true_e;
            }
            break;
        case VIP_FEATURE_NN_XYDP0:
            database = vip_database->nn_xydp0 ? vip_true_e : vip_false_e;
            break;
        case VIP_FEATURE_VIPSRAM_SHARE:
            database = vip_database->vip_sram_share ? vip_true_e : vip_false_e;
            break;
        case VIP_FEATURE_UNIQUE_ID:
            database = vip_database->unique_id ? vip_true_e : vip_false_e;
            break;
        case VIP_FEATURE_VIPSRAM_SIZE:
            database = vip_database->vip_sram_size;
            break;
        case VIP_FEATURE_TP_CORE_CNT:
            database = vip_database->tp_core_count;
            break;
        default:
            break;
        }
    } else if (VIP_HARDWARE_LLM == context->hw_type) {
        if (VIP_NULL == context->feature_db.vipllm_database) {
            PRINTK_E("vip llm feature db is null\n");
            return 0;
        }
        switch (feature) {
        case VIP_FEATURE_MMU:
        case VIP_FEATURE_MMU_40VA:
            database = vip_true_e;
            break;
        default:
            break;
        }
    } else {
        PRINTK_E("query hw_type=%d feature=%d not support\n", feature, context->hw_type);
    }

    return database;
}
