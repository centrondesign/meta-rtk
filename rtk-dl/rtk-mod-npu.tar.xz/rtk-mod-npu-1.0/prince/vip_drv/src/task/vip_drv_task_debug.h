/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#ifndef _VIP_DRV_TASK_DEBUG_H_
#define _VIP_DRV_TASK_DEBUG_H_
#include <vip_drv_type.h>
#include <vip_drv_util.h>
#include <vip_drv_share.h>

#define TASK_HISTORY_RECORD_COUNT 20
#define NUM_OF_AVG_TIME           100

vip_status_e vipdrv_task_tcb_dump(vipdrv_task_t* task);

vip_status_e vipdrv_task_desc_dump(vipdrv_task_t* task);

vip_status_e vipdrv_task_submit_parameter_dump(vipdrv_submit_task_param_t* sbmt_para);

void vipdrv_task_history_record(vipdrv_task_t* task);

vip_status_e vipdrv_task_history_dump(vipdrv_task_t* task);

vip_status_e vipdrv_task_database_dump(void);

#if vpmdTASK_QUEUE_USED
vip_status_e vipdrv_task_queue_dump(vipdrv_task_t* task);
#endif

vip_status_e vipdrv_task_profile_start(vipdrv_task_t* task);

vip_status_e vipdrv_task_profile_end(vipdrv_task_t* task);

#if vpmdENABLE_TASK_PROFILE
void vipdrv_hw_profile_reset(vipdrv_hardware_t* hardware);

vip_status_e vipdrv_task_profile_query(vipdrv_query_profiling_t* profiling);
#endif

#endif
