/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************/
#ifndef _VIP_DRV_TASK_DESCRIPTOR_H
#define _VIP_DRV_TASK_DESCRIPTOR_H
#include <vip_drv_type.h>
#include <vip_drv_share.h>

#define TASK_TIMEOUT_FACTOR 20

/*
   This define specified the number of milliseconds the system will wait
   before it broadcasts the VIP is stuck.
   In other words, it will define the timeout of any operation that needs to wait for the VIP.
   on FPGA, 3600000s as hang by default.
   on silicon, 20s as hang by default.
*/
#ifndef vpmdHARDWARE_TIMEOUT
#if vpmdFPGA_BUILD
#define vpmdHARDWARE_TIMEOUT 3600000
#else
#define vpmdHARDWARE_TIMEOUT 20000
#endif
#endif

#define TASK_MAGIC_DATA  0x80000000
#define TASK_INDEX_SHIFT 18

typedef struct _vipdrv_task_profile_bw {
    vip_uint32_t total_read;
    vip_uint32_t total_write;
    vip_uint32_t total_read_ocb;
    vip_uint32_t total_write_ocb;
} vipdrv_task_profile_bw_t;

typedef struct _vipdrv_task_profile_cycle {
    vip_uint32_t total_cycle;
    vip_uint32_t total_idle_cycle;
} vipdrv_task_profile_cycle_t;

typedef struct _vipdrv_subtask_cmd_info {
    /* 'subtask_id'. the id of video memory for the subtask commands. */
    vip_uint32_t mem_id;
    /* the real size of commands for subtask */
    vip_uint32_t size;
} vipdrv_subtask_cmd_info_t;

typedef struct _vipdrv_subtask_patch_info {
    vipdrv_task_patch_type_e type;
    /* the offset in command */
    vip_uint32_t offset;
    /* the size of command will be patched */
    vip_uint32_t size;
    /* the index of core in all used cores */
    vip_uint32_t core_index;
    /* the core count of this patch uses */
    vip_uint32_t core_count;
} vipdrv_subtask_patch_info_t;

typedef struct _vipdrv_subtask_info {
    vipdrv_subtask_cmd_info_t cmd;
    vip_uint32_t submit_count;

#if vpmdENABLE_TASK_PROFILE
#if vpmdENABLE_APP_PROFILING
    vipdrv_task_profile_cycle_t cur_cycle[vipdMP_NUM];
    vipdrv_task_profile_cycle_t avg_cycle[vipdMP_NUM];
#endif
#if vpmdENABLE_BW_PROFILING
    vipdrv_task_profile_bw_t cur_bw[vipdMP_NUM];
#endif
#endif

    /* the timeconsumed inference this subtask  */
    vip_uint64_t cur_time;
    vip_uint64_t avg_time; /* us */

    /* the index of core for the subtask last runs on */
    vip_uint32_t core_index;

#if vpmdTASK_SCHEDULE
    vip_uint32_t patch_cnt;
    vipdrv_subtask_patch_info_t* patch_info;
#endif
} vipdrv_subtask_info_t;

typedef struct _vipdrv_task_descriptor {
    vip_char_t task_name[TASK_NAME_LENGTH];
    /* the command buffer of preload coeff to SRAM */
    vipdrv_subtask_cmd_info_t preload_cmd;
    vipdrv_subtask_cmd_info_t init_cmd;
    /* the maximal subtask count of this task desc */
    vip_uint32_t subtask_count;
    vipdrv_subtask_info_t* subtasks;
    /* the CPU process id which the task belongs */
    vip_uint32_t pid;

    /* over this time, this task regard as hang, unit is millisecond */
    vip_uint32_t timeout;

    /* the size of vip-sram is used by the task */
    vip_uint32_t vip_sram_size;

    vip_uint32_t skip:1;
    /* set task timeout by hal */
    vip_uint32_t timeout_specify:1;
    /* whether cnn_profiling is set to enable or not */
    vip_uint32_t cnnprofile_enable:1;
    /* 1: bypass trigger hardware */
    vip_uint32_t bypass_sbmit:1;
    /* 1: preload coeff to vip-sram */
    vip_uint32_t preload_vipsram:1;
#if vpmdFLEXA_DMA
    vip_uint32_t continue_mode:1;
#endif
} vipdrv_task_descriptor_t;

vip_status_e vipdrv_task_desc_init(void);

vip_status_e vipdrv_task_desc_uninit(void);

/* Get the command buffer video memory information of vipdrv_task_cmd_type_e in the task
physical: the base address of command buffer
size: the real size of command buffer, not include APPEND cmd.
*/
vip_status_e vipdrv_task_desc_get_cmdbuf(vipdrv_task_descriptor_t* tsk_desc, vipdrv_task_t* task,
                                         vipdrv_task_cmd_type_e type, vip_uint32_t subtask_index,
                                         vip_uint32_t* mem_id, vip_uint8_t** logical, vip_uint32_t* physical,
                                         vip_uint32_t* size, vip_uint32_t* pid, vip_uint32_t* task_id);

vip_status_e vipdrv_task_desc_submit(vipdrv_submit_task_param_t* sbmt_para);

vip_status_e vipdrv_task_desc_wait(vipdrv_wait_task_param_t* wait_para);

vip_uint32_t vipdrv_task_desc_index2id(vip_uint32_t index);

vip_uint32_t vipdrv_task_desc_id2index(vip_uint32_t task_id);

vip_status_e vipdrv_task_desc_valid_check(vip_uint32_t task_id);

vip_status_e vipdrv_task_desc_create(vipdrv_create_task_param_t* tsk_param);

vip_status_e vipdrv_task_desc_destroy(vipdrv_destroy_task_param_t* param);

vip_status_e vipdrv_task_desc_set_property(vipdrv_set_task_property_t* task_property);

vip_status_e vipdrv_task_desc_force_destroy(vip_uint32_t pid);

vip_status_e vipdrv_task_desc_query(vipdrv_query_task_param_t* param);

#endif
