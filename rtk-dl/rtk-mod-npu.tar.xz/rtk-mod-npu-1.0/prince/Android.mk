LOCAL_PATH := $(call my-dir)

#
# VIP_LITE_MAKEFILES
#
include $(CLEAR_VARS)

VIP_LITE_MAKEFILES :=

ifneq ($(strip $(VIP_LITE_MAKEFILES)),)
  include $(VIP_LITE_MAKEFILES)
endif
