/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************
*
*    The GPL License (GPL)
*
*    Copyright (C) 2017 - 2025 Vivante Corporation
*
*    This program is free software; you can redistribute it and/or
*    modify it under the terms of the GNU General Public License
*    as published by the Free Software Foundation; either version 2
*    of the License, or (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software Foundation,
*    Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
*
*****************************************************************************
*
*    Note: This software is released under dual MIT and GPL licenses. A
*    recipient may use this file under the terms of either the MIT license or
*    GPL License. If you wish to use only one license not the other, you can
*    indicate your decision by deleting one of the above license notices in your
*    version of this file.
*
*****************************************************************************/

#ifndef _VIP_LITE_SHARE_H
#define _VIP_LITE_SHARE_H

#include <vip_lite_config.h>


/* Utility macro. */
typedef vip_uint8_t*         vip_uint8_t_ptr;
typedef vip_float_t*         vip_float_t_ptr;
typedef vip_uint32_t*        vip_uint32_t_ptr;
typedef vip_int32_t*         vip_int32_t_ptr;
typedef vip_char_t*          vip_char_t_ptr;
typedef vip_int8_t*          vip_int8_t_ptr;
typedef vip_int16_t*         vip_int16_t_ptr;
typedef vip_int64_t*         vip_int64_t_ptr;

typedef enum _vip_log_level
{
    VIP_LOG_ERROR = 0,
    VIP_LOG_WARN =  1,
    VIP_LOG_INFO =  2,
    VIP_LOG_DEBUG = 3,
    VIP_LOG_PRINT = 4,
} vip_log_level;


#define vipOnError(func)  \
    status = func; \
    if (status != VIP_SUCCESS) { \
        goto onError; \
    }

#define vipGoOnError(func)  \
    status = func; \
    goto onError;

#define vipIsNULL(object)  \
    if (VIP_NULL == object) { \
        status = VIP_ERROR_INVALID_ARGUMENTS; \
        goto onError; \
    }

/* align down. get base address after align */
#define VIP_ALIGN_BASE(n, align) \
( \
    ((n) & ~(vip_uint64_t)(((vip_uint64_t)(align)) - 1)) \
)

/* align up */
#define VIP_ALIGN(n, align) \
( \
    (((n) + ((align) - 1)) & ~(vip_uint64_t)(((vip_uint64_t)(align)) - 1)) \
)

#define VIP_INFINITE  ((vip_uint32_t) ~0U)
#define VIP_MAX(x, y) (((x) >= (y)) ? (x) : (y))
#define VIP_MIN(x, y) (((x) >= (y)) ? (y) : (x))

#define VIP_SETBIT(value, bit, data) \
    (((value) & (~(1 << (bit)))) | ((data & 0x1) << (bit)))

/* set the data into [start-end] bits of value */
#define VIP_SETBITS(value, start, end, data) \
    (((value) & (~((~0ULL >> (63 - (end) + (start))) << (start)))) | \
    (((data) & (~0ULL >> (63 - (end) + (start)))) << (start)))


#define GET_LOW32(data)           ((vip_uint32_t)((data) & 0xFFFFFFFF))
#if vpmd32BIT_OS
#define GET_HIGH32(data)          (0)
#define CONSTRUCT_U64(high, low)  (low)
#else
#define GET_HIGH32(data)         ((vip_uint32_t)(((vip_uint64_t)data) >> 32))
#define CONSTRUCT_U64(high, low) (((vip_uint64_t)(high) << 32) | (low))
#endif

#define BITS_PER_BYTE       8

/*
  the size of memory alignment for video memory.
  64 bytes.
*/
#if ((64 % vpmdCPU_CACHE_LINE_SIZE) != 0)
#define vipdMEMORY_ALIGN_SIZE    VIP_ALIGN(VIP_ALIGN(64, vpmdCPU_CACHE_LINE_SIZE), 64)
#else
#define vipdMEMORY_ALIGN_SIZE    64
#endif

#if vpmdFPGA_BUILD
#define WAIT_TIME_EXE               200
#else
/* core freq=800M, wait=2us,  2000/1.25 = 1600 */
#define WAIT_TIME_EXE               1600
#endif
#define WAIT_SIZE                   8
#define LINK_SIZE                   8
#define WAIT_LINK_SIZE              (WAIT_SIZE + LINK_SIZE)
#define EVENT_SIZE                  8
#define END_SIZE                    8
#define SEMAPHORE_STALL             24


/* IRQ_EVENT_ID value is 0 ~ 29 */
#define IRQ_EVENT_ID                4

#if vpmdENABLE_MMU
#define FLUSH_MMU_STATES_SIZE       24
#define SWITCH_MMU_STATES_SIZE      40
#else
#define FLUSH_MMU_STATES_SIZE       0
#define SWITCH_MMU_STATES_SIZE      0
#endif

#define CHIP_ENABLE_SIZE            8

#if vpmdTASK_PARALLEL_ASYNC
#define APPEND_LINK_SIZE    (vipdMP_NUM * (CHIP_ENABLE_SIZE + WAIT_LINK_SIZE))
#define APPEND_COMMAND_SIZE (SEMAPHORE_STALL + CHIP_ENABLE_SIZE + EVENT_SIZE + CHIP_ENABLE_SIZE + APPEND_LINK_SIZE)
#else
#if vpmdENABLE_POLLING
#define APPEND_COMMAND_SIZE (SEMAPHORE_STALL + END_SIZE)
#else
#define APPEND_COMMAND_SIZE (SEMAPHORE_STALL + CHIP_ENABLE_SIZE + EVENT_SIZE + CHIP_ENABLE_SIZE + END_SIZE)
#endif
#endif

/*
  the max value of command buffer size. PLEASE DON'T INCREASE THIS VALUE.
*/
#define vipdMAX_CMD_SIZE               (65535 * 8)

#if vpmdENABLE_HANG_DUMP || vpmdENABLE_CAPTURE
#define DUMP_REGISTER_ADDRESS_START   0
#define DUMP_REGISTER_ADDRESS_END     23
#define DUMP_REGISTER_CORE_ID_START   24
#define DUMP_REGISTER_CORE_ID_END     29
#define DUMP_REGISTER_TYPE_START      30
#define DUMP_REGISTER_TYPE_END        31
#endif

#endif
