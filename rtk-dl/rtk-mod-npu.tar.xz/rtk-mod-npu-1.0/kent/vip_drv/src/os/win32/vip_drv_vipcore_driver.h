/******************************************************************************\
|* Copyright (c) 2017-2025 by Vivante Corporation.  All Rights Reserved.      *|
|*                                                                            *|
|* The material in this file is confidential and contains trade secrets of    *|
|* of Vivante Corporation.  This is proprietary information owned by Vivante  *|
|* Corporation.  No part of this work may be disclosed, reproduced, copied,   *|
|* transmitted, or used in any way for any purpose, without the express       *|
|* written permission of Vivante Corporation.                                 *|
|*                                                                            *|
\******************************************************************************/

#ifndef _VIP_DRV_DEVICE_DRIVER_H
#define _VIP_DRV_DEVICE_DRIVER_H

#include <stdint.h>
#include <stdarg.h>
#include <vip_lite_config.h>

typedef uintptr_t  vipdrv_uintptr_t;

/*
@brief Set power on/off and clock on/off
@param dev, the index of logical device.
@param core, the core index in logical device.
@param state, power status. refer to vipdrv_power_status_e.
*/
vip_status_e vipdrv_drv_set_power_clk(
    vip_uint32_t dev,
    vip_uint32_t core,
    vip_uint32_t state
    );

/*
 Get the video memory config information
*/
vip_status_e vipdrv_drv_get_memory_config(
    vipdrv_vendor_memory_config_t *memory_info
    );

vip_status_e vipdrv_drv_get_hardware_info(
    vipdrv_hardware_info_t *info
    );
#endif /* __VIP_DRV_DEVICE_DRIVER_H__ */
