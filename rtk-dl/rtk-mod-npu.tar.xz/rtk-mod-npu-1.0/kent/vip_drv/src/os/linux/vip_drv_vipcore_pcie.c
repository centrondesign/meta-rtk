/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************
*
*    The GPL License (GPL)
*
*    Copyright (C) 2017 - 2025 Vivante Corporation
*
*    This program is free software; you can redistribute it and/or
*    modify it under the terms of the GNU General Public License
*    as published by the Free Software Foundation; either version 2
*    of the License, or (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software Foundation,
*    Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
*
*****************************************************************************
*
*    Note: This software is released under dual MIT and GPL licenses. A
*    recipient may use this file under the terms of either the MIT license or
*    GPL License. If you wish to use only one license not the other, you can
*    indicate your decision by deleting one of the above license notices in your
*    version of this file.
*
*****************************************************************************/

#include <linux/slab.h>
#include <linux/module.h>
#include <linux/pci.h>

#include "vip_drv_vipcore_type.h"
#include "vip_drv_vipcore_driver.h"
#include "vip_drv_vipcore_device.h"
#include "vip_drv_vipcore_vendor.h"
#include "vip_drv_vipcore_pcie.h"

/* LINUX PCIE device driver source code */


#if defined (USE_LINUX_PCIE_DEVICE)

#define vipdMAX_PCIE_CARD_NUM   20

static struct completion probed[vipdMAX_PCIE_CARD_NUM];
static struct pci_dev *pdev_array[vipdMAX_PCIE_CARD_NUM] = {VIP_NULL};

static vip_int32_t vipdrv_pcie_probe(
    struct pci_dev *pdev,
    const struct pci_device_id *ent
    )
{
    vip_int32_t ret = 0;
    vip_int32_t index = 0;

    if (VIP_NULL == pdev) {
        PRINTK_E("pcie dev is NULL\n");
        return -ENODEV;
    }
    PRINTK("PCIE DRIVER PROBED pdev:%p\n", pdev);

    if (pci_enable_device(pdev)) {
        PRINTK(KERN_ERR "vipcore, pci_enable_device() failed.\n");
    }

    pci_set_master(pdev);

    if (pci_request_regions(pdev, "vipcore")) {
        PRINTK("vipcore, fail to get ownership of BAR region.\n");
    }

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 18, 0)
    if (dma_set_mask(&pdev->dev, DMA_BIT_MASK(48))) {
        PRINTK(KERN_ERR "vipcore, fail to set DMA mask.\n");
    }
#else
    if (pci_set_dma_mask(pdev, DMA_BIT_MASK(48))) {
        PRINTK(KERN_ERR "vipcore, fail to set DMA mask.\n");
    }
#endif

#if defined (USE_MSI)
    pci_enable_msi(pdev);
#endif

    for (index = 0 ; index < vipdMAX_PCIE_CARD_NUM; index++) {
        /* find a not probed phy device */
        if (VIP_NULL == pdev_array[index]) {
            pdev_array[index] = pdev;
            complete(&probed[index]);
            break;
        }
    }

    return ret;
}

static void vipdrv_pcie_remove(
    struct pci_dev *pdev
    )
{
    pci_set_drvdata(pdev, NULL);
#if defined (USE_MSI)
    pci_disable_msi(pdev);
#endif
    pci_clear_master(pdev);
    pci_release_regions(pdev);
    pci_disable_device(pdev);

    return;
}

static struct pci_driver vip_pci_subdriver = {
    .name     = DEVICE_NAME,
    .id_table = VIP_NULL, /* init in auto_probe_device() */
    .probe    = vipdrv_pcie_probe,
    .remove   = vipdrv_pcie_remove,
};

static vip_int32_t vipdrv_pcie_get_device(
    const struct pci_device_id *vivpcie_ids,
    vip_uint32_t ids_cnt,
    vip_uint8_t is_auto_probe,
    vip_uint32_t *dev_count
    )
{
    vip_uint32_t idx = 0;
    vip_uint32_t count = 0;

    if (!dev_count) {
        PRINTK_E("vipcore: pointer dev_count is null.\n");
        return -1;
    }
    do {
        struct pci_dev *pdev = VIP_NULL;
        do {
            pdev = pci_get_device(vivpcie_ids[idx].vendor, vivpcie_ids[idx].device, pdev);
            if (pdev) {
                if (count >= vipdMAX_PCIE_CARD_NUM) {
                    PRINTK_E("vipcore: find more pcie device than support.\n");
                    return -1;
                }
                if (0 == is_auto_probe) {
                    /* auto probe is 1, get he pdev_array in pcie_probe() */
                    pdev_array[count] = pdev;
                }
                count++;
                PRINTK("pcie idx=%d vendor=0x%x, device=0x%x pdev=0x%p\n",
                        idx, vivpcie_ids[idx].vendor, vivpcie_ids[idx].device, pdev);
            }
        } while (pdev);

        idx++;
    } while (idx < ids_cnt);

    PRINTK("pcie device count=%d\n", count);
    *dev_count = count;

    if ((ids_cnt != 0) && (0 == count)) {
        PRINTK_E("vipcore, fail get pcie device count is 0\n");
        return -1;
    }

    return 0;
}

static void vipdrv_pcie_unregister_driver(
    struct pci_driver *vip_pci_subdriver
    )
{
    pci_unregister_driver(vip_pci_subdriver);
}

static vip_int32_t vipdrv_pcie_register_driver(
    vip_uint32_t dev_count,
    struct pci_driver *vip_pci_subdriver
    )
{
    vip_int32_t ret = 0;
    vip_uint32_t idx = 0;
    vip_size_t timeout = msecs_to_jiffies(5000);

    for (idx = 0; idx < dev_count; idx++) {
        init_completion(&probed[idx]);
    }

    ret = pci_register_driver(vip_pci_subdriver);
    if (ret) {
        goto pci_unregister;
    }

    for (idx = 0; idx < dev_count; idx++) {
        timeout = wait_for_completion_timeout(&probed[idx], timeout);
        if (timeout == 0) {
            PRINTK_E("vipcore: failed to probe pcie device, index:%d\n", idx);
            ret = -ENODEV;
            goto pci_unregister;
        }
    }

    return 0;

pci_unregister:
    pci_unregister_driver(vip_pci_subdriver);
    return ret;
}

vip_int32_t vipdrv_pcie_query_bar_info(
    struct pci_dev *pdev,
    vip_uint64_t *bar_addr,
    vip_uint64_t *bar_size,
    vip_uint32_t bar_num
    )
{
    vip_uint32_t addr = 0;
    vip_uint32_t size = 0;
    vip_uint32_t is_64_bit = 0;
    unsigned long long addr64, size64;

    /* Read the bar address */
    if (pci_read_config_dword(pdev, PCI_BASE_ADDRESS_0 + bar_num * 0x4, &addr) < 0)
        return -1;

    /* Read the bar size */
    if (pci_write_config_dword(pdev, PCI_BASE_ADDRESS_0 + bar_num * 0x4, 0xffffffff) < 0)
        return -1;

    if (pci_read_config_dword(pdev, PCI_BASE_ADDRESS_0 + bar_num * 0x4, &size) < 0)
        return -1;

    /* Write back the bar address */
    if (pci_write_config_dword(pdev, PCI_BASE_ADDRESS_0 + bar_num * 0x4, addr) < 0)
        return -1;

    /* The bar is not working properly */
    if (size == 0xffffffff)
        return -1;

    if ((size & PCI_BASE_ADDRESS_MEM_TYPE_MASK) == PCI_BASE_ADDRESS_MEM_TYPE_64)
        is_64_bit = 1;

    addr64 = addr;
    size &= 0xfffffff0;
    size  = ~size;
    size += 1;
    size64 = size;

    if (is_64_bit) {
        /* Read the bar address */
        if (pci_read_config_dword(pdev, PCI_BASE_ADDRESS_0 + (bar_num + 1) * 0x4, &addr) < 0)
            return -1;

        /* Read the bar size */
        if (pci_write_config_dword(pdev, PCI_BASE_ADDRESS_0 + (bar_num + 1) * 0x4, 0xffffffff) < 0)
            return -1;

        if (pci_read_config_dword(pdev, PCI_BASE_ADDRESS_0 + (bar_num + 1) * 0x4, &size) < 0)
            return -1;

        /* Write back the bar address */
        if (pci_write_config_dword(pdev, PCI_BASE_ADDRESS_0 + (bar_num + 1) * 0x4, addr) < 0)
            return -1;
        if (0xffffffff == size) {
            size = 0;
        }

        addr64 |= ((unsigned long long)addr << 32);

        size &= 0xfffffff0;
        size  = ~size;
        size += 1;
        size64 |= ((unsigned long long)size << 32);
    }

    addr64 &= ~0xfULL;

    PRINTK("vipcore, BAR[%d] addr=0x%"PRIx64", size=0x%"PRIx64", is_64_bit=%d\n",
            bar_num, addr64, size64, is_64_bit);

    *bar_addr = addr64;
    *bar_size = size64;

    return 0;
}

/*
Auto probe pcie device to initialize vip-core platform
@param pcie_ids: IN,the ids of PCIE card.
@param ids_cnt: IN,the number of element for pcie_ids.
@param vendor_operations: IN, vendor device ops
@param vipcore_vendor: OUT, vip core platform struct.
*/
vip_int32_t vipdrv_pcie_device_auto_probe(
    const struct pci_device_id *vivpcie_ids,
    vip_uint32_t ids_cnt,
    vipdrv_vendor_operations_t *vendor_operations,
    vipdrv_vipcore_vendor_t *vipcore_vendor
    )
{
    vip_int32_t ret = 0;
    vip_uint32_t dev_count = 0, idx = 0;
    vip_uint32_t probe_really_cnt = 0;

    if (VIP_NULL == vivpcie_ids) {
        PRINTK_E("vipcore, pcie_ids param is NULL\n");
        return -1;
    }
    if (0 == ids_cnt) {
        PRINTK_E("vipcore, pcie ids_cnt is 0\n");
        return -1;
    }
    if (VIP_NULL == vendor_operations) {
        PRINTK_E("vipcore, vendor_operations param is NULL\n");
        return -1;
    }
    if (VIP_NULL == vipcore_vendor) {
        PRINTK_E("vipcore: vipcore_vendor is null\n");
        return -1;
    }

    /* 2. get pcie device */
    vipdrv_os_zero_memory(pdev_array, sizeof(struct pci_dev *) * vipdMAX_PCIE_CARD_NUM);
    ret = vipdrv_pcie_get_device(vivpcie_ids, ids_cnt, 1, &dev_count);
    if (ret) {
        PRINTK_E("vipcore: fail to get pcie device.\n");
        return -1;
    }

    /* 3. register pcie driver for auto probe pcie device */
    vip_pci_subdriver.id_table = vivpcie_ids;
    ret = vipdrv_pcie_register_driver(dev_count, &vip_pci_subdriver);
    if (ret) {
        PRINTK_E("vipcore: fail to register pcie driver.\n");
        goto pci_unregister;
    }

    for (idx = 0; idx < vipdMAX_PCIE_CARD_NUM; idx++) {
        /* check probe callback function called times */
        if (VIP_NULL != pdev_array[idx]) {
            probe_really_cnt++;
        }
    }
    if (probe_really_cnt > dev_count) {
        PRINTK_E("vipcore, get pcie device count is %u, but probe called count is %u\n",
                dev_count, probe_really_cnt);
        return -1;
    }

    /* 4. initialize vip-core platform */
    vipcore_vendor->device_count = dev_count;
    vipcore_vendor->device = (vipdrv_vendor_device_t *)kmalloc(sizeof(vipdrv_vendor_device_t) * dev_count, GFP_KERNEL);
    if (VIP_NULL == vipcore_vendor->device) {
        PRINTK_E("vipcore, kmalloc failed for device.\n");
        return -1;
    }
    memset(vipcore_vendor->device, 0, sizeof(vipdrv_vendor_device_t) * dev_count);
    for (idx = 0; idx < dev_count; idx++) {
        vipcore_vendor->device[idx].index = idx;
        vipcore_vendor->device[idx].ops = vendor_operations;
        vipcore_vendor->device[idx].pdev = pdev_array[idx];
        vipcore_vendor->device[idx].vipcore_vendor = vipcore_vendor;
    }

    return ret;

pci_unregister:
    vipdrv_pcie_unregister_driver(&vip_pci_subdriver);
    return -1;
}

vip_int32_t vipdrv_pcie_device_auto_remove(
    vipdrv_vipcore_vendor_t *vipcore_vendor
    )
{
    vip_int32_t ret = 0;

    vipdrv_pcie_unregister_driver(&vip_pci_subdriver);

    if (vipcore_vendor->device == VIP_NULL) {
        kfree(vipcore_vendor->device);
        vipcore_vendor->device = VIP_NULL;
    }

    return ret;
}

/*
Dymmy probe pcie device to initialize vip-core platform
@param platform_drv: IN, is the linux platform driver, will be register in module_drv_init func.
@param pcie_ids: IN,the ids of PCIE card.
@param ids_cnt: IN,the number of element for pcie_ids.
@param vendor_operations: IN, vendor device ops
@param vipcore_vendor: OUT, vip core platform struct.
*/
vip_int32_t vipdrv_pcie_device_dummy_probe(
    const struct pci_device_id *vivpcie_ids,
    vip_uint32_t ids_cnt,
    vipdrv_vendor_operations_t *vendor_operations,
    vipdrv_vipcore_vendor_t *vipcore_vendor
    )
{
    vip_int32_t ret = 0;
    vip_uint32_t dev_count = 0, idx = 0;

    if (VIP_NULL == vivpcie_ids) {
        PRINTK_E("vipcore, pcie_ids param is NULL\n");
        return -1;
    }
    if (0 == ids_cnt) {
        PRINTK_E("vipcore, pcie ids_cnt is 0\n");
        return -1;
    }
    if (VIP_NULL == vendor_operations) {
        PRINTK_E("vipcore, vendor_operations param is NULL\n");
        return -1;
    }
    if (VIP_NULL == vipcore_vendor) {
        PRINTK_E("vipcore: vipcore_vendor param is null\n");
        return -1;
    }

    /* 2. get pcie device */
    vipdrv_os_zero_memory(pdev_array, sizeof(struct pci_dev *) * vipdMAX_PCIE_CARD_NUM);
    ret = vipdrv_pcie_get_device(vivpcie_ids, ids_cnt, 0, &dev_count);
    if (ret) {
        PRINTK_E("vipcore: fail to get pcie device.\n");
        return -1;
    }

    for (idx = 0; idx < dev_count; idx++) {
        pci_enable_msi(pdev_array[idx]);
    }

    /* 3. initialize vip-core platform */
    vipcore_vendor->device_count = dev_count;
    vipcore_vendor->device = (vipdrv_vendor_device_t *)kmalloc(sizeof(vipdrv_vendor_device_t) * dev_count, GFP_KERNEL);
    if (VIP_NULL == vipcore_vendor->device) {
        PRINTK_E("vipcore, kmalloc failed for device.\n");
        return -1;
    }
    memset(vipcore_vendor->device, 0, sizeof(vipdrv_vendor_device_t) * dev_count);
    for (idx = 0; idx < dev_count; idx++) {
        vipcore_vendor->device[idx].index = idx;
        vipcore_vendor->device[idx].ops = vendor_operations;
        vipcore_vendor->device[idx].pdev = pdev_array[idx];
        vipcore_vendor->device[idx].vipcore_vendor = vipcore_vendor;
    }

    return ret;

    return -1;
}

vip_int32_t vipdrv_pcie_device_dummy_remove(
    vipdrv_vipcore_vendor_t *vipcore_vendor
    )
{
    vip_int32_t ret = 0;

    if (vipcore_vendor->device == VIP_NULL) {
        kfree(vipcore_vendor->device);
        vipcore_vendor->device = VIP_NULL;
    }

    return ret;
}

/*
Map the CPU logical for PCIE bar space. Used for NPU AHB register.
@param register_offset, the offset of ahb register on this bar_num.
@param register_size, the size of memory need to be mapped.
*/
vip_status_e vipdrv_pcie_bar_map(
    vipdrv_vendor_device_t *device,
    vip_uint32_t bar_num,
    vip_uint32_t register_offset,
    vip_uint32_t register_size,
    void** logical
    )
{
    vip_status_e status = VIP_SUCCESS;

    if ((logical == VIP_NULL) || (register_size == 0)) {
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    *logical = (void *)pci_iomap_range(device->pdev, bar_num, register_offset, register_size);
    if (VIP_NULL == *logical) {
        vipGoOnError(VIP_ERROR_FAILURE);
    }
    PRINTK_D("pcie map bar %d, logical=%p, size=0x%x\n", bar_num, *logical, register_size);

    return status;

onError:
    PRINTK_E("map bar %d size %u\n", bar_num, register_size);
    return status;
}

vip_status_e vipdrv_pcie_bar_unmap(
    vipdrv_vendor_device_t *device,
    void* logical
    )
{
    vip_status_e status = VIP_SUCCESS;
    if (VIP_NULL == logical) {
        return VIP_SUCCESS;
    }

    iounmap(logical);

    return status;
}

#endif
