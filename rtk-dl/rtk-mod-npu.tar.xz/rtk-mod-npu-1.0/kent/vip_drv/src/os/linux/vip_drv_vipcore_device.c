/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************
*
*    The GPL License (GPL)
*
*    Copyright (C) 2017 - 2025 Vivante Corporation
*
*    This program is free software; you can redistribute it and/or
*    modify it under the terms of the GNU General Public License
*    as published by the Free Software Foundation; either version 2
*    of the License, or (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software Foundation,
*    Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
*
*****************************************************************************
*
*    Note: This software is released under dual MIT and GPL licenses. A
*    recipient may use this file under the terms of either the MIT license or
*    GPL License. If you wish to use only one license not the other, you can
*    indicate your decision by deleting one of the above license notices in your
*    version of this file.
*
*****************************************************************************/

#include <linux/pagemap.h>
#include <linux/seq_file.h>
#include <linux/mman.h>
#include <asm/atomic.h>
#include <linux/dma-mapping.h>
#include <linux/slab.h>
#include <linux/workqueue.h>
#include <linux/irqflags.h>
#include <linux/vmalloc.h>
#include <linux/io.h>
#include <linux/kernel.h>
#include <linux/clk.h>
#include <linux/clk-provider.h>
#include <linux/delay.h>
#include <linux/platform_device.h>
#include <linux/device.h>
#include <linux/slab.h>
#include <linux/miscdevice.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/signal.h>
#include <linux/interrupt.h>
#include <linux/vmalloc.h>
#include <linux/dma-mapping.h>
#include <linux/kthread.h>
#include <linux/pagemap.h>
#include <linux/mman.h>
#ifdef CONFIG_COMPAT
#include <asm/compat.h>
#endif
#include <linux/platform_device.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <linux/dma-mapping.h>
#include <linux/math64.h>
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5,16,0))
#include <linux/stdarg.h>
#else
#include <stdarg.h>
#endif
#include <linux/time.h>
#include <linux/mm.h>
#include <linux/debugfs.h>
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4,6,0))
#include <linux/cma.h>
#endif
#if defined (USE_LINUX_PCIE_DEVICE)
#include <linux/pci.h>
#endif

#include "vip_drv_pm.h"
#include "vip_drv_debug.h"
#include "vip_drv_os.h"
#include "vip_drv_os_port.h"
#include "vip_lite_version.h"
#include "vip_drv_video_memory.h"
#include "vip_drv_mem_allocator.h"
#include "vip_drv_interface.h"
#include "vip_drv_context.h"
#include "vip_drv_vipcore_device.h"
#include "vip_drv_vipcore_driver.h"
#include "vip_drv_vipcore_vendor.h"


static vip_int32_t verbose = 1;
module_param(verbose, int, S_IRUGO);
MODULE_PARM_DESC(verbose, "ebable/disable log print");

static vip_int32_t drvType = 0;
module_param(drvType, int, 0644);
MODULE_PARM_DESC(drvType, "0 - Char Driver (Default), 1 - Misc Driver");

static vip_uint32_t major = 199;
module_param(major, uint, 0644);
MODULE_PARM_DESC(major, "major device number for VIP device");



#define MIN_VIDEO_MEMORY_SIZE       (4 * 1024)

#define gcdVIP_IRQ_SHARED   1
#if LINUX_VERSION_CODE >= KERNEL_VERSION (4, 1, 0)
#if gcdVIP_IRQ_SHARED
#define gcdVIP_IRQ_FLAG   (IRQF_SHARED | IRQF_TRIGGER_HIGH)
#else
#define gcdVIP_IRQ_FLAG   (IRQF_TRIGGER_HIGH)
#endif
#else
#if gcdVIP_IRQ_SHARED
#define gcdVIP_IRQ_FLAG   (IRQF_DISABLED | IRQF_SHARED | IRQF_TRIGGER_HIGH)
#else
#define gcdVIP_IRQ_FLAG   (IRQF_DISABLED | IRQF_TRIGGER_HIGH)
#endif
#endif


/* default disable internel clock only used for the SOC that power is always online */
#define DEFAULT_DISABLE_INTERNEL_CLOCK          0

#define LOOP_PHY_DEV_START                                  \
{   vip_uint32_t phy_dev_index = 0;                         \
    for (phy_dev_index = 0 ; phy_dev_index < vipcore_dev->phy_dev_cnt; phy_dev_index++) {

#define LOOP_PHY_DEV_END }}

/*
@brief define loop fun for each vip core
*/
#define LOOP_PHY_DEV_CORE_START                                  \
{  vip_uint32_t core = 0;                                \
   for (core = 0 ; core < phy_dev->vendor->core_count; core++) {

#define LOOP_PHY_DEV_CORE_END }}

static struct platform_device *default_dev = VIP_NULL;

static DEFINE_MUTEX(open_mutex);

typedef struct _vipdrv_command_data {
    union _u {
        vipdrv_initialize_t init;
        vipdrv_allocation_t allocate;
        vipdrv_wait_task_param_t wait;
        vipdrv_cancel_task_param_t cancel;
        vipdrv_submit_task_param_t task;
        vipdrv_operate_cache_t flush;
        vipdrv_reg_t reg;
        vipdrv_query_address_info_t info;
        vipdrv_power_management_t power_manage;
        vipdrv_wrap_user_memory_t wrap_memory;
        vipdrv_query_database_t database;
        vipdrv_deallocation_t unalloc;
        vipdrv_query_profiling_t profiling;
        vipdrv_query_register_dump_t register_dump;
        vipdrv_create_task_param_t create_task;
        vipdrv_set_task_property_t set_prop;
        vipdrv_destroy_task_param_t destroy_task;
        vipdrv_query_device_info_t  q_device;
    } u;
} vipdrv_command_data;


static vip_int32_t drv_open(struct inode * inode, struct file * file)
{
    vip_int32_t ret = 0;
    vipdrv_vipcore_driver_t *kdriver = vipdrv_get_vipcore_driver();

    mutex_lock(&open_mutex);
    kdriver->open_device_count++;

    file->private_data = (void*)kdriver;
    PRINTK_D("drv open process pid=%x, tid=%x\n", vipdrv_os_get_pid(), vipdrv_os_get_tid());

#if !vpmdTASK_QUEUE_USED
    if (kdriver->open_device_count > kdriver->vipcore_dev.phy_dev_cnt) {
        ret = -1;
        kdriver->open_device_count--;
        PRINTK_E("open device, not used task queue open cnt=%d, device_cnt=%d\n",
                kdriver->open_device_count, kdriver->vipcore_dev.phy_dev_cnt);
    }
#endif
    mutex_unlock(&open_mutex);

    return ret;
}

static vip_int32_t drv_release(struct inode * inode, struct file * file)
{
    vipdrv_vipcore_driver_t *kdriver = vipdrv_get_vipcore_driver();

    mutex_lock(&open_mutex);
    kdriver->open_device_count--;

    PRINTK_D("drv release process pid=%x, tid=%x\n", vipdrv_os_get_pid(), vipdrv_os_get_tid());

    vipdrv_destroy();
    mutex_unlock(&open_mutex);

    return 0;
}

static long drv_ioctl(struct file *file, unsigned int ioctl_code, unsigned long arg)
{
    struct ioctl_data arguments;
    void __user *uarg = (void __user *)arg;
    void *data = VIP_NULL;
    void *heap_data = VIP_NULL;
    vipdrv_command_data stack_data;

    if (ioctl_code != VIPDRV_IOCTL) {
        PRINTK("vipcore, error ioctl code is %d\n", ioctl_code);
        return -1;
    }
    if (uarg == VIP_NULL) {
        PRINTK("vipcore, error arg is NULL\n");
        return -1;
    }
    if (copy_from_user(&arguments, uarg, sizeof(arguments)) != 0) {
        PRINTK("vipcore, fail to copy arguments\n");
        return -1;
    }
    data = &stack_data;
    if (arguments.bytes > 0) {
        if (arguments.bytes >= sizeof(vipdrv_command_data)) {
            vipdrv_os_allocate_memory(arguments.bytes, (void **)&heap_data);
            if (VIP_NULL == heap_data) {
                PRINTK("vipcore, fail to malloc memory for ioctl data");
                return -1;
            }
            data = heap_data;
        }

        if (copy_from_user(data, (void*)(vipdrv_uintptr_t)(arguments.buffer), arguments.bytes) != 0) {
            PRINTK("vipcore, %s fail to copy arguments buffer, size: %d\n", __func__, arguments.bytes);
            goto error;
        }
    }

    /* Execute vip-drv command. */
    arguments.error = vipdrv_interface_call(arguments.command, data);
    if (arguments.error != VIP_SUCCESS) {
        if (copy_to_user(uarg, &arguments, sizeof(arguments)) != 0) {
            PRINTK("vipcore, fail to copy data to user arguments\n");
        }
        goto error;
    }

    if (arguments.bytes > 0) {
        if (copy_to_user((void*)(vipdrv_uintptr_t)arguments.buffer, data, arguments.bytes) != 0) {
            PRINTK("vipcore, %s fail to copy data to user arguments buffer, size: %d\n", __func__,
                    arguments.bytes);
            goto error;
        }
    }

    if (copy_to_user(uarg, &arguments, sizeof(arguments)) != 0) {
        PRINTK("vipcore, fail to copy data to user arguments\n");
        goto error;
    }

    if (heap_data != VIP_NULL) {
        vipdrv_os_free_memory(heap_data);
    }
    return 0;

error:
    if ((arguments.error != VIP_ERROR_POWER_OFF) && (arguments.error != VIP_ERROR_CANCELED) &&
        (arguments.error != VIP_ERROR_NOT_FINISH)) {
        vipdrv_intrface_e index = arguments.command;
        if (index > VIPDRV_INTRFACE_MAX) {
            index = VIPDRV_INTRFACE_MAX;
        }
        PRINTK("vipcore, fail to ioctl, command[%d]: %s, status=%d\n",
                (vip_int32_t)arguments.command, ioctl_cmd_string[index], arguments.error);
        PRINTK("VIPLite driver version %d.%d.%d.%s\n",
                VERSION_MAJOR, VERSION_MINOR, VERSION_SUB_MINOR, VERSION_PATCH);
    }
    if (heap_data != VIP_NULL) {
        vipdrv_os_free_memory(heap_data);
    }
    return -1;
}

static long drv_compat_ioctl(struct file *file, unsigned int ioctl_code, unsigned long arg)
{
#ifdef CONFIG_COMPAT
    #if LINUX_VERSION_CODE >= KERNEL_VERSION(5,4,4)
    return compat_ptr_ioctl(file, ioctl_code, arg);
    #else
    return drv_ioctl(file, ioctl_code, (unsigned long)compat_ptr(arg));
    #endif
#else
    return drv_ioctl(file, ioctl_code, arg);
#endif
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 2, 0)
static char *vip_devnode(const struct device *dev, umode_t *mode)
#else
static char *vip_devnode(struct device *dev, umode_t *mode)
#endif
{
    if (mode)
        *mode = 0666;
    return NULL;
}

static struct file_operations file_operations =
{
    .owner          = THIS_MODULE,
    .open           = drv_open,
    .release        = drv_release,
    .unlocked_ioctl = drv_ioctl,
#if LINUX_VERSION_CODE <= KERNEL_VERSION(5,8,18)
#ifdef HAVE_COMPAT_IOCTL
    .compat_ioctl   = drv_compat_ioctl,
#endif
#else
    .compat_ioctl   = drv_compat_ioctl,
#endif
};

static struct miscdevice vipmisc_device = {
    .minor = MISC_DYNAMIC_MINOR,
    .name  = DEVICE_NAME,
    .fops  = &file_operations,
    .mode  = S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH,
};

static vip_int32_t vipdrv_create_chrdev(
    vipdrv_phy_device_t *phy_dev
    )
{
    vip_int32_t ret = 0;
    vipdrv_vipcore_device_t *vipcore_dev = phy_dev->vipcore_dev;
    struct device *device = VIP_NULL;

    /* Create the device. */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
    if (phy_dev->index == 0) {
        device = device_create(vipcore_dev->class,
            NULL, MKDEV(major, phy_dev->index), NULL, DEVICE_NAME);
    }
    else {
        device = device_create(vipcore_dev->class,
            NULL, MKDEV(major, phy_dev->index), NULL, "%s%d", DEVICE_NAME, phy_dev->index);
    }
#else
    if (phy_dev->index == 0) {
        device = device_create(vipcore_dev->class,
            NULL, MKDEV(major, phy_dev->index), DEVICE_NAME);
    }
    else {
        device = device_create(vipcore_dev->class,
            NULL, MKDEV(major, phy_dev->index), "%s%d", DEVICE_NAME, phy_dev->index);
    }
#endif
    if (device == NULL) {
        PRINTK_E("vipcore, device_create failed for device:%d\n", phy_dev->index);
        return -1;
    }
    if (VIP_NULL == phy_dev->device) {
        PRINTK_D("vipcore, set device to 0x%"PRPx"\n", device);
        phy_dev->device = device;
    }
    PRINTK_D("vipcore, created vipcore %d, device=0x%"PRPx", major=%d minor:%d\n",
        phy_dev->index, device, major, phy_dev->index);

    phy_dev->created = 1;

    return ret;
}

static vip_int32_t vipdrv_destroy_chrdev(
    vipdrv_phy_device_t *phy_dev
    )
{
    vip_int32_t ret = 0;
    if (IS_ERR(phy_dev->vipcore_dev->class)) {
        PRINTK_E("vipcore, class is null\n");
        return -1;
    }

    if (phy_dev->created) {
        /* Destroy the device. */
        device_destroy(phy_dev->vipcore_dev->class, MKDEV(major, phy_dev->index));
        phy_dev->created = 0;
    }

    return ret;
}

static vip_int32_t vipdrv_create_miscdev(
    vipdrv_phy_device_t *phy_dev
    )
{
    /* Register as misc driver. */
    PRINTK("vipcore, register misc device\n");
    if (phy_dev->index > 0) {
        vipmisc_device.name = kasprintf(GFP_KERNEL, "%s%d", DEVICE_NAME, phy_dev->index);
    }
    if (misc_register(&vipmisc_device) < 0) {
        PRINTK_E("vipcore, fail to register misc device\n");
        return -1;
    }

    return 0;
}

static vip_int32_t vipdrv_destroy_miscdev(
    vipdrv_phy_device_t *phy_dev
    )
{
    misc_deregister(&vipmisc_device);

    return 0;
}

static vip_int32_t vipdrv_register_chrdev(
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    vip_int32_t result = 0;

    /* Register device. */
    result = register_chrdev(major, DEVICE_NAME, &file_operations);
    if (result < 0) {
        PRINTK_E("vipcore, register_chrdev failed ret=%d\n", result);
        return -1;
    }
    if (0 == major) {
        major = result;
    }

    vipcore_dev->registered = 1;

    return 0;
}

static vip_int32_t vipdrv_unregister_chrdev(
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    if (vipcore_dev->registered) {
        /* Unregister the device. */
        unregister_chrdev(major, DEVICE_NAME);
        vipcore_dev->registered = 0;
    }

    return 0;
}

static vip_int32_t vipdrv_create_class(
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    if (vipcore_dev->class) {
        PRINTK_E("vipcore, vipcore_dev->class is %p which not null\n", vipcore_dev->class);
        return -1;
    }

    /* Create the graphics class. */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 4, 0)
    vipcore_dev->class = class_create(CLASS_NAME);
#else
    vipcore_dev->class = class_create(THIS_MODULE, CLASS_NAME);
#endif
    if (IS_ERR(vipcore_dev->class)) {
        PRINTK_E("vipcore, class_create failed\n");
        return -1;
    }

    vipcore_dev->class->devnode = vip_devnode;
    PRINTK("vipcore, prepare vipcore device, vipcore_dev->class=0x%p\n", vipcore_dev->class);

    return 0;
}

static vip_int32_t vipdrv_destroy_class(
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    if (vipcore_dev->class != VIP_NULL) {
        /* Destroy the class. */
        class_destroy(vipcore_dev->class);
        vipcore_dev->class = VIP_NULL;
    }

    return 0;
}

#if !vpmdENABLE_POLLING
/*
@brief Iinterrupte handle function.
*/
static irqreturn_t drv_irq_handler(
    int irq,
    void *data
    )
{
    uint32_t value = 0;
    uint8_t handled_flag = 0;
    vipdrv_phy_core_t *phy_core = (vipdrv_phy_core_t*)data;
    vipdrv_phy_device_t *phy_dev = phy_core->phy_dev;
    uint8_t *register_base = (uint8_t *)phy_core->register_base;
    vipdrv_phy_core_t *phy_core_map = VIP_NULL;

    if (phy_core->index >= vipdMP_NUM) {
        return IRQ_NONE;
    }

    if (VIP_NULL == register_base) {
        return IRQ_NONE;
    }
    /* Read interrupt status. */
    value = readl(register_base + 0x00010);
    if (value != 0x00) {
        /* Combine with current interrupt flags. */
        phy_core->irq_value = value;
        while (0 != value) {
            value &= (value - 1);
            vipdrv_os_inc_atomic(phy_core->irq_count);
        }
        phy_core_map = &phy_dev->phy_core[phy_core->irq_map];
        phy_core_map->irq_value |= IRQ_VALUE_FLAG;
        /* Wake up any waiters. */
        vipdrv_os_wakeup_interrupt(&phy_core_map->irq_queue);
        handled_flag = 1;
    }

#if vpmdENABLE_FUSA
    {
        uint32_t error_value_ext = 0, error_value= 0;
        phy_core_map = &phy_dev->phy_core[phy_core->irq_map];
        error_value = readl(register_base + 0x00340);
        error_value_ext = readl(register_base + 0x00350);
        if ((error_value != 0) || (error_value_ext != 0)) {
            PRINTK("irq error_value_ext=0x%x error_value=0x%x\n", error_value_ext, error_value);
            phy_core_map->irq_value |= IRQ_VALUE_ERROR_FUSA;
            vipdrv_os_wakeup_interrupt(&phy_core_map->irq_queue);
            handled_flag = 1;
        }
    }
#endif

    if (1 == handled_flag) {
        return IRQ_HANDLED;
    }

    /* Not our IRQ. */
    return IRQ_NONE;
}
#endif

static vip_int32_t drv_prepare_irq(
    vipdrv_phy_device_t *phy_dev
    )
{
    vip_uint32_t j = 0, core_cnt = 0, irq_index = 0;
    vip_uint32_t core_idx = 0;
#if !vpmdENABLE_POLLING
    vip_char_t *irq_name = VIP_NULL;
    vip_char_t *irq_name_default = "vipcore_def";
    vip_char_t *irq_name_core[16] = {
        "vipcore_0", "vipcore_1", "vipcore_2", "vipcore_3",
        "vipcore_4", "vipcore_5",  "vipcore_6", "vipcore_7",
        "vipcore_8", "vipcore_9", "vipcore_10", "vipcore_11",
        "vipcore_12", "vipcore_13", "vipcore_14", "vipcore_15"
    };

    /* Install IRQ. */
    for (core_idx = 0; core_idx < phy_dev->phy_core_cnt; core_idx++) {
        vipdrv_phy_core_t *phy_core = &phy_dev->phy_core[core_idx];
        vip_uint32_t irq_line = 0;

        if (core_idx >= vipdMP_NUM) {
            PRINTK_E("vipcore, fail core_index=%d\n", core_idx);
            continue;
        }
        irq_line = phy_dev->vendor->irq_line[core_idx];
        if (core_idx < (sizeof(irq_name_core) / sizeof(vip_char_t *))) {
            irq_name = irq_name_core[core_idx];
        }
        else {
            irq_name = irq_name_default;
        }

        PRINTK("dev%d core%d, irqline=%d, name=%s\n", phy_dev->index, phy_core->index, irq_line, irq_name);

        if (request_irq(irq_line, drv_irq_handler, gcdVIP_IRQ_FLAG, irq_name, (void *)phy_core)) {
            PRINTK_E("vipcore, request_irq failed line=%d\n", irq_line);
            return -1;
        }
        phy_core->irq_registed = 1;

        vipdrv_os_create_atomic(&phy_core->irq_count);
        /* Initialize the wait queue. */
        init_waitqueue_head(&phy_core->irq_queue);
    }
#endif

    for (core_idx = 0; core_idx < phy_dev->phy_core_cnt; core_idx++) {
        vipdrv_phy_core_t *phy_core_map = VIP_NULL;
        if (core_idx >= vipdMP_NUM) {
            continue;
        }
        if (0 == phy_dev->vendor->device_core_number[core_idx]) {
            break;
        }

        for (j = 0; j < phy_dev->vendor->device_core_number[core_idx]; j++) {
            phy_core_map = &phy_dev->phy_core[core_cnt++];
            phy_core_map->irq_map = irq_index;
        #if !vpmdTASK_PARALLEL_ASYNC
            irq_index++;
        #endif
        }
    #if vpmdTASK_PARALLEL_ASYNC
        irq_index += phy_dev->vendor->device_core_number[core_idx];
    #endif
    }

    return 0;
}

static void drv_unprepare_irq(
    vipdrv_phy_device_t *phy_dev
    )
{
#if !vpmdENABLE_POLLING
    vip_uint32_t core_idx = 0;
    for (core_idx = 0 ; core_idx < phy_dev->phy_core_cnt; core_idx++) {
        vipdrv_phy_core_t *phy_core = &phy_dev->phy_core[core_idx];
        vip_uint32_t irq_line = phy_dev->vendor->irq_line[core_idx];

        if (phy_core->irq_registed) {
            free_irq(irq_line, (void*)phy_core);
            phy_core->irq_registed = 0;
        }
        if (phy_core->irq_count != VIP_NULL) {
            vipdrv_os_destroy_atomic(phy_core->irq_count);
            phy_core->irq_count = VIP_NULL;
        }
    }
#endif
}

static vip_int32_t drv_prepare_register(
    vipdrv_phy_device_t *phy_dev
    )
{
    vipdrv_vendor_device_t *vendor = phy_dev->vendor;
    vipdrv_phy_core_t *phy_core = VIP_NULL;
    vip_uint32_t core_idx = 0;

    for (core_idx = 0; core_idx < phy_dev->phy_core_cnt; core_idx++) {
        phy_core = &phy_dev->phy_core[core_idx];
        phy_core->register_base = vendor->register_base[core_idx];
        phy_core->register_size = vendor->register_size[core_idx];
    }

    return 0;
}

static void drv_unprepare_register(
    vipdrv_phy_device_t *phy_dev
    )
{
    return;
}

#if vpmdENABLE_VIDEO_MEMORY_HEAP
static vip_uint64_t drv_mem_get_deviceVis(
    vipdrv_vipcore_device_t *vipcore_dev,
    vip_uint32_t dev_idx
    )
{
    vip_uint32_t logi_idx = 0;
    vip_uint64_t device_vis = 0;

    for (logi_idx = 0; logi_idx < vipcore_dev->logi_dev_cnt; logi_idx++) {
        vipdrv_logi_device_t *logi_dev = &vipcore_dev->logi_dev[logi_idx];
        vipdrv_phy_device_t *phy_dev = logi_dev->phy_dev;
        if (phy_dev->index == dev_idx) {
            device_vis |= 1 << logi_dev->index;
        }
    }

    return device_vis;
}

/*
Check new heap info is overlap with exist heap info
@param phy_dev, the object of physical device, which include the exist heap info.
@param physical, the cpu physical of new heap info.
@param size, the size of new heap info.
@param heap_index, OUT, the index of found heap info.

return value:
    0: in heap info in NOT overlap with exist heap info, and it is a new heap info.
    1: in heap info is overlap with exist heap info
    2: found a same info in the exist heap info list
*/
static vip_int32_t drv_heap_overlap_check(
    vipdrv_vipcore_device_t *vipcore_dev,
    vip_physical_t physical,
    vip_uint64_t size,
    vip_uint32_t *heap_index
    )
{
    vip_status_e status = VIP_SUCCESS;
    vip_int32_t index = 0;
    vip_uint32_t dev_idx = 0;

    for (index = 0; index < vipcore_dev->heap_count; index++) {
        vip_physical_t cpu_phy = 0, mem_size = 0;
        vipdrv_videomem_heap_info_t *heap = &vipcore_dev->heap_infos[index];
        mem_size = heap->vip_memsize;
        dev_idx = vipdrv_mem_get_devindex(heap->device_vis);
        cpu_phy = vipdrv_drv_get_cpuphysical(dev_idx, heap->vip_physical);

        if ((physical == cpu_phy) && (size == mem_size)) {
            *heap_index = index;
            return 2;
        }

        status = vipdrv_memory_overlap_check(physical, size, cpu_phy, mem_size);
        if (status != VIP_SUCCESS) {
            *heap_index = index;
            PRINTK_F("heap_%d overlap cpy_phy=0x%"PRIx64", size=0x%"PRIx64"\n",
                   index, cpu_phy, mem_size);
            return 1;
        }
    }

    return 0;
}

static vip_int32_t drv_prepare_video_memory(
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    vip_status_e status = VIP_SUCCESS;
    vip_int32_t ret = 0;
    vip_uint32_t i = 0;
    vip_uint32_t heap_cnt = 0;
    vip_uint32_t dev_idx = 0;
    vip_uint32_t size = 0;

    if (0 == vipcore_dev->logi_dev_cnt) {
        PRINTK_E("logical dev cnt is 0, should prepare dev before\n");
        return -1;
    }

    size = sizeof(vipdrv_videomem_heap_info_t) * vipcore_dev->phy_dev_cnt * VIDEO_MEMORY_HEAP_MAX_CNT;
    status = vipdrv_os_allocate_memory(size, (void**)&vipcore_dev->heap_infos);
    if (status != VIP_SUCCESS) {
        PRINTK_E("alloc memory for phy_dev\n");
        return -1;
    }
    vipdrv_os_zero_memory(vipcore_dev->heap_infos, size);

    for (dev_idx = 0 ; dev_idx < vipcore_dev->phy_dev_cnt; dev_idx++) {
        vipdrv_phy_device_t *phy_dev = &vipcore_dev->phy_dev[dev_idx];
        vipdrv_vendor_device_t *vendor_dev = phy_dev->vendor;
        for (i = 0; i < VIDEO_MEMORY_HEAP_MAX_CNT; i++) {
            vip_uint32_t heap_index = 0;
            vip_uint64_t device_vis = 0;
            if ((vendor_dev->heap_memsize[i] < MIN_VIDEO_MEMORY_SIZE) ||
                (VIP_NULL == vendor_dev->heap_name[i]) || (0 == vendor_dev->heap_physical[i])) {
                continue;
            }
            if ((vendor_dev->heap_physical[i] & (vipdMEMORY_HAEAP_BASE_ADDRESS_ALIGN - 1)) != 0) {
                PRINTK_E("dev% heap%d cpu_phy=0x%"PRIx64" not align\n", dev_idx, i, vendor_dev->heap_physical[i]);
                continue;
            }

            ret = drv_heap_overlap_check(vipcore_dev,  vendor_dev->heap_physical[i],
                                         vendor_dev->heap_memsize[i], &heap_index);
            if (ret == 1) {
                PRINTK_E("dev%d heap%d  physical=0x%"PRIx64", size=0x%"PRIx64" overlap with heap_%d\n",
                    dev_idx, i, vendor_dev->heap_physical[i], vendor_dev->heap_memsize[i], heap_index);
                continue;
            }

            device_vis = drv_mem_get_deviceVis(vipcore_dev, phy_dev->index);

            /* same heap info, only need update deviceVis mapping bit */
            if (ret == 2) {
                vipcore_dev->heap_infos[heap_index].device_vis |= device_vis;
                PRINTK_F("found same heap_%d physical=0x%"PRIx64", size=0x%"PRIx64". update deviceVis=0x%x\n",
                    heap_index, vendor_dev->heap_physical[i], vendor_dev->heap_memsize[i],
                    vipcore_dev->heap_infos[heap_index].device_vis);
                continue;
            }

            if (0 == vipdrv_os_strcmp(ALLOCATOR_NAME_HEAP_EXCLUSIVE, vendor_dev->heap_name[i])) {
                /* map reserved memory in boot time */
                struct resource *region = VIP_NULL;
                region = request_mem_region(vendor_dev->heap_physical[i],
                                            vendor_dev->heap_memsize[i], "vip_reserved");
                if (region == NULL) {
                    PRINTK("vipcore, warning request mem region, address=0x%"PRIx64", size=0x%"PRIx64"\n",
                            vendor_dev->heap_physical[i], vendor_dev->heap_memsize[i]);
                }
            }

            vipcore_dev->heap_infos[heap_cnt].vip_physical =
                vendor_dev->ops->phy_cpu2vip(vendor_dev, vendor_dev->heap_physical[i]);
            vipcore_dev->heap_infos[heap_cnt].vip_memsize = vendor_dev->heap_memsize[i];
            vipcore_dev->heap_infos[heap_cnt].name = vendor_dev->heap_name[i];
            vipcore_dev->heap_infos[heap_cnt].ops.phy_cpu2vip = vipdrv_drv_get_vipphysical;
            vipcore_dev->heap_infos[heap_cnt].ops.phy_vip2cpu = vipdrv_drv_get_cpuphysical;
            vipcore_dev->heap_infos[heap_cnt].device_vis |= device_vis;
            PRINTK_F("dev%d heap_idx=%d cpu physical=0x%"PRIx64", size=0x%"PRIx64"\n",
                dev_idx, heap_cnt, vendor_dev->heap_physical[i], vendor_dev->heap_memsize[i]);

            heap_cnt++;
            vipcore_dev->heap_count = heap_cnt;
        }
    }

    /* show heap infos */
    for (i = 0; i < vipcore_dev->heap_count; i++) {
        vipdrv_videomem_heap_info_t *heap = &vipcore_dev->heap_infos[i];
        PRINTK_F("vipcore, heap_idx=%d, name=%s, vip_phy=0x%"PRIx64", size=0x%"PRIx64" dev_vis=0x%x\n",
               i, heap->name, heap->vip_physical, heap->vip_memsize, heap->device_vis);
    }

    PRINTK_D("video memory heap count=%d\n", heap_cnt);
    return ret;
}

static vip_int32_t drv_unprepare_video_memory(
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    vip_uint32_t i = 0;
    vipdrv_videomem_heap_info_t *heap_info = VIP_NULL;

    for (i = 0 ; i < vipcore_dev->heap_count; i++) {
        heap_info = &vipcore_dev->heap_infos[i];
        if (VIP_NULL == heap_info) {
            continue;
        }
        if (heap_info->name != VIP_NULL) {
            if (0 == vipdrv_os_strcmp(ALLOCATOR_NAME_HEAP_EXCLUSIVE, heap_info->name)) {
                release_mem_region(heap_info->vip_physical, heap_info->vip_memsize);
            }
        }
        heap_info->vip_memsize = 0;
        heap_info->vip_physical = 0;
    }

    if (vipcore_dev->heap_infos != VIP_NULL) {
        vipdrv_os_free_memory(vipcore_dev->heap_infos);
        vipcore_dev->heap_infos = VIP_NULL;
    }

    return 0;
}
#endif

#if (vpmdENABLE_DEBUG_LOG > 1)
static vip_int32_t  drv_show_params(
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    #define NAME_HEADER_SIZE  20
    vip_char_t info[256];
    vip_char_t *tmp = VIP_NULL;
    vipdrv_phy_device_t *phy_dev = VIP_NULL;
    vipdrv_vendor_device_t *vendor_dev = VIP_NULL;
    vip_uint32_t i = 0, j = 0;

    if (0 == verbose) {
        return 0;
    }
    for (i = 0; i < vipcore_dev->phy_dev_cnt; i++) {
        #if vpmdENABLE_VIDEO_MEMORY_HEAP
        vip_uint32_t valid_heap_cnt = 0;
        #endif
        phy_dev = &vipcore_dev->phy_dev[i];
        vendor_dev = phy_dev->vendor;
        #if vpmdENABLE_VIDEO_MEMORY_HEAP
        for (j = 0; j < VIDEO_MEMORY_HEAP_MAX_CNT; j++) {
            if (0 == vendor_dev->heap_memsize[j]) {
                continue;
            }
            if (0 == vendor_dev->heap_physical[j]) {
                continue;
            }
            if (VIP_NULL == vendor_dev->heap_name[j]) {
                continue;
            }
            valid_heap_cnt++;
        }
        #endif

        PRINTK("=======vipcore dev%d vendor param=====\n", i);
        tmp = info;
        vipdrv_os_copy_memory(tmp, "registerMemBase     ", NAME_HEADER_SIZE);
        tmp += NAME_HEADER_SIZE;
        LOOP_PHY_DEV_CORE_START
        vipdrv_os_snprint(tmp, 20, "0x%012x, ", vendor_dev->register_physical[core]);
        tmp += 16;
        LOOP_PHY_DEV_CORE_END
        PRINTK("%s\n", info);

        tmp = info;
        vipdrv_os_copy_memory(tmp, "registerMemSize     ", NAME_HEADER_SIZE);
        tmp += NAME_HEADER_SIZE;
        LOOP_PHY_DEV_CORE_START
        vipdrv_os_snprint(tmp, 20, "0x%08x, ", vendor_dev->register_size[core]);
        tmp += 12;
        LOOP_PHY_DEV_CORE_END
        PRINTK("%s\n", info);

        tmp = info;
        vipdrv_os_copy_memory(tmp, "irqLine             ", NAME_HEADER_SIZE);
        tmp += NAME_HEADER_SIZE;
        LOOP_PHY_DEV_CORE_START
        vipdrv_os_snprint(tmp, 20, "0x%08x, ", vendor_dev->irq_line[core]);
        tmp += 12;
        LOOP_PHY_DEV_CORE_END
        PRINTK("%s\n", info);

        #if vpmdENABLE_VIDEO_MEMORY_HEAP
        tmp = info;
        vipdrv_os_copy_memory(tmp, "contiguousSize      ", NAME_HEADER_SIZE);
        tmp += NAME_HEADER_SIZE;
        for (j = 0; j < valid_heap_cnt; j++) {
            vipdrv_os_snprint(tmp, 20, "0x%010lx, ", vendor_dev->heap_memsize[j]);
            tmp += 14;
        }
        PRINTK("%s\n", info);
        tmp = info;
        vipdrv_os_copy_memory(tmp, "cpuContiguousBase   ", NAME_HEADER_SIZE);
        tmp += NAME_HEADER_SIZE;
        for (j = 0; j < valid_heap_cnt; j++) {
            vipdrv_os_snprint(tmp, 20, "0x%010lx, ", vendor_dev->heap_physical[j]);
            tmp += 14;
        }
        PRINTK("%s\n", info);
        tmp = info;
        vipdrv_os_copy_memory(tmp, "vipContiguousBase   ", NAME_HEADER_SIZE);
        tmp += NAME_HEADER_SIZE;
        for (j = 0; j < valid_heap_cnt; j++) {
            vip_physical_t vip_physical = vendor_dev->ops->phy_cpu2vip(vendor_dev, vendor_dev->heap_physical[j]);
            vipdrv_os_snprint(tmp, 20, "0x%010lx, ", vip_physical);
            tmp += 14;
        }
        PRINTK("%s\n", info);
        tmp = info;
        vipdrv_os_copy_memory(tmp, "allocator name      ", NAME_HEADER_SIZE);
        tmp += NAME_HEADER_SIZE;
        for (j = 0; j < valid_heap_cnt; j++) {
            vipdrv_os_snprint(tmp, 20, "%s, ", vendor_dev->heap_name[j]);
            tmp += 15;
        }
        PRINTK("%s\n", info);
        #endif
        PRINTK("AXISramBaseAddress  0x%"PRIx64"\n", vendor_dev->axi_sram_base);
        tmp = info;
        vipdrv_os_copy_memory(tmp, "AXISramSize         ", NAME_HEADER_SIZE);
        tmp += NAME_HEADER_SIZE;
        LOOP_PHY_DEV_CORE_START
        vipdrv_os_snprint(tmp, 20, "0x%08x, ", vendor_dev->axi_sram_size[core]);
        tmp += 12;
        LOOP_PHY_DEV_CORE_END
        PRINTK("%s\n", info);
        PRINTK("VIPSramBaseAddress  0x%08x\n", vendor_dev->vip_sram_base);
        #if vpmdENABLE_RESERVE_PHYSICAL
        PRINTK("reservePhysicalBase 0x%"PRIx64"\n", vendor_dev->reserve_physical_base);
        PRINTK("reservePhysicalSize 0x%08x\n", vendor_dev->reserve_physical_size);
        #endif
        tmp = info;
        vipdrv_os_copy_memory(tmp, "core cnt per-device ", NAME_HEADER_SIZE);
        tmp += NAME_HEADER_SIZE;
        LOOP_PHY_DEV_CORE_START
        if (vendor_dev->device_core_number[core] != 0) {
        vipdrv_os_snprint(tmp, 20, "%02d, ", vendor_dev->device_core_number[core]);
        tmp += 4;
        }
        LOOP_PHY_DEV_CORE_END
        PRINTK("%s\n", info);
        PRINTK("==================================\n");
    }

#if vpmdENABLE_SYS_MEMORY_HEAP
    PRINTK("drvType             0x%08x\n", drvType);
    PRINTK("sysHeapSize         0x%08x\n", vipcore_dev->sys_heap_size);
#endif
     tmp = info;
     vipdrv_os_copy_memory(tmp, "core cnt logc-dev   ", NAME_HEADER_SIZE);
     tmp += NAME_HEADER_SIZE;
     for (j = 0; j < vipcore_dev->logi_dev_cnt; j++) {
         vipdrv_os_snprint(tmp, 20, "%02d, ", vipcore_dev->logi_dev[j].core_cnt);
         tmp += 4;
     }
     PRINTK("%s\n", info);
     PRINTK("==================================\n");

    PRINTK("mmu=%d 40va=%d\n", vpmdENABLE_MMU, vpmdENABLE_40BITVA);
    return 0;
}
#endif

#if DEFAULT_DISABLE_INTERNEL_CLOCK
static vip_int32_t drv_disable_internel_clock(
    vipdrv_phy_device_t *phy_dev
    )
{
    vip_uint32_t value = 0;

    value = VIP_SETBIT(value, 0, 1);
    value = VIP_SETBIT(value, 1, 1);
    value = VIP_SETBIT(value, 2, 1);
    value = VIP_SETBIT(value, 9, 1);

    LOOP_PHY_DEV_CORE_START
    if (VIP_NULL == phy_dev->vendor->register_base[core]) {
        PRINTK_E("register is NULL\n");
        return -1;
    }
    writel(value, (uint8_t *)phy_dev->vendor->register_base[core] + 0x00000);
    LOOP_PHY_DEV_CORE_END

    value = VIP_SETBIT(value, 9, 0);

    LOOP_PHY_DEV_CORE_START
    writel(value, (uint8_t *)phy_dev->vendor->register_base[core] + 0x00000);
    LOOP_PHY_DEV_CORE_END
    PRINTK("hardware internel clock is disabled by default\n");

    return 0;
}
#endif

static vip_int32_t drv_init_logical_device(
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    vip_status_e status = VIP_SUCCESS;
    vip_int32_t ret = 0;
    vip_uint32_t dev_idx = 0, i = 0;
    vip_uint32_t logi_dev_cnt = 0;
    vip_uint32_t logi_dev_idx = 0;
    vip_uint32_t size = 0;

    for (dev_idx = 0 ; dev_idx < vipcore_dev->phy_dev_cnt; dev_idx++) {
        vipdrv_phy_device_t *phy_dev = &vipcore_dev->phy_dev[dev_idx];
        vipdrv_vendor_device_t *vendor_dev = phy_dev->vendor;
        for (i = 0; i < vendor_dev->core_count; i++) {
            if (vendor_dev->device_core_number[i] > vipdMP_NUM) {
                PRINTK_E("phy_dev=%d logi_dev=%d core count=%d large than %d\n",
                        dev_idx, i, vendor_dev->device_core_number[i], vipdMP_NUM);
                goto error;
            }

            if (vendor_dev->device_core_number[i] > 0) {
                logi_dev_cnt++;
            }
            else {
                break;
            }
        }
    }
    if (0 == logi_dev_cnt) {
        PRINTK_E("logical device cnt is 0\n");
        goto error;
    }

    vipcore_dev->logi_dev_cnt = logi_dev_cnt;
    size = sizeof(vipdrv_logi_device_t) * logi_dev_cnt;
    status = vipdrv_os_allocate_memory(size, (void**)&vipcore_dev->logi_dev);
    if (status != VIP_SUCCESS) {
        PRINTK_E("alloc memory for logical device\n");
        goto error;
    }
    vipdrv_os_zero_memory(vipcore_dev->logi_dev, size);

    for (dev_idx = 0 ; dev_idx < vipcore_dev->phy_dev_cnt; dev_idx++) {
        vip_uint32_t core_start_index = 0;
        vipdrv_phy_device_t *phy_dev = &vipcore_dev->phy_dev[dev_idx];
        vipdrv_vendor_device_t *vendor_dev = phy_dev->vendor;;
        for (i = 0; i < vendor_dev->core_count; i++) {
            if (vendor_dev->device_core_number[i] > 0) {
                vipdrv_logi_device_t* logi_device = &vipcore_dev->logi_dev[logi_dev_idx];
                logi_device->index = logi_dev_idx;
                logi_device->core_cnt = vendor_dev->device_core_number[i];
                logi_device->phy_dev = phy_dev;
                logi_device->core_start_index = core_start_index;
                /* default full clock */
                logi_device->core_fscale_percent = 100;
                PRINTK("logical device index=%d, phy_dev idx=%d, core_start_index=%d, core_cnt=%d, freq_percent=%d\n",
                   logi_dev_idx, logi_device->phy_dev->index, logi_device->core_start_index,
                   logi_device->core_cnt, logi_device->core_fscale_percent);
                core_start_index += logi_device->core_cnt;
                logi_dev_idx++;
            }
            else {
                break;
            }
        }
    }

    return ret;
error:
    return -1;
}


static vip_int32_t drv_uninit_logical_device(
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    vip_int32_t ret = 0;

    if (vipcore_dev->logi_dev != VIP_NULL) {
        vipdrv_os_free_memory(vipcore_dev->logi_dev);
        vipcore_dev->logi_dev = VIP_NULL;
    }

    return ret;
}

static vip_int32_t drv_prepare_logical_device_info(
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    vip_uint32_t iter = 0;
    vip_uint32_t core_idx = 0;
    vip_uint32_t logi_idx = 0;

    if (0 == vipcore_dev->logi_dev_cnt) {
        PRINTK_E("logical dev cnt is 0\n");
        return -1;
    }

    vipdrv_os_allocate_memory(sizeof(vipdrv_device_info_t) * vipcore_dev->logi_dev_cnt,
                            (void **)&vipcore_dev->logi_infos);

    if (VIP_NULL == vipcore_dev->logi_infos) {
        PRINTK_E("alloc device info buffer\n");
        return -1;
    }

    for (logi_idx = 0; logi_idx < vipcore_dev->logi_dev_cnt; logi_idx++) {
        vipdrv_logi_device_t *logi_dev = &vipcore_dev->logi_dev[logi_idx];
        vipdrv_phy_device_t *phy_dev = logi_dev->phy_dev;
        vipdrv_device_info_t *info = &vipcore_dev->logi_infos[logi_idx];

        info->core_count = logi_dev->core_cnt;
        info->core_fscale_percent = logi_dev->core_fscale_percent;
        info->axi_sram_base = phy_dev->vendor->axi_sram_base;
        info->vip_sram_base = phy_dev->vendor->vip_sram_base;

        for (core_idx = 0 ; core_idx < logi_dev->core_cnt; core_idx++) {
            vipdrv_phy_core_t *phy_core = &phy_dev->phy_core[logi_dev->core_start_index + core_idx];
            info->core_id[core_idx] = phy_core->id;
            info->vip_reg[core_idx] = phy_core->register_base;
            info->irq_queue[core_idx] = (void*)&phy_core->irq_queue;
            info->irq_count[core_idx] = &phy_core->irq_count;
            info->irq_value[core_idx] = (vip_uint32_t*)&phy_core->irq_value;
            PRINTK("logic dev:%d core_idx:%d core_id:%d reg_base:%p\n", logi_idx, core_idx,
                info->core_id[core_idx], info->vip_reg[core_idx]);
        }

        for (iter = 0; iter < vipdMP_NUM; iter++) {
            info->axi_sram_size[iter] = phy_dev->vendor->axi_sram_size[iter];
        }
    }

    return 0;
}

static vip_int32_t drv_unprepare_logical_device_info(
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    if (vipcore_dev->logi_infos != VIP_NULL) {
        vipdrv_os_free_memory(vipcore_dev->logi_infos);
        vipcore_dev->logi_infos = VIP_NULL;
    }

    return 0;
}

vip_int32_t drv_construct_device(
    vipdrv_vipcore_vendor_t *vipcore_vendor,
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    vip_status_e status = VIP_SUCCESS;
    vip_int32_t ret = 0;
    vip_uint32_t size = 0;
    vip_uint32_t i = 0;
    vip_uint32_t core_id = 0;

    PRINTK("vipcore, construct device vendor devive_cnt=%d\n", vipcore_vendor->device_count);

    vipcore_dev->phy_dev_cnt = vipcore_vendor->device_count;

    /* 1. init physical device */
    size = sizeof(vipdrv_phy_device_t) * vipcore_dev->phy_dev_cnt;
    status = vipdrv_os_allocate_memory(size, (void**)&vipcore_dev->phy_dev);
    if (status != VIP_SUCCESS) {
        PRINTK_E("alloc memory for phy_dev\n");
        return -1;
    }
    vipdrv_os_zero_memory(vipcore_dev->phy_dev, size);

    if (0 == drvType) {
        ret = vipdrv_register_chrdev(vipcore_dev);
        if (ret < 0) {
            PRINTK_E("register chr dev");
            goto error;
        }
        ret = vipdrv_create_class(vipcore_dev);
        if (ret < 0) {
            PRINTK_E("chreate chr class");
            goto error;
        }
    }

    LOOP_PHY_DEV_START
    vipdrv_phy_device_t *phy_dev = &vipcore_dev->phy_dev[phy_dev_index];
    vipdrv_vendor_device_t *vendor_dev = &vipcore_vendor->device[phy_dev_index];

    /* 1.1 init physical device */
    phy_dev->index = phy_dev_index;
    phy_dev->vendor = vendor_dev;
    phy_dev->vipcore_dev = vipcore_dev;
#if defined (USE_LINUX_PLATFORM_DEVICE) || defined (USE_LINUX_PCIE_DEVICE)
    phy_dev->device = &vendor_dev->pdev->dev;
#endif
    /* 1.2 init physical core */
    phy_dev->phy_core_cnt = vendor_dev->core_count;
    PRINTK("vipcore, phy_dev%d, core_cnt=%d\n", phy_dev->index,  phy_dev->phy_core_cnt);
    size = sizeof(vipdrv_phy_core_t) * phy_dev->phy_core_cnt;
    status = vipdrv_os_allocate_memory(size, (void**)&phy_dev->phy_core);
    if (status != VIP_SUCCESS) {
        PRINTK_E("alloc memory for dev%d phy_core\n", phy_dev_index);
        goto error;
    }
    vipdrv_os_zero_memory(phy_dev->phy_core, size);
    for (i = 0; i < phy_dev->phy_core_cnt; i++) {
        vipdrv_phy_core_t *phy_core = &phy_dev->phy_core[i];
        phy_core->index = i;
        phy_core->phy_dev = phy_dev;
        phy_core->id = core_id;
        core_id++;
        if (core_id >= vipdMP_NUM) {
            core_id = 0;
        }
    }

    /* 1.3 register vipcore char device */
    if (0 == drvType) {
        ret = vipdrv_create_chrdev(phy_dev);
        if (ret < 0) {
            PRINTK_E("create chr device");
            goto error;
        }
    }
    else {
        ret = vipdrv_create_miscdev(phy_dev);
        if (ret < 0) {
            PRINTK_E("create misc device");
            goto error;
        }
    }

    ret = drv_prepare_irq(phy_dev);
    if (ret < 0) {
        PRINTK_E("register irq");
        goto error;
    }

    ret = drv_prepare_register(phy_dev);
    if (ret < 0) {
        PRINTK_E("prepare register");
        goto error;
    }

#if DEFAULT_DISABLE_INTERNEL_CLOCK
    /* disable internel clock by default */
    drv_disable_internel_clock(phy_dev);
#endif

    LOOP_PHY_DEV_END

    /* 2. init logical device */
    ret = drv_init_logical_device(vipcore_dev);
    if (ret < 0) {
        PRINTK_E("init logical device\n");
        goto error;
    }

    ret = drv_prepare_logical_device_info(vipcore_dev);
    if (ret < 0) {
        PRINTK_E("prepare logical device\n");
        goto error;
    }

    /* 3. init video memory heap */
#if vpmdENABLE_VIDEO_MEMORY_HEAP
    ret = drv_prepare_video_memory(vipcore_dev);
    if (ret < 0) {
        PRINTK_E("prepare video memory\n");
        goto error;
    }
#else
    PRINTK("video memory heap is disabled\n");
#endif

#if vpmdENABLE_DEBUGFS
    ret = vipdrv_debug_create_fs(vipcore_dev);
    if (ret < 0) {
        PRINTK("create viplite fs failed, error = %d.\n", ret);
    }
#endif

#if (vpmdENABLE_DEBUG_LOG > 1)
    drv_show_params(vipcore_dev);
#endif

    return ret;

error:
    if (vipcore_dev->phy_dev != VIP_NULL) {
        vipdrv_os_free_memory(vipcore_dev->phy_dev);
        vipcore_dev->phy_dev = VIP_NULL;
    }
    return ret;
}

void drv_destroy_device(
    vipdrv_vipcore_device_t *vipcore_dev
    )
{
    PRINTK("vipcore, destroy device start...\n");
    if (VIP_NULL == vipcore_dev->phy_dev) {
        return;
    }

#if vpmdENABLE_DEBUGFS
    vipdrv_debug_destroy_fs(vipcore_dev);
#endif

#if vpmdENABLE_VIDEO_MEMORY_HEAP
    drv_unprepare_video_memory(vipcore_dev);
#endif

    drv_unprepare_logical_device_info(vipcore_dev);

    drv_uninit_logical_device(vipcore_dev);

    LOOP_PHY_DEV_START
    vipdrv_phy_device_t *phy_dev = &vipcore_dev->phy_dev[phy_dev_index];

    drv_unprepare_register(phy_dev);
    drv_unprepare_irq(phy_dev);

    if (phy_dev->phy_core != VIP_NULL) {
        vipdrv_os_free_memory(phy_dev->phy_core);
        phy_dev->phy_core = VIP_NULL;
    }

    if (0 == drvType) {
        vipdrv_destroy_chrdev(phy_dev);
    }
    else {
        vipdrv_destroy_miscdev(phy_dev);
    }

    LOOP_PHY_DEV_END

    if (0 == drvType) {
        vipdrv_destroy_class(vipcore_dev);
        vipdrv_unregister_chrdev(vipcore_dev);
    }

    vipdrv_os_free_memory(vipcore_dev->phy_dev);
    vipcore_dev->phy_dev = VIP_NULL;

    PRINTK("vipcore, destroy device end...\n");
}

vipdrv_phy_device_t* vipdrv_get_phy_device(
    vip_uint32_t index
    )
{
    vipdrv_vipcore_driver_t *kdriver = vipdrv_get_vipcore_driver();
    vipdrv_phy_device_t *phy_dev = VIP_NULL;

    if (index >= kdriver->vipcore_dev.phy_dev_cnt) {
        PRINTK_E("get phy device index=%d max dev_cnt=%d\n", index, kdriver->vipcore_dev.phy_dev_cnt);
        index = 0;
    }
    phy_dev = &kdriver->vipcore_dev.phy_dev[index];

    return phy_dev;
}

vipdrv_logi_device_t* vipdrv_get_logi_device(
    vip_uint32_t index
    )
{
    vipdrv_vipcore_driver_t *kdriver = vipdrv_get_vipcore_driver();
    vipdrv_logi_device_t *logi_dev = VIP_NULL;

    if (index >= kdriver->vipcore_dev.logi_dev_cnt) {
        PRINTK_E("get logi device index=%d max dev_cnt=%d, update index to 0\n",
                    index, kdriver->vipcore_dev.logi_dev_cnt);
        index = 0;
    }
    logi_dev = &kdriver->vipcore_dev.logi_dev[index];

    return logi_dev;
}

/* add a linux platform device for match platform driver */
vip_int32_t drv_platform_device_register(
    struct platform_driver *platform_drv
    )
{
    vip_int32_t ret = 0;

    if (VIP_NULL == platform_drv) {
        return -1;
    }

    default_dev = platform_device_alloc(platform_drv->driver.name, -1);

    if (VIP_NULL == default_dev) {
        PRINTK_E("vipcore: platform_device_alloc failed.\n");
        return -ENOMEM;
    }

    /* Add device */
    ret = platform_device_add(default_dev);
    if (ret) {
        PRINTK_E("vipcore: platform_device_add failed.\n");
        goto put_dev;
    }

    return 0;

put_dev:
    platform_device_put(default_dev);
    return -1;
}

vip_int32_t drv_platform_device_unregister(void)
{
    vip_int32_t ret = 0;

    if (default_dev != VIP_NULL) {
        platform_device_unregister(default_dev);
        default_dev = VIP_NULL;
    }

    return ret;
}
