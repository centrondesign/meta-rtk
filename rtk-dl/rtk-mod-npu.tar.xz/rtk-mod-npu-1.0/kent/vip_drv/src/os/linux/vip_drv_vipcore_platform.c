/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************
*
*    The GPL License (GPL)
*
*    Copyright (C) 2017 - 2025 Vivante Corporation
*
*    This program is free software; you can redistribute it and/or
*    modify it under the terms of the GNU General Public License
*    as published by the Free Software Foundation; either version 2
*    of the License, or (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software Foundation,
*    Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
*
*****************************************************************************
*
*    Note: This software is released under dual MIT and GPL licenses. A
*    recipient may use this file under the terms of either the MIT license or
*    GPL License. If you wish to use only one license not the other, you can
*    indicate your decision by deleting one of the above license notices in your
*    version of this file.
*
*****************************************************************************/

#include <linux/slab.h>
#include <linux/module.h>
#include <linux/pci.h>

#include "vip_drv_vipcore_type.h"
#include "vip_drv_vipcore_driver.h"
#include "vip_drv_vipcore_device.h"
#include "vip_drv_vipcore_vendor.h"
#include "vip_drv_vipcore_platform.h"

/* LINUX platform device driver source code */

#if defined (USE_LINUX_PLATFORM_DEVICE)

#define DRIVER_NAME "vipcore_drv"
#define vipdMAX_PLATFORM_DEV_NUM   20

static struct completion probed[vipdMAX_PLATFORM_DEV_NUM];
static struct platform_device *pdev_array[vipdMAX_PLATFORM_DEV_NUM] = {VIP_NULL};

static vip_int32_t vipdrv_platform_get_device(
    const struct of_device_id *vipcore_dev_match,
    vip_uint32_t vipcore_match_devcnt,
    vip_uint32_t *dts_config_devcnt
    )
{
    vip_uint32_t idx = 0;
    vip_uint32_t count = 0;
    struct device_node *np;

    if (VIP_NULL == vipcore_dev_match) {
        PRINTK_E("vipcore: pointer vipcore_dev_match is null.\n");
        return -1;
    }
    if (VIP_NULL == dts_config_devcnt) {
        PRINTK_E("vipcore: pointer dts_config_devcnt is null.\n");
        return -1;
    }
    for (idx = 0; idx < vipcore_match_devcnt; idx++) {
        np = of_find_compatible_node(NULL, NULL, vipcore_dev_match[idx].compatible);
        if (!np) {
            continue;
        }
        count++;
        PRINTK("vipcore, dts config dev=%s, np=%p\n", vipcore_dev_match[idx].compatible, np);
    }
    if (0 == count) {
        PRINTK_E("vipcore, dts config match dev is 0\n");
        return -1;
    }

    *dts_config_devcnt = count;

    if (*dts_config_devcnt > vipcore_match_devcnt) {
        PRINTK("vipcore, dts config device count %u more than vipcore support device count %u\n",
                *dts_config_devcnt, vipcore_match_devcnt);
        return -1;
    }
    if (*dts_config_devcnt != vipcore_match_devcnt) {
        PRINTK("vipcore, match dev count=%u, dts config device count=%u\n",
                vipcore_match_devcnt, *dts_config_devcnt);
    }
    return 0;
}

static vip_int32_t vip_subdrv_platform_probe(
    struct platform_device *pdev
    )
{
    vip_int32_t ret = 0;
    vip_int32_t index = 0;

    PRINTK("vipcore, platform_device pdev=0x%p\n", pdev);

    for (index = 0 ; index < vipdMAX_PLATFORM_DEV_NUM; index++) {
        /* find a not probed phy device */
        if (VIP_NULL == pdev_array[index]) {
            pdev_array[index] = pdev;
            complete(&probed[index]);
            break;
        }
    }

    if (dma_set_mask(&pdev->dev, DMA_BIT_MASK(40))) {
        PRINTK(KERN_ERR "vipcore, set DMA mask\n");
    }

    return ret;
}

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 11, 0))
static void vip_subdrv_platform_remove(
    struct platform_device *pdev
    )
#else
static vip_int32_t vip_subdrv_platform_remove(
    struct platform_device *pdev
    )
#endif
{
#if (LINUX_VERSION_CODE < KERNEL_VERSION(6, 11, 0))
    return 0;
#endif
}

static struct platform_driver vip_platform_subdriver = {
    .probe      = vip_subdrv_platform_probe,
    .remove     = vip_subdrv_platform_remove,
    .driver     = {
        .owner  = THIS_MODULE,
        .name   = DRIVER_NAME,
    },
};

static vip_int32_t vipdrv_platform_register_subdriver(
    vip_uint32_t dts_config_devcnt,
    struct platform_driver *vipdrv_platform_subdriver
    )
{
    vip_int32_t ret = 0;
    vip_uint32_t idx = 0;
    vip_uint32_t timeout = msecs_to_jiffies(5000);

    if (VIP_NULL == vipdrv_platform_subdriver) {
        PRINTK_E("vipcore, vip platform subdriver is NULL\n");
        return -1;
    }
    for (idx = 0; idx < dts_config_devcnt; idx++) {
        init_completion(&probed[idx]);
    }

    ret = platform_driver_register(vipdrv_platform_subdriver);
    if (ret) {
        goto platform_unregister;
    }
    /* will check probe called times in init function */
    for (idx = 0; idx < dts_config_devcnt; idx++) {
        timeout = wait_for_completion_timeout(&probed[idx], timeout);
        if (timeout == 0) {
            PRINTK_E("vipcore: failed to probe platform device, index:%d\n", idx);
            ret = -ENODEV;
            goto platform_unregister;
        }
    }

    return 0;

platform_unregister:
    platform_driver_unregister(vipdrv_platform_subdriver);
    return ret;
}

/*
initialize vip-core platform from linux platform device,
@param dev_count: IN,the number of element for pcie_ids.
@param vendor_operations: IN, vendor device ops
@param vipcore_vendor: OUT, vip core platform struct.
*/
vip_int32_t vipdrv_platform_device_auto_probe(
    struct of_device_id *vipcore_dev_match,
    vip_uint32_t vipcore_match_devcnt,
    vipdrv_vendor_operations_t *vendor_operations,
    vipdrv_vipcore_vendor_t *vipcore_vendor
    )
{
    vip_uint32_t idx = 0;
    vip_int32_t ret = 0;
    vip_uint32_t dts_config_devcnt = 0;
    vip_uint32_t probe_really_cnt = 0;

    if (0 == vipcore_match_devcnt) {
        PRINTK_E("vipcore, drv support platform device count is 0\n");
        return -1;
    }
    if (VIP_NULL == vipcore_dev_match) {
        PRINTK_E("vipcore, vipcore_dev_match param is NULL\n");
        return -1;
    }
    if (VIP_NULL == vipcore_vendor) {
        PRINTK_E("vipcore, vipcore_vendor param is NULL\n");
        return -1;
    }
    if (VIP_NULL == vendor_operations) {
        PRINTK_E("vipcore, vendor_operations param is NULL\n");
        return -1;
    }

    ret = vipdrv_platform_get_device(vipcore_dev_match, vipcore_match_devcnt, &dts_config_devcnt);
    if (ret) {
        PRINTK_E("vipcore: fail to get platform device.\n");
        return -1;
    }

    vipcore_vendor->device_count = dts_config_devcnt;
    vipcore_vendor->device = (vipdrv_vendor_device_t *)kmalloc(sizeof(vipdrv_vendor_device_t) *
            dts_config_devcnt, GFP_KERNEL);
    if (VIP_NULL == vipcore_vendor->device) {
        PRINTK_E("vipcore, kmalloc failed for platform device.\n");
        return -1;
    }
    memset(vipcore_vendor->device, 0, sizeof(vipdrv_vendor_device_t) * dts_config_devcnt);

    vip_platform_subdriver.driver.of_match_table = vipcore_dev_match;
    ret = vipdrv_platform_register_subdriver(dts_config_devcnt, &vip_platform_subdriver);
    if (ret) {
        PRINTK_E("vipcore: fail to register platform driver.\n");
        return -1;
    }

    for (idx = 0; idx < vipdMAX_PLATFORM_DEV_NUM; idx++) {
        /* check probe callback function called times */
        if (VIP_NULL != pdev_array[idx]) {
            probe_really_cnt++;
        }
    }
    if (probe_really_cnt > dts_config_devcnt) {
        PRINTK_E("vipcore, dts config device count is %u, but device probe called count is %u\n",
                dts_config_devcnt, probe_really_cnt);
        goto platform_unregister;
    }

    for (idx = 0; idx < dts_config_devcnt; idx++) {
        vipcore_vendor->device[idx].index = idx;
        vipcore_vendor->device[idx].ops = vendor_operations;
        vipcore_vendor->device[idx].vipcore_vendor = vipcore_vendor;
        vipcore_vendor->device[idx].pdev = pdev_array[idx];
    }

    return 0;

platform_unregister:
    platform_driver_unregister(&vip_platform_subdriver);
    return -1;
}

void vipdrv_platform_device_auto_remove(
    vipdrv_vipcore_vendor_t *vipcore_vendor
    )
{

    platform_driver_unregister(&vip_platform_subdriver);

    if (vipcore_vendor->device == VIP_NULL) {
        kfree(vipcore_vendor->device);
        vipcore_vendor->device = VIP_NULL;
    }
}
#endif
/*
initialize the vipcore platform, if device doesn't on Linux pcie or platform bus.
@param dev_count: IN,the number of element for pcie_ids.
@param vendor_operations: IN, vendor device ops
@param vipcore_vendor: OUT, vip core platform struct.
*/
vip_int32_t vipdrv_misc_device_init(
    vip_uint32_t dev_count,
    vipdrv_vendor_operations_t *vendor_operations,
    vipdrv_vipcore_vendor_t *vipcore_vendor
    )
{
    vip_uint32_t idx = 0;

    if (0 == dev_count) {
        PRINTK_E("vipcore, platform device init dev_cnt is 0\n");
        return -1;
    }
    if (VIP_NULL == vipcore_vendor) {
        PRINTK_E("vipcore, vipcore_vendor param is NULL\n");
        return -1;
    }
    if (VIP_NULL == vendor_operations) {
        PRINTK_E("vipcore, vendor_operations param is NULL\n");
        return -1;
    }

    vipcore_vendor->device_count = dev_count;
    vipcore_vendor->device = (vipdrv_vendor_device_t *)kmalloc(sizeof(vipdrv_vendor_device_t) * dev_count, GFP_KERNEL);
    if (VIP_NULL == vipcore_vendor->device) {
        PRINTK_E("vipcore, kmalloc failed for device.\n");
        return -1;
    }
    memset(vipcore_vendor->device, 0, sizeof(vipdrv_vendor_device_t) * dev_count);
    for (idx = 0; idx < dev_count; idx++) {
        vipcore_vendor->device[idx].index = idx;
        vipcore_vendor->device[idx].ops = vendor_operations;
        vipcore_vendor->device[idx].vipcore_vendor = vipcore_vendor;
    }

    return 0;
}

void vipdrv_misc_device_uninit(
    vipdrv_vipcore_vendor_t *vipcore_vendor
    )
{
    if (vipcore_vendor->device != VIP_NULL) {
        kfree(vipcore_vendor->device);
        vipcore_vendor->device = VIP_NULL;
    }
}

vip_status_e vipdrv_AHB_register_map(
    vipdrv_vendor_device_t *device,
    vip_physical_t register_physical,
    vip_uint32_t register_size,
    void** logical
    )
{
    vip_status_e status = VIP_SUCCESS;
    vip_char_t *reg_name = "vipcore_reg";

    if ((logical == VIP_NULL) || (register_size == 0)) {
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    if (request_mem_region(register_physical, register_size, reg_name) == VIP_NULL) {
        PRINTK_E("vipcore, warning request register mem physical=0x%"PRIx64", size=0x%x name=%s\n",
            register_physical, register_size, reg_name);
    }

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,6,0)
    *logical = ioremap(register_physical, register_size);
#else
    *logical= ioremap_nocache(register_physical, register_size);
#endif
    if (VIP_NULL == *logical) {
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    return status;
onError:
    PRINTK_E("map bar 0x%llx size %u\n", register_physical, register_size);
    return status;
}

vip_status_e vipdrv_AHB_register_unmap(
    vipdrv_vendor_device_t *device,
    vip_physical_t register_physical,
    vip_uint32_t register_size,
    void* logical
    )
{
    vip_status_e status = VIP_SUCCESS;

    if (VIP_NULL != logical) {
        iounmap(logical);
    }
    if (register_size != 0) {
        release_mem_region(register_physical, register_size);
    }

    return status;
}

/*
Alloc page for video memory heap.
@param size: the size of memory need be allocated.
@param phyiscal: OUT, contignous physical address.
*/
struct page *vipdrv_vendor_alloc_page(
    vip_size_t size,
    vip_physical_t *physical
    )
{
    u32 gfp = 0;
    struct page *heap_page = VIP_NULL;
    vip_physical_t heap_physical = 0;

    gfp = GFP_KERNEL | __GFP_HIGHMEM | __GFP_NOWARN;
    gfp &= ~__GFP_HIGHMEM;
#if defined(CONFIG_ZONE_DMA32) && LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,37)
    gfp |= __GFP_DMA32;
#else
    gfp |= __GFP_DMA;
#endif

    PRINTK("vipcore, allocate page for video memory, size: 0x%llx bytes\n", size);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 27)
    {
    void *addr = alloc_pages_exact(size, gfp | __GFP_NORETRY);
    heap_page = addr ? virt_to_page(addr) : VIP_NULL;
    }
#else
    {
    int order = get_order(size);
    heap_page = alloc_pages(gfp, order);
    }
#endif

    if (VIP_NULL == heap_page) {
     #if vpmdENABLE_MMU
        /* not limite the PA range try again */
        {
            PRINTK_E("vipcore, alloc large than 4GB memory\n");
            gfp = GFP_KERNEL | __GFP_HIGHMEM | __GFP_NOWARN;

            /*In ARM64,there is no highmem zone*/
        #if defined(__aarch64__)
            gfp &= ~__GFP_HIGHMEM;
        #endif
        #if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 27)
            {
            void *addr = alloc_pages_exact(size, gfp | __GFP_NORETRY);
            heap_page = addr ? virt_to_page(addr) : VIP_NULL;
            }
        #else
            {
            int order = get_order(size);
            heap_page = alloc_pages(gfp, order);
            }
        #endif
        }
    #endif

        if (VIP_NULL == heap_page) {
            PRINTK_E("vipcore, fail to alloc page size: 0x%llx bytes\n", size);
            *physical = 0;
            return VIP_NULL;
        }
        else {
            heap_physical = page_to_phys(nth_page(heap_page, 0));
        }
    }
    else {
        heap_physical = page_to_phys(nth_page(heap_page, 0));
    }

    if (physical) {
        *physical = heap_physical;
    }

    return heap_page;
}

/*
Map the CPU logical for AHB register of NPU.
*/
void vipdrv_vendor_free_page(
    vip_size_t size,
    struct page *heap_page
    )
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 27)
    free_pages_exact(page_address(heap_page), size);
#else
    __free_pages(heap_page, get_order(size));
#endif

    PRINTK_I("vipcore, unmap kernel space and free video memory\n");
}
