/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************
*
*    The GPL License (GPL)
*
*    Copyright (C) 2017 - 2025 Vivante Corporation
*
*    This program is free software; you can redistribute it and/or
*    modify it under the terms of the GNU General Public License
*    as published by the Free Software Foundation; either version 2
*    of the License, or (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software Foundation,
*    Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
*
*****************************************************************************
*
*    Note: This software is released under dual MIT and GPL licenses. A
*    recipient may use this file under the terms of either the MIT license or
*    GPL License. If you wish to use only one license not the other, you can
*    indicate your decision by deleting one of the above license notices in your
*    version of this file.
*
*****************************************************************************/

#ifndef _VIP_DRV_VIPCORE_DEVICE_H
#define _VIP_DRV_VIPCORE_DEVICE_H
#include <vip_drv_os_port.h>
#include "vip_drv_vipcore_type.h"
#include <vip_drv_type.h>
#include <linux/version.h>
#include <linux/device.h>
#include <linux/pagemap.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <linux/clk.h>
#include <linux/clk-provider.h>
#include <linux/platform_device.h>


#ifndef DEVICE_NAME
#define DEVICE_NAME              "vipcore"
#endif

#ifndef CLASS_NAME
#define CLASS_NAME               "vipcore_class"
#endif


struct _vipdrv_logi_device
{
    /* the index of this logical device */
    vip_uint32_t            index;

    /* the number of core for this logical device */
    vip_uint32_t            core_cnt;
    /* the start core index in physical device */
    vip_uint32_t            core_start_index;

    vipdrv_phy_device_t    *phy_dev;
    vip_uint32_t            core_fscale_percent;
};

struct _vipdrv_phy_core
{
    /* the index of phy_core in phy_device */
    vip_uint32_t            index;
    /* the id of phy_core in multiple processor(MP) */
    vip_uint32_t            id;

    vipdrv_phy_device_t     *phy_dev;

    vip_int32_t             irq_registed;
    wait_queue_head_t       irq_queue;
    vipdrv_atomic           irq_count;
    volatile vip_uint32_t   irq_value;
    /* map core_id to irq_queue index */
    vip_uint8_t             irq_map;

    /* the VIP's AHB register CPU logical base address */
    volatile void*          register_base;
    /* the size of AHB register memory for the core */
    vip_uint32_t            register_size;

    volatile vip_uint32_t   power_status;
};

struct _vipdrv_phy_device
{
    vipdrv_vendor_device_t   *vendor;

    /* the linux device object of vipcore */
    struct device           *device;

    /* the index of this physical device */
    vip_uint32_t             index;

    vipdrv_vipcore_device_t  *vipcore_dev;

    vip_uint32_t            phy_core_cnt;
    vipdrv_phy_core_t      *phy_core;

    vip_int32_t             created;
};

struct _vipdrv_vipcore_device
{
    /* the count of devices are physical device */
    vip_uint32_t           phy_dev_cnt;
    /* phsyical device */
    vipdrv_phy_device_t   *phy_dev;

    /* the count of devices are logical device */
    vip_uint32_t           logi_dev_cnt;
    /* logical device */
    vipdrv_logi_device_t  *logi_dev;

    /* information of all logical device */
    vipdrv_device_info_t  *logi_infos;

#if vpmdENABLE_VIDEO_MEMORY_HEAP
    /* vido memory heap */
    vip_uint32_t                heap_count;
    vipdrv_videomem_heap_info_t *heap_infos;
#endif

    /* the size of system heap size */
    vip_uint32_t          sys_heap_size;

    /* has register linux char device node */
    vip_int32_t           registered;
    struct class          *class;
};

vipdrv_phy_device_t* vipdrv_get_phy_device(
    vip_uint32_t index
    );

vipdrv_logi_device_t* vipdrv_get_logi_device(
    vip_uint32_t index
    );

vip_int32_t drv_construct_device(
    vipdrv_vipcore_vendor_t *vipcore_vendor,
    vipdrv_vipcore_device_t *vipcore_dev
    );

void drv_destroy_device(
    vipdrv_vipcore_device_t *vipcore_dev
    );

vip_int32_t drv_platform_device_register(
    struct platform_driver *platform_drv
    );

vip_int32_t drv_platform_device_unregister(
    void
    );
#endif
