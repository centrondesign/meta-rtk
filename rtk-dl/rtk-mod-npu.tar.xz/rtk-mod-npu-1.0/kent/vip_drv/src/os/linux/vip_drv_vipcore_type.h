/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************
*
*    The GPL License (GPL)
*
*    Copyright (C) 2017 - 2025 Vivante Corporation
*
*    This program is free software; you can redistribute it and/or
*    modify it under the terms of the GNU General Public License
*    as published by the Free Software Foundation; either version 2
*    of the License, or (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software Foundation,
*    Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
*
*****************************************************************************
*
*    Note: This software is released under dual MIT and GPL licenses. A
*    recipient may use this file under the terms of either the MIT license or
*    GPL License. If you wish to use only one license not the other, you can
*    indicate your decision by deleting one of the above license notices in your
*    version of this file.
*
*****************************************************************************/

#ifndef _VIP_DRV_VIPCORE_TYPE_H
#define _VIP_DRV_VIPCORE_TYPE_H

#include <vip_lite_config.h>


#define MULTI_DEVICE_ENABLE_ID     0


/*
  video memory heap base address alignment size
  4K bytes. request for Linux system page mapping.
*/
#define vipdMEMORY_HAEAP_BASE_ADDRESS_ALIGN  4096

/* the maximum number of heap can be managed by this driver */
#define VIDEO_MEMORY_HEAP_MAX_CNT      16

/* exclusive allocator
 heap-exclusive memory should be:
    1. Device memory on PCIE card.
    2. Reserved in DTS, and reserved by Linux System.
 This memory has not manage by Linux system.
*/
#define ALLOCATOR_NAME_HEAP_EXCLUSIVE     "heap-exclusive"

/* reserved allocator
 reserved memory should be host memory, not used by system and reserved for NPU
 This memory has been manage by Linux system.
*/
#define ALLOCATOR_NAME_HEAP_RESERVED      "heap-reserved"


/*
    Declaration of data type for vipcore in vip-drv
*/
typedef struct _vipdrv_vipcore_driver_t     vipdrv_vipcore_driver_t;
typedef struct _vipdrv_vipcore_vendor       vipdrv_vipcore_vendor_t;
typedef struct _vipdrv_vipcore_device       vipdrv_vipcore_device_t;

typedef struct _vipdrv_vendor_device_t      vipdrv_vendor_device_t;
typedef struct _vipdrv_vendor_operations    vipdrv_vendor_operations_t;
typedef struct _vipdrv_phy_device           vipdrv_phy_device_t;
typedef struct _vipdrv_phy_core             vipdrv_phy_core_t;
typedef struct _vipdrv_logi_device          vipdrv_logi_device_t;



#endif
