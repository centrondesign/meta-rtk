/******************************************************************************\
|* Copyright (c) 2017-2025 by Vivante Corporation.  All Rights Reserved.      *|
|*                                                                            *|
|* The material in this file is confidential and contains trade secrets of    *|
|* of Vivante Corporation.  This is proprietary information owned by Vivante  *|
|* Corporation.  No part of this work may be disclosed, reproduced, copied,   *|
|* transmitted, or used in any way for any purpose, without the express       *|
|* written permission of Vivante Corporation.                                 *|
|*                                                                            *|
\******************************************************************************/
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include <vip_lite_config.h>
#include "vip_drv_context.h"
#include "vip_drv_vipcore_driver.h"
#include "vip_drv_vipcore_vendor.h"
#include "vip_drv_hardware.h"
#include "vip_drv_pm.h"
#include "vip_drv_interface.h"
#include <vip_drv_vipcore_vendor_config.h>
#if FreeRTOS_POSIX
#include "FreeRTOS_POSIX/semaphore.h"
#endif


typedef struct _vipdrv_driver_t {
    /* Mapped cpu virtual address for AHB register memory base */
    volatile void       *vip_reg[vpmdCORE_COUNT];
    vip_int8_t          initialize;

    vip_int32_t         irq_line[vpmdCORE_COUNT];
    vip_int32_t            irq_enabled[vpmdCORE_COUNT];
    volatile vip_uint32_t  irq_values[vpmdCORE_COUNT];
    vipdrv_atomic          irq_count[vpmdCORE_COUNT];
    vip_uint8_t            irq_map[vpmdCORE_COUNT];

#if vpmdENABLE_VIDEO_MEMORY_HEAP
    vipdrv_videomem_heap_info_t heap_info;
    vip_physical_t              cpu_physical; /* CPU physical adddress for the VIP memory */
#endif

    SemaphoreHandle_t      irq_sem_handle[vpmdCORE_COUNT];

    /* information of all hardware information */
    vipdrv_hardware_info_t      hw_info;

    vip_uint32_t     power_status[vpmdCORE_COUNT];  /* power on/off states */
    vip_uint32_t     core_count;
    vip_uint32_t     core_fscale_percent;
} vipdrv_driver_t;


static vipdrv_driver_t kdriver;

#define LOOP_CORE_START                                  \
{  vip_uint32_t core = 0;                                \
   for(core = 0 ; core < kdriver.core_count; core++){

#define LOOP_CORE_END }}

#if !vpmdENABLE_POLLING
/*
@brief interrupt handle function.
*/
static void vipdrv_irq_handler(
    void *data
    )
{
    vip_uint32_t value = 0;
    vip_uint32_t core_index = VIPDRV_PTR_TO_UINT32(data) - 1;
    vipdrv_os_read_reg(kdriver.vip_reg[core_index], 0x00010, &value);
    if (value != 0x00) {
        kdriver.irq_values[core_index] = value;
        while (0 != value) {
            value &= (value - 1);
            vipdrv_os_inc_atomic(kdriver.irq_count[core_index]);
        }
        kdriver.irq_values[kdriver.irq_map[core_index]] |= IRQ_VALUE_FLAG;
        vipdrv_os_wakeup_interrupt(&kdriver.irq_sem_handle[kdriver.irq_map[core_index]]);
    }
}
#endif

/*
@brief convert CPU physical to VIP physical.
@param cpu_physical. the physical address of CPU domain.
*/
vip_physical_t vipdrv_drv_get_vipphysical(
    vip_uint32_t device_index,
    vip_physical_t cpu_physical
    )
{
    vip_physical_t vip_physical = cpu_physical;

    return vip_physical;
}

/*
@brief convert VIP physical to CPU physical.
@param vip_physical. the physical address of VIP domain.
*/
vip_physical_t vipdrv_drv_get_cpuphysical(
    vip_uint32_t device_index,
    vip_physical_t vip_physical
    )
{
    vip_physical_t cpu_physical = vip_physical;

    return cpu_physical;
}

/*
 Get the video memory config information
 1. the size of system memory used by vip_hal.
 2. reserve_physical is a video memory, used by vip_create_network_from_physical() api in nbg_linker.
 3. heap info is used for video memory heap basic information.
*/
vip_status_e vipdrv_drv_get_memory_config(
    vipdrv_vendor_memory_config_t *memory_info
    )
{
    vip_status_e status = VIP_SUCCESS;

    if (VIP_NULL == memory_info) {
        PRINTK_E("get video memory info param is NULL\n");
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

#if vpmdENABLE_SYS_MEMORY_HEAP
    memory_info->sys_heap_size = SYSTEM_MEMORY_HEAP_SIZE;
#endif

#if vpmdENABLE_RESERVE_PHYSICAL
    memory_info->reserve_phy_base = 0;
    memory_info->reserve_phy_size = 0;
#endif

#if vpmdENABLE_VIDEO_MEMORY_HEAP
    memory_info->heap_count = 1;
    memory_info->heap_infos = &kdriver.heap_info;
    if ((kdriver.heap_info.vip_physical == 0) || (kdriver.heap_info.vip_memsize == 0) ||
        (kdriver.heap_info.name == VIP_NULL)) {
        PRINTK("vipcore, heap name or size is null\n");
        status = VIP_ERROR_IO;
    }
#endif

    return status;
}

/*
@brief Get all hardware basic information.
*/
vip_status_e vipdrv_drv_get_hardware_info(
    vipdrv_hardware_info_t *info
    )
{
    if (VIP_NULL == info) {
        PRINTK_E("get hardware info param is NULL\n");
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    info->device_count = kdriver.hw_info.device_count;
    info->device_info = kdriver.hw_info.device_info;

    return VIP_SUCCESS;
}

/*
@brief Set power on/off and clock on/off
@param device_index, the index of logical device.
@param core_index, the core index in logical device.
@param state, power status. refer to vipdrv_power_status_e.
*/
vip_status_e vipdrv_drv_set_power_clk(
    vip_uint32_t device_index,
    vip_uint32_t core_index,
    vip_uint32_t state
    )
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t core_id = 0;
    vipdrv_hardware_info_t *hw_info = &kdriver.hw_info;
    vipdrv_device_info_t *device_info = VIP_NULL;

    /* convert the core index to core id */
    if (device_index >= hw_info->device_count) {
        PRINTK_E("set power clk dev_idx=%d max dev cnt=%d\n", device_index, hw_info->device_count);
        return VIP_ERROR_INVALID_ARGUMENTS;
    }
    device_info = &hw_info->device_info[device_index];
    if (core_index >= device_info->core_count) {
        PRINTK_E("set power clk dev_idx=%d max core cnt=%d, invalid core idx=%d\n",
                 device_index, device_info->core_count, core_index);
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    core_id = device_info->core_id[core_index];

    if (state == VIPDRV_POWER_ON) {
        if (state != kdriver.power_status[core_id]) {
            vipOnError(vipdrv_vendor_power_on(core_id));
            kdriver.power_status[core_id] = VIPDRV_POWER_ON;
        }
    }
    else if (state == VIPDRV_POWER_OFF) {
        if (state != kdriver.power_status[core_id]) {
            vipOnError(vipdrv_vendor_power_off(core_id));
            kdriver.power_status[core_id] = VIPDRV_POWER_OFF;
        }
    }
    else {
        PRINTK("vipcore, no this state=%d in set power clk\n", state);
        status = VIP_ERROR_FAILURE;
    }

    return status;
onError:
    PRINTK_E("vipcore, set power clock core=%d core_id=%d\n", core_index, core_id);
    return status;
}

static vip_status_e drv_prepare_logical_device_info(void)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t core = 0;
    vip_uint32_t i = 0, j = 0, core_cnt = 0, irq_index = 0;
    vip_uint32_t device_core_number[vipdMAX_DEVICE_NUM] = {0};
    vip_uint32_t logi_dev_cnt = 0;
    vip_uint32_t logi_idx = 0;
    vip_uint32_t core_start_index = 0;
    vipdrv_device_info_t *device_info = VIP_NULL;

    for (core = 0; core < vpmdCORE_COUNT; core++) {
        device_core_number[core] = LOGIC_DEVICES_WITH_CORE[core];
    }

    for (i = 0; i < vpmdCORE_COUNT; i++) {
        if (0 == device_core_number[i]) {
            break;
        }
        logi_dev_cnt++;
        for (j = 0; j < device_core_number[i]; j++) {
            kdriver.irq_map[core_cnt++] = irq_index;
            #if !vpmdTASK_PARALLEL_ASYNC
            irq_index++;
            #endif
        }
        #if vpmdTASK_PARALLEL_ASYNC
        irq_index += device_core_number[i];
        #endif
    }
    if (0 == logi_dev_cnt) {
        PRINTK_E("logical device cnt is 0\n");
        return VIP_ERROR_FAILURE;
    }
    PRINTK_D("logical device cnt is %d\n", logi_dev_cnt);

    kdriver.hw_info.device_count = logi_dev_cnt;
    vipdrv_os_allocate_memory(sizeof(vipdrv_device_info_t) * logi_dev_cnt, (void **)&device_info);
    if (VIP_NULL == device_info) {
        PRINTK_E("alloc device info memory\n");
        return VIP_ERROR_FAILURE;
    }
    kdriver.hw_info.device_info = device_info;

    for (logi_idx = 0; logi_idx < logi_dev_cnt; logi_idx++) {
        vipdrv_device_info_t *info = &device_info[logi_idx];
        info->core_count = device_core_number[logi_idx];
        info->core_fscale_percent = kdriver.core_fscale_percent;
        info->axi_sram_base = AXI_SRAM_BASE_ADDRESS;
        info->vip_sram_base = VIP_SRAM_BASE_ADDRESS;

        for (core = 0; core < info->core_count; core++) {
            kdriver.irq_values[core] = 0;
            info->vip_reg[core] = (void *)kdriver.vip_reg[core + core_start_index];
            info->irq_queue[core] = (void*)&kdriver.irq_sem_handle[core + core_start_index];
            info->irq_value[core] = (vip_uint32_t*)&kdriver.irq_values[core + core_start_index];
            info->axi_sram_size[core] = AXI_SRAM_SIZE[core + core_start_index];
            info->irq_count[core] = &kdriver.irq_count[core + core_start_index];
            info->core_id[core] = core_start_index + core;
        }
        core_start_index += info->core_count;
    }

    return status;
}

static vip_int32_t drv_unprepare_logical_device_info(void)
{
    if (kdriver.hw_info.device_info != VIP_NULL) {
        vipdrv_os_free_memory(kdriver.hw_info.device_info);
        kdriver.hw_info.device_info = VIP_NULL;
    }

    return 0;
}

/*
@brief do some initialize in this function.
@param, vip_memsizem, the size of video memory heap.
*/
vip_status_e vipdrv_drv_init(
    vip_uint32_t vip_memsize
    )
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t i = 0;

    /* memset kdriver */
    vipdrv_os_zero_memory(&kdriver, sizeof(vipdrv_driver_t));

    /* 1. init kdriver */
    kdriver.initialize = 0;
    kdriver.core_count = vpmdCORE_COUNT;/* NPU core count on one device, multiple-processor */
    kdriver.core_fscale_percent = 100; /* default full clock */
    for (i = 0 ; i < kdriver.core_count; i++) {
        kdriver.irq_line[i] = IRQ_LINE_NUMBER[i];
        kdriver.vip_reg[i] = (void*)AHB_REGISTER_BASE_ADDRESS[i];
    }

    /* 2. power on all NPU cores */
    for (i = 0 ; i < kdriver.core_count; i++) {
        status = vipdrv_vendor_power_on(i);
        if (status != VIP_SUCCESS) {
            PRINTK_E("vipcore, drv init power on core_id=%d\n", i);
            vipGoOnError(status);
        }
    }

     vipOnError(vipdrv_vendor_init());

    /* 3. init video memory heap */
#if vpmdENABLE_VIDEO_MEMORY_HEAP
    if(0 == kdriver.cpu_physical) {
        kdriver.cpu_physical = VIDEO_MEMORY_HEAP_BASE_ADDRESS;
        kdriver.heap_info.vip_physical = vipdrv_drv_get_vipphysical(0, kdriver.cpu_physical);
        kdriver.heap_info.vip_memsize  = VIDEO_MEMORY_HEAP_SIZE;
        kdriver.heap_info.name = "heap-reserved";
        kdriver.heap_info.ops.phy_cpu2vip = vipdrv_drv_get_vipphysical;
        kdriver.heap_info.ops.phy_vip2cpu = vipdrv_drv_get_cpuphysical;
        kdriver.heap_info.device_vis = ~(vip_uint64_t)0;
    }
    PRINTK("vipcore, video memory heap name:%s, vip_phy:0x%"PRIx64", cpu_phy:0x%"PRIx64", size:0x%08x\n",
            kdriver.heap_info.name, kdriver.heap_info.vip_physical,
            kdriver.cpu_physical, kdriver.heap_info.vip_memsize);

    /* not used, Keep compiler happy.
      You can alloc a contiguous memory from system as the video memory heap */
    vip_memsize = vip_memsize;
#endif

    /* 4. init irq */
    LOOP_CORE_START
    #if !vpmdENABLE_POLLING
    if(!kdriver.irq_enabled[core]) {
        /* please implement interrupt register function on your platform */
        vipOnError(vipdrv_vendor_register_irq(kdriver.irq_line[core], (void*)vipdrv_irq_handler, (void*)(core + 1)));
        kdriver.irq_enabled[core] = 1;
    }
    #endif

    if(!kdriver.initialize){
        kdriver.irq_sem_handle[core] = xSemaphoreCreateBinary();
        if(kdriver.irq_sem_handle[core] == NULL) {
            PRINTK("vipdrv vip_drv_init rtos sem handle fail\n");
            vipGoOnError(VIP_ERROR_FAILURE);
        }
        vipdrv_os_create_atomic(&kdriver.irq_count[core]);
    }
    LOOP_CORE_END

    /* 5. get logical device config */
    vipOnError(drv_prepare_logical_device_info());

    kdriver.initialize = 1;

    return status;
onError:
    PRINTK_E("drv init\n");
    return status;
}

/*
@brief do some un-initialize in this function.
*/
vip_status_e vipdrv_drv_exit(void)
{
    vip_status_e status = VIP_SUCCESS;

    drv_unprepare_logical_device_info();

    LOOP_CORE_START
    if(kdriver.irq_enabled[core]) {
        vipdrv_vendor_unregister_irq(kdriver.irq_line[core]);
    }

    if (VIP_NULL != kdriver.irq_sem_handle[core]){
        vSemaphoreDelete(kdriver.irq_sem_handle[core]);
    }
    if (VIP_NULL != kdriver.irq_count[core]) {
        vipdrv_os_destroy_atomic(kdriver.irq_count[core]);
    }

    status = vipdrv_vendor_power_off(core);
    if (status != VIP_SUCCESS) {
        PRINTK("vipcore, drv exitpower off\n");
    }
    LOOP_CORE_END
    kdriver.initialize = 0;

    vipdrv_vendor_unint();

    vipdrv_os_zero_memory(&kdriver, sizeof(vipdrv_driver_t));

    return status;
}
