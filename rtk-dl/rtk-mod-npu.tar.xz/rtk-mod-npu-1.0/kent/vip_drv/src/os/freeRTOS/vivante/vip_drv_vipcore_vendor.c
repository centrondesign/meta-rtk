/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************
*
*    The GPL License (GPL)
*
*    Copyright (C) 2017 - 2025 Vivante Corporation
*
*    This program is free software; you can redistribute it and/or
*    modify it under the terms of the GNU General Public License
*    as published by the Free Software Foundation; either version 2
*    of the License, or (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software Foundation,
*    Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
*
*****************************************************************************
*
*    Note: This software is released under dual MIT and GPL licenses. A
*    recipient may use this file under the terms of either the MIT license or
*    GPL License. If you wish to use only one license not the other, you can
*    indicate your decision by deleting one of the above license notices in your
*    version of this file.
*
*****************************************************************************/

#include "FreeRTOS.h"
#include "vip_lite_config.h"
#include "vip_drv_vipcore_vendor.h"

/* Xilinx platform includes. */
#include "xil_cache.h"

vip_status_e vipdrv_vendor_init(
    void)
{
    vip_status_e status = VIP_SUCCESS;
    /* you can do something on your platfrom */

    Xil_DCacheDisable();

    return status;
}

vip_status_e vipdrv_vendor_unint(
    void)
{
    vip_status_e status = VIP_SUCCESS;
    /* do nothing, you can do something on your platfrom */

    Xil_DCacheEnable();

    return status;
}

/*
@brief NPU HW reset and power on
@param core_id, the index of core of this NPU device.
*/
vip_status_e vipdrv_vendor_power_on(
    vip_uint32_t core_id
    )
{
    vip_status_e status = VIP_SUCCESS;

    /* HW reset NPU */

    /* Supply power and clock for NPU  */

    return status;
}

/*
@brief power off NPU
@param core_id, the index of core of this NPU device.
*/
vip_status_e vipdrv_vendor_power_off(
    vip_uint32_t core_id
    )
{
    vip_status_e status = VIP_SUCCESS;

    /* powe down NPU  */

    return status;
}

/*
@brief register NPU irq to freeRTOS
*/
vip_status_e vipdrv_vendor_register_irq(
    vip_uint32_t irq_line,
    void* handler,
    void* handler_params
    )
{
    vip_status_e status = VIP_SUCCESS;
    vip_int32_t ret;

    if (handler == VIP_NULL) {
        PRINTK_E("invalid params for register irq\n");
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    ret = xPortInstallInterruptHandler(irq_line, (XInterruptHandler)handler, (void*)handler_params);
    if (ret == pdPASS) {
        vPortEnableInterrupt(irq_line);
    }
    else {
        PRINTK_E("Fail register intr\n");
        status = VIP_ERROR_FAILURE;
    }

    return status;
}

vip_status_e vipdrv_vendor_unregister_irq(
    vip_uint32_t irq_line
    )
{
    vip_status_e status = VIP_SUCCESS;

    vPortDisableInterrupt(irq_line);

    return status;
}

/*
@brief fluch CPU cache for video memory
*/
#if vpmdENABLE_FLUSH_CPU_CACHE
vip_status_e vipdrv_vendor_flush_cache(
    IN vip_physical_t physical,
    IN void *logical,
    IN vip_uint32_t size,
    IN vip_uint8_t type
    )
{
    vip_status_e status = VIP_SUCCESS;

    if (logical == VIP_NULL) {
        PRINTK_E("invalid params flush cache\n");
        return VIP_ERROR_INVALID_ARGUMENTS;
    }

    switch (type) {
        case VIPDRV_CACHE_CLEAN:
        case VIPDRV_CACHE_FLUSH:
            Xil_DCacheFlushRange((INTPTR)logical, (u32)size);
            break;
        case VIPDRV_CACHE_INVALID:
            Xil_DCacheInvalidateRange((INTPTR)logical, (u32)size);
            break;
        default:
            PRINTK_E("not support this flush cache type=%d\n", type);
            status = VIP_ERROR_INVALID_ARGUMENTS;
            break;
    }

    logical = logical;

    return status;

}
#endif
