/****************************************************************************
*
*    The MIT License (MIT)
*
*    Copyright (c) 2017 - 2025 Vivante Corporation
*
*    Permission is hereby granted, free of charge, to any person obtaining a
*    copy of this software and associated documentation files (the "Software"),
*    to deal in the Software without restriction, including without limitation
*    the rights to use, copy, modify, merge, publish, distribute, sublicense,
*    and/or sell copies of the Software, and to permit persons to whom the
*    Software is furnished to do so, subject to the following conditions:
*
*    The above copyright notice and this permission notice shall be included in
*    all copies or substantial portions of the Software.
*
*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*    DEALINGS IN THE SOFTWARE.
*
*****************************************************************************
*
*    The GPL License (GPL)
*
*    Copyright (C) 2017 - 2025 Vivante Corporation
*
*    This program is free software; you can redistribute it and/or
*    modify it under the terms of the GNU General Public License
*    as published by the Free Software Foundation; either version 2
*    of the License, or (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program; if not, write to the Free Software Foundation,
*    Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
*
*****************************************************************************
*
*    Note: This software is released under dual MIT and GPL licenses. A
*    recipient may use this file under the terms of either the MIT license or
*    GPL License. If you wish to use only one license not the other, you can
*    indicate your decision by deleting one of the above license notices in your
*    version of this file.
*
*****************************************************************************/
#undef VIPDRV_LOG_ZONE
#define VIPDRV_LOG_ZONE  VIPDRV_LOG_ZONE_VIDEO_MEMORY

#include <vip_drv_mem_allocator.h>
#include <vip_drv_context.h>
#include <vip_drv_mem_heap.h>
#include <vip_drv_mem_allocator_array.h>
#include <vip_drv_vipcore_driver.h>
#if vpmdENABLE_MMU
#include <vip_drv_mmu.h>
#endif

vip_status_e vipdrv_memory_overlap_check(
    vip_address_t physical_a,
    vip_uint64_t size_a,
    vip_address_t physical_b,
    vip_uint64_t size_b
    )
{
    vip_status_e status = VIP_SUCCESS;

    if (physical_a > physical_b) {
        if ((physical_b + size_b) >= physical_a) {
            status = VIP_ERROR_FAILURE;
        }
    }
    else if (physical_a < physical_b){
        if ((physical_a + size_a) >= physical_b) {
            status = VIP_ERROR_FAILURE;
        }
    }
    else {
        status = VIP_ERROR_FAILURE;
    }

    return status;
}

/*
 Check the ''name' matched with allocator desc name to find a allocator.
*/
#if vpmdENABLE_VIDEO_MEMORY_HEAP
static vipdrv_allocator_desc_t* vipdrv_get_alloc_desc(
    vip_char_t* name
    )
{
    vip_uint32_t index = 0;
    vipdrv_allocator_desc_t* allocator_desc = VIP_NULL;
    vip_uint32_t allocator_cnt = sizeof(video_mem_allocator_array) / sizeof(video_mem_allocator_array[0]);
    if (0 == allocator_cnt) {
        PRINTK_E("get allocator array, no video memory allocator\n");
        return allocator_desc;
    }
    for (index = 0; index < allocator_cnt; index++) {
        vipdrv_allocator_desc_t* temp = &video_mem_allocator_array[index];
        if (0 == vipdrv_os_strcmp(name, temp->name)) {
            if (temp->init != VIP_NULL) {
                allocator_desc = temp;
                PRINTK_D("get video memory allocator desc name=%s\n", name);
                break;
            }
            else {
                PRINTK_E("get allocator desc name=%s, init func is NULL\n", name);
                break;
            }
        }
    }
    /*if (VIP_NULL == allocator_desc) {
        PRINTK_E("find allocator desc %s, allocator_cnt=%d\n", name, allocator_cnt);
    }*/
    return allocator_desc;
}
#endif

#define CHECK_CALLBACK_FUNC(func)                                            \
if (VIP_NULL == allocator->callback.func) {                                  \
    PRINTK_E("allocator %s: %s callback is null\n", allocator->name, #func); \
    vipGoOnError(VIP_ERROR_FAILURE);                                         \
}

static vip_bool_e cmp_allocator(
    vipdrv_allocator_t *p,
    vipdrv_allocator_t *q
    )
{
    /* put the scarce allocator at the end of list */
    /* 1. allocator type: heap -> dync -> other. */
    if (p->alctor_type < q->alctor_type) {
        return vip_true_e;
    }
    else if (p->alctor_type > q->alctor_type) {
        return vip_false_e;
    }

    /* 2. device visibility: device 0 -> device 0 & 1 */
    if (p->device_vis != q->device_vis) {
        if ((p->device_vis & q->device_vis) == p->device_vis) {
            return vip_true_e;
        }
        else if ((p->device_vis & q->device_vis) == q->device_vis) {
            return vip_false_e;
        }
    }

    /* 3. physical address: over 4G -> 4G */
    if ((p->mem_flag & VIPDRV_MEM_FLAG_4GB_ADDR_PA) < (q->mem_flag & VIPDRV_MEM_FLAG_4GB_ADDR_PA)) {
        return vip_true_e;
    }
    else if ((p->mem_flag & VIPDRV_MEM_FLAG_4GB_ADDR_PA) > (q->mem_flag & VIPDRV_MEM_FLAG_4GB_ADDR_PA)) {
        return vip_false_e;
    }

    /* 4. address continue: 4K continue -> 64K continue -> 1M continue -> 16M continue -> continue */
    if ((p->mem_flag & VIPDRV_MEM_FLAG_CONTIGUOUS) < (q->mem_flag & VIPDRV_MEM_FLAG_CONTIGUOUS)) {
        return vip_true_e;
    }
    else if ((p->mem_flag & VIPDRV_MEM_FLAG_CONTIGUOUS) > (q->mem_flag & VIPDRV_MEM_FLAG_CONTIGUOUS)) {
        return vip_false_e;
    }

    return vip_true_e;
}

static vip_status_e vipdrv_allocator_list_add(
    vipdrv_allocator_t *allocator
    )
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    vipdrv_alloc_mgt_t* cur = (vipdrv_alloc_mgt_t*)context->alloc_list_head;
    vipdrv_alloc_mgt_t* last = VIP_NULL;

    CHECK_CALLBACK_FUNC(allocate);
    CHECK_CALLBACK_FUNC(free);
    CHECK_CALLBACK_FUNC(map_user_logical);
    CHECK_CALLBACK_FUNC(unmap_user_logical);
    CHECK_CALLBACK_FUNC(map_kernel_logical);
    CHECK_CALLBACK_FUNC(unmap_kernel_logical);
#if vpmdENABLE_FLUSH_CPU_CACHE
    CHECK_CALLBACK_FUNC(flush_cache);
#endif
    CHECK_CALLBACK_FUNC(phy_vip2cpu);
    CHECK_CALLBACK_FUNC(phy_cpu2vip);

    while (VIP_NULL != cur) {
        if (vip_true_e == cmp_allocator(allocator, (vipdrv_allocator_t*)cur)) {
            break;
        }

        last = cur;
        cur = (vipdrv_alloc_mgt_t*)cur->next;
    }
    if (VIP_NULL != last) {
        last->next = allocator;
    }
    else {
        context->alloc_list_head = allocator;
    }
    ((vipdrv_alloc_mgt_t*)allocator)->next = (vipdrv_allocator_t*)cur;
    return status;
onError:
    PRINTK_E("add allocator\n");
    return status;
}

static vip_status_e vipdrv_alloc_mgt_dyn_alloc(
    vipdrv_video_mem_phy_handle_t* handle,
    vipdrv_alloc_param_ptr param
    )
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_alloc_mgt_dyn_t* alloc_mgt_dyn = VIP_NULL;

    if (handle == VIP_NULL) {
        PRINTK_E("allocate for dyn memory\n");
        return VIP_ERROR_INVALID_ARGUMENTS;
    }
    alloc_mgt_dyn = (vipdrv_alloc_mgt_dyn_t*)handle->allocator;
    handle->allocator_type = alloc_mgt_dyn->allocator_mgt.allocator.alctor_type;

    status = alloc_mgt_dyn->allocator_mgt.base_callback.allocate(handle, param);

    return status;
}

static vip_status_e vipdrv_alloc_mgt_dyn_init(
    vipdrv_alloc_mgt_dyn_t* alloc_mgt_dyn
    )
{
    vip_status_e status = VIP_SUCCESS;

    vipdrv_os_copy_memory(&alloc_mgt_dyn->allocator_mgt.base_callback,
        &alloc_mgt_dyn->allocator_mgt.allocator.callback, sizeof(vipdrv_allocator_callback_t));

    alloc_mgt_dyn->allocator_mgt.allocator.callback.allocate = vipdrv_alloc_mgt_dyn_alloc;

    return status;
}

/*
1. alloc and create a dynamic allocator management.
2. init and construct mangement.
3. add allocator into allocator_list.
*/
static vip_status_e vipdrv_allocator_mgt_register_dyn(
    vipdrv_allocator_desc_t* allocator_desc
    )
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_allocator_t* allocator = VIP_NULL;
    vipdrv_alloc_mgt_dyn_t* alloc_mgt_dyn = VIP_NULL;

    if (VIP_NULL == allocator_desc) {
        PRINTK_E("allocator desc is NULL\n");
        return VIP_ERROR_FAILURE;
    }

    vipOnError(vipdrv_os_allocate_memory(sizeof(vipdrv_alloc_mgt_dyn_t), (void**)&alloc_mgt_dyn));
    vipdrv_os_zero_memory(alloc_mgt_dyn, sizeof(vipdrv_alloc_mgt_dyn_t));
    allocator = &alloc_mgt_dyn->allocator_mgt.allocator;

    /* construct an allocator */
    if (allocator_desc->init != VIP_NULL) {
        vipOnError(allocator_desc->init(allocator, allocator_desc->name, allocator_desc->allocator_type));
    }
    /* construct dynamic allocator management */
    vipOnError(vipdrv_alloc_mgt_dyn_init(alloc_mgt_dyn));
    vipOnError(vipdrv_allocator_list_add(allocator));
    PRINTK_D("register dyn allocator, name=%s, type=0x%x, mem_flag=0x%x, visible=0x%"PRIx64"\n",
             allocator->name, allocator->alctor_type, allocator->mem_flag, allocator->device_vis);

    if (0 == (VIPDRV_ALLOCATOR_TYPE_WRAP & allocator_desc->allocator_type)) {
        VIPDRV_LOOP_DEVICE_START
        if (allocator->device_vis & ((vip_uint64_t)1 << dev->device_index)) {
            dev->share_mem_device_vis |= allocator->device_vis;
        }
        VIPDRV_LOOP_DEVICE_END
    }

    return status;

onError:
    if (VIP_NULL != alloc_mgt_dyn) {
        vipdrv_os_free_memory(alloc_mgt_dyn);
        alloc_mgt_dyn = VIP_NULL;
    }
    PRINTK_E("register dyn allocator name=%s\n", allocator_desc->name);
    return status;
}

#if vpmdENABLE_VIDEO_MEMORY_HEAP
static vip_status_e vipdrv_allocator_mgt_register_heap(
    vipdrv_videomem_heap_info_t *heap_info,
    vip_bool_e mmu_page_heap
    )
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_allocator_t *allocator = VIP_NULL;
    vipdrv_alloc_mgt_heap_t *heap = VIP_NULL;
    vipdrv_allocator_desc_t *alloc_desc = vipdrv_get_alloc_desc(heap_info->name);
    if (0 == heap_info->vip_memsize) {
        return VIP_SUCCESS;
    }
    if (VIP_NULL == alloc_desc) {
        vipGoOnError(VIP_ERROR_FAILURE);
    }

    if (VIPDRV_ALLOCATOR_TYPE_VIDO_HEAP != alloc_desc->allocator_type) {
        PRINTK_E("type=%d, ask fill the VIDO_HEAP in _x_array.h\n", alloc_desc->allocator_type);
        vipGoOnError(VIP_ERROR_INVALID_ARGUMENTS);
    }

    vipOnError(vipdrv_os_allocate_memory(sizeof(vipdrv_alloc_mgt_heap_t), (void**)&heap));
    vipdrv_os_zero_memory(heap, sizeof(vipdrv_alloc_mgt_heap_t));
    allocator = &heap->allocator_mgt.allocator;

    /* construct an allocator */
    vipOnError(alloc_desc->init(allocator, alloc_desc->name, alloc_desc->allocator_type));
    /* construct heap allocator management */
    vipOnError(vipdrv_alloc_mgt_heap_init(heap, heap_info));
    if (vip_true_e == mmu_page_heap) {
        heap->allocator_mgt.allocator.mem_flag |= VIPDRV_MEM_FLAG_MMU_PAGE_MEM;
        heap->allocator_mgt.allocator.name = "heap-mmu-page";
        heap->allocator_mgt.allocator.mmu_map = 0;
    }
    vipOnError(vipdrv_allocator_list_add(allocator));
    PRINTK_D("register heap name=%s allocator size=0x%"PRIx64" phy=0x%"PRIx64", type=0x%x, memflag=0x%x.\n",
           heap_info->name, heap_info->vip_memsize, heap_info->vip_physical,
           allocator->alctor_type, allocator->mem_flag);
    return status;
onError:
    if (VIP_NULL != heap) {
        vipdrv_os_free_memory(heap);
        heap = VIP_NULL;
    }
    PRINTK_E("register heap, name=%s", heap_info->name);
    return status;
}
#endif

static vip_status_e vipdrv_allocator_mgt_unregister(
    vipdrv_alloc_mgt_t* alloc_mgt
    )
{
    if (alloc_mgt->allocator.callback.uninit) {
        alloc_mgt->allocator.callback.uninit(&alloc_mgt->allocator);
    }
    if (alloc_mgt->base_callback.uninit) {
        alloc_mgt->base_callback.uninit(&alloc_mgt->allocator);
    }
    vipdrv_os_free_memory(alloc_mgt);

    return VIP_SUCCESS;
}

#if vpmdENABLE_VIDEO_MEMORY_HEAP
static vip_bool_e cmp_heap(void* x, void* y) {
    vip_uint64_t x_vis = ((vipdrv_videomem_heap_info_t*)x)->device_vis;
    vip_uint64_t y_vis = ((vipdrv_videomem_heap_info_t*)y)->device_vis;
    while (x_vis && y_vis) {
        x_vis &= (x_vis - 1);
        y_vis &= (y_vis - 1);
    }

    if (x_vis) {
        return vip_true_e;
    }
    return vip_false_e;
}

static vip_status_e allocator_heap_init(void)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t i = 0;
    vipdrv_vendor_memory_config_t mem_config = { 0 };
    vipdrv_videomem_heap_info_t *heap_infos = VIP_NULL;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    vip_uint64_t device_vis = (~(vip_uint64_t)0) >> (64 - context->device_count);
    vip_uint32_t temp_size = 0;
#if vpmdENABLE_MMU
    vip_uint32_t mmu_table_size = vipdrv_mmu_get_page_table_size();
#endif

    context->mem_prop_cnt = 0;
    vipOnError(vipdrv_drv_get_memory_config(&mem_config));
    if (0 == mem_config.heap_count) {
        PRINTK_E("vido mem heap count is 0\n");
    }

    temp_size = sizeof(vipdrv_mem_property_t) * context->device_count;
    vipOnError(vipdrv_os_allocate_memory(temp_size, (void**)&context->mem_props));
    vipdrv_os_zero_memory(context->mem_props, temp_size);
    temp_size = sizeof(vipdrv_videomem_heap_info_t) * mem_config.heap_count;
    vipOnError(vipdrv_os_allocate_memory(temp_size, (void**)&heap_infos));
    vipdrv_os_copy_memory(heap_infos, mem_config.heap_infos, temp_size);
    vipdrv_heap_sort((void*)heap_infos, sizeof(vipdrv_videomem_heap_info_t), mem_config.heap_count, cmp_heap);

    for (i = 0; i < mem_config.heap_count; i++) {
        vipdrv_videomem_heap_info_t *heap_info = &heap_infos[i];
        if ((VIP_NULL == heap_info->name) || (0 == heap_info->vip_memsize)) {
            PRINTK_W("heap % size=0x%"PRIx64", may name is null\n", heap_info->vip_memsize, heap_info->name);
            continue;
        }
        PRINTK_D("video memory heap %d, vip phy=0x%"PRIx64", size=0x%"PRIx64", name=%s, visible=0x%"PRIx64"\n",
            i, heap_info->vip_physical, heap_info->vip_memsize, heap_info->name, heap_info->device_vis);
        /* memory space overlap check */
        status = vipdrv_memory_overlap_check(context->vip_sram_address, context->vip_sram_size[0],
                            heap_info->vip_physical, heap_info->vip_memsize);
        if (status != VIP_SUCCESS) {
            PRINTK_E("check heap[0x%"PRIx64"~0x%"PRIx64"] overlap with vip-sram[0x%"PRIx64"~0x%"PRIx64"]\n",
                    heap_info->vip_physical, heap_info->vip_memsize + heap_info->vip_physical,
                    context->vip_sram_address, context->vip_sram_address + context->vip_sram_size[0]);
            vipGoOnError(status);
        }
        else {
            vipdrv_videomem_heap_info_t origin_info = { 0 };
            vipdrv_os_copy_memory(&origin_info, heap_info, sizeof(vipdrv_videomem_heap_info_t));

            if ((device_vis & origin_info.device_vis)
                #if vpmdENABLE_MMU
                && (origin_info.vip_memsize >= mmu_table_size)
                #endif
                )
           {
                vip_uint64_t all_device_vis = device_vis & origin_info.device_vis;
                device_vis &= ~all_device_vis;
                context->mem_props[context->mem_prop_cnt].device_vis = all_device_vis;
                context->mem_props[context->mem_prop_cnt].index = context->mem_prop_cnt;

                #if vpmdENABLE_MMU
                {
                vipdrv_videomem_heap_info_t split_info = { 0 };
                vipOnError(vipdrv_mmu_split_heap(&origin_info, mmu_table_size, &split_info));
                split_info.device_vis = all_device_vis;
                PRINTK_D("split mmu page, vip physical=0x%"PRIx64", size=0x%"PRIx64", name=%s, visible=0x%"PRIx64"\n",
                          split_info.vip_physical, split_info.vip_memsize, split_info.name, all_device_vis);
                vipOnError(vipdrv_allocator_mgt_register_heap(&split_info, vip_true_e));
                VIPDRV_LOOP_DEVICE_START
                if (all_device_vis & ((vip_uint64_t)1 << dev->device_index)) {
                    dev->mem_prop = &context->mem_props[context->mem_prop_cnt];
                }
                VIPDRV_LOOP_DEVICE_END
                }
                #endif

                context->mem_prop_cnt += 1;
                if (context->mem_prop_cnt > context->device_count) {
                    PRINTK_E("mem_prop is %d large than device count=%d\n",
                                context->mem_prop_cnt, context->device_count);
                    vipGoOnError(VIP_ERROR_FAILURE);
                }
            }
            vipOnError(vipdrv_allocator_mgt_register_heap(&origin_info, vip_false_e));
        }

        VIPDRV_LOOP_DEVICE_START
        if (heap_info->device_vis & ((vip_uint64_t)1 << dev->device_index)) {
            dev->share_mem_device_vis |= heap_info->device_vis;
        }
        VIPDRV_LOOP_DEVICE_END
    }

#if vpmdENABLE_MMU
    if (device_vis) {
        PRINTK_E("no heap for mmu page, heap_cnt=%d, device_vis=0x%x mmu_table_size=%u\n",
            mem_config.heap_count, device_vis, mmu_table_size);
        PRINTK_E("Pls reduce the max video memory size supported by driver via vipdMMU_TOTAL_VIDEO_MEMORY=%uMB\n",
                vipdMMU_TOTAL_VIDEO_MEMORY / 1000 / 1000);
        vipGoOnError(VIP_ERROR_NOT_SUPPORTED);
    }
    if (0 == context->mem_prop_cnt) {
        PRINTK_E("mem porp cnt is 0\n");
        vipGoOnError(VIP_ERROR_INVALID_ARGUMENTS);
    }
#else
    if (device_vis) {
        context->mem_props[context->mem_prop_cnt].device_vis = device_vis;
        context->mem_props[context->mem_prop_cnt].index = context->mem_prop_cnt;
        context->mem_prop_cnt += 1;
        if (context->mem_prop_cnt > context->device_count) {
            PRINTK_E("mem_prop cnt %d large than device count=%d\n", context->mem_prop_cnt, context->device_count);
            vipGoOnError(VIP_ERROR_FAILURE);
        }
    }
#endif
    if (VIP_NULL != heap_infos) {
        vipdrv_os_free_memory(heap_infos);
    }
    return status;
onError:
    for (i = 0; i < mem_config.heap_count; i++) {
        PRINTK_E("heap_%d name=%s vip physical=0x%"PRIx64" size=0x%"PRIx64" visible=0x%"PRIx64"\n",
            i, mem_config.heap_infos[i].name, mem_config.heap_infos[i].vip_physical,
            mem_config.heap_infos[i].vip_memsize, mem_config.heap_infos[i].device_vis);
    }
    if (VIP_NULL != heap_infos) {
        vipdrv_os_free_memory(heap_infos);
    }
    return status;
}
#endif

vip_status_e vipdrv_allocator_init(void)
{
    vip_status_e status = VIP_SUCCESS;
    vip_uint32_t i = 0;
#if vpmdENABLE_VIDEO_MEMORY_HEAP
    vipOnError(allocator_heap_init());
#endif

    /* register dynamic allocator */
    for (i = 0; i < sizeof(video_mem_allocator_array) / sizeof(video_mem_allocator_array[0]); i++) {
        vipdrv_allocator_desc_t* allocator_desc = &video_mem_allocator_array[i];
        if (allocator_desc->allocator_type > VIPDRV_ALLOCATOR_TYPE_VIDO_HEAP) {
            if (allocator_desc->init != VIP_NULL) {
                vipOnError(vipdrv_allocator_mgt_register_dyn(allocator_desc));
            }
            else {
                PRINTK_E("register allocator desc name=%s, init func is NULL\n",
                          allocator_desc->name);
            }
        }
    }

#if vpmdENABLE_DEBUG_LOG > 3
    vipdrv_allocator_dump();
#endif

onError:
    return status;
}

vip_status_e vipdrv_allocator_uninit(void)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    vipdrv_alloc_mgt_t* cur = (vipdrv_alloc_mgt_t*)context->alloc_list_head;
    vipdrv_alloc_mgt_t* next = VIP_NULL;

    while (VIP_NULL != cur) {
        next = (vipdrv_alloc_mgt_t*)cur->next;
        vipdrv_allocator_mgt_unregister(cur);
        cur = next;
    }
    context->alloc_list_head = VIP_NULL;

    if (VIP_NULL != context->mem_props) {
        vipdrv_os_free_memory(context->mem_props);
        context->mem_props = VIP_NULL;
    }

    return status;
}

vip_status_e vipdrv_allocator_get(
    vipdrv_allocator_type_e alctor_type,
    vipdrv_mem_flag_e mem_flag,
    vip_uint64_t device_vis,
    vipdrv_allocator_t** allocator
    )
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    vipdrv_alloc_mgt_t* alloc_node = VIP_NULL;

    /* find last allocator */
    if (VIP_NULL != *allocator) {
        alloc_node = (vipdrv_alloc_mgt_t*)((vipdrv_alloc_mgt_t*)(*allocator))->next;
    }
    else {
        alloc_node = (vipdrv_alloc_mgt_t*)context->alloc_list_head;
    }

    /* find allocator from last allocator */
    while (alloc_node) {
        vipdrv_mem_flag_e flag_tmp = mem_flag;
        if (0 == alloc_node->allocator.mmu_map) {
            flag_tmp &= ~VIPDRV_MEM_FLAG_MMU_PAGE_WRITEABLE;
            flag_tmp &= ~VIPDRV_MEM_FLAG_4GB_ADDR_VA;
        }
        if ((alctor_type & alloc_node->allocator.alctor_type) &&
            (device_vis & alloc_node->allocator.device_vis) == device_vis &&
            (alloc_node->allocator.mem_flag & flag_tmp) == flag_tmp &&
            (alloc_node->allocator.mem_flag & VIPDRV_MEM_FLAG_MMU_PAGE_MEM) ==
            (flag_tmp & VIPDRV_MEM_FLAG_MMU_PAGE_MEM)) {
            *allocator = &alloc_node->allocator;
            break;
        }
        alloc_node = (vipdrv_alloc_mgt_t*)alloc_node->next;
    }

    if (VIP_NULL == alloc_node) {
        status = VIP_ERROR_FAILURE;
    }
#if DEBUG_ALLOCATOR
    else {
        PRINTK_D("get video mem allocator name=%s\n", (*allocator)->name);
    }
#endif
    return status;
}

vip_uint32_t vipdrv_allocator_dyn_alloc_count(void)
{
    vip_uint32_t count = 0;
    vip_uint32_t index;
    vip_uint32_t allocator_cnt = sizeof(video_mem_allocator_array) / sizeof(video_mem_allocator_array[0]);

    for (index = 0; index < allocator_cnt; index++) {
        vipdrv_allocator_desc_t* allocator_desc = &video_mem_allocator_array[index];
        if (VIPDRV_ALLOCATOR_TYPE_DYN_ALLOC == allocator_desc->allocator_type) {
            count++;
        }
    }
    return count;
}

/* dump allocator arrary and allocator list */
vip_status_e vipdrv_allocator_dump(void)
{
    vip_status_e status = VIP_SUCCESS;
    vipdrv_context_t* context = (vipdrv_context_t*)vipdrv_get_context(VIPDRV_CONTEXT_PROP_ALL);
    vipdrv_alloc_mgt_t* alloc_node = VIP_NULL;
    vipdrv_allocator_t* allocator = VIP_NULL;
    vip_uint32_t index = 0;
    vip_uint32_t allocator_cnt = sizeof(video_mem_allocator_array) / sizeof(video_mem_allocator_array[0]);

    PRINTK_F("allocator desc arrary:\n");
    for (index = 0; index < allocator_cnt; index++) {
        vipdrv_allocator_desc_t* temp = &video_mem_allocator_array[index];
        PRINTK_F("index: %d, name: %s, allocator_type=0x%x\n", index, temp->name, temp->allocator_type);
    }

    PRINTK_F("allocator list:\n");
    index = 0;
    alloc_node = (vipdrv_alloc_mgt_t*)context->alloc_list_head;
    while (alloc_node) {
        allocator = &alloc_node->allocator;
        #if vpmdENABLE_VIDEO_MEMORY_HEAP
        if (allocator->alctor_type & VIPDRV_ALLOCATOR_TYPE_VIDO_HEAP) {
            vipdrv_alloc_mgt_heap_t* heap = (vipdrv_alloc_mgt_heap_t*)allocator;
            PRINTK_F("index: %d, name: %s, mem_flag=0x%x, alctor_type=0x%x, device_vis=0x%"PRIx64", "
                     "total size=0x%"PRIx64", free size=0x%"PRIx64", physical=0x%"PRIx64", virtual=0x%"PRIx64"\n",
                    index, allocator->name, allocator->mem_flag, allocator->alctor_type,
                    allocator->device_vis, heap->total_size, heap->free_bytes, heap->physical, heap->virtual);
            vipdrv_heap_dump(heap);
        }
        else
        #endif
        {
            PRINTK_F("index: %d, name: %s, mem_flag=0x%x, alctor_type=0x%x, device_vis=0x%"PRIx64", mmu_map=%d\n",
                    index, allocator->name, allocator->mem_flag, allocator->alctor_type,
                    allocator->device_vis, allocator->mmu_map);
        }
        alloc_node = (vipdrv_alloc_mgt_t*)alloc_node->next;
        index++;
    }

    PRINTK_F("allocator device visible:\n");
    VIPDRV_LOOP_DEVICE_START
    PRINTK_F("  dev%d share mem visible=0x%"PRIx64"\n", dev->share_mem_device_vis);
    VIPDRV_LOOP_DEVICE_END

    return status;
}

