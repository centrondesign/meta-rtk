#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include "gstrtkgpufunction.h"
#include "gstrtkgpuconverter.h"
#include <gst/allocators/gstdmabuf.h>
#include <gstrtkdmaallocator.h>
#include <gstrtksubtitlepool.h>
#include <string.h>
#include <stdio.h>
#include <drm_fourcc.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <linux/dma-heap.h>

#define DEFAULT_PROP_VIDEO_ROTATE 0
#define DEFAULT_PROP_OUT_WIDTH 1920
#define DEFAULT_PROP_OUT_HEIGHT 1080

#define ALIGN64(x) ((x + (63)) & ~(63))
#define ALIGN8(x) ((x + (7)) & ~(7))

enum
{
  PROP_0,
  PROP_VIDEO_ROTATE,
  PROP_OUT_WIDTH,
  PROP_OUT_HEIGHT,
  PROP_OUT_FORMAT,
  PROP_LAST
};

GST_DEBUG_CATEGORY_STATIC (gst_rtkgpu_converter_debug);
GST_DEBUG_CATEGORY_STATIC (gst_rtkgpu_converter_lib_debug);

#define GST_CAT_DEFAULT gst_rtkgpu_converter_debug

#define VIDEO_IN_FORMATS \
    "{ BGRx, BGRA, RGBx, xBGR, xRGB, RGBA, ABGR, ARGB, " \
    "RGB, BGR, NV12, NV21, NV16, NV61, NV24 }"

#define VIDEO_OUT_FORMATS \
    "{ BGRx, BGRA, RGBx, xBGR, xRGB, RGBA, ABGR, ARGB, " \
    "RGB, BGR, NV12, NV21, NV16 }"

#define RTKGPUCONVERTER_VIDEO_IN_CAPS GST_VIDEO_CAPS_MAKE(VIDEO_IN_FORMATS)
#define RTKGPUCONVERTER_VIDEO_OUT_CAPS GST_VIDEO_CAPS_MAKE(VIDEO_OUT_FORMATS)

#define RTKGPUCONVERTER_ALL_VIDEO_CAPS RTKGPUCONVERTER_VIDEO_CAPS ";" \
    GST_VIDEO_CAPS_MAKE_WITH_FEATURES ("ANY", GST_VIDEO_FORMATS_ALL)

static GstStaticCaps sw_video_template_caps = GST_STATIC_CAPS (RTKGPUCONVERTER_VIDEO_IN_CAPS);

static GstStaticPadTemplate src_factory = GST_STATIC_PAD_TEMPLATE ("src",
    GST_PAD_SRC,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS (RTKGPUCONVERTER_VIDEO_OUT_CAPS)
    );

static GstStaticPadTemplate video_sink_factory =
    GST_STATIC_PAD_TEMPLATE ("video_sink",
    GST_PAD_SINK,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS (RTKGPUCONVERTER_VIDEO_IN_CAPS)
    );

#define GST_RTKGPU_CONVERTER_GET_LOCK(gpuconverter) (&GST_RTKGPU_CONVERTER (gpuconverter)->lock)
#define GST_RTKGPU_CONVERTER_GET_COND(gpuconverter) (&GST_RTKGPU_CONVERTER (gpuconverter)->cond)
#define GST_RTKGPU_CONVERTER_LOCK(gpuconverter)     (g_mutex_lock (GST_RTKGPU_CONVERTER_GET_LOCK (gpuconverter)))
#define GST_RTKGPU_CONVERTER_UNLOCK(gpuconverter)   (g_mutex_unlock (GST_RTKGPU_CONVERTER_GET_LOCK (gpuconverter)))
#define GST_RTKGPU_CONVERTER_WAIT(gpuconverter)     (g_cond_wait (GST_RTKGPU_CONVERTER_GET_COND (gpuconverter), GST_RTKGPU_CONVERTER_GET_LOCK (gpuconverter)))
#define GST_RTKGPU_CONVERTER_SIGNAL(gpuconverter)   (g_cond_signal (GST_RTKGPU_CONVERTER_GET_COND (gpuconverter)))
#define GST_RTKGPU_CONVERTER_BROADCAST(gpuconverter)(g_cond_broadcast (GST_RTKGPU_CONVERTER_GET_COND (gpuconverter)))


static void gst_rtkgpu_converter_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec);
static void gst_rtkgpu_converter_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec);

static void gst_rtkgpu_converter_finalize (GObject * object);

static GstStateChangeReturn gst_rtkgpu_converter_change_state (GstElement * element,
    GstStateChange transition);

#define gst_rtkgpu_converter_parent_class parent_class
G_DEFINE_TYPE (GstRtkGpuConverter, gst_rtkgpu_converter, GST_TYPE_ELEMENT);
#define _do_init \
  GST_DEBUG_CATEGORY_INIT (gst_rtkgpu_converter_debug, "rtkgpuconverter", \
      0, "RTK Gpu Converter");\
  GST_DEBUG_CATEGORY_INIT (gst_rtkgpu_converter_lib_debug, "rtkgpuconverter_library",\
      0, "RTK Gpu Converter library");
GST_ELEMENT_REGISTER_DEFINE_WITH_CODE (rtkgpuconverter, "rtkgpuconverter",
    GST_RANK_PRIMARY, GST_TYPE_RTKGPU_CONVERTER, _do_init);

static gboolean gst_rtkgpu_converter_setcaps_video (GstPad * pad,
    GstRtkGpuConverter * gpuconverter, GstCaps * caps);

static GstFlowReturn gst_rtkgpu_converter_chain_video (GstPad * pad,
    GstObject * parent, GstBuffer * buf);

static gboolean gst_rtkgpu_converter_event_video (GstPad * pad, GstObject * parent,
    GstEvent * event);
static gboolean gst_rtkgpu_converter_event_src (GstPad * pad, GstObject * parent,
    GstEvent * event);

static gboolean gst_rtkgpu_converter_query_video (GstPad * pad, GstObject * parent,
    GstQuery * query);
static gboolean gst_rtkgpu_converter_query_src (GstPad * pad, GstObject * parent,
    GstQuery * query);

static void config_output_buffer_size(GstRtkGpuConverter *gpuconverter);

GType out_format_get_type(void) {
  static GType t = 0;
  if (t == 0) {
    static const GEnumValue values[] = {
      {DRM_FORMAT_NV12, "NV12", "NV12" },
      {DRM_FORMAT_NV21, "NV21", "NV21" },
      {DRM_FORMAT_NV16, "NV16", "NV16" },
      {DRM_FORMAT_RGB888, "RGB", "RGB" },
      {DRM_FORMAT_BGR888, "BGR", "BGR" },
      {DRM_FORMAT_ARGB8888, "ARGB", "ARGB" },
      {DRM_FORMAT_XRGB8888, "xRGB", "xRGB" },
      {DRM_FORMAT_BGRA8888, "BGRA", "BGRA" },
      {DRM_FORMAT_BGRX8888, "BGRx", "BGRx" },
      {DRM_FORMAT_XBGR8888, "xBGR", "xBGR" },
      {DRM_FORMAT_ABGR8888, "ABGR", "ABGR" },
      {DRM_FORMAT_RGBX8888, "RGBx", "RGBx" },
      {DRM_FORMAT_RGBA8888, "RGBA", "RGBA" },
      {0, NULL, NULL}
    };
    t = g_enum_register_static("out_format", values);
  }
  return t;
}

#define OUT_FORMAT (out_format_get_type())

static void
gst_rtkgpu_converter_class_init (GstRtkGpuConverterClass * klass)
{
  GObjectClass *gobject_class = (GObjectClass *) klass;
  GstElementClass *gstelement_class = (GstElementClass *) klass;

  gobject_class->set_property = gst_rtkgpu_converter_set_property;
  gobject_class->get_property = gst_rtkgpu_converter_get_property;

  g_object_class_install_property (G_OBJECT_CLASS (klass), PROP_VIDEO_ROTATE,
      g_param_spec_uint ("rotate", "rotate degree",
          "rotate degree",
          0, G_MAXINT, DEFAULT_PROP_VIDEO_ROTATE, G_PARAM_READWRITE | GST_PARAM_CONTROLLABLE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (G_OBJECT_CLASS (klass), PROP_OUT_WIDTH,
      g_param_spec_uint ("width", "output width",
          "output width",
          0, G_MAXINT, DEFAULT_PROP_OUT_WIDTH, G_PARAM_READWRITE | GST_PARAM_CONTROLLABLE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (G_OBJECT_CLASS (klass), PROP_OUT_HEIGHT,
      g_param_spec_uint ("height", "output height",
          "output height",
          0, G_MAXINT, DEFAULT_PROP_OUT_HEIGHT, G_PARAM_READWRITE | GST_PARAM_CONTROLLABLE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (G_OBJECT_CLASS (klass), PROP_OUT_FORMAT,
      g_param_spec_enum ("out-format", "Output drm format",
          "Output drm format",
          OUT_FORMAT, DRM_FORMAT_NV12, G_PARAM_READWRITE | GST_PARAM_CONTROLLABLE | G_PARAM_STATIC_STRINGS));

  gobject_class->finalize = gst_rtkgpu_converter_finalize;

  gstelement_class->change_state = GST_DEBUG_FUNCPTR (gst_rtkgpu_converter_change_state);

  gst_element_class_add_static_pad_template (gstelement_class, &src_factory);
  gst_element_class_add_static_pad_template (gstelement_class, &video_sink_factory);

  gst_element_class_set_static_metadata (gstelement_class, "RTK Gpu Converter",
      "Rtk Gpu Converter",
      "Scale and rotate video frame",
      "yaozenhu@realtek.com");
}

static void
gst_rtkgpu_converter_init (GstRtkGpuConverter *gpuconverter)
{
  gpuconverter->srcpad = gst_pad_new_from_static_template (&src_factory, "src");
  gpuconverter->video_sinkpad = gst_pad_new_from_static_template (&video_sink_factory, "video_sink");

  gst_pad_set_chain_function (gpuconverter->video_sinkpad,
      GST_DEBUG_FUNCPTR (gst_rtkgpu_converter_chain_video));

  gst_pad_set_event_function (gpuconverter->video_sinkpad,
      GST_DEBUG_FUNCPTR (gst_rtkgpu_converter_event_video));
  gst_pad_set_event_function (gpuconverter->srcpad,
      GST_DEBUG_FUNCPTR (gst_rtkgpu_converter_event_src));

  gst_pad_set_query_function (gpuconverter->srcpad,
      GST_DEBUG_FUNCPTR (gst_rtkgpu_converter_query_src));
  gst_pad_set_query_function (gpuconverter->video_sinkpad,
      GST_DEBUG_FUNCPTR (gst_rtkgpu_converter_query_video));

  GST_PAD_SET_PROXY_ALLOCATION (gpuconverter->video_sinkpad);

  gst_element_add_pad (GST_ELEMENT (gpuconverter), gpuconverter->srcpad);
  gst_element_add_pad (GST_ELEMENT (gpuconverter), gpuconverter->video_sinkpad);

  gpuconverter->video_flushing = FALSE;
  gpuconverter->video_eos = FALSE;

  gst_segment_init (&gpuconverter->video_segment, GST_FORMAT_TIME);

  gpuconverter->out_width = DEFAULT_PROP_OUT_WIDTH;
  gpuconverter->out_height = DEFAULT_PROP_OUT_HEIGHT;
  gpuconverter->video_rotate = DEFAULT_PROP_VIDEO_ROTATE;

  gpuconverter->out_pool = gst_video_buffer_pool_new();
  gpuconverter->out_reconfig = TRUE;
  gpuconverter->out_fourcc = DRM_FORMAT_NV12;

  g_mutex_init (&gpuconverter->lock);
  g_cond_init (&gpuconverter->cond);
}

static uint32_t gst_rtkgpu_converter_gst_to_drm_format(GstVideoFormat format)
{
  switch (format)
  {
    case GST_VIDEO_FORMAT_NV12:
      return DRM_FORMAT_NV12;
    case GST_VIDEO_FORMAT_NV21:
      return DRM_FORMAT_NV21;
    case GST_VIDEO_FORMAT_NV16:
      return DRM_FORMAT_NV16;
    case GST_VIDEO_FORMAT_NV61:
      return DRM_FORMAT_NV61;
    case GST_VIDEO_FORMAT_NV24:
      return DRM_FORMAT_NV24;
    case GST_VIDEO_FORMAT_RGB:
      return DRM_FORMAT_BGR888;
    case GST_VIDEO_FORMAT_BGR:
      return DRM_FORMAT_RGB888;
    case GST_VIDEO_FORMAT_BGRA:
      return DRM_FORMAT_ARGB8888;
    case GST_VIDEO_FORMAT_BGRx:
      return DRM_FORMAT_XRGB8888;
    case GST_VIDEO_FORMAT_ARGB:
      return DRM_FORMAT_BGRA8888;
    case GST_VIDEO_FORMAT_xRGB:
      return DRM_FORMAT_BGRX8888;
    case GST_VIDEO_FORMAT_RGBx:
      return DRM_FORMAT_XBGR8888;
    case GST_VIDEO_FORMAT_RGBA:
      return DRM_FORMAT_ABGR8888;
    case GST_VIDEO_FORMAT_xBGR:
      return DRM_FORMAT_RGBX8888;
    case GST_VIDEO_FORMAT_ABGR:
      return DRM_FORMAT_RGBA8888;
    default:
      printf("unsupport gst format: %d\n", format);
      break;
  }
  return DRM_FORMAT_INVALID;
}

static GstVideoFormat gst_rtkgpu_converter_drm_to_gst_format(uint32_t drm_fourcc)
{
  switch (drm_fourcc)
  {
    case DRM_FORMAT_NV12:
      return GST_VIDEO_FORMAT_NV12;
    case DRM_FORMAT_NV21:
      return GST_VIDEO_FORMAT_NV21;
    case DRM_FORMAT_NV16:
      return GST_VIDEO_FORMAT_NV16;
    case DRM_FORMAT_NV61:
      return GST_VIDEO_FORMAT_NV61;
    case DRM_FORMAT_NV24:
      return GST_VIDEO_FORMAT_NV24;
    case DRM_FORMAT_RGB888:
      return GST_VIDEO_FORMAT_BGR;
    case DRM_FORMAT_BGR888:
      return GST_VIDEO_FORMAT_RGB;
    case DRM_FORMAT_ARGB8888:
      return GST_VIDEO_FORMAT_BGRA;
    case DRM_FORMAT_XRGB8888:
      return GST_VIDEO_FORMAT_BGRx;
    case DRM_FORMAT_BGRA8888:
      return GST_VIDEO_FORMAT_ARGB;
    case DRM_FORMAT_BGRX8888:
      return GST_VIDEO_FORMAT_xRGB;
    case DRM_FORMAT_XBGR8888:
      return GST_VIDEO_FORMAT_RGBx;
    case DRM_FORMAT_ABGR8888:
      return GST_VIDEO_FORMAT_RGBA;
    case DRM_FORMAT_RGBX8888:
      return GST_VIDEO_FORMAT_xBGR;
    case DRM_FORMAT_RGBA8888:
      return GST_VIDEO_FORMAT_ABGR;
    default:
      printf("unsupport drm format:%x\n", drm_fourcc);
      break;
  }
  return GST_VIDEO_FORMAT_UNKNOWN;
}

static double gst_rtkgpu_converter_pixel_size(uint32_t drm_fourcc)
{
  switch (drm_fourcc)
  {
    case DRM_FORMAT_NV12:
    case DRM_FORMAT_NV21:
      return 1.5;
    case DRM_FORMAT_NV16:
    case DRM_FORMAT_NV61:
      return 2;
    case DRM_FORMAT_RGB888:
    case DRM_FORMAT_BGR888:
    case DRM_FORMAT_NV24:
      return 3;
    case DRM_FORMAT_ARGB8888:
    case DRM_FORMAT_XRGB8888:
    case DRM_FORMAT_BGRA8888:
    case DRM_FORMAT_BGRX8888:
    case DRM_FORMAT_XBGR8888:
    case DRM_FORMAT_ABGR8888:
    case DRM_FORMAT_RGBX8888:
    case DRM_FORMAT_RGBA8888:
      return 4;
  }
  return 4;
}

static int gst_rtkgpu_converter_fourcc_plane(uint32_t drm_fourcc)
{
  switch (drm_fourcc)
  {
    case DRM_FORMAT_NV12:
    case DRM_FORMAT_NV21:
    case DRM_FORMAT_NV16:
    case DRM_FORMAT_NV61:
    case DRM_FORMAT_NV24:
      return 2;
    case DRM_FORMAT_RGB888:
    case DRM_FORMAT_BGR888:
    case DRM_FORMAT_ARGB8888:
    case DRM_FORMAT_XRGB8888:
    case DRM_FORMAT_BGRA8888:
    case DRM_FORMAT_BGRX8888:
    case DRM_FORMAT_XBGR8888:
    case DRM_FORMAT_ABGR8888:
    case DRM_FORMAT_RGBX8888:
    case DRM_FORMAT_RGBA8888:
      return 1;
  }
  return -1;
}

static GstStateChangeReturn
gst_rtkgpu_converter_change_state (GstElement * element, GstStateChange transition)
{
  GstRtkGpuConverter *gpuconverter = GST_RTKGPU_CONVERTER (element);
  GstStateChangeReturn ret;

  switch (transition) {
    case GST_STATE_CHANGE_PAUSED_TO_READY:
      GST_RTKGPU_CONVERTER_LOCK (gpuconverter);
      gpuconverter->video_flushing = TRUE;
      GST_RTKGPU_CONVERTER_UNLOCK (gpuconverter);
      break;
    default:
      break;
  }

  ret = GST_ELEMENT_CLASS (parent_class)->change_state (element, transition);
  if (ret == GST_STATE_CHANGE_FAILURE)
    return ret;

  switch (transition) {
    case GST_STATE_CHANGE_READY_TO_PAUSED:
      GST_RTKGPU_CONVERTER_LOCK (gpuconverter);
      gpuconverter->video_flushing = FALSE;
      gpuconverter->video_eos = FALSE;
      gst_segment_init (&gpuconverter->video_segment, GST_FORMAT_TIME);
      GST_RTKGPU_CONVERTER_UNLOCK (gpuconverter);
      break;
    default:
      break;
  }

  return ret;
}

static void
gst_rtkgpu_converter_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec)
{
  GstRtkGpuConverter *gpuconverter = GST_RTKGPU_CONVERTER (object);

  GST_RTKGPU_CONVERTER_LOCK (gpuconverter);
  switch (prop_id) {
    case PROP_VIDEO_ROTATE:
      gpuconverter->video_rotate = g_value_get_uint (value);
      break;
    case PROP_OUT_WIDTH:
      gpuconverter->out_width = g_value_get_uint (value);
      break;
    case PROP_OUT_HEIGHT:
      gpuconverter->out_height = g_value_get_uint (value);
      break;
    case PROP_OUT_FORMAT:
      gpuconverter->out_fourcc = g_value_get_enum (value);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
  GST_RTKGPU_CONVERTER_UNLOCK (gpuconverter);
}

static void
gst_rtkgpu_converter_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec)
{
  GstRtkGpuConverter *gpuconverter = GST_RTKGPU_CONVERTER (object);

  GST_RTKGPU_CONVERTER_LOCK (gpuconverter);
  switch (prop_id) {
    case PROP_VIDEO_ROTATE:
      g_value_set_uint(value, gpuconverter->video_rotate);
      break;
    case PROP_OUT_WIDTH:
      g_value_set_uint(value, gpuconverter->out_width);
      break;
    case PROP_OUT_HEIGHT:
      g_value_set_uint(value, gpuconverter->out_height);
      break;
    case PROP_OUT_FORMAT:
      g_value_set_enum(value, gpuconverter->out_fourcc);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
  GST_RTKGPU_CONVERTER_UNLOCK (gpuconverter);
}

static gboolean
gst_rtkgpu_converter_negotiate (GstRtkGpuConverter * gpuconverter, GstCaps * caps)
{
  gboolean ret = TRUE;

  gst_pad_check_reconfigure (gpuconverter->srcpad);

  if (!caps)
    caps = gst_pad_get_current_caps (gpuconverter->video_sinkpad);
  else
    gst_caps_ref (caps);

  if (!caps || gst_caps_is_empty (caps))
    goto no_format;

  {
    GstCaps *tmp_caps = gst_static_caps_get (&sw_video_template_caps);
    ret = gst_caps_is_subset (caps, tmp_caps);
    gst_caps_unref (tmp_caps);
  }

  if (ret) {
    ret = gst_pad_set_caps (gpuconverter->srcpad, caps);
  }

  if (!ret) {
    gst_pad_mark_reconfigure (gpuconverter->srcpad);
  }

  gst_caps_unref (caps);

  if (!ret)
    gst_pad_mark_reconfigure (gpuconverter->srcpad);

  return ret;

no_format:
  {
    if (caps)
      gst_caps_unref (caps);
    gst_pad_mark_reconfigure (gpuconverter->srcpad);
    return FALSE;
  }
}

static gboolean
gst_rtkgpu_converter_setcaps_video (GstPad * pad, GstRtkGpuConverter * gpuconverter, GstCaps * caps)
{
  GstVideoInfo info;
  gboolean ret;

  if (!gst_video_info_from_caps (&info, caps))
    goto invalid_caps;

  gpuconverter->in_fourcc = gst_rtkgpu_converter_gst_to_drm_format(GST_VIDEO_INFO_FORMAT(&info));
  if (gpuconverter->in_fourcc == DRM_FORMAT_INVALID) {
    printf("input format is unsupported:%d\n", GST_VIDEO_INFO_FORMAT(&info));
    return FALSE;
  }

  if (gst_rtkgpu_converter_drm_to_gst_format(gpuconverter->out_fourcc) == GST_VIDEO_FORMAT_UNKNOWN)
  {
    printf("output format is unsupported:%x\n", gpuconverter->out_fourcc);
    return FALSE;
  }

  gpuconverter->video_info = info;

  if (gpuconverter->out_reconfig) {
    config_output_buffer_size(gpuconverter);
    gpuconverter->out_reconfig = FALSE;
  }

  ret = gst_rtkgpu_converter_negotiate (gpuconverter, gpuconverter->out_caps);

  {
    GstCaps *tmp_caps = gst_static_caps_get (&sw_video_template_caps);
    ret = gst_caps_is_subset (caps, tmp_caps);
    gst_caps_unref (tmp_caps);
  }

  return ret;

invalid_caps:
  {
    printf("%s err caps\n", __func__);
    return FALSE;
  }
}

static gboolean
gst_rtkgpu_converter_event_video (GstPad * pad, GstObject * parent, GstEvent * event)
{
  gboolean ret = FALSE;
  GstRtkGpuConverter *gpuconverter = GST_RTKGPU_CONVERTER (parent);

  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_CAPS:
    {
      GstCaps *caps;
      gst_event_parse_caps (event, &caps);
      ret = gst_rtkgpu_converter_setcaps_video (pad, gpuconverter, caps);
      gst_event_unref (event);
      break;
    }
    case GST_EVENT_SEGMENT:
    {
      GstSegment segment;

      gst_event_copy_segment (event, &segment);

      if (segment.format == GST_FORMAT_TIME) {
        gpuconverter->video_segment = segment;
        ret = gst_pad_event_default (pad, parent, event);
      } else {
        ret = FALSE;
        gst_event_unref (event);
      }
      break;
    }
    case GST_EVENT_EOS:
      GST_RTKGPU_CONVERTER_LOCK (gpuconverter);
      gpuconverter->video_eos = TRUE;
      GST_RTKGPU_CONVERTER_UNLOCK (gpuconverter);
      ret = gst_pad_event_default (pad, parent, event);
      break;
    case GST_EVENT_FLUSH_START:
      GST_RTKGPU_CONVERTER_LOCK (gpuconverter);
      gpuconverter->video_flushing = TRUE;
      GST_RTKGPU_CONVERTER_BROADCAST (gpuconverter);
      GST_RTKGPU_CONVERTER_UNLOCK (gpuconverter);
      ret = gst_pad_event_default (pad, parent, event);
      break;
    case GST_EVENT_FLUSH_STOP:
      GST_RTKGPU_CONVERTER_LOCK (gpuconverter);
      gpuconverter->video_flushing = FALSE;
      gpuconverter->video_eos = FALSE;
      gst_segment_init (&gpuconverter->video_segment, GST_FORMAT_TIME);
      GST_RTKGPU_CONVERTER_UNLOCK (gpuconverter);
      ret = gst_pad_event_default (pad, parent, event);
      break;
    default:
      ret = gst_pad_event_default (pad, parent, event);
      break;
  }

  return ret;
}

static gboolean
gst_rtkgpu_converter_event_src (GstPad * pad, GstObject * parent, GstEvent * event)
{
  GstRtkGpuConverter *gpuconverter = GST_RTKGPU_CONVERTER (parent);
  gboolean ret;

  ret = gst_pad_push_event (gpuconverter->video_sinkpad, event);

  return ret;
}

static GstCaps *
gst_rtkgpu_converter_get_videosink_caps (GstPad * pad, GstRtkGpuConverter * gpuconverter, GstCaps * filter)
{
  GstPad *srcpad = gpuconverter->srcpad;
  GstCaps *peer_caps = NULL, *caps = NULL, *rtkgpuconverter_filter = NULL;

  if (filter) {
    GstCaps *sw_caps = gst_static_caps_get (&sw_video_template_caps);
    rtkgpuconverter_filter = gst_caps_intersect(filter, sw_caps);
    gst_caps_unref (sw_caps);
  }

  peer_caps = gst_pad_peer_query_caps (srcpad, rtkgpuconverter_filter);

  if (rtkgpuconverter_filter)
    gst_caps_unref (rtkgpuconverter_filter);

  if (peer_caps) {

    if (gst_caps_is_any (peer_caps)) {
      caps = gst_caps_copy (gst_pad_get_pad_template_caps (srcpad));
    } else {
      GstCaps *sw_caps = gst_static_caps_get (&sw_video_template_caps);
      caps = gst_caps_intersect (peer_caps, sw_caps);
      gst_caps_unref (sw_caps);
    }

    gst_caps_unref (peer_caps);

  } else {
    caps = gst_pad_get_pad_template_caps (pad);
  }

  if (filter) {
    GstCaps *intersection = gst_caps_intersect_full (filter, caps,
        GST_CAPS_INTERSECT_FIRST);
    gst_caps_unref (caps);
    caps = intersection;
  }

  return caps;
}

static GstCaps *
gst_rtkgpu_converter_get_src_caps (GstPad * pad, GstRtkGpuConverter * gpuconverter, GstCaps * filter)
{
  GstPad *srcpad = gpuconverter->video_sinkpad;
  GstCaps *peer_caps = NULL, *caps = NULL, *rtkgpuconverter_filter = NULL;

  if (filter) {
    GstCaps *sw_caps = gst_static_caps_get (&sw_video_template_caps);
    rtkgpuconverter_filter = gst_caps_intersect(filter, sw_caps);
    gst_caps_unref (sw_caps);
  }

  peer_caps = gst_pad_peer_query_caps (srcpad, rtkgpuconverter_filter);

  if (rtkgpuconverter_filter)
    gst_caps_unref (rtkgpuconverter_filter);

  if (peer_caps) {

    if (gst_caps_is_any (peer_caps)) {
      caps = gst_caps_copy (gst_pad_get_pad_template_caps (srcpad));
    } else {
      GstCaps *sw_caps = gst_static_caps_get (&sw_video_template_caps);
      caps = gst_caps_intersect (peer_caps, sw_caps);
      gst_caps_unref (sw_caps);
    }

    gst_caps_unref (peer_caps);

  } else {
    caps = gst_pad_get_pad_template_caps (pad);
  }

  if (filter) {
    GstCaps *intersection = gst_caps_intersect_full (filter, caps,
        GST_CAPS_INTERSECT_FIRST);
    gst_caps_unref (caps);
    caps = intersection;
  }

  return caps;
}

static gboolean
gst_rtkgpu_converter_query_video (GstPad * pad, GstObject * parent, GstQuery * query)
{
  GstRtkGpuConverter *gpuconverter = GST_RTKGPU_CONVERTER (parent);
  gboolean res = FALSE;

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_CAPS:
    {
      GstCaps *filter, *caps;

      gst_query_parse_caps (query, &filter);
      caps = gst_rtkgpu_converter_get_videosink_caps (pad, gpuconverter, filter);
      gst_query_set_caps_result (query, caps);
      gst_caps_unref (caps);
      res = TRUE;
      break;
    }
    case GST_QUERY_ALLOCATION:
    {
      GstCaps *caps = NULL;
      GstVideoInfo info;
      GstAllocator *allocator;
      guint size;

      gst_query_parse_allocation (query, &caps, NULL);

      if (caps && gst_video_info_from_caps (&info, caps)) {
        size = GST_VIDEO_INFO_SIZE (&info);
        gst_query_add_allocation_pool (query, NULL, size, 0, 0);
        gst_query_add_allocation_meta (query, GST_VIDEO_META_API_TYPE, NULL);

        allocator = gst_dmabuf_allocator_new ();
        if (allocator) {
          GstAllocationParams params;
          gst_allocation_params_init (&params);
          gst_query_add_allocation_param (query, allocator, &params);
          gst_object_unref (allocator);
        }

        res = TRUE;
      } else {
        res = gst_pad_query_default (pad, parent, query);
      }
      break;
    }
    default:
      res = gst_pad_query_default (pad, parent, query);
      break;
  }

  return res;
}

static gboolean
gst_rtkgpu_converter_query_src (GstPad * pad, GstObject * parent, GstQuery * query)
{
  gboolean res = FALSE;

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_CAPS:
    {
      GstCaps *filter, *caps;

      gst_query_parse_caps (query, &filter);
      caps = gst_rtkgpu_converter_get_src_caps (pad, (GstRtkGpuConverter *) parent, filter);
      gst_query_set_caps_result (query, caps);
      gst_caps_unref (caps);
      res = TRUE;
      break;
    }
    default:
      res = gst_pad_query_default (pad, parent, query);
      break;
  }

  return res;
}

static void config_output_buffer_size(GstRtkGpuConverter *gpuconverter)
{
  GstVideoAlignment video_align;
  gst_buffer_pool_set_active (gpuconverter->out_pool, FALSE);

  if (gpuconverter->out_caps) {
    gst_caps_unref(gpuconverter->out_caps);
    gpuconverter->out_caps = NULL;
  }

  GstVideoInfo info;
  gst_video_info_set_format(&info, gst_rtkgpu_converter_drm_to_gst_format(gpuconverter->out_fourcc), gpuconverter->out_width, gpuconverter->out_height);

  video_align.stride_align[0]=0;
  video_align.stride_align[1]=0;
  video_align.stride_align[2]=0;
  video_align.stride_align[3]=0;
  video_align.padding_top   = 0;
  video_align.padding_left  = 0;
  video_align.padding_right = ALIGN64(gpuconverter->out_width) - gpuconverter->out_width;
  video_align.padding_bottom = ALIGN64(gpuconverter->out_height) - gpuconverter->out_height;

  gsize plane_size[GST_VIDEO_MAX_PLANES];
  gst_video_info_align_full(&info, &video_align, plane_size);

  gpuconverter->out_caps  = gst_video_info_to_caps(&info);

  GstStructure *structure;
  GstAllocator *alloc;

  structure = gst_buffer_pool_get_config (gpuconverter->out_pool);

  gst_structure_set (structure,
      "padding-top", G_TYPE_UINT, video_align.padding_top,
      "padding-bottom", G_TYPE_UINT, video_align.padding_bottom,
      "padding-left", G_TYPE_UINT, video_align.padding_left,
      "padding-right", G_TYPE_UINT, video_align.padding_right,
      "stride-align0", G_TYPE_UINT, video_align.stride_align[0],
      "stride-align1", G_TYPE_UINT, video_align.stride_align[1],
      "stride-align2", G_TYPE_UINT, video_align.stride_align[2],
      "stride-align3", G_TYPE_UINT, video_align.stride_align[3], NULL);

  gst_buffer_pool_config_set_params (structure, gpuconverter->out_caps,
		gst_rtkgpu_converter_pixel_size(gpuconverter->out_fourcc) * ALIGN64(gpuconverter->out_width) * ALIGN64(gpuconverter->out_height), 0, 10);

  printf("stride:%d slice_height:%d\n",
		ALIGN64(gpuconverter->out_width), ALIGN64(gpuconverter->out_height));

  gst_buffer_pool_config_add_option (structure, GST_BUFFER_POOL_OPTION_VIDEO_META);
  gst_buffer_pool_config_add_option (structure, GST_BUFFER_POOL_OPTION_VIDEO_ALIGNMENT);

  alloc = gst_rtk_dma_allocator_new ();
  gst_buffer_pool_config_set_allocator (structure, alloc, NULL);
  gst_buffer_pool_set_config (gpuconverter->out_pool, structure);

  gst_object_unref(alloc);
  gst_buffer_pool_set_active (gpuconverter->out_pool, TRUE);
}

static void gst_rtkgpu_converter_composition(GstRtkGpuConverter *gpuconverter, GstBuffer *video)
{
  GstVideoInfo video_info = gpuconverter->video_info;
  GstVideoMeta *vmeta = gst_buffer_get_video_meta (video);

  for (int i = 0; i < gst_buffer_n_memory (video); i++) {
    if (!gst_is_dmabuf_memory (gst_buffer_peek_memory (video, i))) {
      printf("video is not dmabuf\n");
      return;
    }
  }

  if (vmeta) {
    for (int i = 0; i < vmeta->n_planes; i++) {
      video_info.offset[i] = vmeta->offset[i];
      video_info.stride[i] = vmeta->stride[i];
    }
  }

  GstBuffer *fb_buffer;
  GstFlowReturn ret = gst_buffer_pool_acquire_buffer (gpuconverter->out_pool, &fb_buffer, NULL);
  if (ret == GST_FLOW_OK) {
    GST_BUFFER_TIMESTAMP(fb_buffer) = GST_BUFFER_TIMESTAMP(video);
    GST_BUFFER_DURATION(fb_buffer) = GST_CLOCK_TIME_NONE;
  } else {
    printf("can't alloc out buffer\n");
    goto fail;
  }
 
  EGL_INFO egl_info;
  if (init_egl(&egl_info) == -1) {
    printf("init egl fail\n");
    goto release_buffer;
  }

  egl_info.view_width = ALIGN64(gpuconverter->out_width);
  egl_info.view_height = ALIGN64(gpuconverter->out_height);
// prepare framebuffer info
  IMAGE_INFO fb_image_info = {0};
  EGL_IMAGE fb_image;

  fb_image_info.n_plane = gst_rtkgpu_converter_fourcc_plane(gpuconverter->out_fourcc);
  if (fb_image_info.n_plane == -1)
  {
    printf("output format is unsupported:%x\n", gpuconverter->out_fourcc);
    goto release_buffer;
  }

  fb_image_info.fourcc = gpuconverter->out_fourcc;
  fb_image_info.width = gpuconverter->out_width;
  fb_image_info.height = gpuconverter->out_height;
  GstMemory *m = gst_buffer_peek_memory (fb_buffer, 0);
  GstVideoMeta *meta = gst_buffer_get_video_meta(fb_buffer);

  if (meta) {
    for (int i = 0; i < meta->n_planes; i++) {
        fb_image_info.fd[i] = gst_dmabuf_memory_get_fd (m);
        fb_image_info.stride[i] = meta->stride[i];
        fb_image_info.offset[i] = meta->offset[i];
    }
  }

  if (create_image_texture(&egl_info, &fb_image, fb_image_info) == -1) {
    printf("create framebuffer image fail\n");
    goto release_egl;
  }

  if (create_framebuffer(&egl_info, &fb_image, fb_image_info) == -1) {
    printf("generate framebuffer fail\n");
    goto release_fb_image;
  }
// prepare video info

  if (gpuconverter->in_fourcc != DRM_FORMAT_NV24) {
    IMAGE_INFO video_image_info = {0};
    EGL_IMAGE video_image = {0};

    video_image_info.fourcc = gpuconverter->in_fourcc;
    if (video_image_info.fourcc == DRM_FORMAT_INVALID)
    {
      printf("video format is wrong:%x\n", video_image_info.fourcc);
      goto release_fb_image;
    }

    video_image_info.width = GST_VIDEO_INFO_WIDTH(&video_info);
    video_image_info.height = GST_VIDEO_INFO_HEIGHT(&video_info);
    video_image_info.n_plane = GST_VIDEO_INFO_N_PLANES(&video_info);

    for (int i = 0; i < video_image_info.n_plane; i++) {
      guint offset, mem_idx, length;
      gsize skip;
      offset = GST_VIDEO_INFO_PLANE_OFFSET (&video_info, i);
      video_image_info.stride[i] = GST_VIDEO_INFO_PLANE_STRIDE (&video_info, i);
      if (gst_buffer_find_memory (video, offset, 1, &mem_idx, &length, &skip)) {
        GstMemory *m = gst_buffer_peek_memory (video, mem_idx);
        video_image_info.offset[i] = m->offset + GST_VIDEO_INFO_PLANE_OFFSET (&video_info, i);
        video_image_info.fd[i] = gst_dmabuf_memory_get_fd (m);
      }
    }

    create_image_texture(&egl_info, &video_image, video_image_info);
    set_input_nv24_texture(&egl_info, 0);
    add_texture(&egl_info, &video_image, gpuconverter->video_rotate);
    draw_frame(&egl_info);
    destroy_image(&egl_info, &video_image);
  } else {
    IMAGE_INFO video_image_info[2] = {0};
    EGL_IMAGE video_image[2] = {0};

    if (gpuconverter->in_fourcc == DRM_FORMAT_INVALID)
    {
      printf("video format is wrong:%x\n", gpuconverter->in_fourcc);
      goto release_fb_image;
    }

    video_image_info[0].fourcc = DRM_FORMAT_R8;
    video_image_info[1].fourcc = DRM_FORMAT_GR88;
	for (int i = 0; i < 2; i++) {
      video_image_info[i].width = GST_VIDEO_INFO_WIDTH(&video_info);
      video_image_info[i].height = GST_VIDEO_INFO_HEIGHT(&video_info);
      video_image_info[i].n_plane = 1;
    }

    for (int i = 0; i < 2; i++) {
      guint offset, mem_idx, length;
      gsize skip;
      offset = GST_VIDEO_INFO_PLANE_OFFSET (&video_info, i);
      video_image_info[i].stride[0] = GST_VIDEO_INFO_PLANE_STRIDE (&video_info, i);
      if (gst_buffer_find_memory (video, offset, 1, &mem_idx, &length, &skip)) {
        GstMemory *m = gst_buffer_peek_memory (video, mem_idx);
        video_image_info[i].offset[0] = m->offset + GST_VIDEO_INFO_PLANE_OFFSET (&video_info, i);
        video_image_info[i].fd[0] = gst_dmabuf_memory_get_fd (m);
      }
    }

    // Handle non-64-aligned stride by allocating 64-aligned buffer and copying
    int allocated_fds[2] = {-1, -1};
    guint aligned_strides[2] = {0, 0};
    guint heights[2] = {0, 0};

    if (video_image_info[0].stride[0] != ALIGN64(video_image_info[0].stride[0])) {
      int dma_heap_fd = open("/dev/dma_heap/system", O_RDWR);
      if (dma_heap_fd < 0) {
        printf("open dma_heap/system fail\n");
        goto release_fb_image;
      }

      GstMapInfo map;
      if (gst_buffer_map(video, &map, GST_MAP_READ) != TRUE)
      {
        printf("gst_buffer_map fail\n");
        goto release_fb_image;
      }

      for (int i = 0; i < 2; i++) {
        guint orig_stride = video_image_info[i].stride[0];
        guint aligned_stride = ALIGN64(orig_stride);
        guint height = video_image_info[i].height;

        aligned_strides[i] = aligned_stride;
        heights[i] = height;

        guint aligned_size = aligned_stride * height;

        struct dma_heap_allocation_data alloc_data = {
          .len = aligned_size,
          .fd = 0,
          .fd_flags = O_RDWR | O_CLOEXEC,
          .heap_flags = 0
        };

        if (ioctl(dma_heap_fd, DMA_HEAP_IOCTL_ALLOC, &alloc_data) < 0) {
          printf("dma_heap allocation failed\n");
          if (dma_heap_fd >= 0)
            close(dma_heap_fd);

          for (int j = 0; j < i; j++) {
            if (allocated_fds[j] >= 0)
              close(allocated_fds[j]);
          }
          goto release_fb_image;
        }

        // Map original buffer
        void *src = map.data + video_image_info[i].offset[0];

        // Map allocated buffer at correct offset
        void *dst = mmap(NULL, aligned_size, PROT_READ | PROT_WRITE, MAP_SHARED, alloc_data.fd, 0);
        if (dst == MAP_FAILED) {
          printf("mmap destination fail\n");
          if (dma_heap_fd >= 0)
            close(dma_heap_fd);
 
         if (alloc_data.fd >= 0)
            close(alloc_data.fd);

          for (int j = 0; j < i; j++) {
            if (allocated_fds[j] >= 0)
              close(allocated_fds[j]);
          }
          goto release_fb_image;
        }

        // Copy data row by row
        guint row_size = (orig_stride < aligned_stride) ? orig_stride : aligned_stride;
        for (guint row = 0; row < height; row++) {
          guint8 *src_row = (guint8 *)src + (row * orig_stride);
          guint8 *dst_row = (guint8 *)dst + (row * aligned_stride);
          memcpy(dst_row, src_row, row_size);
        }

        munmap(dst, aligned_size);

        // Update video_image_info with new aligned buffer
        video_image_info[i].fd[0] = alloc_data.fd;
        video_image_info[i].stride[0] = aligned_stride;
        video_image_info[i].offset[0] = 0;
        allocated_fds[i] = alloc_data.fd;

        printf("plane %d: stride %d -> %d (copied to 64-aligned)\n",
            i, orig_stride, aligned_stride);
      }
      if (dma_heap_fd >= 0)
        close(dma_heap_fd);
      gst_buffer_unmap(video, &map);
    }

    create_image_texture(&egl_info, &video_image[0], video_image_info[0]);
    create_image_texture(&egl_info, &video_image[1], video_image_info[1]);
    set_input_nv24_texture(&egl_info, 1);

    video_image[0].type = TEXTURE_Y_PLANE;
    add_texture(&egl_info, &video_image[0], gpuconverter->video_rotate);
    video_image[1].type = TEXTURE_UV_PLANE;
    add_texture(&egl_info, &video_image[1], gpuconverter->video_rotate);
    draw_frame(&egl_info);
    destroy_image(&egl_info, &video_image[0]);
    destroy_image(&egl_info, &video_image[1]);

    // Close allocated fd
    for (int i = 0; i < 2; i++) {
      if (allocated_fds[i] >= 0)
        close(allocated_fds[i]);
    }
  }
  gst_pad_push(gpuconverter->srcpad, fb_buffer);

  destroy_image(&egl_info, &fb_image);
  destroy_egl(&egl_info);
  return;

release_fb_image:
  destroy_image(&egl_info, &fb_image);
release_egl:
  destroy_egl(&egl_info);
release_buffer:
  if (fb_buffer)
    gst_buffer_unref(fb_buffer);
fail:
  return;
}

static GstFlowReturn
gst_rtkgpu_converter_chain_video (GstPad * pad, GstObject * parent, GstBuffer * buffer)
{
  GstFlowReturn ret = GST_FLOW_OK;
  GstRtkGpuConverter *gpuconverter = GST_RTKGPU_CONVERTER (parent);
  gboolean in_seg = FALSE;
  guint64 start, stop, clip_start = 0, clip_stop = 0;

  if (gst_pad_check_reconfigure (gpuconverter->srcpad)) {
    config_output_buffer_size(gpuconverter);
    if (!gst_rtkgpu_converter_negotiate (gpuconverter, gpuconverter->out_caps)) {
      gst_pad_mark_reconfigure (gpuconverter->srcpad);
      if (GST_PAD_IS_FLUSHING (gpuconverter->srcpad))
        goto flushing_no_unlock;
      else
        goto not_negotiated;
    }
  }

  if (!GST_BUFFER_TIMESTAMP_IS_VALID (buffer))
    goto missing_timestamp;

  start = GST_BUFFER_TIMESTAMP (buffer);

  if (!GST_BUFFER_DURATION_IS_VALID (buffer)) {
    stop = GST_CLOCK_TIME_NONE;
  } else {
    stop = start + GST_BUFFER_DURATION (buffer);
  }

  if (stop == GST_CLOCK_TIME_NONE && start < gpuconverter->video_segment.start)
    goto out_of_segment;

  in_seg =
      gst_segment_clip (&gpuconverter->video_segment, GST_FORMAT_TIME, start, stop,
      &clip_start, &clip_stop);

  if (!in_seg)
    goto out_of_segment;

  /* if the buffer is only partially in the segment, fix up stamps */
  if (clip_start != start || (stop != -1 && clip_stop != stop)) {
    buffer = gst_buffer_make_writable (buffer);
    GST_BUFFER_TIMESTAMP (buffer) = clip_start;
    if (stop != -1)
      GST_BUFFER_DURATION (buffer) = clip_stop - clip_start;
  }

  GST_RTKGPU_CONVERTER_LOCK (gpuconverter);

  if (gpuconverter->video_flushing)
    goto flushing;

  if (gpuconverter->video_eos)
    goto have_eos;

  gst_rtkgpu_converter_composition(gpuconverter, buffer);
  GST_RTKGPU_CONVERTER_UNLOCK (gpuconverter);
  gst_buffer_unref(buffer);

  gpuconverter->video_segment.position = clip_start;

  return ret;

flushing:
  {
    printf("video: flushing\n");
    GST_RTKGPU_CONVERTER_UNLOCK (gpuconverter);
  }
flushing_no_unlock:
  {
    printf("video: flushing no unlock\n");
    gst_buffer_unref (buffer);
    return GST_FLOW_FLUSHING;
  }
have_eos:
  {
    printf("video: have eos\n");
    GST_RTKGPU_CONVERTER_UNLOCK (gpuconverter);
    gst_buffer_unref (buffer);
    return GST_FLOW_EOS;
  }
not_negotiated:
  {
    printf("video: not negotiated\n");
    gst_buffer_unref (buffer);
    return GST_FLOW_NOT_NEGOTIATED;
  }
missing_timestamp:
  {
    printf("video: missing timestamp\n");
    gst_buffer_unref (buffer);
    return GST_FLOW_OK;
  }
out_of_segment:
  {
    printf("video: out of segment\n");
    gst_buffer_unref (buffer);
    return GST_FLOW_OK;
  }
}

static void
gst_rtkgpu_converter_finalize (GObject * object)
{
  GstRtkGpuConverter *gpuconverter = GST_RTKGPU_CONVERTER (object);

  g_mutex_clear (&gpuconverter->lock);
  g_cond_clear (&gpuconverter->cond);

  if (gpuconverter->out_caps) {
    gst_caps_unref(gpuconverter->out_caps);
    gpuconverter->out_caps = NULL;
  }

  if (gpuconverter->out_pool) {
    g_object_unref(gpuconverter->out_pool);
    gpuconverter->out_pool = NULL;
  }

  G_OBJECT_CLASS (parent_class)->finalize (object);
}

static gboolean
plugin_init (GstPlugin * plugin)
{
  return GST_ELEMENT_REGISTER (rtkgpuconverter, plugin);
}

#ifndef VERSION
#define VERSION "0.0.FIXME"
#endif
#ifndef PACKAGE
#define PACKAGE "FIXME_package"
#endif
#ifndef PACKAGE_NAME
#define PACKAGE_NAME "FIXME_package_name"
#endif
#ifndef GST_PACKAGE_ORIGIN
#define GST_PACKAGE_ORIGIN "http://FIXME.org/"
#endif

GST_PLUGIN_DEFINE (GST_VERSION_MAJOR,
    GST_VERSION_MINOR,
    rtkgpuconverter,
    "RTK Gpu Converter",
    plugin_init, VERSION, "LGPL", PACKAGE_NAME, GST_PACKAGE_ORIGIN)
