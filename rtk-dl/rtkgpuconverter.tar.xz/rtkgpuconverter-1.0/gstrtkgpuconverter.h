#ifndef __GST_RTKGPU_CONVERTER__
#define __GST_RTKGPU_CONVERTER__
#include <gst/gst.h>
#include <gst/video/video.h>

G_BEGIN_DECLS

#define GST_TYPE_RTKGPU_CONVERTER (gst_rtkgpu_converter_get_type())
#define GST_RTKGPU_CONVERTER(obj) (G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_RTKGPU_CONVERTER,GstRtkGpuConverter))
#define GST_RTKGPU_CONVERTER_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST((klass),GST_TYPE_RTKGPU_CONVERTER,GstRtkGpuConverterClass))
#define GST_RTKGPU_CONVERTER_GET_CLASS(obj) (G_TYPE_INSTANCE_GET_CLASS ((obj), \
    GST_TYPE_RTKGPU_CONVERTER, GstRtkGpuConverterClass))
#define GST_IS_RTKGPU_CONVERTER(obj) (G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_TYPE_RTKGPU_CONVERTER))
#define GST_IS_RTKGPU_CONVERTER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass),GST_TYPE_RTKGPU_CONVERTER))

typedef struct _GstRtkGpuConverter GstRtkGpuConverter;
typedef struct _GstRtkGpuConverterClass GstRtkGpuConverterClass;

struct _GstRtkGpuConverter
{
  GstElement element;
  GstPad *video_sinkpad, *srcpad;

  GMutex lock;
  GCond cond;

  GstSegment video_segment;
  gboolean video_flushing;
  gboolean video_eos;

  GstVideoInfo video_info;
  uint32_t in_fourcc;
  uint32_t out_fourcc;
  GstCaps *out_caps;
  GstBufferPool *out_pool;
  guint out_width, out_height;
  guint video_rotate;
  gboolean out_reconfig;
};

struct _GstRtkGpuConverterClass
{
  GstElementClass parent_class;
};

GType gst_rtkgpu_converter_get_type (void);

GST_ELEMENT_REGISTER_DECLARE (rtkgpuconverter);

G_END_DECLS

#endif
