#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <GLES3/gl31.h>

#ifndef __GPU_FUNCTION_H__
#define __GPU_FUNCTION_H__

#define MAX_PLANE 3

typedef enum texture_type {
  TEXTURE_NORMAL = 0,
  TEXTURE_Y_PLANE,
  TEXTURE_UV_PLANE,
} TEXTURE_TYPE;

typedef struct egl_info {
	EGLContext egl_ctx;
	EGLDisplay egl_display;
	GLuint program;
	GLuint frag;
	GLuint vert;
	PFNGLEGLIMAGETARGETTEXTURE2DOESPROC image_target_texture_2d;
	PFNEGLCREATEIMAGEKHRPROC create_image;
	PFNEGLDESTROYIMAGEKHRPROC destroy_image;
	GLuint pos;
	GLuint texCoord1;
	GLsizei view_width;
	GLsizei view_height;
	GLuint active_tex;
} EGL_INFO;

typedef struct egl_image {
	EGLImageKHR image;
	GLuint texture;
	GLuint framebuffer;
    TEXTURE_TYPE type;
} EGL_IMAGE;

typedef struct image_info {
	int n_plane;
	unsigned int fourcc;
	int width;
	int height;
	int fd[MAX_PLANE];
	int offset[MAX_PLANE];
	int stride[MAX_PLANE];
} IMAGE_INFO;

int init_egl(EGL_INFO *info);
int create_image_texture(EGL_INFO *egl_info, EGL_IMAGE *image, IMAGE_INFO image_info);
int create_framebuffer(EGL_INFO *egl_info, EGL_IMAGE *image, IMAGE_INFO image_info);
void add_texture(EGL_INFO *egl_info, EGL_IMAGE *image, int rotation);
void draw_frame(EGL_INFO *egl_info);
void destroy_image(EGL_INFO *egl_info, EGL_IMAGE *image);
void destroy_egl(EGL_INFO *info);
int drm_fourcc_stride_factor(uint32_t fourcc);
void set_input_nv24_texture(EGL_INFO *egl_info, int is_nv24);
void set_output_nv24_framebuffer(EGL_INFO *egl_info, int is_nv24);
#endif // end of __GPU_FUNCTION_H__

