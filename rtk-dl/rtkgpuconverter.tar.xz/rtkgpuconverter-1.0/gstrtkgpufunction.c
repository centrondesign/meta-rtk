#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include "gstrtkgpufunction.h"

static const char *vert_shader_text =
	"attribute vec4 uPos;\n"
	"attribute vec2 uTexCoord1;\n"
	"varying vec2 u_TexCoord1;\n"
	"void main() {\n"
	"  gl_Position = uPos;\n"
	"  u_TexCoord1 = uTexCoord1;\n"
	"}\n";

static const char *frag_shader_text =
	"#extension GL_OES_EGL_image_external : require\n"
	"precision mediump float;\n"
	"uniform samplerExternalOES uVideoTexture;\n"
	"uniform samplerExternalOES uVideoUVTexture;\n"
	"uniform int uOutIsYUV;\n"
	"uniform int uInIsNV24;\n"
	"uniform int uOutIsNV24;\n"
	"varying vec2 u_TexCoord1;\n"
	"void main() {\n"
	"  vec4 color = vec4(0.0, 0.0, 0.0, 0.0);\n"
	"  color = texture2D(uVideoTexture, u_TexCoord1);\n"
	"  float Alpha = color.a;\n"
	"  if (uOutIsYUV > 0) {\n"
	"    if (uInIsNV24 > 0) {\n"
	"      float Y = color.r;\n"
	"      vec4 uv_color = texture2D(uVideoUVTexture, u_TexCoord1);\n"
	"      float U = uv_color.r;\n"
	"      float V = uv_color.g;\n"
	"      gl_FragColor = vec4(Y, U, V, 1);\n"
	"    } else {\n"
	"      float Y = color.r * 0.299   + color.g * 0.587     + color.b * 0.114;\n"
	"      float U = color.r * -0.169  + color.g * -0.332    + color.b * 0.500    + 0.5;\n"
	"      float V = color.r * 0.500   + color.g * -0.419    + color.b * -0.0813  + 0.5;\n"
	"      gl_FragColor = vec4(Y, U, V, Alpha);\n"
	"    }\n"
	"  } else {\n"
	"    if (uInIsNV24 > 0) {\n"
	"      float Y = color.r;\n"
	"      vec4 uv_color = texture2D(uVideoUVTexture, u_TexCoord1);\n"
	"      float U = uv_color.r - 0.5;\n"
	"      float V = uv_color.g - 0.5;\n"
	"      float R = Y + 1.402 * V;\n"
	"      float G = Y - 0.344136 * U - 0.714136 * V;\n"
	"      float B = Y + 1.772 * U;\n;"
	"      gl_FragColor = vec4(R, G, B, 1);\n"
	"    } else {\n"
	"      gl_FragColor = color;\n"
	"    }\n"
	"  }\n"
	"}\n";

GLfloat verts[4][2] = {
	{ -1.0,  1.0 },
	{ -1.0, -1.0 },
	{  1.0,  1.0 },
	{  1.0, -1.0 }
};

GLfloat texcoord_0[4][2] = {
	{ 0.0f, 1.0f },
	{ 0.0f, 0.0f },
	{ 1.0f, 1.0f },
	{ 1.0f, 0.0f },
};

GLfloat texcoord_90[4][2] = {
	{ 1.0f, 1.0f },
	{ 0.0f, 1.0f },
	{ 1.0f, 0.0f },
	{ 0.0f, 0.0f },
};

GLfloat texcoord_180[4][2] = {
	{ 1.0f, 0.0f },
	{ 1.0f, 1.0f },
	{ 0.0f, 0.0f },
	{ 0.0f, 1.0f },
};

GLfloat texcoord_270[4][2] = {
	{ 0.0f, 0.0f },
	{ 1.0f, 0.0f },
	{ 0.0f, 1.0f },
	{ 1.0f, 1.0f },
};

static int drm_is_yuv(uint32_t drm_fourcc)
{
	switch (drm_fourcc)
	{
		case DRM_FORMAT_NV12:
		case DRM_FORMAT_NV21:
		case DRM_FORMAT_NV16:
		case DRM_FORMAT_NV61:
		case DRM_FORMAT_NV24:
			return 1;
        case DRM_FORMAT_RGB888:
        case DRM_FORMAT_BGR888:
		case DRM_FORMAT_ARGB8888:
		case DRM_FORMAT_XRGB8888:
		case DRM_FORMAT_BGRA8888:
		case DRM_FORMAT_BGRX8888:
		case DRM_FORMAT_XBGR8888:
		case DRM_FORMAT_ABGR8888:
		case DRM_FORMAT_RGBX8888:
		case DRM_FORMAT_RGBA8888:
			return 0;
	}
	return 1;
}

int drm_fourcc_stride_factor(uint32_t drm_fourcc)
{
	switch (drm_fourcc)
	{
		case DRM_FORMAT_NV12:
		case DRM_FORMAT_NV21:
		case DRM_FORMAT_NV16:
		case DRM_FORMAT_NV61:
			return 1;
		case DRM_FORMAT_RGB888:
		case DRM_FORMAT_BGR888:
			return 3;
		case DRM_FORMAT_ARGB8888:
		case DRM_FORMAT_XRGB8888:
		case DRM_FORMAT_BGRA8888:
		case DRM_FORMAT_BGRX8888:
		case DRM_FORMAT_XBGR8888:
		case DRM_FORMAT_ABGR8888:
		case DRM_FORMAT_RGBX8888:
		case DRM_FORMAT_RGBA8888:
			return 4;
	}
	return 4;
}

int init_egl(EGL_INFO *info)
{
	EGLint num_configs;
	EGLConfig egl_config;
	GLint status;

	const EGLint config_attribs[] = {
		EGL_RENDERABLE_TYPE,         EGL_OPENGL_ES2_BIT,
		EGL_RED_SIZE,                8,
		EGL_GREEN_SIZE,              8,
		EGL_BLUE_SIZE,               8,
		EGL_ALPHA_SIZE,              8,
		EGL_NONE};

	const EGLint context_attribs[] = {
		EGL_CONTEXT_CLIENT_VERSION, 2,
		EGL_NONE, EGL_NONE};


	info->egl_display = eglGetDisplay(EGL_DEFAULT_DISPLAY);

	if (info->egl_display == EGL_NO_DISPLAY) {
		printf("eglGetDisplay fail\n");
		return -1;
	}

	if (!eglInitialize(info->egl_display, NULL, NULL)) {
		printf("eglInitialize fail\n");
		return -1;
	}

	if (!eglChooseConfig(info->egl_display, config_attribs, &egl_config, 1, &num_configs)) {
		printf("eglChooseConfig fail\n");
		return -1;
	}

	info->egl_ctx = eglCreateContext(info->egl_display, egl_config, EGL_NO_CONTEXT, context_attribs);

	if (info->egl_ctx == EGL_NO_CONTEXT) {
		printf("eglCreateContext fail\n");
	}

	if (!eglMakeCurrent(info->egl_display, EGL_NO_SURFACE, EGL_NO_SURFACE, info->egl_ctx)) {
		printf("eglMakeCurrent fail\n");
		return -1;
	}

	info->image_target_texture_2d = (void *) eglGetProcAddress("glEGLImageTargetTexture2DOES");
	if (info->image_target_texture_2d == NULL) {
		printf("No glEGLImageTargetTexture2DOES extension\n");
		return -1;
	}

	info->create_image = (void *) eglGetProcAddress("eglCreateImageKHR");
	if (info->create_image == NULL) {
		printf("No eglCreateImageKHR extension\n");
		return -1;
	}

	info->destroy_image = (void *) eglGetProcAddress("eglDestroyImageKHR");
	if (info->destroy_image == NULL) {
		printf("No eglDestroyImageKHR extension\n");
		return -1;
	}

	info->vert = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(info->vert, 1, (const char **) &vert_shader_text, NULL);
	glCompileShader(info->vert);
	glGetShaderiv(info->vert, GL_COMPILE_STATUS, &status);
	if (!status) {
		printf("create vert shader fail\n");
		return -1;
	}

	info->frag = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(info->frag, 1, (const char **) &frag_shader_text, NULL);
	glCompileShader(info->frag);
	glGetShaderiv(info->frag, GL_COMPILE_STATUS, &status);
	if (!status) {
		printf("create frag shader fail\n");
		return -1;
	}

	info->program = glCreateProgram();
	glAttachShader(info->program, info->frag);
	glAttachShader(info->program, info->vert);
	glLinkProgram(info->program);

	glGetProgramiv(info->program, GL_LINK_STATUS, &status);
	if (!status) {
		printf("get program fail\n");
		return -1;
	}

	glUseProgram(info->program);

	info->pos = glGetAttribLocation(info->program, "uPos");
	info->texCoord1 = glGetAttribLocation(info->program, "uTexCoord1");

	return 0;
}

int create_image_texture(EGL_INFO *egl_info, EGL_IMAGE *image, IMAGE_INFO image_info)
{
	EGLint attribs[52];
	int atti = 0;

	attribs[atti++] = EGL_WIDTH;
	attribs[atti++] = image_info.width;
	attribs[atti++] = EGL_HEIGHT;
	attribs[atti++] = image_info.height;
	attribs[atti++] = EGL_LINUX_DRM_FOURCC_EXT;
	attribs[atti++] = image_info.fourcc;

	if (image_info.n_plane > 0) {
		attribs[atti++] = EGL_DMA_BUF_PLANE0_FD_EXT;
		attribs[atti++] = image_info.fd[0];
		attribs[atti++] = EGL_DMA_BUF_PLANE0_OFFSET_EXT;
		attribs[atti++] = image_info.offset[0];
		attribs[atti++] = EGL_DMA_BUF_PLANE0_PITCH_EXT;
		attribs[atti++] = image_info.stride[0];
	}

	if (image_info.n_plane > 1) {
		attribs[atti++] = EGL_DMA_BUF_PLANE1_FD_EXT;
		attribs[atti++] = image_info.fd[1];
		attribs[atti++] = EGL_DMA_BUF_PLANE1_OFFSET_EXT;
		attribs[atti++] = image_info.offset[1];
		attribs[atti++] = EGL_DMA_BUF_PLANE1_PITCH_EXT;
		attribs[atti++] = image_info.stride[1];
	}

	attribs[atti++] = EGL_NONE;

	image->image = egl_info->create_image(egl_info->egl_display, EGL_NO_CONTEXT, EGL_LINUX_DMA_BUF_EXT, NULL, attribs);
	if (image->image == EGL_NO_IMAGE_KHR) {
		EGLint code;
		code = eglGetError();
		printf("create_image fail format %x:(0x%04lx)\n", image_info.fourcc, code);
		return -1;
	}

	glGenTextures(1, &image->texture);
	glBindTexture(GL_TEXTURE_EXTERNAL_OES, image->texture);
	glTexParameteri(GL_TEXTURE_EXTERNAL_OES, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_EXTERNAL_OES, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_EXTERNAL_OES, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_EXTERNAL_OES, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	egl_info->image_target_texture_2d(GL_TEXTURE_EXTERNAL_OES, image->image);
	glBindTexture(GL_TEXTURE_EXTERNAL_OES, 0);
	egl_info->active_tex = 0;
	return 0;
}

int create_framebuffer(EGL_INFO *egl_info, EGL_IMAGE *image, IMAGE_INFO image_info)
{
	GLint gl_out_is_yuv;
	int yuv = drm_is_yuv(image_info.fourcc);
	gl_out_is_yuv = glGetUniformLocation(egl_info->program, "uOutIsYUV");
	glUniform1i(gl_out_is_yuv, yuv);

	glBindTexture(GL_TEXTURE_EXTERNAL_OES, image->texture);
	glGenFramebuffers(1, &image->framebuffer);
	glBindFramebuffer(GL_FRAMEBUFFER, image->framebuffer);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_EXTERNAL_OES, image->texture, 0);
	glBindTexture(GL_TEXTURE_EXTERNAL_OES, 0);

	if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
		printf("framebuffer prepare fail\n");
		return -1;
	}
	return 0;
}

void set_input_nv24_texture(EGL_INFO *egl_info, int is_nv24)
{
  GLint gl_input_nv24;
  gl_input_nv24 = glGetUniformLocation(egl_info->program, "uInIsNV24");
  glUniform1i(gl_input_nv24, is_nv24);
}

void set_output_nv24_framebuffer(EGL_INFO *egl_info, int is_nv24)
{
  GLint gl_output_nv24;
  gl_output_nv24 = glGetUniformLocation(egl_info->program, "uOutIsNV24");
  glUniform1i(gl_output_nv24, is_nv24);
}

void add_texture(EGL_INFO *egl_info, EGL_IMAGE *image, int rotation)
{
    GLint gl_tex_loc;

    GLfloat *r_matrix = (GLfloat *)texcoord_0;
    switch (rotation) {
        case 0:
            r_matrix = (GLfloat *)texcoord_0;
            break;
        case 90:
            r_matrix = (GLfloat *)texcoord_90;
            break;
        case 180:
            r_matrix = (GLfloat *)texcoord_180;
            break;
        case 270:
            r_matrix = (GLfloat *)texcoord_270;
            break;
        default:
            break;
    }

	glVertexAttribPointer(egl_info->texCoord1, 2, GL_FLOAT, GL_FALSE, 0, r_matrix);

	if (image->type == TEXTURE_UV_PLANE) {
		gl_tex_loc = glGetUniformLocation(egl_info->program, "uVideoUVTexture");
	} else {
		gl_tex_loc = glGetUniformLocation(egl_info->program, "uVideoTexture");
	}

	glUniform1i(gl_tex_loc, egl_info->active_tex);
	glActiveTexture(GL_TEXTURE0 + egl_info->active_tex);
	glBindTexture(GL_TEXTURE_EXTERNAL_OES, image->texture);
	egl_info->active_tex++;
}

void draw_frame(EGL_INFO *egl_info) {
	glViewport(0, 0, egl_info->view_width, egl_info->view_height);
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT);
	glVertexAttribPointer(egl_info->pos, 2, GL_FLOAT, GL_FALSE, 0, verts);
	glEnableVertexAttribArray(egl_info->texCoord1);
	glEnableVertexAttribArray(egl_info->pos);
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	glFinish();

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_EXTERNAL_OES, 0);
	glDisableVertexAttribArray(egl_info->texCoord1);
	glDisableVertexAttribArray(egl_info->pos);
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
	glUseProgram(0);
}

void destroy_image(EGL_INFO *egl_info, EGL_IMAGE *image)
{
	if (image->framebuffer != GL_NONE)
		glDeleteFramebuffers(1, &image->framebuffer);

	if (image->texture != GL_NONE)
		glDeleteTextures(1, &image->texture);

	if (image->image != EGL_NO_IMAGE_KHR)
		egl_info->destroy_image(egl_info->egl_display, image->image);
}

void destroy_egl(EGL_INFO *info)
{
	if (info->vert != GL_NONE)
		glDeleteShader(info->vert);

	if (info->frag != GL_NONE)
		glDeleteShader(info->frag);

	if (info->program != GL_NONE)
		glDeleteProgram(info->program);

	if (info->egl_ctx != EGL_NO_CONTEXT)
		eglDestroyContext(info->egl_display, info->egl_ctx);
}


