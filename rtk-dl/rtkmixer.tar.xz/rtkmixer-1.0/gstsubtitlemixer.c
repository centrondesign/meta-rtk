#include "gstsubtitlemixer.h"
#include <gstrtkdmaallocator.h>
#include "subtitlemixersinkpad.h"
#include "ext/rtk_drm_vowb.h"
#include "ext/ve_common.h"
#include "ext/rtk_heap.h"
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <stdbool.h>
#include <xf86drm.h>

#define DRM_IOCTL_RTK_VOWB_RUN_CMD          DRM_IOWR(DRM_COMMAND_BASE + 0x47, struct rtk_drm_vowb_run_cmd)
#define DRM_IOCTL_RTK_VOWB_CHECK_CMD        DRM_IOWR(DRM_COMMAND_BASE + 0x48, struct rtk_drm_vowb_check_cmd)
#define DRM_IOCTL_RTK_VOWB_GET_FEATURES     DRM_IOWR(DRM_COMMAND_BASE + 0x49, struct rtk_drm_vowb_run_cmd)

#define GST_CAT_DEFAULT gst_subtitle_mixer_debug
GST_DEBUG_CATEGORY_STATIC (gst_subtitle_mixer_debug);

static void gst_subtitle_mixer_child_proxy_init (gpointer g_iface, gpointer data);

#define gst_subtitle_mixer_parent_class parent_class
G_DEFINE_TYPE_WITH_CODE (GstSubtitleMixer, gst_subtitle_mixer,
     GST_TYPE_AGGREGATOR, G_IMPLEMENT_INTERFACE (GST_TYPE_CHILD_PROXY,
         gst_subtitle_mixer_child_proxy_init));

#define DEFAULT_VIDEO_WIDTH         1280
#define DEFAULT_VIDEO_HEIGHT        720
#define DEFAULT_VIDEO_FPS_NUM       30
#define DEFAULT_VIDEO_FPS_DEN       1

#define DEFAULT_PROP_MIN_BUFFERS    0
#define DEFAULT_PROP_MAX_BUFFERS    6

#define GST_submixer_MAX_QUEUE_LEN  4

#undef GST_VIDEO_SIZE_RANGE
#define GST_VIDEO_SIZE_RANGE "(int) [ 1, 32767 ]"

#undef GST_VIDEO_FPS_RANGE
#define GST_VIDEO_FPS_RANGE "(fraction) [ 0, 255 ]"

#define GST_VIDEO_FORMATS \
  "{ NV12, BGRA }"

static GType gst_converter_request_get_type(void);
#define GST_TYPE_CONVERTER_REQUEST  (gst_converter_request_get_type())
#define GST_CONVERTER_REQUEST(obj) ((GstConverterRequest *) obj)

typedef struct _GstConverterRequest GstConverterRequest;

struct _GstConverterRequest {
  GstMiniObject parent;

  // List with video frames for each valid input.
  GArray        *inframes;
  // Output frame submitted with provided ID.
  GstVideoFrame *outframe;

  // Time it took for this request to be processed.
  GstClockTime  time;
};

GST_DEFINE_MINI_OBJECT_TYPE (GstConverterRequest, gst_converter_request);

static GstCaps *
gst_subtitle_mixer_sink_caps (void)
{
  static GstCaps *caps = NULL;
  static gsize inited = 0;

  if (g_once_init_enter (&inited)) {
    caps = gst_caps_from_string (GST_VIDEO_CAPS_MAKE (GST_VIDEO_FORMATS));

    g_once_init_leave (&inited, 1);
  }
  return caps;
}

static GstCaps *
gst_subtitle_mixer_src_caps (void)
{
  static GstCaps *caps = NULL;
  static gsize inited = 0;

  if (g_once_init_enter (&inited)) {
    caps = gst_caps_from_string (GST_VIDEO_CAPS_MAKE (GST_VIDEO_FORMATS));

    g_once_init_leave (&inited, 1);
  }
  return caps;
}

static GstPadTemplate *
gst_subtitle_mixer_sink_template (void)
{
  return gst_pad_template_new_with_gtype ("sink_%u", GST_PAD_SINK, GST_PAD_REQUEST,
      gst_subtitle_mixer_sink_caps (), GST_TYPE_SUBTITLE_MIXER_SINKPAD);
}

static GstPadTemplate *
gst_subtitle_mixer_src_template (void)
{
  return gst_pad_template_new_with_gtype ("src", GST_PAD_SRC, GST_PAD_ALWAYS,
      gst_subtitle_mixer_src_caps (), GST_TYPE_AGGREGATOR_PAD);
}

static void
gst_converter_request_free (GstConverterRequest * request)
{
  GstVideoFrame *frame = NULL;
  GstBuffer *buffer = NULL;
  guint idx = 0;

  for (idx = 0; idx < request->inframes->len; idx++) {
    frame = &(g_array_index (request->inframes, GstVideoFrame, idx));

    if ((buffer = frame->buffer) != NULL) {
      gst_video_frame_unmap (frame);
      gst_buffer_unref (buffer);
    }
  }

  if ((buffer = request->outframe->buffer) != NULL) {
    if (gst_buffer_get_size (buffer) != 0)
      gst_video_frame_unmap (request->outframe);

    gst_buffer_unref (buffer);
  }

  g_slice_free (GstVideoFrame, request->outframe);
  g_array_free (request->inframes, TRUE);
  g_slice_free (GstConverterRequest, request);
}

static GstConverterRequest *
gst_converter_request_new (guint n_inputs)
{
  GstConverterRequest *request = g_slice_new0 (GstConverterRequest);

  gst_mini_object_init (GST_MINI_OBJECT (request), 0,
      GST_TYPE_CONVERTER_REQUEST, NULL, NULL,
      (GstMiniObjectFreeFunction) gst_converter_request_free);

  request->inframes =
      g_array_sized_new (FALSE, TRUE, sizeof (GstVideoFrame), n_inputs);
  g_array_set_size (request->inframes, n_inputs);

  request->outframe = g_slice_new0 (GstVideoFrame);
  request->time = GST_CLOCK_TIME_NONE;

  return request;
}

static inline void
gst_converter_request_unref (GstConverterRequest * request)
{
  gst_mini_object_unref (GST_MINI_OBJECT_CAST (request));
}


static inline void
gst_data_queue_item_free (gpointer data)
{
  GstDataQueueItem *item = data;
  gst_converter_request_unref (GST_CONVERTER_REQUEST (item->object));
  g_slice_free (GstDataQueueItem, item);
}

static GstBufferPool *
gst_subtitle_mixer_create_pool (GstSubtitleMixer * submixer, GstCaps * caps)
{
  GstBufferPool *pool = NULL;
  GstStructure *config = NULL;
  GstAllocator *allocator = NULL;
  GstVideoInfo info;

  if (!gst_video_info_from_caps (&info, caps)) {
    GST_ERROR_OBJECT (submixer, "Invalid caps %" GST_PTR_FORMAT, caps);
    return NULL;
  }

  GstVideoFormat format;
  GstVideoAlignment align;
  gboolean success;
  guint width, height;

  width = GST_VIDEO_INFO_WIDTH (&info);
  height = GST_VIDEO_INFO_HEIGHT (&info);
  format = GST_VIDEO_INFO_FORMAT (&info);

  pool = gst_video_buffer_pool_new ();
  config = gst_buffer_pool_get_config (pool);

  allocator = gst_rtk_dma_allocator_new ();
  if (allocator == NULL) {
    GST_ERROR_OBJECT (submixer, "Failed to create rtk dma allocator");
    gst_clear_object (&pool);
    return NULL;
  }

  gst_buffer_pool_config_set_params (config, caps, info.size,
      DEFAULT_PROP_MIN_BUFFERS, DEFAULT_PROP_MAX_BUFFERS);
  gst_buffer_pool_config_set_allocator (config, allocator, NULL);

  if (!gst_buffer_pool_set_config (pool, config)) {
    GST_WARNING_OBJECT (submixer, "Failed to set pool configuration!");
    g_clear_object (&pool);
  }

  g_object_unref (allocator);

  return pool;
}

static gboolean
gst_subtitle_mixer_prepare_input_frame (GstSubtitleMixer * submixer,
    GstSubtitleMixerSinkPad * sinkpad, GstVideoFrame * frame, guint idx)
{
  GstBuffer *buffer = NULL;
  GstSegment *segment = NULL;
  GstClockTime timestamp, position;
  GstClockTime timestamp_tmp;

  buffer = gst_aggregator_pad_peek_buffer (GST_AGGREGATOR_PAD (sinkpad));

  if (buffer == NULL) {
    GST_TRACE_OBJECT (sinkpad, "No buffer available!");
    return FALSE;
  }

  GST_TRACE_OBJECT (sinkpad, "Taking %" GST_PTR_FORMAT, buffer);

  segment = &GST_AGGREGATOR_PAD (GST_AGGREGATOR (submixer)->srcpad)->segment;

  // Check whether the buffer should be kept in the queue for future reuse.
  timestamp = gst_segment_to_running_time (
      &GST_AGGREGATOR_PAD (sinkpad)->segment, GST_FORMAT_TIME,
      GST_BUFFER_PTS (buffer)) + GST_BUFFER_DURATION (buffer);
  if(idx == 1){
    timestamp = gst_segment_to_running_time (
      &GST_AGGREGATOR_PAD (sinkpad)->segment, GST_FORMAT_TIME,
      GST_BUFFER_PTS (buffer));
      GST_TRACE_OBJECT (sinkpad, "GST_BUFFER_PTS (buffer) %" GST_TIME_FORMAT, GST_TIME_ARGS(GST_BUFFER_PTS (buffer)));
      GST_TRACE_OBJECT (sinkpad, "GST_BUFFER_DURATION (buffer) %" GST_TIME_FORMAT, GST_TIME_ARGS(GST_BUFFER_DURATION (buffer)));
  }

  position = gst_segment_to_running_time (segment, GST_FORMAT_TIME,
      segment->position) + submixer->duration;
  if(idx == 1){
    position = gst_segment_to_running_time (segment, GST_FORMAT_TIME,
          segment->position);
      GST_INFO_OBJECT (sinkpad, "timestamp %" GST_TIME_FORMAT, GST_TIME_ARGS(timestamp));
      GST_INFO_OBJECT (sinkpad, "position %" GST_TIME_FORMAT, GST_TIME_ARGS(position));
  }

  if (timestamp > position) {
    GST_DEBUG_OBJECT (sinkpad, "Keeping buffer at least until %"
        GST_TIME_FORMAT, GST_TIME_ARGS (timestamp));
  }
  else{
    if (idx == 1 && gst_buffer_get_size (buffer) != 0 &&
      !GST_BUFFER_FLAG_IS_SET (buffer, GST_BUFFER_FLAG_GAP)) {
        gst_buffer_unref (buffer);
        if(submixer->subframe)
          gst_buffer_unref (submixer->subframe);

        if (submixer->subframe_info != NULL)
            gst_video_info_free (submixer->subframe_info);

        submixer->subframe = gst_aggregator_pad_pop_buffer (GST_AGGREGATOR_PAD (sinkpad));
        submixer->subframe_info = gst_video_info_copy(sinkpad->info);
        return TRUE;
    }
    else
      gst_aggregator_pad_drop_buffer (GST_AGGREGATOR_PAD (sinkpad));
  }

  // GAP buffer, nothing further to do.
  if (gst_buffer_get_size (buffer) == 0 ||
      GST_BUFFER_FLAG_IS_SET (buffer, GST_BUFFER_FLAG_GAP)) {
    gst_buffer_unref (buffer);
    return TRUE;
  }

  if (!gst_video_frame_map (frame, sinkpad->info, buffer,
          GST_MAP_READ | GST_VIDEO_FRAME_MAP_FLAG_NO_REF)) {
    GST_ERROR_OBJECT (sinkpad, "Failed to map input buffer!");
    gst_buffer_unref (buffer);
    return FALSE;
  }

  return TRUE;
}

static gboolean
gst_subtitle_mixer_prepare_output_frame (GstSubtitleMixer * submixer,
    GstVideoFrame * frame, gboolean is_gap)
{
  GstBufferPool *pool = submixer->outpool;
  GstBuffer *buffer = NULL;

  if (!is_gap) {
    if (!gst_buffer_pool_is_active (pool) &&
        !gst_buffer_pool_set_active (pool, TRUE)) {
      GST_ERROR_OBJECT (submixer, "Failed to activate output video buffer pool!");
      return FALSE;
    }

    if (gst_buffer_pool_acquire_buffer (pool, &buffer, NULL) != GST_FLOW_OK) {
      GST_ERROR_OBJECT (submixer, "Failed to create output video buffer!");
      return FALSE;
    }

    if (!gst_video_frame_map (frame, submixer->outinfo, buffer,
            GST_MAP_READWRITE | GST_VIDEO_FRAME_MAP_FLAG_NO_REF)) {
      GST_ERROR_OBJECT (submixer, "Failed to map output buffer!");
      gst_buffer_unref (buffer);
      return FALSE;
    }
  } else {
    // Create an empty GAP buffer, which will be submitted downstream.
    buffer = gst_buffer_new ();
    GST_BUFFER_FLAG_SET (buffer, GST_BUFFER_FLAG_GAP);
    frame->buffer = buffer;
  }

  GST_BUFFER_DURATION (buffer) = submixer->duration;

  {
    GstSegment *s = NULL;

    GST_OBJECT_LOCK (submixer);
    s = &GST_AGGREGATOR_PAD (GST_AGGREGATOR (submixer)->srcpad)->segment;

    GST_BUFFER_TIMESTAMP (buffer) = (s->position == GST_CLOCK_TIME_NONE ||
        s->position <= s->start) ? s->start : s->position;

    s->position = GST_BUFFER_TIMESTAMP (buffer) + GST_BUFFER_DURATION (buffer);
    GST_OBJECT_UNLOCK (submixer);
  }

  GST_TRACE_OBJECT (submixer, "Output %" GST_PTR_FORMAT, buffer);
  return TRUE;
}

static gboolean
gst_subtitle_mixer_propose_allocation (GstAggregator * aggregator,
    GstAggregatorPad * pad, GstQuery * inquery, GstQuery * outquery)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER_CAST (aggregator);

  GstCaps *caps = NULL;
  GstBufferPool *pool = NULL;
  GstVideoInfo info;
  guint size = 0;
  gboolean needpool = FALSE;
  guint width, height;

  GST_DEBUG_OBJECT (submixer, "Pad %s:%s", GST_DEBUG_PAD_NAME (pad));

  // Extract caps from the query.
  gst_query_parse_allocation (outquery, &caps, &needpool);

  if (NULL == caps) {
    GST_ERROR_OBJECT (submixer, "Failed to extract caps from query!");
    return FALSE;
  }

  if (!gst_video_info_from_caps (&info, caps)) {
    GST_ERROR_OBJECT (submixer, "Failed to get video info!");
    return FALSE;
  }

  // Get the size from video info.
  size = GST_VIDEO_INFO_SIZE (&info);

  if (needpool) {
    GstStructure *structure = NULL;
    GstAllocator *allocator = NULL;

    pool = gst_subtitle_mixer_create_pool (submixer, caps);
    structure = gst_buffer_pool_get_config (pool);

    // Set caps and size in query.
    gst_buffer_pool_config_set_params (structure, caps, size, 0, 0);

    gst_buffer_pool_config_get_allocator (structure, &allocator, NULL);
    gst_query_add_allocation_param (outquery, allocator, NULL);

    if (!gst_buffer_pool_set_config (pool, structure)) {
      GST_ERROR_OBJECT (submixer, "Failed to set buffer pool configuration!");
      gst_object_unref (pool);
      return FALSE;
    }
  }

  // If upstream does't have a pool requirement, set only size in query.
  gst_query_add_allocation_pool (outquery, needpool ? pool : NULL, size, 0, 0);

  if (pool != NULL)
    gst_object_unref (pool);

  gst_query_add_allocation_meta (outquery, GST_VIDEO_META_API_TYPE, NULL);
  return TRUE;
}

static gboolean
gst_subtitle_mixer_decide_allocation (GstAggregator * aggregator,
    GstQuery * query)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER_CAST (aggregator);
  GstCaps *caps = NULL;
  GstBufferPool *pool = NULL;
  guint size, minbuffers, maxbuffers;

  gst_query_parse_allocation (query, &caps, NULL);
  if (!caps) {
    GST_ERROR_OBJECT (submixer, "Failed to parse the decide_allocation caps!");
    return FALSE;
  }

  // Invalidate the cached pool if there is an allocation_query.
  if (submixer->outpool) {
    gst_buffer_pool_set_active (submixer->outpool, FALSE);
    gst_object_unref (submixer->outpool);
  }

  // Create a new buffer pool.
  pool = gst_subtitle_mixer_create_pool (submixer, caps);
  submixer->outpool = pool;

  {
    GstStructure *config = NULL;
    GstAllocator *allocator = NULL;
    GstAllocationParams params;

    // Get the configured pool properties in order to set in query.
    config = gst_buffer_pool_get_config (pool);
    gst_buffer_pool_config_get_params (config, &caps, &size, &minbuffers,
        &maxbuffers);

    if (gst_buffer_pool_config_get_allocator (config, &allocator, &params))
      gst_query_add_allocation_param (query, allocator, &params);

    gst_structure_free (config);
  }

  // Check whether the query has pool.
  if (gst_query_get_n_allocation_pools (query) > 0)
    gst_query_set_nth_allocation_pool (query, 0, pool, size, minbuffers,
        maxbuffers);
  else
    gst_query_add_allocation_pool (query, pool, size, minbuffers,
        maxbuffers);

  gst_query_add_allocation_meta (query, GST_VIDEO_META_API_TYPE, NULL);

  return TRUE;
}

static gboolean
gst_subtitle_mixer_sink_query (GstAggregator * aggregator,
    GstAggregatorPad * pad, GstQuery * query)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);

  GST_TRACE_OBJECT (submixer, "Received %s query on pad %s:%s",
      GST_QUERY_TYPE_NAME (query), GST_DEBUG_PAD_NAME (pad));

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_CAPS:
    {
      GstCaps *filter = NULL, *caps = NULL;

      gst_query_parse_caps (query, &filter);
      caps = gst_subtitle_mixer_sinkpad_getcaps (pad, aggregator, filter);
      gst_query_set_caps_result (query, caps);

      gst_caps_unref (caps);
      return TRUE;
    }
    case GST_QUERY_ACCEPT_CAPS:
    {
      GstCaps *caps = NULL;
      gboolean success = FALSE;

      gst_query_parse_accept_caps (query, &caps);
      success = gst_subtitle_mixer_sinkpad_acceptcaps (pad, aggregator, caps);
      gst_query_set_accept_caps_result (query, success);

      return TRUE;
    }
    default:
      break;
  }

  return GST_AGGREGATOR_CLASS (parent_class)->sink_query (
      aggregator, pad, query);
}

static gboolean
gst_subtitle_mixer_sink_event (GstAggregator * aggregator,
    GstAggregatorPad * pad, GstEvent * event)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);

  GST_TRACE_OBJECT (submixer, "Received %s event on pad %s:%s",
      GST_EVENT_TYPE_NAME (event), GST_DEBUG_PAD_NAME (pad));

  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_CAPS:
    {
      GstCaps *caps = NULL;
      gboolean success = FALSE;

      gst_event_parse_caps (event, &caps);
      success = gst_subtitle_mixer_sinkpad_setcaps (pad, aggregator, caps);

      gst_event_unref (event);
      return success;
    }
    default:
      break;
  }

  return GST_AGGREGATOR_CLASS (parent_class)->sink_event (
      aggregator, pad, event);
}

static gboolean
gst_subtitle_mixer_src_query (GstAggregator * aggregator, GstQuery * query)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);

  GST_TRACE_OBJECT (submixer, "Received %s query on src pad",
      GST_QUERY_TYPE_NAME (query));

  switch (GST_QUERY_TYPE (query)) {
    case GST_QUERY_POSITION:
    {
      GstSegment *segment = &GST_AGGREGATOR_PAD (aggregator->srcpad)->segment;
      GstFormat format = GST_FORMAT_UNDEFINED;

      gst_query_parse_position (query, &format, NULL);

      if (format != GST_FORMAT_TIME) {
        GST_ERROR_OBJECT (submixer, "Unsupported POSITION format: %s!",
            gst_format_get_name (format));
        return FALSE;
      }

      gst_query_set_position (query, format,
          gst_segment_to_stream_time (segment, format, segment->position));
      return TRUE;
    }
    case GST_QUERY_DURATION:
      // TODO
      break;
    default:
      break;
  }

  return GST_AGGREGATOR_CLASS (parent_class)->src_query (aggregator, query);
}

static gboolean
gst_subtitle_mixer_src_event (GstAggregator * aggregator, GstEvent * event)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);

  GST_TRACE_OBJECT (submixer, "Received %s event on src pad",
      GST_EVENT_TYPE_NAME (event));

  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_QOS:
      // TODO
      break;
    default:
      break;
  }

  return GST_AGGREGATOR_CLASS (parent_class)->src_event (aggregator, event);
}

static GstFlowReturn
gst_subtitle_mixer_update_src_caps (GstAggregator * aggregator,
    GstCaps * caps, GstCaps ** othercaps)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);
  gint outwidth = 0, outheight = 0, out_fps_n = 0, out_fps_d = 0;
  guint idx = 0, length = 0;
  gboolean configured = TRUE;


  GST_DEBUG_OBJECT (submixer, "Update output caps based on caps %"
      GST_PTR_FORMAT, caps);

  {
    GstSubtitleMixerSinkPad *sinkpad = NULL;
    GList *list = NULL;

    GST_OBJECT_LOCK (submixer);

    // Extrapolate the highest width, height and frame rate from the sink pads.
    for (list = GST_ELEMENT (submixer)->sinkpads; list; list = list->next) {
      gint width, height, fps_n, fps_d;
      gdouble fps = 0.0, outfps = 0;

      sinkpad = GST_SUBTITLE_MIXER_SINKPAD_CAST (list->data);

      if (NULL == sinkpad->info) {
        GST_DEBUG_OBJECT (submixer, "%s caps not set!", GST_PAD_NAME (sinkpad));
        configured = FALSE;
        continue;
      }

      GST_SUBTITLE_MIXER_SINKPAD_LOCK (sinkpad);

      width = GST_VIDEO_INFO_WIDTH (sinkpad->info);
      height = GST_VIDEO_INFO_HEIGHT (sinkpad->info);

      fps_n = GST_VIDEO_INFO_FPS_N (sinkpad->info);
      fps_d = GST_VIDEO_INFO_FPS_D (sinkpad->info);

      GST_SUBTITLE_MIXER_SINKPAD_UNLOCK (sinkpad);

      if (width == 0 || height == 0)
        continue;

      // Take the greater dimensions.
      outwidth = (width > outwidth) ? width : outwidth;
      outheight = (height > outheight) ? height : outheight;

      gst_util_fraction_to_double (fps_n, fps_d, &fps);

      if (out_fps_d != 0)
        gst_util_fraction_to_double (out_fps_n, out_fps_d, &outfps);

      if (outfps < fps) {
        out_fps_n = fps_n;
        out_fps_d = fps_d;
      }
    }

    GST_OBJECT_UNLOCK (submixer);
  }

  *othercaps = gst_caps_new_empty ();
  length = gst_caps_get_size (caps);

  for (idx = 0; idx < length; idx++) {
    GstStructure *structure = gst_caps_get_structure (caps, idx);
    GstCapsFeatures *features = gst_caps_get_features (caps, idx);
    const GValue *framerate = NULL;
    gint width = 0, height = 0;

    // If this is already expressed by the existing caps skip this structure.
    if (idx > 0 && gst_caps_is_subset_structure_full (*othercaps, structure, features))
      continue;

    // Make a copy that will be modified.
    structure = gst_structure_copy (structure);

    gst_structure_get_int (structure, "width", &width);
    gst_structure_get_int (structure, "height", &height);
    framerate = gst_structure_get_value (structure, "framerate");

    if (!width && !outwidth) {
      gst_structure_set (structure, "width", G_TYPE_INT,
          DEFAULT_VIDEO_WIDTH, NULL);
      GST_DEBUG_OBJECT (submixer, "Width not set, using default value: %d",
          DEFAULT_VIDEO_WIDTH);
    } else if (!width) {
      gst_structure_set (structure, "width", G_TYPE_INT, outwidth, NULL);
      GST_DEBUG_OBJECT (submixer, "Width not set, using extrapolated width "
          "based on the sinkpads: %d", outwidth);
    }

    if (!height && !outheight) {
      gst_structure_set (structure, "height", G_TYPE_INT,
          DEFAULT_VIDEO_HEIGHT, NULL);
      GST_DEBUG_OBJECT (submixer, "Height not set, using default value: %d",
          DEFAULT_VIDEO_HEIGHT);
    } else if (!height) {
      gst_structure_set (structure, "height", G_TYPE_INT, outheight, NULL);
      GST_DEBUG_OBJECT (submixer, "Height not set, using extrapolated height "
          "based on the sinkpads: %d", outheight);
    }

    if (!gst_value_is_fixed (framerate) && (out_fps_n <= 0 || out_fps_d <= 0)) {
      gst_structure_fixate_field_nearest_fraction (structure, "framerate",
          DEFAULT_VIDEO_FPS_NUM, DEFAULT_VIDEO_FPS_DEN);
      GST_DEBUG_OBJECT (submixer, "Frame rate not set, using default value: "
          "%d/%d", DEFAULT_VIDEO_FPS_NUM, DEFAULT_VIDEO_FPS_DEN);
    } else if (!gst_value_is_fixed (framerate)) {
      gst_structure_fixate_field_nearest_fraction (structure, "framerate",
          out_fps_n, out_fps_d);
      GST_DEBUG_OBJECT (submixer, "Frame rate not set, using extrapolated "
          "rate (%d/%d) from the sinkpads", out_fps_n, out_fps_d);
    } else {
      gint fps_n = gst_value_get_fraction_numerator (framerate);
      gint fps_d = gst_value_get_fraction_denominator (framerate);
      gdouble fps = 0.0, outfps = 0.0;

      gst_util_fraction_to_double (fps_n, fps_d, &fps);
      gst_util_fraction_to_double (out_fps_n, out_fps_d, &outfps);

      if (fps != outfps) {
        GST_ERROR_OBJECT (submixer, "Set framerate (%d/%d) is not compatible"
            " with the extrapolated rate (%d/%d) from the sinkpads!", fps_n,
            fps_d, out_fps_n, out_fps_d);
        gst_structure_free (structure);
        gst_caps_unref (*othercaps);
        return GST_FLOW_NOT_SUPPORTED;
      }
    }

    // TODO optimize that to take into account sink pads format.
    // Fixate the format field in case it wasn't already fixated.
    gst_structure_set (structure, "format", G_TYPE_STRING, "NV12", NULL);
    gst_structure_fixate_field (structure, "format");

    framerate = gst_structure_get_value (structure, "framerate");
    submixer->duration = gst_util_uint64_scale_int (GST_SECOND,
        gst_value_get_fraction_denominator (framerate),
        gst_value_get_fraction_numerator (framerate));

    gst_caps_append_structure_full (*othercaps, structure,
        gst_caps_features_copy (features));
  }

  GST_DEBUG_OBJECT (submixer, "Updated caps %" GST_PTR_FORMAT, *othercaps);

  // Applicable for 1.20 version, since the GstAggregator base class is not
  // marking src pad for reconfigure in case NEED_DATA is returned.
  // On older versions, mark reconfigure is already happening but it won't
  // cause any problem since it is just about setting the flag.
  if (!configured)
    gst_pad_mark_reconfigure (GST_AGGREGATOR_SRC_PAD (submixer));

  return configured ? GST_FLOW_OK : GST_AGGREGATOR_FLOW_NEED_DATA;
}

static GstCaps *
gst_subtitle_mixer_fixate_src_caps (GstAggregator * aggregator, GstCaps * caps)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);
  guint idx = 0;

  // Check caps structures for memory:GBM feature.
  for (idx = 0; idx < gst_caps_get_size (caps); idx++) {
    GstCapsFeatures *features = gst_caps_get_features (caps, idx);
  }

  caps = gst_caps_fixate (caps);
  GST_DEBUG_OBJECT (submixer, "Fixated output caps to %" GST_PTR_FORMAT, caps);

  return caps;
}

static gboolean
gst_subtitle_mixer_negotiated_src_caps (GstAggregator * aggregator,
    GstCaps * caps)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);
  GstVideoInfo info;
  gint dar_n = 0, dar_d = 0;

  GST_DEBUG_OBJECT (submixer, "Negotiated caps %" GST_PTR_FORMAT, caps);

  if (!gst_video_info_from_caps (&info, caps)) {
    GST_ERROR_OBJECT (submixer, "Failed to get video info from caps!");
    return FALSE;
  }

  if (!gst_util_fraction_multiply (info.width, info.height,
          info.par_n, info.par_d, &dar_n, &dar_d)) {
    GST_WARNING_OBJECT (submixer, "Failed to calculate DAR!");
    dar_n = dar_d = -1;
  }

  GST_DEBUG_OBJECT (submixer, "Output %dx%d (PAR: %d/%d, DAR: %d/%d), size"
      " %" G_GSIZE_FORMAT, info.width, info.height, info.par_n, info.par_d,
      dar_n, dar_d, info.size);

  if (submixer->outinfo != NULL)
    gst_video_info_free (submixer->outinfo);

  submixer->outinfo = gst_video_info_copy (&info);

  gst_aggregator_set_latency (aggregator, submixer->duration,
      submixer->duration);

  return TRUE;
}

static void
gst_subtitle_mixer_task_loop (gpointer userdata)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (userdata);
  GstDataQueueItem *item = NULL;

  if (gst_data_queue_pop (submixer->requests, &item)) {
    GstConverterRequest *request = NULL;
    GstBuffer *buffer = NULL;
    gboolean success = TRUE;

    // Increase the request reference count to indicate that it is in use.
    request = GST_CONVERTER_REQUEST (gst_mini_object_ref (item->object));
    item->destroy (item);

    // Get time difference between current time and start.
    request->time = GST_CLOCK_DIFF (request->time, gst_util_get_timestamp ());

    GST_LOG_OBJECT (submixer, "Request took %" G_GINT64_FORMAT ".%03"
        G_GINT64_FORMAT " ms", GST_TIME_AS_MSECONDS (request->time),
        (GST_TIME_AS_USECONDS (request->time) % 1000));

    // Increase the buffer reference count to indicate that it is in use.
    buffer = gst_buffer_ref (request->outframe->buffer);
    gst_converter_request_unref (request);

    gst_aggregator_finish_buffer (GST_AGGREGATOR (submixer), buffer);
  } else {
    GST_DEBUG_OBJECT (submixer, "Paused worker thread");
    gst_task_pause (submixer->worktask);
  }
}

static gboolean
gst_subtitle_mixer_start (GstAggregator * aggregator)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);

  if (submixer->worktask != NULL)
    return TRUE;

  submixer->worktask =
      gst_task_new (gst_subtitle_mixer_task_loop, aggregator, NULL);
  GST_INFO_OBJECT (submixer, "Created task %p", submixer->worktask);

  gst_task_set_lock (submixer->worktask, &submixer->worklock);

  if (!gst_task_start (submixer->worktask)) {
    GST_ERROR_OBJECT (submixer, "Failed to start worker task!");
    return FALSE;
  }

  // Disable requests queue in flushing state to enable normal work.
  gst_data_queue_set_flushing (submixer->requests, FALSE);
  return TRUE;
}

static gboolean
gst_subtitle_mixer_stop (GstAggregator * aggregator)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);

  if (NULL == submixer->worktask)
    return TRUE;

  // Set the requests queue in flushing state.
  gst_data_queue_set_flushing (submixer->requests, TRUE);

  if (!gst_task_stop (submixer->worktask))
    GST_WARNING_OBJECT (submixer, "Failed to stop worker task!");

  // Make sure task is not running.
  g_rec_mutex_lock (&submixer->worklock);
  g_rec_mutex_unlock (&submixer->worklock);

  if (!gst_task_join (submixer->worktask)) {
    GST_ERROR_OBJECT (submixer, "Failed to join worker task!");
    return FALSE;
  }

  // Flush converter and requests queue.
  gst_data_queue_flush (submixer->requests);

  GST_INFO_OBJECT (submixer, "Removing task %p", submixer->worktask);

  gst_object_unref (submixer->worktask);
  submixer->worktask = NULL;

  return TRUE;
}

static GstClockTime
gst_subtitle_mixer_get_next_time (GstAggregator * aggregator)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);
  GstSegment *segment = &GST_AGGREGATOR_PAD (aggregator->srcpad)->segment;
  GstClockTime nexttime;

  GST_OBJECT_LOCK (submixer);
  nexttime = (segment->position == GST_CLOCK_TIME_NONE ||
      segment->position < segment->start) ? segment->start : segment->position;

  if (segment->stop != GST_CLOCK_TIME_NONE && nexttime > segment->stop)
    nexttime = segment->stop;

  nexttime = gst_segment_to_running_time (segment, GST_FORMAT_TIME, nexttime);
  GST_OBJECT_UNLOCK (submixer);

  return nexttime;
}

static gboolean
gst_subtitle_mixer_is_eos (GstAggregator * aggregator)
{
  GList *list = NULL;
  gboolean eos = TRUE;

  GST_OBJECT_LOCK (aggregator);

  // Iterate over every sink pad and check whether they reached EOS.
  for (list = GST_ELEMENT (aggregator)->sinkpads; list; list = list->next)
    eos &= gst_aggregator_pad_is_eos (GST_AGGREGATOR_PAD (list->data));

  GST_OBJECT_UNLOCK (aggregator);

  return eos;
}

static GstFlowReturn
gst_subtitle_mixer_transform (GstAggregator * aggregator, GstVideoFrame * inframe, GstVideoFrame * subframe, GstVideoFrame * outframe)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);
  GstMemory *in_mem, *sub_mem, *out_mem;
  GstClockTime time = GST_CLOCK_TIME_NONE;
  GstMapInfo mapinfo;
  GstVideoFormat sub_fmt;
  struct ve_frame_info *veframe_info = NULL;
  struct drm_prime_handle in_prime_handle, sub_prime_handle , out_prime_handle;
  struct drm_gem_close in_gem_close , sub_gem_close, out_gem_close;
  int ret, retry=0,bufBitDepth = 0, sub_format = 39;
  bool ve2_compress = FALSE;
  gint src_y_height;
  gint src_y_width;
  gint sub_y_height;
  gint sub_y_width;
  gint dest_y_height;
  gint dest_y_width;
  gsize in_size, in_offset, in_maxsize;
  gsize sub_size, sub_offset, sub_maxsize;

  gint in_width, in_height;
  gint sub_width, sub_height;

  memset(&in_prime_handle, 0, sizeof(in_prime_handle));
  memset(&out_prime_handle, 0, sizeof(out_prime_handle));
  in_mem = gst_buffer_peek_memory (inframe->buffer, 0);
  out_mem = gst_buffer_peek_memory (outframe->buffer, 0);

  in_prime_handle.fd = gst_dmabuf_memory_get_fd (in_mem);
  out_prime_handle.fd = gst_dmabuf_memory_get_fd (out_mem);
  ret = ioctl (submixer->drmfd, DRM_IOCTL_PRIME_FD_TO_HANDLE, &in_prime_handle);
  if (ret != 0) {
    GST_ERROR_OBJECT (submixer, "DRM_IOCTL_PRIME_FD_TO_HANDLE in fail! Error = (%s)\n", strerror(errno));
  }
  ret = ioctl (submixer->drmfd, DRM_IOCTL_PRIME_FD_TO_HANDLE, &out_prime_handle);
  if (ret != 0) {
    GST_ERROR_OBJECT (submixer, "DRM_IOCTL_PRIME_FD_TO_HANDLE out fail! Error = (%s)\n", strerror(errno));
  }

  src_y_width = GST_VIDEO_FRAME_COMP_WIDTH (inframe, 0);
  src_y_height = GST_VIDEO_FRAME_COMP_HEIGHT (inframe, 0);
  dest_y_width = GST_VIDEO_FRAME_COMP_WIDTH (outframe, 0);
  dest_y_height = GST_VIDEO_FRAME_COMP_HEIGHT (outframe, 0);


  GstVideoMeta *in_meta;
  in_meta = gst_buffer_get_video_meta (inframe->buffer);
  in_width = src_y_width + in_meta->alignment.padding_right + in_meta->alignment.padding_left;
  in_height = src_y_height + in_meta->alignment.padding_top + in_meta->alignment.padding_bottom;
  GST_TRACE_OBJECT (submixer, "src_y_width %d src_y_height %d",src_y_width,src_y_height);
  GST_TRACE_OBJECT (submixer, "src_width %d src_height %d",in_width,in_height);
  GST_TRACE_OBJECT (submixer, "dest_y_width %d dest_y_height %d",dest_y_width,dest_y_height);

  in_size = gst_memory_get_sizes (in_mem, &in_offset, &in_maxsize);
  GST_TRACE_OBJECT (submixer, "in_size %d in_offset %d in_maxsize %d",in_size,in_offset,in_maxsize);
  gst_memory_map (in_mem, &mapinfo, GST_MAP_READ);
  veframe_info = (struct ve_frame_info *)(mapinfo.data - in_offset);
  GST_TRACE_OBJECT (submixer, "veframe_info->yuvs.bufBitDepth %d",veframe_info->yuvs.bufBitDepth);
  if(veframe_info->yuvs.bufBitDepth == 10)
    bufBitDepth = 10;
  if(veframe_info->yuvs.lumaOffTblAddr != 0xffffffff)
    ve2_compress = TRUE;
  gst_memory_unmap (in_mem, &mapinfo);

  if(subframe != NULL) {
    memset(&sub_prime_handle, 0, sizeof(sub_prime_handle));
    sub_mem = gst_buffer_peek_memory (subframe->buffer, 0);
    sub_prime_handle.fd = gst_dmabuf_memory_get_fd (sub_mem);
    ret = ioctl (submixer->drmfd, DRM_IOCTL_PRIME_FD_TO_HANDLE, &sub_prime_handle);
    if (ret != 0) {
      GST_ERROR_OBJECT (submixer, "DRM_IOCTL_PRIME_FD_TO_HANDLE sub fail! Error = (%s)\n", strerror(errno));
    }
    sub_y_width = GST_VIDEO_FRAME_COMP_WIDTH (subframe, 0);
    sub_y_height = GST_VIDEO_FRAME_COMP_HEIGHT (subframe, 0);
    sub_fmt = GST_VIDEO_FRAME_FORMAT(subframe);
    GST_TRACE_OBJECT (submixer, "sub_y_width %d sub_y_height %d",sub_y_width,sub_y_height);
    GST_TRACE_OBJECT (submixer, "sub_width %d sub_height %d",sub_width,sub_height);
    sub_size = gst_memory_get_sizes (sub_mem, &sub_offset, &sub_maxsize);
    GST_TRACE_OBJECT (submixer, "sub_size %d sub_offset %d sub_maxsize %d",sub_size,sub_offset,sub_maxsize);
    switch (sub_fmt) {
      case GST_VIDEO_FORMAT_BGRA:
        sub_format = INBAND_CMD_GRAPHIC_FORMAT_ARGB8888_LITTLE;
        break;
      default:
        GST_LOG_OBJECT (submixer, "Unsupported graphic format");
        break;
    }
  }


  struct rtk_drm_vowb_run_cmd arg = {0};

  arg.pic.src_handle = in_prime_handle.handle; // handle of y_addr & c_addr
  arg.pic.mode = 4;
  arg.pic.y_offset = in_offset;
  arg.pic.c_offset = in_offset + in_width * in_height;
  arg.pic.y_pitch = in_width;
  arg.pic.c_pitch = in_width;

  arg.pic.mode   = CONSECUTIVE_FRAME;
  arg.pic.w      = in_width;
  arg.pic.h      = in_height;
  arg.pic.crop_x = 0;
  arg.pic.crop_y = 0;
  arg.pic.crop_w = src_y_width;
  arg.pic.crop_h = src_y_height;

  arg.pic.wb_handle = out_prime_handle.handle; // handle of wb_y_addr & wb_c_addr
  arg.pic.wb_y_offset = 0;
  arg.pic.wb_c_offset = dest_y_width * dest_y_height;
  arg.pic.wb_pitch = dest_y_width;
  arg.pic.wb_w = dest_y_width;
  arg.pic.wb_h = dest_y_height;


  arg.pic.brightness = 32;
  arg.pic.contrast = 32;
  arg.pic.hue = 32;
  arg.pic.saturation = 32;
  arg.pic.sub_enable = 0;

  arg.pic.target_format = 0; // 0 => NV12
  arg.pic.buf_bit_depth = bufBitDepth;  // 0 => NV12 10 => RTK 10bit

  if(ve2_compress) {
    GST_LOG_OBJECT (submixer, "ve2_compress");
    arg.pic.w = veframe_info->yuvs.width;
    arg.pic.h = veframe_info->yuvs.height;
    arg.pic.y_pitch = veframe_info->yuvs.Y_pitch;
    arg.pic.c_pitch = veframe_info->yuvs.C_pitch;
    arg.pic.tvve_picture_width = veframe_info->yuvs.tvve_picture_width;
    arg.pic.tvve_lossy_en = veframe_info->yuvs.tvve_lossy_en;
    arg.pic.tvve_bypass_en = veframe_info->yuvs.tvve_bypass_en;
    arg.pic.tvve_qlevel_sel_y = veframe_info->yuvs.tvve_qlevel_sel_y;
    arg.pic.tvve_qlevel_sel_c = veframe_info->yuvs.tvve_qlevel_sel_c;
    arg.pic.luma_off_tbl_addr = veframe_info->yuvs.lumaOffTblAddr;
    arg.pic.chroma_off_tbl_addr = veframe_info->yuvs.chromaOffTblAddr;
  }

  arg.pic.transferCharacteristics = veframe_info->yuvs.transferCharacteristics;
  arg.pic.video_full_range_flag = veframe_info->yuvs.video_full_range_flag;
  arg.pic.matrix_coefficients = veframe_info->yuvs.matrix_coefficients;

  if(subframe != NULL) {
    arg.pic.sub_enable = 1;
    arg.pic.sub_handle = sub_prime_handle.handle;
    arg.pic.sub_offset = 0;
    arg.pic.sub_w = sub_y_width;
    arg.pic.sub_h = sub_y_height;
    arg.pic.sub_pitch = sub_y_width * 4;
    arg.pic.sub_format = sub_format;
  }
  else{
    arg.pic.sub_enable = 0;
  }


  ret = ioctl(submixer->drmfd, DRM_IOCTL_RTK_VOWB_RUN_CMD, &arg);
  while (ret < 0) {
    if(retry > 100) {
      GST_ERROR_OBJECT (submixer, "DRM_IOCTL_RTK_VOWB_RUN_CMD retry fail! Error = (%s)\n", strerror(errno));
      return GST_FLOW_ERROR;
    }
    usleep(10000);
    GST_LOG_OBJECT (submixer, "DRM_IOCTL_RTK_VOWB_RUN_CMD retry %d fail! Error = (%s)\n",++retry, strerror(errno));
    ret = ioctl(submixer->drmfd, DRM_IOCTL_RTK_VOWB_RUN_CMD, &arg);
  }
  struct rtk_drm_vowb_check_cmd check_arg = { .job_id = arg.job_id, .flags = RTK_DRM_VOWB_FLAGS_CHECK_CMD_BLOCK, };

  ret = ioctl(submixer->drmfd, DRM_IOCTL_RTK_VOWB_CHECK_CMD, &check_arg);
  retry = 0;
  while (ret || check_arg.job_done != 1) {
    if(retry > 100) {
      GST_ERROR_OBJECT (submixer, "DRM_IOCTL_RTK_VOWB_CHECK_CMD retry fail! Error = (%s)\n", strerror(errno));
      return GST_FLOW_ERROR;
    }
    usleep(10000);
    GST_LOG_OBJECT (submixer, "DRM_IOCTL_RTK_VOWB_CHECK_CMD retry %d fail! Error = (%s)\n",++retry, strerror(errno));
    ret = ioctl(submixer->drmfd, DRM_IOCTL_RTK_VOWB_CHECK_CMD, &check_arg);
  }

  memset(&in_gem_close, 0, sizeof(in_gem_close));
  memset(&out_gem_close, 0, sizeof(out_gem_close));
  in_gem_close.handle = in_prime_handle.handle;
  out_gem_close.handle = out_prime_handle.handle;
  if (ioctl(submixer->drmfd, DRM_IOCTL_GEM_CLOSE, &in_gem_close) < 0) {
    GST_ERROR_OBJECT (submixer, "DRM_IOCTL_GEM_CLOSE in_gem fail! Error = (%s)\n", strerror(errno));
  }

  if (ioctl(submixer->drmfd, DRM_IOCTL_GEM_CLOSE, &out_gem_close) < 0) {
    GST_ERROR_OBJECT (submixer, "DRM_IOCTL_GEM_CLOSE out_gem fail! Error = (%s)\n", strerror(errno));
  }

  if(subframe != NULL) {
    memset(&sub_gem_close, 0, sizeof(sub_gem_close));
    sub_gem_close.handle = sub_prime_handle.handle;
    if (ioctl(submixer->drmfd, DRM_IOCTL_GEM_CLOSE, &sub_gem_close) < 0) {
      GST_ERROR_OBJECT (submixer, "DRM_IOCTL_GEM_CLOSE sub_gem fail! Error = (%s)\n", strerror(errno));
    }
  }

  return GST_FLOW_OK;
}

static GstFlowReturn
gst_subtitle_mixer_aggregate (GstAggregator * aggregator, gboolean timeout)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);
  GstConverterRequest *request = NULL;
  GstDataQueueItem *item = NULL;
  gboolean success = FALSE;

  if (timeout && (NULL == submixer->outinfo))
    return GST_AGGREGATOR_FLOW_NEED_DATA;

  // Check whether all pads have reached EOS.
  if (gst_subtitle_mixer_is_eos (aggregator))
    return GST_FLOW_EOS;

  request = gst_converter_request_new (submixer->n_inputs);


  // Get start time for performance measurements.
  request->time = gst_util_get_timestamp ();

  GList *list = NULL;
  gboolean is_gap = FALSE;
  gboolean is_video = FALSE;
  guint idx = 0, num = 0;
  //GstVideoFrame *inframe;

  GST_OBJECT_LOCK (submixer);

  // Extrapolate the highest width, height and frame rate from the sink pads.
  for (list = GST_ELEMENT (submixer)->sinkpads; list; list = list->next, idx++) {
    GstSubtitleMixerSinkPad *sinkpad = GST_SUBTITLE_MIXER_SINKPAD (list->data);
    GstVideoFrame *inframe = &(g_array_index (request->inframes, GstVideoFrame, idx));

    if (gst_aggregator_pad_is_eos (GST_AGGREGATOR_PAD (sinkpad)))
      continue;

    if (!gst_subtitle_mixer_prepare_input_frame (submixer, sinkpad, inframe, idx)) {
      GST_TRACE_OBJECT (submixer, "Failed to prepare input frame!");
      GST_OBJECT_UNLOCK (submixer);
      return FALSE;
    }
    // GAP input buffer, nothing to do.
    if (inframe->buffer == NULL)
      continue;
    if(idx == 0)
      is_video = TRUE;
    num++;
  }

  GST_OBJECT_UNLOCK (submixer);
  GST_DEBUG_OBJECT (submixer, "Submitted request inframe num: %d idx %d", num, idx);

  if (!gst_subtitle_mixer_prepare_output_frame (submixer, request->outframe, is_gap)) {
    GST_ERROR_OBJECT (submixer, "Failed to prepae output frame!");
    return FALSE;
  }
  if(num == 2)
  {
    gst_subtitle_mixer_transform(submixer, &(g_array_index (request->inframes, GstVideoFrame, 0)), &(g_array_index (request->inframes, GstVideoFrame, 1)), request->outframe);
  }
  else if(is_video)
  {
    if(submixer->subframe) {
      GST_LOG_OBJECT (submixer, "submixer->ref_frame");
      GstVideoFrame subframe;
      if (!gst_video_frame_map (&subframe, submixer->subframe_info, submixer->subframe,
          GST_MAP_READ | GST_VIDEO_FRAME_MAP_FLAG_NO_REF)) {
        GST_ERROR_OBJECT (submixer, "Failed to map sub buffer!");
        gst_buffer_unref (submixer->subframe);
      } else {
        gst_subtitle_mixer_transform(submixer, &(g_array_index (request->inframes, GstVideoFrame, 0)), &subframe, request->outframe);
      }
      gst_video_frame_unmap(&subframe);
    }
    else
      gst_subtitle_mixer_transform(submixer, &(g_array_index (request->inframes, GstVideoFrame, 0)), NULL, request->outframe);
  }

  item = g_slice_new0 (GstDataQueueItem);
  item->object = GST_MINI_OBJECT (request);
  item->visible = TRUE;
  item->destroy = gst_data_queue_item_free;

  // Push the request into the queue or free it on failure.
  if (!gst_data_queue_push (submixer->requests, item)) {
    item->destroy (item);
    return GST_FLOW_OK;
  }

  return GST_FLOW_OK;
}

static GstFlowReturn
gst_subtitle_mixer_flush (GstAggregator * aggregator)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (aggregator);

  GST_INFO_OBJECT (submixer, "Flushing subframe");

  if(submixer->subframe)
    gst_buffer_unref (submixer->subframe);

  if (submixer->subframe_info != NULL)
    gst_video_info_free (submixer->subframe_info);

  return GST_FLOW_OK;
}

static GstPad*
gst_subtitle_mixer_request_pad (GstElement * element, GstPadTemplate * templ,
    const gchar * reqname, const GstCaps * caps)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (element);
  GstPad *pad = NULL;

  pad = GST_ELEMENT_CLASS (parent_class)->request_new_pad
      (element, templ, reqname, caps);

  if (pad == NULL) {
    GST_ERROR_OBJECT (element, "Failed to create sink pad!");
    return NULL;
  }

  GST_OBJECT_LOCK (submixer);

  // Extract the pad index field from its name.
  GST_SUBTITLE_MIXER_SINKPAD (pad)->index =
      g_ascii_strtoull (&GST_PAD_NAME (pad)[5], NULL, 10);

  submixer->n_inputs = element->numsinkpads;

  GST_OBJECT_UNLOCK (submixer);

  GST_DEBUG_OBJECT (submixer, "Created pad: %s", GST_PAD_NAME (pad));

  gst_child_proxy_child_added (GST_CHILD_PROXY (element), G_OBJECT (pad),
      GST_OBJECT_NAME (pad));

  return pad;
}

static void
gst_subtitle_mixer_release_pad (GstElement * element, GstPad * pad)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (element);

  GST_DEBUG_OBJECT (submixer, "Releasing pad: %s", GST_PAD_NAME (pad));

  GST_OBJECT_LOCK (submixer);
  submixer->n_inputs = element->numsinkpads - 1;
  GST_OBJECT_UNLOCK (submixer);

  if (0 == submixer->n_inputs) {
    GstSegment *segment =
        &GST_AGGREGATOR_PAD (GST_AGGREGATOR (submixer)->srcpad)->segment;
    segment->position = GST_CLOCK_TIME_NONE;
  }

  gst_child_proxy_child_removed (GST_CHILD_PROXY (submixer), G_OBJECT (pad),
      GST_OBJECT_NAME (pad));

  GST_ELEMENT_CLASS (parent_class)->release_pad (GST_ELEMENT (submixer), pad);

  gst_pad_mark_reconfigure (GST_AGGREGATOR_SRC_PAD (submixer));
}

static void
gst_subtitle_mixer_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (object);

  GST_SUBTITLE_MIXER_LOCK (submixer);

  switch (prop_id) {
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }

  GST_SUBTITLE_MIXER_UNLOCK (submixer);
}

static void
gst_subtitle_mixer_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (object);

  GST_SUBTITLE_MIXER_LOCK (submixer);

  switch (prop_id) {
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }

  GST_SUBTITLE_MIXER_UNLOCK (submixer);
}

static void
gst_subtitle_mixer_finalize (GObject * object)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (object);
  int ret, param=0;

  if (submixer->requests != NULL) {
    gst_data_queue_set_flushing (submixer->requests, TRUE);
    gst_data_queue_flush (submixer->requests);
    gst_object_unref (GST_OBJECT_CAST(submixer->requests));
  }

  if (submixer->outpool != NULL) {
    gst_buffer_pool_set_active (submixer->outpool, FALSE);
    gst_object_unref (submixer->outpool);
  }

  if (submixer->outinfo != NULL)
    gst_video_info_free (submixer->outinfo);

  close(submixer->drmfd);

  if(submixer->subframe)
    gst_buffer_unref (submixer->subframe);

  if(submixer->subframe_info != NULL)
    gst_video_info_free (submixer->subframe_info);

  g_rec_mutex_clear (&submixer->worklock);
  g_mutex_clear (&submixer->lock);

  G_OBJECT_CLASS (parent_class)->finalize (G_OBJECT (submixer));
}

static gboolean
queue_is_full_cb (GstDataQueue * queue, guint visible, guint bytes,
                  guint64 time, gpointer checkdata)
{
  return (visible >= GST_submixer_MAX_QUEUE_LEN) ? TRUE : FALSE;
}

static void
gst_subtitle_mixer_class_init (GstSubtitleMixerClass * klass)
{
  GObjectClass *gobject = G_OBJECT_CLASS (klass);
  GstElementClass *element = GST_ELEMENT_CLASS (klass);
  GstAggregatorClass *aggregator = GST_AGGREGATOR_CLASS (klass);

  GST_DEBUG_CATEGORY_INIT (gst_subtitle_mixer_debug, "rtksubtitlemixer", 0,
      "rtksubtitlemixer");

  gobject->finalize = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_finalize);
  gobject->set_property = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_set_property);
  gobject->get_property = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_get_property);

  gst_element_class_set_static_metadata (element,
      "rtksubtitlemixer", "Video/Compositor/Scaler",
      "Mix together multiple video streams", "rtksubtitlemixer");

  gst_element_class_add_pad_template (element,
      gst_subtitle_mixer_sink_template ());
  gst_element_class_add_pad_template (element,
      gst_subtitle_mixer_src_template ());

  element->request_new_pad = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_request_pad);
  element->release_pad = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_release_pad);

  aggregator->propose_allocation =
      GST_DEBUG_FUNCPTR (gst_subtitle_mixer_propose_allocation);
  aggregator->decide_allocation =
      GST_DEBUG_FUNCPTR (gst_subtitle_mixer_decide_allocation);
  aggregator->sink_query = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_sink_query);
  aggregator->sink_event = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_sink_event);
  aggregator->src_event = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_src_event);
  aggregator->src_query = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_src_query);
  aggregator->update_src_caps =
      GST_DEBUG_FUNCPTR (gst_subtitle_mixer_update_src_caps);
  aggregator->fixate_src_caps =
      GST_DEBUG_FUNCPTR (gst_subtitle_mixer_fixate_src_caps);
  aggregator->negotiated_src_caps =
      GST_DEBUG_FUNCPTR (gst_subtitle_mixer_negotiated_src_caps);
  aggregator->start = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_start);
  aggregator->stop = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_stop);
  aggregator->get_next_time =
      GST_DEBUG_FUNCPTR (gst_subtitle_mixer_get_next_time);
  aggregator->aggregate = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_aggregate);
  aggregator->flush = GST_DEBUG_FUNCPTR (gst_subtitle_mixer_flush);
}

static void
gst_subtitle_mixer_init (GstSubtitleMixer * submixer)
{
  g_mutex_init (&submixer->lock);
  g_rec_mutex_init (&submixer->worklock);

  submixer->n_inputs = 0;

  submixer->outinfo = NULL;
  submixer->outpool = NULL;
  submixer->subframe = NULL;
  submixer->subframe_info = NULL;

  submixer->duration = GST_CLOCK_TIME_NONE;

  submixer->worktask = NULL;
  submixer->requests =
      gst_data_queue_new (queue_is_full_cb, NULL, NULL, submixer);

  submixer->drmfd =  drmOpen("realtek",NULL);
  if (drmDropMaster(submixer->drmfd) < 0) {
      GST_DEBUG_OBJECT (submixer, "drmDropMaster failed; currently not the master.");
  } else {
      GST_DEBUG_OBJECT (submixer, "drmDropMaster");
  }

  int ret;
  guint64 features = 0;
  ret = ioctl(submixer->drmfd, DRM_IOCTL_RTK_VOWB_GET_FEATURES, &features);
  if (ret != 0) {
    GST_ERROR_OBJECT (submixer, "DRM_IOCTL_RTK_VOWB_GET_FEATURES fail! Error = (%s)\n", strerror(errno));
    close(submixer->drmfd);
    return;
  }

  if((features & RTK_DRM_VOWB_FEATURE_VIDEO_OSD_MIX_SUPPORT) == 0) {
    GST_ERROR_OBJECT (submixer, "cheapset not support video osd mix.\n");
    close(submixer->drmfd);
    return;
  }

  GST_AGGREGATOR_PAD (GST_AGGREGATOR (submixer)->srcpad)->segment.position =
      GST_CLOCK_TIME_NONE;
}


static GObject *
gst_subtitle_mixer_child_proxy_get_child_by_index (GstChildProxy * proxy,
    guint index)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (proxy);
  GList *list = NULL;
  GObject *gobject = NULL;

  GST_OBJECT_LOCK (submixer);

  if (list != NULL)
    gobject = gst_object_ref (list->data);

  GST_OBJECT_UNLOCK (submixer);

  return gobject;
}

static guint
gst_subtitle_mixer_child_proxy_get_children_count (GstChildProxy * proxy)
{
  GstSubtitleMixer *submixer = GST_SUBTITLE_MIXER (proxy);
  guint count = 0;

  GST_OBJECT_LOCK (submixer);
  count = GST_ELEMENT_CAST (submixer)->numsinkpads;
  GST_OBJECT_UNLOCK (submixer);

  return count;
}

static void
gst_subtitle_mixer_child_proxy_init (gpointer g_iface, gpointer data)
{
  GstChildProxyInterface *iface = (GstChildProxyInterface *) g_iface;

  iface->get_child_by_index = gst_subtitle_mixer_child_proxy_get_child_by_index;
  iface->get_children_count = gst_subtitle_mixer_child_proxy_get_children_count;
}

static gboolean
plugin_init (GstPlugin * plugin)
{
  return gst_element_register (plugin, "rtksubtitlemixer", GST_RANK_PRIMARY,
          GST_TYPE_SUBTITLE_MIXER);
}

#ifndef VERSION
#define VERSION "0.0.FIXME"
#endif
#ifndef PACKAGE
#define PACKAGE "FIXME_package"
#endif
#ifndef PACKAGE_NAME
#define PACKAGE_NAME "FIXME_package_name"
#endif
#ifndef GST_PACKAGE_ORIGIN
#define GST_PACKAGE_ORIGIN "http://FIXME.org/"
#endif

GST_PLUGIN_DEFINE (GST_VERSION_MAJOR, GST_VERSION_MINOR,
    rtksubtitlemixer, "rtksubtitlemixer", plugin_init,
    VERSION, "LGPL", PACKAGE_NAME, GST_PACKAGE_ORIGIN)
