#ifndef __GST_SUBTITLE_MIXER_SINKPAD_H__
#define __GST_SUBTITLE_MIXER_SINKPAD_H__

#include <gst/gst.h>
#include <gst/base/gstaggregator.h>
#include <gst/video/video.h>

G_BEGIN_DECLS

#define GST_TYPE_SUBTITLE_MIXER_SINKPAD \
  (gst_subtitle_mixer_sinkpad_get_type())
#define GST_SUBTITLE_MIXER_SINKPAD(obj) \
  (G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_SUBTITLE_MIXER_SINKPAD,\
                              GstSubtitleMixerSinkPad))
#define GST_SUBTITLE_MIXER_SINKPAD_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_CAST((klass),GST_TYPE_SUBTITLE_MIXER_SINKPAD,\
                           GstSubtitleMixerSinkPadClass))
#define GST_IS_SUBTITLE_MIXER_SINKPAD(obj) \
  (G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_TYPE_SUBTITLE_MIXER_SINKPAD))
#define GST_IS_SUBTITLE_MIXER_SINKPAD_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_TYPE((klass),GST_TYPE_SUBTITLE_MIXER_SINKPAD))
#define GST_SUBTITLE_MIXER_SINKPAD_CAST(obj) ((GstSubtitleMixerSinkPad *)(obj))

#define GST_SUBTITLE_MIXER_SINKPAD_GET_LOCK(obj) \
  (&GST_SUBTITLE_MIXER_SINKPAD(obj)->lock)
#define GST_SUBTITLE_MIXER_SINKPAD_LOCK(obj) \
  g_mutex_lock(GST_SUBTITLE_MIXER_SINKPAD_GET_LOCK(obj))
#define GST_SUBTITLE_MIXER_SINKPAD_UNLOCK(obj) \
  g_mutex_unlock(GST_SUBTITLE_MIXER_SINKPAD_GET_LOCK(obj))

typedef struct _GstSubtitleMixerSinkPad GstSubtitleMixerSinkPad;
typedef struct _GstSubtitleMixerSinkPadClass GstSubtitleMixerSinkPadClass;

struct _GstSubtitleMixerSinkPad {
  /// Inherited parent structure.
  GstAggregatorPad        parent;

  /// Global mutex lock.
  GMutex                  lock;

  /// Sink pad index.
  guint                   index;
  /// Negotiated caps on the pad input parsed to video info.
  GstVideoInfo            *info;
};

struct _GstSubtitleMixerSinkPadClass {
  /// Inherited parent structure.
  GstAggregatorPadClass parent;
};

GType gst_subtitle_mixer_sinkpad_get_type (void);

gboolean
gst_subtitle_mixer_sinkpad_setcaps (GstAggregatorPad * sinkpad,
                                    GstAggregator * aggregator,
                                    GstCaps * caps);

gboolean
gst_subtitle_mixer_sinkpad_acceptcaps (GstAggregatorPad * sinkpad,
                                       GstAggregator * aggregator,
                                       GstCaps * caps);

GstCaps *
gst_subtitle_mixer_sinkpad_getcaps (GstAggregatorPad * sinkpad,
                                    GstAggregator * aggregator,
                                    GstCaps * filter);

G_END_DECLS

#endif // __GST_SUBTITLE_MIXER_SINKPAD_H__
