#ifndef __GST_RTK_SUBTITLE_MIXER_H__
#define __GST_RTK_SUBTITLE_MIXER_H__

#include <gst/gst.h>
#include <gst/base/gstaggregator.h>
#include <gst/base/gstdataqueue.h>
#include <gst/video/video.h>

G_BEGIN_DECLS

#define GST_TYPE_SUBTITLE_MIXER \
  (gst_subtitle_mixer_get_type())
#define GST_SUBTITLE_MIXER(obj) \
  (G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_SUBTITLE_MIXER,GstSubtitleMixer))
#define GST_SUBTITLE_MIXER_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_CAST((klass),GST_TYPE_SUBTITLE_MIXER,GstSubtitleMixerClass))
#define GST_IS_SUBTITLE_MIXER(obj) \
  (G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_TYPE_SUBTITLE_MIXER))
#define GST_IS_SUBTITLE_MIXER_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_TYPE((klass),GST_TYPE_SUBTITLE_MIXER))
#define GST_SUBTITLE_MIXER_CAST(obj)       ((GstSubtitleMixer *)(obj))

#define GST_SUBTITLE_MIXER_GET_LOCK(obj) (&GST_SUBTITLE_MIXER(obj)->lock)
#define GST_SUBTITLE_MIXER_LOCK(obj) \
  g_mutex_lock(GST_SUBTITLE_MIXER_GET_LOCK(obj))
#define GST_SUBTITLE_MIXER_UNLOCK(obj) \
  g_mutex_unlock(GST_SUBTITLE_MIXER_GET_LOCK(obj))

typedef struct _GstSubtitleMixer GstSubtitleMixer;
typedef struct _GstSubtitleMixerClass GstSubtitleMixerClass;

struct _GstSubtitleMixer {
  GstAggregator        parent;

  /// Global mutex lock.
  GMutex               lock;

  /// Number of sink pads.
  guint                n_inputs;

  /// Output pad caps.
  GstVideoInfo         *outinfo;
  /// Output buffer pool.
  GstBufferPool        *outpool;

  /// Output buffer duration.
  GstClockTime         duration;

  /// Worker task.
  GstTask              *worktask;
  /// Worker task mutex.
  GRecMutex            worklock;
  /// Worker queue.
  GstDataQueue         *requests;

  guint                drmfd;

  GstBuffer            *subframe;
  GstVideoInfo         *subframe_info;

};

struct _GstSubtitleMixerClass {
  GstAggregatorClass parent;
};

G_GNUC_INTERNAL GType gst_subtitle_mixer_get_type (void);

G_END_DECLS

#endif // __GST_RTK_SUBTITLE_MIXER_H__