/* GStreamer
 *
 * Copyright (C) 2025
 *
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 *
 */

#ifndef __GST_KMS_SINK_H__
#define __GST_KMS_SINK_H__

#include <gst/video/gstvideosink.h>
#include <gst/video/video-hdr.h>

G_BEGIN_DECLS

#define GST_TYPE_RTKNVR_SINK \
  (gst_rtk_nvr_sink_get_type())
#define GST_KMS_SINK(obj) \
  (G_TYPE_CHECK_INSTANCE_CAST((obj), GST_TYPE_RTKNVR_SINK, GstRTKNVRSink))
#define GST_KMS_SINK_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_CAST((klass), GST_TYPE_RTKNVR_SINK, GstRTKNVRSinkClass))
#define GST_IS_KMS_SINK(obj) \
  (G_TYPE_CHECK_INSTANCE_TYPE((obj), GST_TYPE_RTKNVR_SINK))
#define GST_IS_KMS_SINK_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_TYPE((klass), GST_TYPE_RTKNVR_SINK))

#define MAX_QUEUE_SIZE 16
#define FRAME_KEEP 2

typedef struct _GstRTKNVRSink GstRTKNVRSink;
typedef struct _GstRTKNVRSinkClass GstRTKNVRSinkClass;

struct _GstRTKNVRSink {
  GstVideoSink videosink;

  /*< private >*/
  gint fd;
  gint conn_id;
  gint crtc_id;
  guint pipe;

  /* crtc data */
  guint16 hdisplay, vdisplay;
  guint32 buffer_id;

  /* capabilities */
  gboolean has_prime_import;
  gboolean has_prime_export;

  GstVideoInfo vinfo; //obtain from caps
  GstCaps *allowed_caps;
  GstBufferPool *pool;
  GstAllocator *allocator;
  GstVideoInfo last_vinfo;
  guint last_width;
  guint last_height;
  GstBuffer *last_buffer;
  gchar *devname;
  GstPoll *poll;
  GstPollFD pollfd;

  /* render video rectangle */
  GstVideoRectangle vowb_rect;

  guint frameNumberW;

  /* reconfigure info if driver doesn't scale */
  gboolean reconfigure;

  gboolean is_internal_fd;
  pthread_t fenceThread;
  gboolean fenceThreadStarted;
  gboolean fenceThreadStopRequested;
  guint fencefd[MAX_QUEUE_SIZE];
  GstBuffer *buffer[MAX_QUEUE_SIZE];
  int fencefd_index_first;
  int fencefd_index_last;
  int fencefd_queue_size;
  pthread_mutex_t fence_mutex;
  gint channel_id;
};

struct _GstRTKNVRSinkClass {
  GstVideoSinkClass parent_class;
};

GType gst_rtk_nvr_sink_get_type (void) G_GNUC_CONST;
GST_ELEMENT_REGISTER_DECLARE (rtknvrsink);
G_END_DECLS

#endif /* __GST_KMS_SINK_H__ */
