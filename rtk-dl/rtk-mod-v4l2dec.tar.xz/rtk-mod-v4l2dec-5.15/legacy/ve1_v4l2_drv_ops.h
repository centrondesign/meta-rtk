/*
 * Realtek video decoder v4l2 driver
 *
 * Copyright (c) 2024 Realtek Semiconductor Corp. All rights reserved.
 *
 * SPDX-License-Identifier: LicenseRef-Realtek-Proprietary
 *
 * This software component is confidential and proprietary to Realtek
 * Semiconductor Corp. Disclosure, reproduction, redistribution, in whole
 * or in part, of this work and its derivatives without express permission
 * is prohibited.
 */
#ifndef __VE1_V4L2_DRV_OPS__
#define __VE1_V4L2_DRV_OPS__

#include <linux/fs.h>
#include <linux/types.h>
#include "ve1.h"

#if IS_ENABLED(CONFIG_RTK_PRINCE_VE1)
extern int prince_vdi_ioctl_get_instance_pool(vpudrv_buffer_t *vdb);
extern int prince_vdi_ioctl_get_register_info(vpudrv_buffer_t *vdb);
extern int prince_vdi_ioctl_set_rtk_clk_gating(vpu_clock_info_t* clockInfo);
extern int prince_vdi_ioctl_get_common_memory(vpudrv_buffer_t *vdb);
extern ssize_t prince_vdi_write_bit_firmware(vpu_bit_firmware_info_t *buf, size_t len);
extern int prince_vdi_ioctl_allocate_physical_memory(void *filp, vpudrv_buffer_t *vdb);
extern int prince_vdi_ioctl_free_physical_memory(vpudrv_buffer_t *vdb);
extern int prince_vdi_ioctl_allocate_physical_memory_no_mmap(void *filp, vpudrv_buffer_t *vdb);
extern int prince_vdi_ioctl_free_physical_memory_no_mmap(vpudrv_buffer_t *vdb);
extern int prince_vdi_ioctl_open_instance(void *filp, vpudrv_inst_info_t *inst_info);
extern int prince_vdi_ioctl_close_instance(vpudrv_inst_info_t *inst_info);
extern int prince_vdi_ioctl_wait_interrupt(vpudrv_intr_info_t *intr_info);
#endif

#if IS_ENABLED(CONFIG_RTK_KENT_VE1)
extern int kent_vdi_ioctl_get_instance_pool(vpudrv_buffer_t *vdb);
extern int kent_vdi_ioctl_get_register_info(vpudrv_buffer_t *vdb);
extern int kent_vdi_ioctl_set_rtk_clk_gating(vpu_clock_info_t* clockInfo);
extern int kent_vdi_ioctl_get_common_memory(vpudrv_buffer_t *vdb);
extern ssize_t kent_vdi_write_bit_firmware(vpu_bit_firmware_info_t *buf, size_t len);
extern int kent_vdi_ioctl_allocate_physical_memory(void *filp, vpudrv_buffer_t *vdb);
extern int kent_vdi_ioctl_free_physical_memory(vpudrv_buffer_t *vdb);
extern int kent_vdi_ioctl_allocate_physical_memory_no_mmap(void *filp, vpudrv_buffer_t *vdb);
extern int kent_vdi_ioctl_free_physical_memory_no_mmap(vpudrv_buffer_t *vdb);
extern int kent_vdi_ioctl_open_instance(void *filp, vpudrv_inst_info_t *inst_info);
extern int kent_vdi_ioctl_close_instance(vpudrv_inst_info_t *inst_info);
extern int kent_vdi_ioctl_wait_interrupt(vpudrv_intr_info_t *intr_info);
#endif

#if IS_ENABLED(CONFIG_RTD16XXB_VE1_CODEC)
extern int rtd16xxb_vdi_ioctl_get_instance_pool(vpudrv_buffer_t *vdb);
extern int rtd16xxb_vdi_ioctl_get_register_info(vpudrv_buffer_t *vdb);
extern int rtd16xxb_vdi_ioctl_set_rtk_clk_gating(vpu_clock_info_t* clockInfo);
extern int rtd16xxb_vdi_ioctl_get_common_memory(vpudrv_buffer_t *vdb);
extern ssize_t rtd16xxb_vdi_write_bit_firmware(vpu_bit_firmware_info_t *buf, size_t len);
extern int rtd16xxb_vdi_ioctl_allocate_physical_memory(void *filp, vpudrv_buffer_t *vdb);
extern int rtd16xxb_vdi_ioctl_free_physical_memory(vpudrv_buffer_t *vdb);
extern int rtd16xxb_vdi_ioctl_allocate_physical_memory_no_mmap(void *filp, vpudrv_buffer_t *vdb);
extern int rtd16xxb_vdi_ioctl_free_physical_memory_no_mmap(vpudrv_buffer_t *vdb);
extern int rtd16xxb_vdi_ioctl_open_instance(void *filp, vpudrv_inst_info_t *inst_info);
extern int rtd16xxb_vdi_ioctl_close_instance(vpudrv_inst_info_t *inst_info);
extern int rtd16xxb_vdi_ioctl_wait_interrupt(vpudrv_intr_info_t *intr_info);
#endif
#endif