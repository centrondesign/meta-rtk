/*
 * Realtek video decoder v4l2 driver
 *
 * Copyright (c) 2021 Realtek Semiconductor Corp.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 and
 * only version 2 as published by the Free Software Foundation.
 */
#ifndef __DRV_IF_H__
#define __DRV_IF_H__

#include <linux/sched.h>
#include <linux/pid.h>
#include <linux/debugfs.h>
#include <media/v4l2-device.h>
#include <media/v4l2-ctrls.h>
#include "ve1_v4l2_drv_ops.h"

#define CODEC_VERSION "1.1.20"

#define RTK_V4L2_SET_SECURE (V4L2_CID_USER_REALTEK_BASE + 0)
#define RTK_V4L2_DEC_SET_ENHANCE (V4L2_CID_USER_REALTEK_BASE + 1)
#define RTK_V4L2_DEC_GET_INFO (V4L2_CID_USER_REALTEK_BASE + 2)

enum RTK_ENHANCE_MODE {
	RTK_DISABLE_ENHANCE,
	RTK_ENABLE_ENHANCE,
	RTK_AUTO_ENHANCE,
};

struct videc_dev {
	struct v4l2_device v4l2_dev;
	struct video_device video_dev[2];

	struct mutex dev_mutex;
	struct mutex ve1_hw_mutex;

	struct v4l2_m2m_dev *m2m_dev;
	struct device *dev;
	struct dentry *debugfs_root;

	uint32_t enhance_mode;

	void *ve1_devinfo; /* struct rtkve1_dev_info */
	void __iomem *ve1_register;
	struct workqueue_struct *encode_workqueue;
	u32 ve1_instance_nums; /* total instance number including ve1 decoder and encoder */
	const struct rtkve_match_data *ve_data;
	u8 *ve1fw_binary;
	u32 ve1fw_size_in_word;

	atomic_t ve1_num_inst;
	atomic_t ve2_num_inst;

	struct list_head instances;
	struct list_head enc_instances;
};

struct rtk_dec_params {
	//Colorimetry
	uint32_t matrix_coefficients;
	uint32_t range;
	uint32_t transfer_characteristics;
	uint32_t primaries;

	uint8_t en_adaptive_playback;
	uint8_t en_pts_reorder;
	uint32_t enhance_mode; // 0:Disable (Default), 1:Enable, 2:Auto(Bigger than 2K Enable)
};

struct videc_params {
	uint8_t is_secure;

	struct v4l2_ctrl_hdr10_mastering_display mastering;
	struct v4l2_ctrl_hdr10_cll_info cll;
	struct rtk_dec_params dec_params;
};

struct videc_ctx {
	/* RTKDEV_FOURCC_ENC or RTKDEV_FOURCC_DEC for distinguish priv in device_run() */
	u32 rtkdev_fourcc;
	struct v4l2_fh fh;
	struct videc_dev *dev;

	void *file; /* struct file */
	void *vpu_ctx; /* context of vpu */
	void *ve_ctx; /* context of video engine */

	int reqbuf_out;
	int reqbuf_cap;
	bool is_sub_res_chg;
	bool has_stream_on;
	bool params_update;
	bool support_gpu_cache;
	pid_t pid;
	char comm[TASK_COMM_LEN];

	struct v4l2_ctrl_handler ctrl_hdl;
	struct videc_params params;

	struct list_head list;
};

struct rtkve1_drv_ops {
	int (*get_instance_pool)(vpudrv_buffer_t *vdb);
	int (*get_register_info)(vpudrv_buffer_t *vdb);
	int (*set_rtk_clk_gating)(vpu_clock_info_t* clockInfo);
	int (*get_common_memory)(vpudrv_buffer_t *vdb);
	ssize_t (*write_bit_firmware)(vpu_bit_firmware_info_t *buf, size_t len);
	int (*allocate_physical_memory)(void *filp, vpudrv_buffer_t *vdb);
	int (*free_physical_memory)(vpudrv_buffer_t *vdb);
	int (*allocate_physical_memory_no_mmap)(void *filp, vpudrv_buffer_t *vdb);
	int (*free_physical_memory_no_mmap)(vpudrv_buffer_t *vdb);
	int (*open_instance)(void *filp, vpudrv_inst_info_t *inst_info);
	int (*close_instance)(vpudrv_inst_info_t *inst_info);
	int (*wait_interrupt)(vpudrv_intr_info_t *intr_info);
};

enum rtk_product {
	RTK_STARK,
	RTK_KENT,
	RTK_PRINCE
};

struct rtkve_match_data {
	enum rtk_product product;
	const char *fw_name;
	struct rtkve1_drv_ops drv_ops;
	bool gpu_cache;
};

#ifdef VPU_GET_CC
int cc_data_channel_init(void);
void cc_data_channel_exit(void);
void cc_data_channel_send(char *message, int total_size, int pid);
bool cc_isCCReaderReady(void);
bool cc_isCCInit(void);
__u32 cc_getCCReaderPid(void);
#endif
#endif
