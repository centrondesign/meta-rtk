#ifndef __RTKVE4_ENC_COMMON_H__
#define __RTKVE4_ENC_COMMON_H__

#include <linux/debugfs.h>
#include <media/v4l2-device.h> // for struct v4l2_device, struct video_device
#include <media/v4l2-ctrls.h> // for struct v4l2_ctrl_handler
#include <media/v4l2-fh.h> // for struct v4l2_fh
#include <media/v4l2-ioctl.h>
#include <media/v4l2-mem2mem.h>
#include <media/v4l2-event.h>
#include "rtkve4enc_drv.h"
#include "ve4.h"

#define RTKVE4_ENC_DEV_NAME "rtkve4-enc"

#define RTKVE4_CMD_TRAFFIC 0x3020

//#define VDI_LITTLE_ENDIAN 0

#define VE4_BWB_ENABLE 1
#define VPU_ALIGN4096(_x)           (((_x)+0xfff)&~0xfff)

#define WAVE627ENC_WORKBUF_SIZE         (256*1024)
#define BS_BUF_SIZE (4 * 1024)
#define RTKVE4_ENC_HEADER_TEMP_BUF_SIZE 256
#define VUI_HRD_RBSP_BUF_SIZE           0x4000
#define SEI_NAL_DATA_BUF_SIZE           0x4000


#define RTKVE4_ENC_TIMEOUT 1000 /* ms */
#define RTKVE4_MAX_FRAME_BUFFERS 32

#define	HEADER_H264_SPS	0
#define	HEADER_H264_PPS	1

#define WAVE6_DEC_HEVC_MVCOL_BUF_SIZE(_w, _h)    ((ALIGN(_w, 256)/16)*(ALIGN(_h, 64)/16)*1*16)
#define WAVE6_DEC_AVC_MVCOL_BUF_SIZE(_w, _h)     ((ALIGN(_w, 64)/16)*(ALIGN(_h, 16)/16)*5*16)
#define WAVE6_DEC_VP9_MVCOL_BUF_SIZE(_w, _h)     ((ALIGN(_w, 64)/64)*(ALIGN(_h, 64)/64)*32*16 + (ALIGN(_w, 256)/256)*(ALIGN(_h, 64)/64)*16*16)
#define WAVE6_DEC_AV1_MVCOL_BUF_SIZE(_w, _h)     (((ALIGN(_w, 64)/64*16*16) + (ALIGN(_w, 256)/64*8*16))*ALIGN(_h, 64)/64 + (ALIGN(_w, 128)/64)*(ALIGN(_h, 128)/64)*4*128 + 656*16)
#define WAVE6_AV1_DEFAULT_CDF_BUF_SIZE           (48*1024)
#define WAVE6_VP9_SEGMAP_BUF_SIZE(_w, _h)        ((ALIGN(_w, 64)/64)*((ALIGN(_h, 64)/64)*64)
#define WAVE6_FBC_LUMA_TABLE_SIZE(_w, _h)        (ALIGN(_w, 256)*(ALIGN(_h, 64)/32))
#define WAVE6_FBC_CHROMA_TABLE_SIZE(_w, _h)      (ALIGN(_w/2, 256)*(ALIGN(_h, 64)/32))
#define WAVE6_ENC_AV1_MVCOL_BUF_SIZE             (12*1024)
#define WAVE6_ENC_AVC_MVCOL_BUF_SIZE(_w, _h)     ((ALIGN(_w, 512)/512)*(ALIGN(_h, 16)/16)*16)
#define WAVE6_ENC_HEVC_MVCOL_BUF_SIZE(_w, _h)    ((ALIGN(_w, 64)/64)*((ALIGN(_h, 64)/64)*128))
#define WAVE6_ENC_SUBSAMPLED_SIZE(_w, _h)        (ALIGN(_w/4, 16)*ALIGN(_h/4, 32))

#define MAX_GDI_IDX      31
#define MAX_REG_FRAME    (MAX_GDI_IDX*2) // 2 for WTL

#define USE_SRC_PRP_AXI         0
#define DEFAULT_SRC_AXI         USE_SRC_PRP_AXI

#define DISPLAY_IDX_FLAG_SEQ_END     -1
#define DISPLAY_IDX_FLAG_NO_FB       -3
#define DECODED_IDX_FLAG_NO_FB       -1
#define DECODED_IDX_FLAG_SKIP        -2
#define DECODED_IDX_FLAG_FLUSHED     -3

#define RECON_IDX_FLAG_ENC_END       -1
#define RECON_IDX_FLAG_ENC_DELAY     -2
#define RECON_IDX_FLAG_HEADER_ONLY   -3
#define RECON_IDX_FLAG_CHANGE_PARAM  -4

#define MAX_ROI_NUMBER  10

typedef u64 PhysicalAddress;

// new COD_STD since WAVE series
enum {
    W_HEVC_DEC  = 0x00,
    W_HEVC_ENC  = 0x01,
    W_AVC_DEC   = 0x02,
    W_AVC_ENC   = 0x03,
    W_VP9_DEC   = 0x16,
    W_AVS2_DEC  = 0x18,
    W_AV1_DEC   = 0x1A,
    W_AV1_ENC   = 0x1B,
    STD_UNKNOWN = 0xFF
};

/**
 * @brief   This is a special enumeration type for NAL unit coding options
*/
typedef enum {
    CODEOPT_ENC_HEADER_IMPLICIT = (1 << 0), /**< A flag to encode (a) headers (VPS, SPS, PPS) implicitly for generating bitstreams conforming to spec. */
    CODEOPT_ENC_VCL             = (1 << 1), /**< A flag to encode VCL nal unit explicitly */
} ENC_PIC_CODE_OPTION;


/**
 * @brief   This is a special enumeration type for explicit encoding headers such as VPS, SPS, PPS. (WAVE encoder only)
*/
enum WaveEncHeaderType {
    CODEOPT_ENC_VPS = (1 << 2), /**< A flag to encode VPS nal unit explicitly */
    CODEOPT_ENC_SPS = (1 << 3), /**< A flag to encode SPS nal unit explicitly */
    CODEOPT_ENC_PPS = (1 << 4), /**< A flag to encode PPS nal unit explicitly */
} ;

enum {
	INT_BIT_INIT = 0,
	INT_BIT_SEQ_INIT = 1,
	INT_BIT_SEQ_END = 2,
	INT_BIT_PIC_RUN = 3,
	INT_BIT_FRAMEBUF_SET = 4,
	INT_BIT_ENC_HEADER = 5,
	INT_BIT_DEC_PARA_SET = 7,
	INT_BIT_DEC_BUF_FLUSH = 8,
	INT_BIT_USERDATA = 9,
	INT_BIT_DEC_FIELD = 10,
#ifdef SUPPORT_CDB
	INT_BIT_DEBUFFER = 12,
#endif
	INT_BIT_DEC_MB_ROWS = 13,
	INT_BIT_BIT_BUF_EMPTY = 14,
	INT_BIT_BIT_BUF_FULL = 15
};

// BIT_RUN command
enum { DEC_SEQ_INIT = 1,
       ENC_SEQ_INIT = 1,
       DEC_SEQ_END = 2,
       ENC_SEQ_END = 2,
       PIC_RUN = 3,
       SET_FRAME_BUF = 4,
       ENCODE_HEADER = 5,
       ENC_PARA_SET = 6,
       DEC_PARA_SET = 7,
       DEC_BUF_FLUSH = 8,
       RC_CHANGE_PARAMETER = 9,
       VPU_SLEEP = 10,
       VPU_WAKE = 11,
       ENC_ROI_INIT = 12,
       FIRMWARE_GET = 0xf };

enum sw_reset_mode {
	SW_RESET_SAFETY, /**< It resets VPU in safe way. It waits until pending bus transaction is completed and then perform reset. */
	SW_RESET_FORCE, /**< It forces to reset VPU without waiting pending bus transaction to be completed. It is used for immediate termination such as system off. */
	SW_RESET_ON_BOOT /**< This is the default reset mode that is executed since system booting.  This mode is actually executed in VPU_Init(), so does not have to be used independently. */
};


#define W_MIN_ENC_PIC_WIDTH             256U
#define W_MIN_ENC_PIC_HEIGHT            128U
#define W_MAX_ENC_PIC_WIDTH             8192U
#define W_MAX_ENC_PIC_HEIGHT            8192U

#define RAW_MIN_ENC_PIC_WIDTH 256U
#define RAW_MIN_ENC_PIC_HEIGHT 128U
#define RAW_MAX_ENC_PIC_WIDTH 8192U
#define RAW_MAX_ENC_PIC_HEIGHT 8192U

#define ENC_PIC_SIZE_STEP 1

#define DEFAULT_FRAMERATE_NUM 30000
#define DEFAULT_FRAMERATE_DENOM 1000
#define DEFAULT_GOP 30
#define DEFAULT_I_FRAME_QP 30

#define MIN_BITRATE (64 * 1024)
#define MAX_BITRATE (50000 * 1024)
#define DEF_BITRATE (20000 * 1024)

#define MAX_GOP_NUM  8
#define MAX_CUSTOM_LAMBDA_NUM             52
#define MAX_NUM_CHANGEABLE_TEMPORAL_LAYER 4

struct vpu_format {
	unsigned int v4l2_pix_fmt;
	unsigned int max_width;
	unsigned int min_width;
	unsigned int max_height;
	unsigned int min_height;
	unsigned int num_planes;
};

enum vpu_fmt_type { VPU_FMT_TYPE_CODEC = 0, VPU_FMT_TYPE_RAW = 1 };

enum rtkve4_enc_state {
	RTK_VE4_STATE_ENC_IDLE = 0,
	RTK_VE4_STATE_ENC_OPEN,
	RTK_VE4_STATE_ENC_SEQ_INIT,
	RTK_VE4_STATE_ENC_REG_FBS,
	RTK_VE4_STATE_ENC_HEADER,
	RTK_VE4_STATE_ENC_PIC,
	RTK_VE4_STATE_ENC_SEQ_END,
	RTK_VE4_STATE_ENC_TIMEOUT
};

typedef enum {
/**
@verbatim
Linear frame map type

NOTE: Products earlier than CODA9 can only set this linear map type.
@endverbatim
*/
    LINEAR_FRAME_MAP                            = 0,  /**< Linear frame map type */
    TILED_FRAME_V_MAP                           = 1,  /**< Tiled frame vertical map type (CODA9 only) */
    TILED_FRAME_H_MAP                           = 2,  /**< Tiled frame horizontal map type (CODA9 only) */
    TILED_FIELD_V_MAP                           = 3,  /**< Tiled field vertical map type (CODA9 only) */
    TILED_MIXED_V_MAP                           = 4,  /**< Tiled mixed vertical map type (CODA9 only) */
    TILED_FRAME_MB_RASTER_MAP                   = 5,  /**< Tiled frame MB raster map type (CODA9 only) */
    TILED_FIELD_MB_RASTER_MAP                   = 6,  /**< Tiled field MB raster map type (CODA9 only) */
    TILED_FRAME_NO_BANK_MAP                     = 7,  /**< Tiled frame no bank map. (CODA9 only) */ // coda980 only
    TILED_FIELD_NO_BANK_MAP                     = 8,  /**< Tiled field no bank map. (CODA9 only) */ // coda980 only
    LINEAR_FIELD_MAP                            = 9,  /**< Linear field map type. (CODA9 only) */ // coda980 only
    CODA_TILED_MAP_TYPE_MAX                     = 10,
    COMPRESSED_FRAME_MAP_V50_LOSSLESS_8BIT      = 11, /**< CFRAME50(Chips&Media Frame Buffer Compression) compressed framebuffer type */
    COMPRESSED_FRAME_MAP_V50_LOSSLESS_10BIT     = 12, /**< CFRAME50(Chips&Media Frame Buffer Compression) compressed framebuffer type */
    COMPRESSED_FRAME_MAP_V50_LOSSY              = 13, /**< CFRAME50(Chips&Media Frame Buffer Compression) compressed framebuffer type */
    COMPRESSED_FRAME_MAP_V50_LOSSLESS_422_8BIT  = 14, /**< CFRAME50(Chips&Media Frame Buffer Compression) compressed 4:2:2 framebuffer type */
    COMPRESSED_FRAME_MAP_V50_LOSSLESS_422_10BIT = 15, /**< CFRAME50(Chips&Media Frame Buffer Compression) compressed 4:2:2 framebuffer type */
    COMPRESSED_FRAME_MAP_V50_LOSSY_422          = 16, /**< CFRAME50(Chips&Media Frame Buffer Compression) compressed 4:2:2 framebuffer type */
    PVRIC_COMPRESSED_FRAME_MAP                  = 17, /**< PVRIC compressed frame map type (WAVE6 Encoder only) */
    COMPRESSED_FRAME_MAP                        = 18, /**< Compressed frame map type (WAVE only) */
    COMPRESSED_FRAME_MAP_DUAL_CORE_8BIT         = 19, /**< 8bit compressed frame map type for dual core */
    COMPRESSED_FRAME_MAP_DUAL_CORE_10BIT        = 20, /**< 10bit compressed frame map type for dual core */
    PVRIC_COMPRESSED_FRAME_LOSSLESS_MAP         = 21, /**< PVRIC compressed frame map type for lossless mode (WAVE Decoder only) */
    PVRIC_COMPRESSED_FRAME_LOSSY_MAP            = 22, /**< PVRIC compressed frame map type for lossy mode (WAVE Decoder only) */
    COMPRESSED_FRAME_MAP_DUAL_CORE_MCTS_8BIT    = 23, /**< 8bit compressed frame map type for dual core mcts mode*/
    COMPRESSED_FRAME_MAP_DUAL_CORE_MCTS_10BIT   = 24, /**< 10bit compressed frame map type for dual core mcts mode*/
    COMPRESSED_FRAME_MAP_RRB_8BIT               = 25, /**< 8bit compressed frame map type for reference ring buffer mode */
    ARM_COMPRESSED_FRAME_MAP_V12                = 27, /**< AFBC(ARM Frame Buffer Compression) V1.2 compressed frame map type for AFBC decoding. (WAVE6 Encoder only) */
    ARM_COMPRESSED_FRAME_MAP_V12E               = 28, /**< AFBC(ARM Frame Buffer Compression) V1.2 compressed frame map type for AFBC encoding. (WAVE6 Decoder only) */
    TILED_MAP_TYPE_MAX
} TiledMapType;

/**
* @brief    This is an enumeration type for representing AUX buffer type.
*/
typedef enum {
    AUX_BUF_FBC_Y_TBL, /**< The luma offset table buffer for compressed frame. */
    AUX_BUF_FBC_C_TBL, /**< The chroma offset table buffer for compressed frame. */
    AUX_BUF_MV_COL, /**< The co-located motion vector buffer. */
    AUX_BUF_DEF_CDF, /**< The default CDF buffer. (AV1 only) */
    AUX_BUF_SEG_MAP, /**< The segmentation feature buffer. (VP9 only) */
    AUX_BUF_MV_COL_PRE_ENT, /**< The co-located motion vector buffer for pre-entropy. (AV1, VP9 only) */
    AUX_BUF_SUB_SAMPLE, /**< The sub-sampled buffer for motion estimation. (Encoder only) */
    AUX_BUF_TYPE_MAX,
} AuxBufferType;

struct rtkve4enc_params {
	u32 framerate_num;
	u32 framerate_denom;
	u32 framerate;
	u32 bitrate;
	u32 bitrate_mode;
	u32 gop_size;
	u32 header_with_frm;
	u32 force_key_frm;
	u32 h264_profile_idc;
	u32 h264_level_idc;
	s32 intra_qp;
	u32 transform_8x8_mode;
	u32 field_flag;
	u32 field_ref_mode;
	u32 entropy_coding_mode;
	u32 s_ctrl_level_value;
	bool frame_rc_enable;
};

struct EncInitialInfo{
    int             minFrameBufferCount; /**< Minimum number of frame buffer */
    int             minSrcFrameCount;    /**< Minimum number of source buffer */
    int             reqMvColBufferCount; /**< This is the number of MV col buffers required for encoding. Applications must allocate as many as this number of MV col buffers and register the number of buffers to VPU using VPU_EncRegisterAuxBuffer() before encoding pictures. (WAVE6 only) */
    int             maxLatencyPictures;  /**< Maximum number of picture latency */
    int             seqInitErrReason;    /**< Error information */
    int             warnInfo;            /**< Warn information */
    u32             vlcBufSize; /**< The size of task buffer */
    u32             paramBufSize; /**< The size of task buffer */
};

struct enc_cmd_set_param_reg {
    u32 enable;
    u32 src_size;
    u32 custom_map_endian;
    u32 sps_param;
    u32 pps_param;
    u32 gop_param;
    u32 intra_param;
    u32 conf_win_top_bot;
    u32 conf_win_left_right;
    u32 rdo_param;
    u32 slice_param;
    u32 intra_refresh;
    u32 intra_min_max_qp;
    u32 rc_frame_rate;
    u32 rc_target_rate;
    u32 rc_param;
    u32 hvs_param;
    u32 rc_max_bitrate;
    u32 rc_vbv_buffer_size;
    u32 inter_min_max_qp;
    u32 rot_param;
    u32 num_units_in_tick;
    u32 time_scale;
    u32 num_ticks_poc_diff_one;
    u32 max_intra_pic_bit;
    u32 max_inter_pic_bit;
    u32 bg_param;
    u32 non_vcl_param;
    u32 vui_rbsp_addr;
    u32 hrd_rbsp_addr;
    u32 qround_offset;
    u32 quant_param_1;
    u32 quant_param_2;
    u32 custom_gop_param;
    u32 custom_gop_pic_param[MAX_GOP_NUM];
    u32 tile_param;
    u32 custom_lambda[MAX_CUSTOM_LAMBDA_NUM];
    u32 temporal_layer_qp[MAX_NUM_CHANGEABLE_TEMPORAL_LAYER];
    u32 sfs_param;
    u32 ref_ring_buf_param;
    u32 color_param;
};

struct enc_cmd_set_fb_reg {
    u32 option;
    u32 pic_info;
    u32 pic_size;
    u32 num_fb;
    u32 fbc_stride;
    u32 fbc_y[MAX_GDI_IDX];
    u32 fbc_c[MAX_GDI_IDX];
    u32 fbc_y_offset[MAX_GDI_IDX];
    u32 fbc_c_offset[MAX_GDI_IDX];
    u32 mv_col[MAX_GDI_IDX];
    u32 sub_sampled[MAX_GDI_IDX];
    u32 default_cdf;
    u32 fbc_y_end;
    u32 fbc_c_end;
};

struct enc_cmd_enc_pic_reg {
    u32 bs_start;
    u32 bs_size;
    u32 bs_option;
    u32 use_sec_axi;
    u32 report_param;
    u32 mv_histo_class0;
    u32 mv_histo_class1;
    u32 custom_map_param;
    u32 custom_map_addr;
    u32 src_pic_idx;
    u32 src_addr_y;
    u32 src_addr_u;
    u32 src_addr_v;
    u32 src_size_y;
    u32 src_size_u;
    u32 src_size_v;
    u32 src_stride;
    u32 src_format;
    u32 src_axi_sel;
    u32 code_option;
    u32 pic_param;
    u32 longterm_pic;
    u32 prefix_sei_nal_addr;
    u32 prefix_sei_info;
    u32 suffix_sei_nal_addr;
    u32 suffix_sei_info;
    u32 cf50d_ctrl;
    u32 cf50d_ofst_base_y;
    u32 cf50d_ofst_base_cb;
    u32 cf50d_ofst_base_cr;
    u32 irb_cf50d_ofst_curr_y;
    u32 irb_cf50d_ofst_curr_cb;
    u32 irb_cf50d_ofst_curr_cr;
    u32 irb_cf50d_ofst_end_y;
    u32 irb_cf50d_ofst_end_cb;
    u32 irb_cf50d_ofst_end_cr;
    u32 timestamp;
    u32 sfs_buf_idx;
    u32 irb_curr_y;
    u32 irb_curr_cb;
    u32 irb_curr_cr;
    u32 irb_end_y;
    u32 irb_end_cb;
    u32 irb_end_cr;
};

/**
* @brief This structure is used for reporting FME SUM. (WAVE6 only)
*/
struct EncReportFmeSum{
    u32 lowerX0;  /**< L0 FME 32x32 mv_x sum lower. */
    u32 higherX0; /**< L0 FME 32x32 mv_x sum higher. */
    u32 lowerY0;  /**< L0 FME 32x32 mv_y sum lower. */
    u32 higherY0; /**< L0 FME 32x32 mv_y sum higher. */
    u32 lowerX1;  /**< L1 FME 32x32 mv_x sum lower. */
    u32 higherX1; /**< L1 FME 32x32 mv_x sum higher. */
    u32 lowerY1;  /**< L1 FME 32x32 mv_y sum lower. */
    u32 higherY1; /**< L1 FME 32x32 mv_y sum higher. */
} ;

/**
* @brief This structure is used for reporting MV histogram. (WAVE6 only)
*/
struct EncReportMvHisto{
    u32 cnt0; /**< The count number of MV histogram accumulated for class 0. */
    u32 cnt1; /**< The count number of MV histogram accumulated for class 1. */
    u32 cnt2; /**< The count number of MV histogram accumulated for class 2. */
    u32 cnt3; /**< The count number of MV histogram accumulated for class 3. */
    u32 cnt4; /**< The count number of MV histogram accumulated for class 4. */
} ;

/**
* @brief This structure is used for reporting picture average variance. (WAVE6 only)
*/
struct EncReportPicAvgRcVar{
    u32 lower; /**< An average value of variance lower. */
    u32 higher; /**< An average value of variance higher. */
} ;

/**
* @brief This structure is used for reporting sum of MV magnitude. (WAVE6 only)
*/
struct EncReportMvMagSum{
    u32 l0Lower; /**< Sum of MV magnitude in List0 lower. */
    u32 l0Higher; /**< Sum of MV magnitude in List0 higher. */
    u32 l1Lower; /**< Sum of MV magnitude in List1 lower. */
    u32 l1Higher; /**< Sum of MV magnitude in List1 higher. */
} ;

/**
* @brief    This is a data structure of Timestamp. (WAVE6 only)
*/
struct TimestampInfo{
    u32 hour; /**< It specifies the hour of timestamp. */
    u32 min;  /**< It specifies the minute of timestamp. */
    u32 sec;  /**< It specifies the second of timestamp. */
    u32 ms;   /**< It specifies the millisecond of timestamp. */
};

/**
* @brief    This is a data structure for reporting cycle information. (WAVE6 only)
*/
struct ReportCycle{
    u32  hostCmdStartTick;    /**< Start Tick of DEC_PIC/ENC_PIC host command for the picture */
    u32  hostCmdEndTick;      /**< End tick of DEC_PIC/ENC_PIC host command for the picture (until host get the result for the picture) */
    u32  processingStartTick; /**< Start tick of processing hw block for the picture */
    u32  processingEndTick;   /**< End tick of processing hw block for the picture */
    u32  vpuStartTick;        /**< Start tick of decoding/encoding for the picture */
    u32  vpuEndTick;          /**< End tick of decoding/encoding for the picture */
    u32  frameCycle;          /**< The total cycle of host command for the picture */
    u32  processingCycle;     /**< The total cycle of processing for the picture */
    u32  vpuCycle;            /**< The total cycle of decoding/encoding for the picture except processing cycle */
    u32  preProcessingStartTick; /**< Start tick of pre-processing hw block for the picture */
    u32  preProcessingEndTick;   /**< End tick of pre-processing hw block for the picture */
    u32  preVpuStartTick;        /**< Start tick of pre-decoding/encoding for the picture */
    u32  preVpuEndTick;          /**< End tick of pre-decoding/encoding for the picture */
    u32  preProcessingCycle;     /**< The total cycle of pre-processing for the picture */
    u32  preVpuCycle;            /**< The total cycle of pre-decoding/encoding for the picture except pre-processing cycle */
} ;

struct EncOutputInfo{
/**
@verbatim
The physical address of the starting point of newly encoded picture stream

If dynamic buffer allocation is enabled in line-buffer mode, this value is
identical with the specified picture stream buffer address by HOST.
@endverbatim
*/
    PhysicalAddress bitstreamBuffer;
    u32 bitstreamSize;   /**< The byte size of encoded bitstream */
    int bitstreamWrapAround;/**< This is a flag to indicate that the write point is wrapped around in bitsteam buffer in case of ring buffer mode. If this flag is 1 in line buffer mode, it indicates fullness of bitstream buffer. Then HOST application needs a larger bitstream buffer. */
    int picType;            /**< <<vpuapi_h_PicType>> */
    int numOfSlices;        /**< The number of slices of the currently being encoded Picture  */
    int reconFrameIndex;    /**< A reconstructed frame index. The reconstructed frame can be used for reference of future frame.  */
//    FrameBuffer reconFrame; /**< A reconstructed frame address and information. Please refer to <<vpuapi_h_FrameBuffer>>.  */
    PhysicalAddress rdPtr;  /**< A read pointer in bitstream buffer, which is where HOST has read encoded bitstream from the buffer */
    PhysicalAddress wrPtr;  /**< A write pointer in bitstream buffer, which is where VPU has written encoded bitstream into the buffer  */
    int picSkipped;         /**< A flag which represents whether the current encoding has been skipped or not. (WAVE5 only) */
    int numOfIntra;         /**< The number of intra coded block (WAVE5 HEVC only) */
    int numOfMerge;         /**< The number of merge block in 8x8 (WAVE5 HEVC only) */
    int numOfSkipBlock;     /**< The number of skip block in 8x8 (WAVE5 HEVC only) */
    int avgCtuQp;           /**< The average value of CTU QPs (WAVE5 only) */
    int encPicByte;         /**< The number of encoded picture bytes (WAVE5 only)  */
    int encGopPicIdx;       /**< The GOP index of the currently encoded picture (WAVE5 only) */
    int encPicPoc;          /**< The POC(picture order count) value of the currently encoded picture (WAVE5 only) */
    int releaseSrcFlag;     /**< The source buffer indicator of the encoded pictures(WAVE5 only) */
    int encSrcIdx;          /**< The source buffer index of the currently encoded picture (WAVE5, WAVE6) */
    int encVclNut;          /**< The VCL NAL unit type of the currently encoded picture(WAVE5 only). For more information, refer to the RET_QUERY_ENC_VCL_NUT register in programmer's guide. */
    int encPicCnt;          /**< The encoded picture number (WAVE5 only) */
    int errorReason;        /**< The error reason of the currently encoded picture (WAVE5 only) */
    int warnInfo;           /**< The warning information of the currently encoded picture (WAVE5 only) */
    // Report Information
//    EncReportInfo mbInfo;   /**< The parameter for reporting MB data(CODA9 only) . Please refer to <<vpuapi_h_EncReportInfo>> structure. */
//    EncReportInfo mvInfo;   /**< The parameter for reporting motion vector(CODA9 only). Please refer to <<vpuapi_h_EncReportInfo>> structure. */
//    EncReportInfo sliceInfo;/**< The parameter for reporting slice information(CODA9 only). Please refer to <<vpuapi_h_EncReportInfo>> structure. */
    int frameCycle;         /**< The parameter for reporting the cycle number of encoding one frame.*/
    u64 pts;             /**< The PTS(Presentation Timestamp) of the encoded picture which is retrieved and managed from VPU API */
    u32 encHostCmdTick;       /**< Tick of ENC_PIC command for the picture */
    u32 encPrepareStartTick;  /**< Start tick of preparing slices of the picture */
    u32 encPrepareEndTick;    /**< End tick of preparing slices of the picture  */

    u32 prepareCycle;   /**< The number of cycles for preparing slices of a picture */
    u32 processing;     /**< The number of cycles for processing slices of a picture */
    u32 EncodedCycle;   /**< The number of cycles for encoding slices of a picture */
    struct ReportCycle cycle; /**< Refer to <<vpuapi_h_ReportCycle>>. (WAVE6 only) */

    u32 picDistortionLow;  /**< The 32bit lowest difference value(SSD) between an original block and a reconstructed block in the encoded picture. It can be an indicator for image quality. Host cannot tune quality by using this value, because this value is not an input parameter, but a reporting value. */
    u32 picDistortionHigh; /**< The 32bit highest difference value(SSD) between an original block and a reconstructed block in the encoded picture. It can be an indicator for image quality. Host cannot tune quality by using this value, because this value is not an input parameter, but a reporting value. */
    PhysicalAddress reportNalSizeAddr; /**< It specifies the address of nal size report. */
    bool nonRefPicFlag; /**< It indicates whether the current picture is used for reference picture or not. (WAVE6 only) */
    struct EncReportFmeSum reportFmeSum; /**< <<vpuapi_h_EncReportFmeSum>>. (WAVE6 only) */
    struct EncReportMvHisto reportMvHisto; /**< <<vpuapi_h_EncReportMvHisto>>. (WAVE6 only) */
    struct EncReportPicAvgRcVar reportPicAvgRcVar; /**< <<vpuapi_h_EncReportPicAvgRcVar>>. (WAVE6 only) */
    struct EncReportMvMagSum reportMvMagSum; /**< <<vpuapi_h_EncReportMvMagSum>>. (WAVE6 only) */
    struct TimestampInfo timestamp; /**< It indicates the Timestamp parameter. (WAVE6 only) <<vpuapi_h_TimestampInfo>> */
    PhysicalAddress sourceYAddr; /**< The base address of the source buffer for Y component. (WAVE6 only) */
    PhysicalAddress customMapAddr; /**< The base address of the custom map buffer. (WAVE6 only) */
    PhysicalAddress prefixSeiNalAddr; /**< The base address of the prefix SEI NAL buffer. (WAVE6 only) */
    PhysicalAddress suffixSeiNalAddr; /**< The base address of the suffix SEI NAL buffer. (WAVE6 only) */
};


struct rtkve4_buf {
	void *vaddr;
	dma_addr_t paddr;
	u32 size;
	struct debugfs_blob_wrapper blob;
	struct dentry *dentry;
};

struct rtkve4_dev_info {
	struct rtkve4_buf codebuf;
	struct rtkve4_buf parabuf;
	struct rtkve4_buf tempbuf;
};


struct rtkve4enc_ctx {
	/* RTKDEV_FOURCC_ENC or RTKDEV_FOURCC_DEC for distinguish priv in device_run() */
	u32 rtkdev_fourcc;
	u32 inst_index;
	struct videc_dev *dev;
	struct v4l2_fh v4l2_fh;
	struct v4l2_ctrl_handler v4l2_ctrl_hdl;
	struct v4l2_pix_format_mplane src_fmt;
	struct v4l2_pix_format_mplane dst_fmt;
	const struct rtkve4_context_ops *ops;
	struct dentry *debugfs_entry;
	struct work_struct encode_work;
	struct vpudrv_buffer_t regs;
	struct v4l2_m2m_buffer empty_last_buf;

	enum v4l2_colorspace colorspace;
	enum v4l2_xfer_func xfer_func;
	enum v4l2_ycbcr_encoding ycbcr_enc;
	enum v4l2_quantization quantization;

	struct v4l2_rect crop; /* cropping rectangle for input */

	u32 src_buf_addr;
	u32 src_buf_size;
	u32 src_buf_width;
	u32 src_buf_height;

	u32 codec_mode;
	struct rtkve4enc_params enc_params;
	struct EncInitialInfo initialInfo;
	struct rtkve4_buf bitstream;
	struct rtkve4_buf workbuf;
	struct rtkve4_buf vbVuiRbsp;
	struct rtkve4_buf vbHrdRbsp;
	struct rtkve4_buf vbTemp;
	struct rtkve4_buf vbAr;
	struct rtkve4_buf vbSecAxi;
	struct rtkve4_buf framebuf[RTKVE4_MAX_FRAME_BUFFERS];
    struct rtkve4_buf vbMV[MAX_REG_FRAME];        //!< colMV buffer (WAVE encoder)
    struct rtkve4_buf vbFbcYTbl[MAX_REG_FRAME];   //!< FBC Luma table buffer (WAVE encoder)
    struct rtkve4_buf vbFbcCTbl[MAX_REG_FRAME];   //!< FBC Chroma table buffer (WAVE encoder)
    struct rtkve4_buf vbSubSamBuf[MAX_REG_FRAME]; //!< Sub-sampled buffer for ME (WAVE encoder)
    struct rtkve4_buf vbDefCdf;
	struct EncOutputInfo OutInfo;
	u8 frame_addr[RTKVE4_MAX_FRAME_BUFFERS][3][4];

	enum rtkve4_enc_state enc_state;
	enum WaveEncHeaderType headerType;
	int open_encoder_done;
	int seq_init_done;
	int reg_fbs_done;
	int enc_header_done;
	int enc_pic_done;
	int seq_end_done;
	int stopping;
	bool eos;
	bool hdr_enc_flag;
	bool encodeVuiRbsp;
	bool encodeHrdRbsp;
	bool stateDoing;
	bool useEncRdoEnable;
	bool useEncLfEnable;
	bool enc_initialized;
	bool out_streamon;
	bool cap_streamon;

	u32 rdPtr;
	u32 wrPtr;
	u32 bsSize;
	u32 enc_min_fb_num;
	u32 queued_src_buf_num;
	u32 queued_dst_buf_num;
	int reqbuf_cnt_out;
	int reqbuf_cnt_cap;

	void *enc_hdr_buf;
	u32 enc_hdr_buf_size;
	u32 enc_hdr_bytes;

	int outbuf_new_file;
	void *outbuf_fp;
	unsigned char outbuf_file_name[256];
	int enc_bs_new_file;
	void *enc_bs_fp;
	unsigned char enc_bs_file_name[256];
};

struct rtkve4_context_ops {
	const struct vpu_format *(*find_vpu_fmt)(unsigned int v4l2_pix_fmt,
		enum vpu_fmt_type type);
	const struct vpu_format *(*find_vpu_fmt_by_idx)(unsigned int idx,
		enum vpu_fmt_type type);
	int (*queue_init)(void *priv, struct vb2_queue *src_vq,
		struct vb2_queue *dst_vq);
	int (*ctrls_setup)(struct rtkve4enc_ctx *inst);
	int (*create_encoder)(struct rtkve4enc_ctx *ctx, struct v4l2_requestbuffers *rb);
//	int (*decide_state)(struct rtkve4enc_ctx *ctx, enum rtkve4_enc_state *new_state);
	int (*open_encoder)(struct rtkve4enc_ctx *ctx);
	int (*seq_init)(struct rtkve4enc_ctx *ctx);
	int (*reg_fbs)(struct rtkve4enc_ctx *ctx);
//	int (*enc_header)(struct rtkve4enc_ctx *ctx);
	int (*enc_pic)(struct rtkve4enc_ctx *ctx);
	void (*seq_end)(struct rtkve4enc_ctx *ctx);
	void (*run_timeout)(struct rtkve4enc_ctx *ctx);
};

void rtkve_set_default_format(struct rtkve4enc_ctx *inst,
		struct v4l2_pix_format_mplane *src_fmt,
		struct v4l2_pix_format_mplane *dst_fmt);

extern struct v4l2_ioctl_ops rtkve4enc_ioctl_ops;
extern const struct rtkve4_context_ops rtkve4enc_ops;

static inline struct rtkve4enc_ctx *v4l2fh_to_ctx(struct v4l2_fh *vfh)
{
	return container_of(vfh, struct rtkve4enc_ctx, v4l2_fh);
}

int rtkve4_md5_hash(unsigned char *result, int resultLen, char *data, int dataLen);
int rtkve4_alloc_dma_memory(struct videc_dev *dev, struct rtkve4_buf *buf,
        size_t size, const char *name, struct dentry *parent);
void rtkve4_free_dma_memory(struct videc_dev *dev,
        struct rtkve4_buf *buf, const char *name);
int rtkve4_get_sram_memory(struct videc_dev *dev, struct rtkve4_buf *vb);
void rtkve4_parabuf_write(struct rtkve4enc_ctx *ctx, int index, u32 value);
int rtkve4_write_memory(struct videc_dev *dev,
    void *vaddr, size_t bufsize,
    size_t offset, u8 *data, int len, int endian);
int rtkve4_read_memory(struct videc_dev *dev,
    void *vaddr, size_t bufsize,
    size_t offset, u8 *data, int len, int endian);
void rtkve4_reg_writel(struct videc_dev *dev, unsigned int addr,
		     unsigned int data);
unsigned int rtkve4_reg_readl(struct videc_dev *dev, u32 addr);
void rtkve4_wrap_reg_writel(struct videc_dev *dev, unsigned int addr,
		     unsigned int data);
unsigned int rtkve4_wrap_reg_readl(struct videc_dev *dev, u32 addr);
void rtkve4_issue_command(struct rtkve4enc_ctx *ctx, u32 cmd);
int rtkve4_wait_interrupt(struct rtkve4enc_ctx *ctx, unsigned int timeout);
void rtkve4_clear_interrupt(struct rtkve4enc_ctx *ctx);
int rtkve4_wait_busy(struct videc_dev *dev, unsigned int addr);
int rtkve4_initialize(struct rtkve4enc_ctx *ctx);
int rtkve4_finalize(struct rtkve4enc_ctx *ctx);

#endif // #define __RTKVE4_ENC_COMMON_H__
