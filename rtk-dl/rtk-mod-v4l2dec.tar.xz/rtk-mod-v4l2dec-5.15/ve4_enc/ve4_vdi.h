//------------------------------------------------------------------------------
// File: ve1_vdi.h
//
// Copyright (c) 2006, Chips & Media.  All rights reserved.
//------------------------------------------------------------------------------

#ifndef _VDI_H_
#define _VDI_H_

/************************************************************************/
/* COMMON REGISTERS                                                     */
/************************************************************************/
#define VPU_PRODUCT_NAME_REGISTER (0x90)
#define VPU_PRODUCT_CODE_REGISTER (0x94)

#define MAX_VPU_CORE_NUM MAX_NUM_VPU_CORE
#define SUPPORT_INTERRUPT

#define MAX_VPU_BUFFER_POOL      \
	(64 * MAX_NUM_INSTANCE + \
	 12 * 3) //+12*3 => mvCol + YOfsTable + COfsTable

//ENABLE_TEE_DRM_FLOW
#define VE_SECURE_NORMAL 1
#define VE_SECURE_PROTECTION 2

typedef struct vpu_buffer_t {
	int size;
	unsigned long phys_addr;
	unsigned long base;
	unsigned long virt_addr;
	/* RTK, for security video path, 0: normal, 1: ve special, 2: protection */
	unsigned int req_spec_region;
} vpu_buffer_t;

typedef enum {
	VDI_LITTLE_ENDIAN = 0, /* 64bit LE */
	VDI_BIG_ENDIAN, /* 64bit BE */
	VDI_32BIT_LITTLE_ENDIAN,
	VDI_32BIT_BIG_ENDIAN,
	/* WAVE PRODUCTS */
	VDI_128BIT_LITTLE_ENDIAN = 16,
	VDI_128BIT_LE_BYTE_SWAP,
	VDI_128BIT_LE_WORD_SWAP,
	VDI_128BIT_LE_WORD_BYTE_SWAP,
	VDI_128BIT_LE_DWORD_SWAP,
	VDI_128BIT_LE_DWORD_BYTE_SWAP,
	VDI_128BIT_LE_DWORD_WORD_SWAP,
	VDI_128BIT_LE_DWORD_WORD_BYTE_SWAP,
	VDI_128BIT_BE_DWORD_WORD_BYTE_SWAP,
	VDI_128BIT_BE_DWORD_WORD_SWAP,
	VDI_128BIT_BE_DWORD_BYTE_SWAP,
	VDI_128BIT_BE_DWORD_SWAP,
	VDI_128BIT_BE_WORD_BYTE_SWAP,
	VDI_128BIT_BE_WORD_SWAP,
	VDI_128BIT_BE_BYTE_SWAP,
	VDI_128BIT_BIG_ENDIAN = 31,
	VDI_ENDIAN_MAX
} EndianMode;

#define VDI_128BIT_ENDIAN_MASK 0xf

#endif //#ifndef _VDI_H_
