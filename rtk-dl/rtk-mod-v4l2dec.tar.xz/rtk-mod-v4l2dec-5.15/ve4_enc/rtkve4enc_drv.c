/*
 * Realtek video decoder v4l2 driver
 *
 * Copyright (c) 2021 Realtek Semiconductor Corp.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 and
 * only version 2 as published by the Free Software Foundation.
 */

#include <linux/module.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/version.h>
#ifdef VPU_GET_CC
#include <linux/module.h>
#include <linux/netlink.h>
#include <net/netlink.h>
#include <net/net_namespace.h>
#endif
#include <linux/platform_device.h>
#include <linux/of_reserved_mem.h>
#include <media/v4l2-mem2mem.h>
#include <media/v4l2-device.h>
#include <media/v4l2-ioctl.h>
#include <media/v4l2-ctrls.h>
#include <media/v4l2-event.h>
#include <media/videobuf2-vmalloc.h>
#include <media/videobuf2-dma-contig.h>
#include "rtkve4enc_drv.h"
#include "rtkve4enc_common.h"

#define VPU_PLATFORM_DEVICE_NAME "realtek-ve4"
#define ENABLE_ADAPTIVE_PLAYBACK (0)
#define ENABLE_REORDER_PTS (0)
#define INVERT_BITVAL_1 (~1)

#define RTKDEV_FOURCC_ENC v4l2_fourcc('R', 'E', 'N', 'C')
#define RTKDEV_FOURCC_DEC v4l2_fourcc('R', 'D', 'E', 'C')

ssize_t get_video_status(struct device *dev, struct device_attribute *attr,
			 char *buf);

static DEVICE_ATTR(video_status, S_IRUSR, get_video_status, NULL);

static char hasVideo = 0;

#ifdef ENABLE_SHOW_VIDEO_INFO
static int width = 0;
static int height = 0;
static uint32_t pixfmt = 0;

ssize_t get_video_info(struct device *dev, struct device_attribute *attr,
		       char *buf);

static DEVICE_ATTR(video_info, S_IRUSR, get_video_info, NULL);
#endif // #ifdef ENABLE_SHOW_VIDEO_INFO

ssize_t set_enhance_mode(struct device *dev, struct device_attribute *attr,
			 const char *buf, size_t count);

static DEVICE_ATTR(enhance, S_IWUSR, NULL, set_enhance_mode);

enum {
	V4L2_M2M_SRC = 0,
	V4L2_M2M_DST = 1,
};

#ifdef VPU_GET_CC
static struct sock *cc_data_sk = NULL;
__u32 ccReaderPid;
bool bcc_data_channel_bind;
#define NETLINK_CC_DATA 31
#define CC_DATA_LINK 0x12
#define CC_DATA_UNLINK 0x13
#endif

static inline struct videc_ctx *file2ctx(struct file *file)
{
	return container_of(file->private_data, struct videc_ctx, fh);
}

/*
 * mem2mem callbacks
 */

/**
 * job_ready() - check whether an instance is ready to be scheduled to run
 */
static int rtkve4_enc_job_ready(void *priv)
{
	struct rtkve4enc_ctx *enc_ctx;
	enc_ctx = (struct rtkve4enc_ctx *)priv;
	dev_dbg(enc_ctx->dev->dev, "[%d]%s: state %d\n", enc_ctx->inst_index,
		__func__, enc_ctx->enc_state);
	return 1;
}

static void rtkve4_enc_job_abort(void *priv)
{
	u32 *rtk_fourcc = (u32 *)priv;
	struct rtkve4enc_ctx *enc_ctx;
	//	struct videc_ctx *ctx = NULL;
	//	struct videc_dev *dev = NULL;
	//	const struct vpu_fmt_ops *op = NULL;
	enc_ctx = (struct rtkve4enc_ctx *)priv;
	dev_dbg(enc_ctx->dev->dev, "%s\n", __func__);

	if (*rtk_fourcc == RTKDEV_FOURCC_ENC) {
		dev_dbg(enc_ctx->dev->dev, "%d.%s\n", __LINE__, __func__);
	}
	dev_dbg(enc_ctx->dev->dev, "%s done\n", __func__);
}

/* device_run() - prepares and starts the device
 *
 * This simulates all the immediate preparations required before starting
 * a device. This will be called by the framework when it decides to schedule
 * a particular instance.
 */
static void rtkve4_enc_device_run(void *priv)
{
	u32 *rtk_fourcc = (u32 *)priv;
	struct rtkve4enc_ctx *enc_ctx;
	enc_ctx = (struct rtkve4enc_ctx *)priv;

	if (*rtk_fourcc == RTKDEV_FOURCC_ENC) {
		//pr_err("%d.%s.priv:0x%px.encode rtk_fourcc:0x%x\n",
		//	__LINE__, __func__,
		//	priv, *rtk_fourcc);
		queue_work(enc_ctx->dev->encode_workqueue,
			   &enc_ctx->encode_work);
	} else if (*rtk_fourcc == RTKDEV_FOURCC_DEC) {
		//pr_err("%d.%s.priv:0x%px.decode rtk_fourcc:0x%x\n",
		//	__LINE__, __func__,
		//	priv, *rtk_fourcc);
	} else {
		pr_err("%d.%s.priv:0x%px.unkown rtk_fourcc:0x%x\n", __LINE__,
		       __func__, priv, *rtk_fourcc);
	}
}

static void rtkve4_encode_work(struct work_struct *work)
{
	struct rtkve4enc_ctx *ctx =
		container_of(work, struct rtkve4enc_ctx, encode_work);
	struct vb2_v4l2_buffer *src_buf = NULL, *dst_buf = NULL;
	int ret = 0;

	if (ctx->enc_state == RTK_VE4_STATE_ENC_ERROR) {
		dev_err(ctx->dev->dev,
			"%d.%s.ctx:0x%px in error state, skip encoding.\n",
			__LINE__, __func__, ctx);
		goto exit;
	}

	if (ctx->out_streamon && ctx->cap_streamon &&
	    (ctx->enc_state == RTK_VE4_STATE_ENC_IDLE)) {
		ctx->stopping = 0;
		ctx->enc_state = RTK_VE4_STATE_ENC_OPEN;
		dev_dbg(ctx->dev->dev, "%d.%s.ctx:0x%px.new_state:%d.\n",
			__LINE__, __func__, ctx, ctx->enc_state);
	}

	if (ctx->stopping && (ctx->enc_state >= RTK_VE4_STATE_ENC_SEQ_INIT)) {
		dev_dbg(ctx->dev->dev,
			"%d.%s.ctx:0x%px stopping encoder. current state:%d.\n",
			__LINE__, __func__, ctx, ctx->enc_state);
		goto exit;
	}

	/*
	 * When the last empty buffer is processed, we need to send a buffer with LAST flag
	 * to indicate the end of stream.
	 */
	src_buf = v4l2_m2m_next_src_buf(ctx->v4l2_fh.m2m_ctx);
	if (src_buf == &ctx->empty_last_buf.vb) {
		const struct v4l2_event eos_event = { .type = V4L2_EVENT_EOS };

		v4l2_m2m_src_buf_remove(ctx->v4l2_fh.m2m_ctx);
		dev_dbg(ctx->dev->dev, "%d.%s.empty_last_buf come back.\n",
			__LINE__, __func__);

		dst_buf = v4l2_m2m_dst_buf_remove(ctx->v4l2_fh.m2m_ctx);
		if (!dst_buf) {
			dev_err(ctx->dev->dev,
				"%d.%s.no dst_buf for empty_last_buf.\n",
				__LINE__, __func__);
			v4l2_m2m_job_finish(ctx->dev->m2m_dev,
					    ctx->v4l2_fh.m2m_ctx);
			return;
		}
		vb2_set_plane_payload(&dst_buf->vb2_buf, 0, 0);
		v4l2_m2m_last_buffer_done(ctx->v4l2_fh.m2m_ctx, dst_buf);
		v4l2_m2m_job_finish(ctx->dev->m2m_dev, ctx->v4l2_fh.m2m_ctx);
		v4l2_event_queue_fh(&ctx->v4l2_fh, &eos_event);
		return;
	}

	switch (ctx->enc_state) {
	case RTK_VE4_STATE_ENC_IDLE:
		break;
	case RTK_VE4_STATE_ENC_OPEN:
		if (!ctx->open_encoder_done)
			ret = ctx->ops->open_encoder(ctx);
		ctx->enc_state = (!ret) ? RTK_VE4_STATE_ENC_SEQ_INIT :
					  RTK_VE4_STATE_ENC_ERROR;
		break;
	case RTK_VE4_STATE_ENC_SEQ_INIT:
		ret = ctx->ops->seq_init(ctx);
		ctx->enc_state = (!ret) ? RTK_VE4_STATE_ENC_REG_FBS :
					  RTK_VE4_STATE_ENC_ERROR;
		break;
	case RTK_VE4_STATE_ENC_REG_FBS:
		ret = ctx->ops->reg_fbs(ctx);
		ctx->enc_state = (!ret) ? RTK_VE4_STATE_ENC_HEADER :
					  RTK_VE4_STATE_ENC_ERROR;
		break;
	case RTK_VE4_STATE_ENC_HEADER:
		ctx->hdr_enc_flag = false;
		ret = ctx->ops->enc_pic(ctx);
		ctx->enc_state = (!ret) ? RTK_VE4_STATE_ENC_PIC :
					  RTK_VE4_STATE_ENC_ERROR;
		break;
	case RTK_VE4_STATE_ENC_PIC:
		ret = ctx->ops->enc_pic(ctx);
		break;
	case RTK_VE4_STATE_ENC_SEQ_END:
		ctx->ops->seq_end(ctx);
		break;
	default:
		break;
	}

exit:
	v4l2_m2m_job_finish(ctx->dev->m2m_dev, ctx->v4l2_fh.m2m_ctx);
}

static int rtkve4enc_open(struct file *file)
{
	struct video_device *vdev = video_devdata(file);
	struct videc_dev *dev = video_drvdata(file);
	struct rtkve4enc_ctx *ctx = NULL;
	struct vb2_queue *src_vq;
	int ret = 0;

	dev_dbg(dev->dev, "%d.%s.[+] video_device:0x%px.videc_dev:0x%px\n",
		__LINE__, __func__, vdev, dev);

	if (mutex_lock_interruptible(&dev->dev_mutex)) {
		dev_err(dev->dev, "%d.%s.mutex_lock_interruptible() fail\n",
			__LINE__, __func__);
		return -ERESTARTSYS;
	}

	ctx = kzalloc(sizeof(*ctx), GFP_KERNEL);
	if (!ctx) {
		ret = -ENOMEM;
		dev_err(dev->dev, "%d.%s.kzalloc ctx fail\n", __LINE__,
			__func__);
		goto open_unlock;
	}

	ctx->rtkdev_fourcc = RTKDEV_FOURCC_ENC;
	ctx->dev = dev;
	dev_dbg(dev->dev, "%d.%s.ctx:0x%px\n", __LINE__, __func__, ctx);

	v4l2_fh_init(&ctx->v4l2_fh, vdev);
	file->private_data = &ctx->v4l2_fh;
	v4l2_fh_add(&ctx->v4l2_fh);

	ctx->ops = &rtkve4enc_ops;
	/* queue_init */
	ctx->v4l2_fh.m2m_ctx =
		v4l2_m2m_ctx_init(dev->m2m_dev, ctx, ctx->ops->queue_init);
	if (IS_ERR(ctx->v4l2_fh.m2m_ctx)) {
		ret = PTR_ERR(ctx->v4l2_fh.m2m_ctx);
		dev_err(dev->dev, "%d.%s.v4l2_m2m_ctx_init() fail\n", __LINE__,
			__func__);
		goto free_ctx;
	}
	dev_dbg(dev->dev, "%d.%s.m2m_ctx:0x%px\n", __LINE__, __func__,
		ctx->v4l2_fh.m2m_ctx);

	src_vq = v4l2_m2m_get_vq(ctx->v4l2_fh.m2m_ctx,
				 V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
	ctx->empty_last_buf.vb.vb2_buf.vb2_queue = src_vq;

	/* ctrls_setup */
	if (ctx->ops->ctrls_setup(ctx)) {
		ret = -ENODEV;
		dev_err(dev->dev, "%d.%s.ctrls_setup() fail\n", __LINE__,
			__func__);
		goto err_m2m_release;
	}

	rtkve_set_default_format(ctx, &ctx->src_fmt, &ctx->dst_fmt);
	ctx->colorspace = V4L2_COLORSPACE_DEFAULT;
	ctx->ycbcr_enc = V4L2_YCBCR_ENC_DEFAULT;
	ctx->quantization = V4L2_QUANTIZATION_DEFAULT;
	ctx->xfer_func = V4L2_XFER_FUNC_DEFAULT;

	INIT_WORK(&ctx->encode_work, rtkve4_encode_work);
	ctx->debugfs_entry =
		debugfs_create_dir(RTKVE4_ENC_DEV_NAME, dev->debugfs_root);

	mutex_unlock(&dev->dev_mutex);
	dev_dbg(dev->dev, "%d.%s.[-] ret:%d\n", __LINE__, __func__, ret);
	return ret;

err_m2m_release:
	v4l2_m2m_ctx_release(ctx->v4l2_fh.m2m_ctx);
free_ctx:
	v4l2_fh_del(&ctx->v4l2_fh);
	v4l2_fh_exit(&ctx->v4l2_fh);
	kfree(ctx);
open_unlock:
	mutex_unlock(&dev->dev_mutex);
	return ret;
}

static int rtkve4enc_release(struct file *file)
{
	struct videc_dev *dev = video_drvdata(file);
	struct rtkve4enc_ctx *ctx = v4l2fh_to_ctx(file->private_data);

	dev_dbg(dev->dev, "%d.%s.[+] ctx:%px\n", __LINE__, __func__, ctx);
	mutex_lock(&dev->dev_mutex);
	if (ctx->enc_initialized) {
		if (ctx->enc_state >= RTK_VE4_STATE_ENC_SEQ_INIT) {
			ctx->ops->seq_end(ctx);
		}
		rtkve4_finalize(ctx);
	}
	v4l2_m2m_ctx_release(ctx->v4l2_fh.m2m_ctx);
	// release/reset resource
	v4l2_ctrl_handler_free(&ctx->v4l2_ctrl_hdl);
	v4l2_fh_del(&ctx->v4l2_fh);
	v4l2_fh_exit(&ctx->v4l2_fh);
	debugfs_remove_recursive(ctx->debugfs_entry);
	kfree(ctx);
	ctx = NULL;
	mutex_unlock(&dev->dev_mutex);
	dev_dbg(dev->dev, "%d.%s.[-]\n", __LINE__, __func__);

	return 0;
}

static const struct v4l2_file_operations rtkve4enc_fops = {
	.owner = THIS_MODULE,
	.open = rtkve4enc_open,
	.release = rtkve4enc_release,
	.poll = v4l2_m2m_fop_poll,
	.unlocked_ioctl = video_ioctl2,
	.mmap = v4l2_m2m_fop_mmap,
};

static struct video_device rtkve4enc_videodev = {
	.name = RTKVE4_ENC_DEV_NAME,
	.vfl_dir = VFL_DIR_M2M,
	.fops = &rtkve4enc_fops,
	.ioctl_ops = &rtkve4enc_ioctl_ops,
	.minor = -1,
	.release = video_device_release_empty,
};

static struct v4l2_m2m_ops m2m_ops = {
	.device_run = rtkve4_enc_device_run,
	.job_ready = rtkve4_enc_job_ready,
	.job_abort = rtkve4_enc_job_abort,
};

ssize_t get_video_status(struct device *dev, struct device_attribute *attr,
			 char *buf)
{
	return sprintf(buf, "%d\n", hasVideo);
}
#ifdef ENABLE_SHOW_VIDEO_INFO
ssize_t get_video_info(struct device *dev, struct device_attribute *attr,
		       char *buf)
{
	char buffer[8];

	if (hasVideo == 0) {
		pixfmt = 0;
		width = 0;
		height = 0;
	}

	if (pixfmt)
		snprintf(buffer, 5, "%s", (char *)&pixfmt);
	else
		sprintf(buffer, "Unknown");

	return sprintf(buf, "%d %s %d %d\n", hasVideo, buffer, width, height);
}
#endif // #ifdef ENABLE_SHOW_VIDEO_INFO

ssize_t set_enhance_mode(struct device *dev, struct device_attribute *attr,
			 const char *buf, size_t count)
{
	struct videc_dev *v_dev = dev_get_drvdata(dev);
	unsigned long mode;
	int ret = 0;

	ret = kstrtol(buf, 0, &mode);
	if (ret != 0 || mode & INVERT_BITVAL_1) {
		pr_err("Incorrect input value. Please input 1 or 0.");
		return -EINVAL;
	}

	v_dev->en_enhance = mode;

	return count;
}

static int rtkve4_enc_probe(struct platform_device *pdev)
{
	struct videc_dev *dev;
	struct video_device *enc_dev;
	int ret;

	/* Allocate a new instance */
	dev = devm_kzalloc(&pdev->dev, sizeof(*dev), GFP_KERNEL);
	if (!dev)
		return -ENOMEM;

	dev->ve4_devinfo = kzalloc(sizeof(struct rtkve4_dev_info), GFP_KERNEL);
	if (!dev->ve4_devinfo) {
		dev_err(&pdev->dev,
			"%d.%s.kzalloc struct rtkve4_dev_info fail\n", __LINE__,
			__func__);
		return -ENOMEM;
	}

	ret = of_reserved_mem_device_init(&pdev->dev);
	if (ret)
		dev_err(&pdev->dev, "init reserved memory failed");

	spin_lock_init(&dev->irqlock);

	/* Initialize the top-level structure */
	ret = v4l2_device_register(&pdev->dev, &dev->v4l2_dev);
	if (ret)
		return ret;

	dev->dev = &pdev->dev;
	atomic_set(&dev->num_inst, 0);
	mutex_init(&dev->dev_mutex);
	mutex_init(&dev->ve4_hw_mutex);

	/* Initialize rtkve4-enc video_device */
	dev->video_dev = rtkve4enc_videodev;
	enc_dev = &dev->video_dev;
	enc_dev->lock = &dev->dev_mutex;
	enc_dev->v4l2_dev = &dev->v4l2_dev;
	enc_dev->device_caps = V4L2_CAP_VIDEO_M2M_MPLANE | V4L2_CAP_STREAMING;
	video_set_drvdata(enc_dev, dev);

	platform_set_drvdata(pdev, dev);

	/* Initialize per-driver m2m data */
	dev->m2m_dev = v4l2_m2m_init(&m2m_ops);
	if (IS_ERR(dev->m2m_dev)) {
		dev_err(&pdev->dev, "Failed to init mem2mem device\n");
		ret = PTR_ERR(dev->m2m_dev);
		goto err_m2m;
	}

	dev->encode_workqueue = alloc_ordered_workqueue(
		RTKVE4_ENC_DEV_NAME, WQ_MEM_RECLAIM | WQ_FREEZABLE);
	if (!dev->encode_workqueue) {
		dev_err(&pdev->dev, "Failed to create encode workqueue\n");
		ret = -EINVAL;
		goto err_workq;
	}

	/* Register video4linux device after initialization is completed */
	ret = video_register_device(enc_dev, VFL_TYPE_VIDEO, -1);
	if (ret) {
		dev_err(&pdev->dev, "Failed to register encode device\n");
		goto err_enc;
	}

	dev_info(&pdev->dev,
		 "%d.%s.encoder registered as /dev/video%d.name=%s\n", __LINE__,
		 __func__, enc_dev->num, enc_dev->name);

	ret = device_create_file(&pdev->dev, &dev_attr_video_status);
	if (ret < 0)
		dev_err(&pdev->dev, "failed to create v4l2 video attribute\n");

#ifdef ENABLE_SHOW_VIDEO_INFO
	ret = device_create_file(&pdev->dev, &dev_attr_video_info);
	if (ret < 0)
		dev_err(&pdev->dev,
			"failed to create v4l2 video information!\n");
#endif // #ifdef ENABLE_SHOW_VIDEO_INFO

	ret = device_create_file(&pdev->dev, &dev_attr_enhance);
	if (ret < 0)
		dev_err(&pdev->dev,
			"failed to create v4l2 enhance attribute\n");

	dev->debugfs_root = debugfs_create_dir("rtkvenc4-dbg", NULL);

	return 0;

err_enc:
	video_unregister_device(&dev->video_dev);
	destroy_workqueue(dev->encode_workqueue);
err_workq:
	v4l2_m2m_release(dev->m2m_dev);
err_m2m:
	v4l2_device_unregister(&dev->v4l2_dev);

	return ret;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 11, 0)
static void rtkve4_enc_remove(struct platform_device *pdev)
#else
static int rtkve4_enc_remove(struct platform_device *pdev)
#endif
{
	struct videc_dev *dev = platform_get_drvdata(pdev);

	dev_info(&pdev->dev, "Removing %s\n", RTKVE4_ENC_DEV_NAME);

	if (dev->encode_workqueue)
		destroy_workqueue(dev->encode_workqueue);
	kfree(dev->ve4_devinfo);
	dev->ve4_devinfo = NULL;

	device_remove_file(&pdev->dev, &dev_attr_video_status);
#ifdef ENABLE_SHOW_VIDEO_INFO
	device_remove_file(&pdev->dev, &dev_attr_video_info);
#endif // #ifdef ENABLE_SHOW_VIDEO_INFO
	v4l2_m2m_release(dev->m2m_dev);
	video_unregister_device(&dev->video_dev);
	v4l2_device_unregister(&dev->v4l2_dev);
	debugfs_remove_recursive(dev->debugfs_root);

#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 11, 0)
	return 0;
#endif
}

static const struct of_device_id rtkve4_dt_ids[] = {
	{ .compatible = "realtek,kent-vpu-ve4" },
	{ /* sentinel */ }
};
MODULE_DEVICE_TABLE(of, rtkve4_dt_ids);

static struct platform_driver rtkve4_enc_driver = {
	.probe		= rtkve4_enc_probe,
	.remove		= rtkve4_enc_remove,
	.driver		= {
		.name	= VPU_PLATFORM_DEVICE_NAME,
		.of_match_table = of_match_ptr(rtkve4_dt_ids),
	},
};

module_platform_driver(rtkve4_enc_driver);

MODULE_VERSION(xstr(GIT_VERSION));
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("RTK Video Engine V4L2 encode driver (VE4)");
