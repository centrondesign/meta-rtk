// SPDX-License-Identifier: (GPL-2.0 OR BSD-3-Clause)
/*
 * Realtek video encoder v4l2 driver
 *
 * Copyright (c) 2024 Realtek Semiconductor Corp. All rights reserved.
 *
 * SPDX-License-Identifier: LicenseRef-Realtek-Proprietary
 *
 * This software component is confidential and proprietary to Realtek
 * Semiconductor Corp. Disclosure, reproduction, redistribution, in whole
 * or in part, of this work and its derivatives without express permission
 * is prohibited.
 */
#include <linux/clk.h>
#include <linux/debugfs.h>
#include <linux/delay.h>
#include <linux/firmware.h>
#include <linux/gcd.h>
#include <linux/genalloc.h>
#include <linux/idr.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/irq.h>
#include <linux/kfifo.h>
#include <linux/module.h>
#include <linux/of_device.h>
#include <linux/platform_device.h>
#include <linux/pm_runtime.h>
#include <linux/slab.h>
#include <linux/videodev2.h>
#include <linux/of.h>
#include <linux/ratelimit.h>
#include <linux/reset.h>
#include <linux/vmalloc.h>
#include <linux/version.h>

#include <media/v4l2-ctrls.h>
#include <media/v4l2-device.h>
#include <media/v4l2-event.h>
#include <media/v4l2-ioctl.h>
#include <media/v4l2-mem2mem.h>
#include <media/videobuf2-v4l2.h>
#include <media/videobuf2-dma-contig.h>
#include <media/videobuf2-vmalloc.h>

#include "rtkve4enc_common.h"
#include "rtkve4_regdefine.h"
#include "ve4_vdi.h"
#include "rtkve4enc_av1_cdf_table.h"

//#define RTKVE4_DUMP_OUTBUF_EN
#if defined(RTKVE4_DUMP_OUTBUF_EN)
static int g_outbuf_dump_serial = 0;
#endif

//#define RTKVE4_DUMP_ENC_BS_EN
#if defined(RTKVE4_DUMP_ENC_BS_EN)
static int g_enc_bs_dump_serial = 0;
#endif

#define VE4_PROT_CTRL                                                          \
	(0x008) // 0x9814_E408, VE4 wrapper register starts from 0x9814_E400

static const struct vpu_format rtkve4enc_fmt_list[2][3] = {
	[VPU_FMT_TYPE_CODEC] = {
#if IS_ENABLED(CONFIG_RTK_V4L2_EN_CODEC_H264)
		{
			.v4l2_pix_fmt = V4L2_PIX_FMT_H264,
			.max_width = W_MAX_ENC_PIC_WIDTH,
			.min_width = W_MIN_ENC_PIC_WIDTH,
			.max_height = W_MAX_ENC_PIC_HEIGHT,
			.min_height = W_MIN_ENC_PIC_HEIGHT,
			.num_planes = 1,
		},
#endif
#if IS_ENABLED(CONFIG_RTK_V4L2_EN_CODEC_HEVC)
		{
			.v4l2_pix_fmt = V4L2_PIX_FMT_HEVC,
			.max_width = W_MAX_ENC_PIC_WIDTH,
			.min_width = W_MIN_ENC_PIC_WIDTH,
			.max_height = W_MAX_ENC_PIC_HEIGHT,
			.min_height = W_MIN_ENC_PIC_HEIGHT,
			.num_planes = 1,
		},
#endif
#if 0
		{
			.v4l2_pix_fmt = V4L2_PIX_FMT_AV1,
			.max_width = W_MAX_ENC_PIC_WIDTH,
			.min_width = W_MIN_ENC_PIC_WIDTH,
			.max_height = W_MAX_ENC_PIC_HEIGHT,
			.min_height = W_MIN_ENC_PIC_HEIGHT,
			.num_planes = 1,
		},
#endif
	},
	[VPU_FMT_TYPE_RAW] = {
		{
			.v4l2_pix_fmt = V4L2_PIX_FMT_YUV420,
			.max_width = RAW_MAX_ENC_PIC_WIDTH,
			.min_width = RAW_MIN_ENC_PIC_WIDTH,
			.max_height = RAW_MAX_ENC_PIC_HEIGHT,
			.min_height = RAW_MIN_ENC_PIC_HEIGHT,
			.num_planes = 1,
		},
		{
			.v4l2_pix_fmt = V4L2_PIX_FMT_NV12,
			.max_width = RAW_MAX_ENC_PIC_WIDTH,
			.min_width = RAW_MIN_ENC_PIC_WIDTH,
			.max_height = RAW_MAX_ENC_PIC_HEIGHT,
			.min_height = RAW_MIN_ENC_PIC_HEIGHT,
			.num_planes = 1,
		},
		{
			.v4l2_pix_fmt = V4L2_PIX_FMT_NV21,
			.max_width = RAW_MAX_ENC_PIC_WIDTH,
			.min_width = RAW_MIN_ENC_PIC_WIDTH,
			.max_height = RAW_MAX_ENC_PIC_HEIGHT,
			.min_height = RAW_MIN_ENC_PIC_HEIGHT,
			.num_planes = 1,
		},
	}
};

const char *rtk_ve4_enc_state_str[] = {
	[RTK_VE4_STATE_ENC_IDLE] = "idle",
	[RTK_VE4_STATE_ENC_OPEN] = "open_encoder",
	[RTK_VE4_STATE_ENC_SEQ_INIT] = "seq_init",
	[RTK_VE4_STATE_ENC_REG_FBS] = "reg_fbs",
	[RTK_VE4_STATE_ENC_HEADER] = "enc_header",
	[RTK_VE4_STATE_ENC_PIC] = "enc_pic",
	[RTK_VE4_STATE_ENC_SEQ_END] = "seq_end",
	[RTK_VE4_STATE_ENC_TIMEOUT] = "enc_timeout",
};

enum VIDEO_RATE_CONTROL_MODE {
	VIDEO_RATE_CBR = 0,
	VIDEO_RATE_VBR = 1,
	VIDEO_RATE_CVBR = 2,
};

/* vb2_ops */
static int rtkve_enc_queue_setup(struct vb2_queue *q, unsigned int *num_buffers,
				 unsigned int *num_planes, unsigned int sizes[],
				 struct device *alloc_devs[])
{
	struct rtkve4enc_ctx *ctx = vb2_get_drv_priv(q);
	struct v4l2_pix_format_mplane inst_format =
		(V4L2_TYPE_IS_OUTPUT(q->type)) ? ctx->src_fmt : ctx->dst_fmt;
	unsigned int i;
	int ret = 0;

	dev_dbg(ctx->dev->dev, "%s: num_buffers %d num_planes %d type %d\n",
		__func__, *num_buffers, *num_planes, q->type);

	if (*num_planes) {
		if (inst_format.num_planes != *num_planes) {
			ret = -EINVAL;
			goto exit;
		}

		for (i = 0; i < *num_planes; i++) {
			if (sizes[i] < inst_format.plane_fmt[i].sizeimage) {
				ret = -EINVAL;
				goto exit;
			}
		}
	} else {
		*num_planes = inst_format.num_planes;
		for (i = 0; i < *num_planes; i++) {
			sizes[i] = inst_format.plane_fmt[i].sizeimage;
			dev_dbg(ctx->dev->dev, "size[%d] : %d\n", i, sizes[i]);
		}
	}
exit:
	return ret;
}

static int rtkve_enc_buf_out_validate(struct vb2_buffer *vb)
{
	struct vb2_v4l2_buffer *vbuf = to_vb2_v4l2_buffer(vb);

	vbuf->field = V4L2_FIELD_NONE;
	return 0;
}

static int rtkve_enc_buf_prepare(struct vb2_buffer *vb)
{
	struct rtkve4enc_ctx *ctx = vb2_get_drv_priv(vb->vb2_queue);
	struct vb2_queue *vq = vb->vb2_queue;
	struct v4l2_pix_format_mplane *fmt;
	int i;

	dev_dbg(ctx->dev->dev, "%d.%s.ctx:0x%px.type:%s\n", __LINE__, __func__,
		ctx, v4l2_type_names[vq->type]);
	if (V4L2_TYPE_IS_OUTPUT(vb->type)) {
		fmt = &ctx->src_fmt;
	} else {
		fmt = &ctx->dst_fmt;
	}

	for (i = 0; i < fmt->num_planes; i++) {
		if (vb2_plane_size(vb, i) < fmt->plane_fmt[i].sizeimage) {
			dev_err(ctx->dev->dev,
				"data will not fit into plane %d (%lu < %d)", i,
				vb2_plane_size(vb, i),
				fmt->plane_fmt[i].sizeimage);
			return -EINVAL;
		}
	}

	return 0;
}

static void rtkve_enc_buf_queue(struct vb2_buffer *vb)
{
	struct vb2_v4l2_buffer *vbuf = to_vb2_v4l2_buffer(vb);
	struct rtkve4enc_ctx *ctx = vb2_get_drv_priv(vb->vb2_queue);
	struct vb2_queue *vq = vb->vb2_queue;

	if (V4L2_TYPE_IS_OUTPUT(vb->type))
		vbuf->sequence = ctx->queued_src_buf_num++;
	else
		vbuf->sequence = ctx->queued_dst_buf_num++;

	dev_dbg(ctx->dev->dev, "%d.%s.ctx:0x%px.type:%s.sequence:%d\n",
		__LINE__, __func__, ctx, v4l2_type_names[vq->type],
		vbuf->sequence);

	v4l2_m2m_buf_queue(ctx->v4l2_fh.m2m_ctx, vbuf);
}

static int rtkve_enc_start_streaming(struct vb2_queue *q, unsigned int count)
{
	struct rtkve4enc_ctx *ctx = vb2_get_drv_priv(q);
	int ret = 0;

	dev_dbg(ctx->dev->dev, "%d.%s.ctx:0x%px.type:%s\n", __LINE__, __func__,
		ctx, v4l2_type_names[q->type]);

	if (V4L2_TYPE_IS_OUTPUT(q->type))
		ctx->out_streamon = true;
	else {
		ctx->stopping = 0;
		ctx->eos = false;
		ctx->cap_streamon = true;
	}

	return ret;
}

static void rtkve_enc_return_buffer(struct vb2_queue *vq, u32 state)
{
	struct rtkve4enc_ctx *ctx = vb2_get_drv_priv(vq);
	struct vb2_v4l2_buffer *vbuf;

	for (;;) {
		if (V4L2_TYPE_IS_OUTPUT(vq->type))
			vbuf = v4l2_m2m_src_buf_remove(ctx->v4l2_fh.m2m_ctx);
		else
			vbuf = v4l2_m2m_dst_buf_remove(ctx->v4l2_fh.m2m_ctx);

		if (!vbuf)
			break;

		dev_dbg(ctx->dev->dev,
			"%d.%s.type:%s.v4l2_m2m_buf_done.vbuf:0x%px\n",
			__LINE__, __func__, v4l2_type_names[vq->type], vbuf);
		v4l2_m2m_buf_done(vbuf, state);
	}
}

static void rtkve_enc_stop_streaming(struct vb2_queue *q)
{
	struct rtkve4enc_ctx *ctx = vb2_get_drv_priv(q);
	struct v4l2_m2m_ctx *m2m_ctx = ctx->v4l2_fh.m2m_ctx;

	dev_dbg(ctx->dev->dev, "%d.%s.[+] ctx:0x%px.type:%s\n", __LINE__,
		__func__, ctx, v4l2_type_names[q->type]);

	v4l2_m2m_suspend(ctx->dev->m2m_dev);

	rtkve_enc_return_buffer(q, VB2_BUF_STATE_ERROR);

	if (V4L2_TYPE_IS_OUTPUT(q->type)) {
		ctx->queued_src_buf_num = 0;
		ctx->out_streamon = false;
	} else {
		ctx->stopping = 1;
		ctx->cap_streamon = false;
		queue_work(ctx->dev->encode_workqueue, &ctx->encode_work);
		flush_work(&ctx->encode_work);

		if (v4l2_m2m_has_stopped(m2m_ctx))
			v4l2_m2m_clear_state(m2m_ctx);

		ctx->queued_dst_buf_num = 0;
	}

	v4l2_m2m_resume(ctx->dev->m2m_dev);
	dev_dbg(ctx->dev->dev, "%d.%s.[-] ctx:0x%px.type:%s\n", __LINE__,
		__func__, ctx, v4l2_type_names[q->type]);
}

static const struct vb2_ops rtkve4enc_vb2_ops = {
	.queue_setup = rtkve_enc_queue_setup,
	.buf_out_validate = rtkve_enc_buf_out_validate,
	.buf_prepare = rtkve_enc_buf_prepare,
	.wait_prepare = vb2_ops_wait_prepare,
	.wait_finish = vb2_ops_wait_finish,
	.buf_queue = rtkve_enc_buf_queue,
	.start_streaming = rtkve_enc_start_streaming,
	.stop_streaming = rtkve_enc_stop_streaming,
};

/* rtkve4_context_ops */
static const struct vpu_format *rtkve_enc_find_fmt(unsigned int v4l2_pix_fmt,
						   enum vpu_fmt_type type)
{
	unsigned int index;
	const struct vpu_format *fmt = NULL;

	for (index = 0; index < ARRAY_SIZE(rtkve4enc_fmt_list[type]); index++) {
		if (rtkve4enc_fmt_list[type][index].v4l2_pix_fmt ==
		    v4l2_pix_fmt)
			fmt = &rtkve4enc_fmt_list[type][index];
	}

	return fmt;
}

static const struct vpu_format *
rtkve_enc_find_fmt_by_idx(unsigned int idx, enum vpu_fmt_type type)
{
	const struct vpu_format *fmt = NULL;

	if (idx >= ARRAY_SIZE(rtkve4enc_fmt_list[type]))
		goto exit;

	if (!rtkve4enc_fmt_list[type][idx].v4l2_pix_fmt)
		goto exit;

	fmt = &rtkve4enc_fmt_list[type][idx];

exit:
	return fmt;
}

#define MAX_LEVEL_IDX 16
static const int g_anLevel[MAX_LEVEL_IDX] __maybe_unused = {
	10, 11, 11, 12, 13,
	/*10, 16, 11, 12, 13,*/
	20, 21, 22, 30, 31, 32, 40, 41, 42, 50, 51
};

static const int g_anLevelMaxMBPS[MAX_LEVEL_IDX] __maybe_unused = {
	1485,  1485,   3000,   6000,   11880,  11880,  19800,  20250,
	40500, 108000, 216000, 245760, 245760, 522240, 589824, 983040
};

static const int g_anLevelMaxFS[MAX_LEVEL_IDX] __maybe_unused = {
	99,   99,   396,  396,	396,  396,  792,   1620,
	1620, 3600, 5120, 8192, 8192, 8704, 22080, 36864
};

static const int g_anLevelMaxBR[MAX_LEVEL_IDX] __maybe_unused = {
	64,    64,    192,   384,   768,   2000,  4000,	  4000,
	10000, 14000, 20000, 20000, 50000, 50000, 135000, 240000
};

static const int g_anLevelMaxMbs[MAX_LEVEL_IDX] __maybe_unused = {
	28, 28, 56, 56, 56, 56, 79, 113, 113, 169, 202, 256, 256, 263, 420, 543
};

#if defined(RTKVE4_DUMP_OUTBUF_EN)
static void dump_outbuf(struct rtkve4enc_ctx *ctx, uint8_t *buf,
			uint32_t offset, uint32_t len)
{
	int filp_open_flags;
	ssize_t bytes = 0;
	loff_t pos = 0;

	if (ctx == NULL) {
		return;
	}

	if ((buf != NULL) && (len != 0)) {
		if (ctx->outbuf_new_file == 1) {
			ctx->outbuf_new_file = 0;
			filp_open_flags = O_CREAT | O_WRONLY;
			memset(ctx->outbuf_file_name, 0,
			       sizeof(unsigned char) * 256);
			snprintf(ctx->outbuf_file_name, 256,
				 "/mnt/outbuf_%d.yuv", g_outbuf_dump_serial);
			g_outbuf_dump_serial++;
			dev_dbg(ctx->dev->dev,
				"%d.%s.create new outbuf dump:%s\n", __LINE__,
				__func__, ctx->outbuf_file_name);
		} else {
			filp_open_flags = O_APPEND | O_WRONLY;
		}
		ctx->outbuf_fp = (void *)filp_open(ctx->outbuf_file_name,
						   filp_open_flags, 0);
		if (IS_ERR((struct file *)ctx->outbuf_fp)) {
			dev_err(ctx->dev->dev, "%d.%s.filp_open %s fail\n",
				__LINE__, __func__, ctx->outbuf_file_name);
		} else {
			bytes = kernel_write((struct file *)(ctx->outbuf_fp),
					     (void *)(buf + offset),
					     (size_t)len, &pos);
			filp_close((struct file *)(ctx->outbuf_fp), NULL);
			ctx->outbuf_fp = NULL;
		}
	}
}
#endif

static int enc_alloc_custom_buffers(struct rtkve4enc_ctx *ctx)
{
	struct videc_dev *dev = ctx->dev;
	int ret = 0;

	if (ctx->encodeVuiRbsp == TRUE) {
		if (ctx->vbVuiRbsp.size == 0) {
			ret = rtkve4_alloc_dma_memory(dev, &ctx->vbVuiRbsp,
						      VUI_HRD_RBSP_BUF_SIZE,
						      "vbVuiRbsp",
						      ctx->debugfs_entry);
			if (ret < 0) {
				dev_err(dev->dev,
					"%d.%s.alloc_dma.name:vbVuiRbsp fail\n",
					__LINE__, __func__);
				return ret;
			}

			dev_dbg(dev->dev,
				"%d.%s.alloc_dma.name:VuiRbsp.size:%d.paddr:0x%llx.vaddr:0x%px\n",
				__LINE__, __func__, ctx->vbVuiRbsp.size,
				ctx->vbVuiRbsp.paddr, ctx->vbVuiRbsp.vaddr);
		}
	}
	if (ctx->encodeHrdRbsp == TRUE) {
		if (ctx->vbHrdRbsp.size == 0) {
			ret = rtkve4_alloc_dma_memory(dev, &ctx->vbHrdRbsp,
						      VUI_HRD_RBSP_BUF_SIZE,
						      "vbHrdRbsp",
						      ctx->debugfs_entry);
			if (ret < 0) {
				dev_err(dev->dev,
					"%d.%s.alloc_dma.name:vbHrdRbsp fail\n",
					__LINE__, __func__);
				return ret;
			}

			dev_dbg(dev->dev,
				"%d.%s.alloc_dma.name:workbuf.size:%d.paddr:0x%llx.vaddr:0x%px\n",
				__LINE__, __func__, ctx->vbHrdRbsp.size,
				ctx->vbHrdRbsp.paddr, ctx->vbHrdRbsp.vaddr);
		}
	}

	return ret;
}

static int enc_alloc_bsbuf_workbuf(struct rtkve4enc_ctx *ctx)
{
	struct videc_dev *dev = ctx->dev;
	int ret = 0;

	if (ctx->bitstream.size == 0) {
		ret = rtkve4_alloc_dma_memory(dev, &ctx->bitstream, BS_BUF_SIZE,
					      "bsbuf", ctx->debugfs_entry);
		if (ret < 0) {
			dev_err(dev->dev, "%d.%s.alloc_dma.name:bsbuf fail\n",
				__LINE__, __func__);
			return ret;
		}
		dev_dbg(dev->dev,
			"%d.%s.alloc_dma.name:bsbuf.size:%d.paddr:0x%llx.vaddr:0x%px\n",
			__LINE__, __func__, ctx->bitstream.size,
			ctx->bitstream.paddr, ctx->bitstream.vaddr);
	}
	if (ctx->workbuf.size == 0) {
		ret = rtkve4_alloc_dma_memory(
			dev, &ctx->workbuf,
			VPU_ALIGN4096(WAVE627ENC_WORKBUF_SIZE), "workbuf",
			ctx->debugfs_entry);
		if (ret < 0) {
			dev_err(dev->dev, "%d.%s.alloc_dma.name:workbuf fail\n",
				__LINE__, __func__);
			return ret;
		}
		dev_dbg(dev->dev,
			"%d.%s.alloc_dma.name:workbuf.size:%d.paddr:0x%llx.vaddr:0x%px\n",
			__LINE__, __func__, ctx->workbuf.size,
			ctx->workbuf.paddr, ctx->workbuf.vaddr);
	}

	return ret;
}

static int enc_alloc_tempbuf_arTbuf(struct rtkve4enc_ctx *ctx)
{
	struct videc_dev *dev = ctx->dev;
	int ret = 0;

	if (ctx->vbTemp.size == 0) {
		ret = rtkve4_alloc_dma_memory(dev, &ctx->vbTemp,
					      VPU_ALIGN4096(WAVE6_TEMPBUF_SIZE),
					      "vbTemp", ctx->debugfs_entry);
		if (ret < 0) {
			return ret;
		}
		dev_dbg(dev->dev,
			"%d.%s.alloc_dma.name:vbTemp.size:%d.paddr:0x%llx.vaddr:0x%px\n",
			__LINE__, __func__, ctx->vbTemp.size, ctx->vbTemp.paddr,
			ctx->vbTemp.vaddr);
	}
	if (ctx->vbAr.size == 0) {
		ret = rtkve4_alloc_dma_memory(
			dev, &ctx->vbAr, VPU_ALIGN4096(WAVE6_AR_TABLE_BUF_SIZE),
			"vbAr", ctx->debugfs_entry);
		if (ret < 0) {
			return ret;
		}
		dev_dbg(dev->dev,
			"%d.%s.alloc_dma.name:vbAr.size:%d.paddr:0x%llx.vaddr:0x%px\n",
			__LINE__, __func__, ctx->vbAr.size, ctx->vbAr.paddr,
			ctx->vbAr.vaddr);
	}

	return ret;
}

static int enc_alloc_frame_buffers(struct rtkve4enc_ctx *ctx)
{
	struct videc_dev *dev = ctx->dev;
	int ret = 0;
	int i = 0;
	char dbg_name[16];

	for (i = 0; i < ctx->enc_min_fb_num; i++) {
		memset(dbg_name, 0, sizeof(dbg_name));
		snprintf(dbg_name, 16, "framebuf%d", i);
		ret = rtkve4_alloc_dma_memory(dev, &ctx->framebuf[i],
					      ctx->src_buf_size, dbg_name,
					      ctx->debugfs_entry);
		if (ret < 0) {
			dev_err(dev->dev, "%d.%s.alloc_dma.name:%s fail\n",
				__LINE__, __func__, dbg_name);
			return -ENOMEM;
		}
		dev_dbg(dev->dev,
			"%d.%s.alloc_dma.%d.name:%s.size:%d.paddr:0x%llx.vaddr:0x%px\n",
			__LINE__, __func__, i, dbg_name, ctx->framebuf[i].size,
			ctx->framebuf[i].paddr, ctx->framebuf[i].vaddr);
	}

	return ret;
}

static void calc_src_buf_w_h(u32 fmt, u32 src_buf_size, u32 width, u32 hieght,
			     u32 *align_width, u32 *align_height)
{
	int align[] = { 16, 32, 64, 128 };
	int i = 0;

	for (i = 0; i < sizeof(align)/sizeof(int); i++) {
		*align_width = ALIGN(width, align[i]);
		*align_height = ALIGN(hieght, align[i]);

		if (fmt == V4L2_PIX_FMT_NV12 ||
			fmt == V4L2_PIX_FMT_YUV420) {
			if (((*align_width) * (*align_height) * 3 /2) == src_buf_size)
				return;
		} else if (fmt == V4L2_PIX_FMT_NV16 ||
				fmt == V4L2_PIX_FMT_YUV422P) {
			if (((*align_width) * (*align_height) * 2) == src_buf_size)
				return;
		} else if (fmt == V4L2_PIX_FMT_NV24 ||
				fmt == V4L2_PIX_FMT_YUV444M ||
				fmt == V4L2_PIX_FMT_RGB24) {
			if (((*align_width) * (*align_height) * 3) == src_buf_size)
				return;
		}
	}

	*align_width = width;
	*align_height = hieght;
}

static int load_av1_cdf_table(struct rtkve4enc_ctx *ctx)
{
	int ret = 0;
	const uint16_t *tbl_data = NULL;
	uint32_t tbl_size = AV1_MAX_CDF_WORDS * AV1_CDF_WORDS_SIZE * 2;
	struct videc_dev *dev = ctx->dev;

	dev_dbg(dev->dev, "Start to load av1 default cdf table\n");

	tbl_data = defCdfTbl;
	ret = rtkve4_write_memory(dev, ctx->vbDefCdf.vaddr, tbl_size, 0,
				  (u8 *)tbl_data, sizeof(tbl_data),
				  VDI_128BIT_LITTLE_ENDIAN);

	if (ret < 0) {
		dev_err(dev->dev, "%d.%s.write memory failed %d\n", __LINE__,
			__func__, ret);
		return ret;
	}

	dev_dbg(dev->dev, "Success to load av1 default cdf table\n");
	return 0;
}

static int rtk_set_ve4_prot_mode(struct rtkve4enc_ctx *ctx, int enable)
{
	unsigned int value = 0;
	struct videc_dev *dev = ctx->dev;

	value = rtkve4_wrap_reg_readl(dev, VE4_PROT_CTRL);
	(void)value;

	if (enable == 0) {
		rtkve4_wrap_reg_writel(dev, VE4_PROT_CTRL, (0x2 << 4));
	} else {
		rtkve4_wrap_reg_writel(dev, VE4_PROT_CTRL, (0x5 << 4));
	}

	return 0;
}

static void gen_set_param_reg(struct rtkve4enc_ctx *ctx, u32 codec,
			      struct enc_cmd_set_param_reg *reg)
{
	uint32_t i;

	if (codec == W_HEVC_ENC) {
		reg->sps_param = (0 /*param.enScalingList*/ << 31) |
				 (0 /*param.enStillPicture*/ << 30) |
				 (1 /*param.strongIntraSmoothing*/ << 27) |
				 (1 /*param.intraTransSkip*/ << 25) |
				 (1 /*param.enSAO*/ << 24) |
				 (1 /*param.enTemporalMVP*/ << 23) |
				 (0 /*param.enLongTerm*/ << 21) |
				 (1 /*chromaFormatIDC*/ << 19) |
				 (8 /*param.internalBitDepth*/ << 14) |
				 (0 /*param.tier*/ << 12) |
				 (0 /*param.level*/ << 3) |
				 (0 /*param.profile*/ << 0);
		reg->pps_param = (0 /*(param.crQpOffset&0x1F)*/ << 19) |
				 (0 /*(param.cbQpOffset&0x1F)*/ << 14) |
				 (0 /*(param.tcOffsetDiv2&0xF)*/ << 10) |
				 (0 /*(param.betaOffsetDiv2&0xF)*/ << 6) |
				 (0 /*(!param.enDBK)*/ << 5) | //lint !e514
				 (1 /*param.lfCrossSliceBoundaryFlag*/ << 2) |
				 (1 /*param.constrainedIntraPred*/ << 1);
		reg->intra_param =
			(ctx->enc_params.gop_size /*param.intraPeriod*/ << 16) |
			(0 /*param.forcedIdrHeader*/ << 9) |
			(ctx->enc_params.intra_qp /*param.qp*/ << 3) |
			(1 /*param.decodingRefreshType*/ << 0);
		reg->rdo_param = (0 /*param.enCustomLambda*/ << 22) |
				 (0 /*param.meCenter*/ << 21) |
				 (0 /*param.enQpMap*/ << 20) |
				 (0 /*param.enModeMap*/ << 19) |
				 (0 /*param.enQRoundOffset*/ << 17) |
				 (1 /*param.disableCoefClear*/ << 4) |
				 (0 /*param.enAdaptiveRound*/ << 3) |
				 (1 /*param.enHvsQp*/ << 2);
		reg->slice_param = (0 /*param.sliceArg*/ << 3) |
				   (0 /*param.sliceMode*/ << 0);
		reg->quant_param_2 =
			((10 /*param.lambdaDqpInter*/ & 0x3F) << 14) |
			((10 /*param.lambdaDqpIntra*/ & 0x3F) << 8);
		reg->non_vcl_param =
			(0 /*open_param.hrdRbspDataSize*/ << 18) |
			(0 /*open_param.vuiRbspDataSize*/ << 4) |
			(0 /*open_param.encodeHrdRbspInVPS*/ << 2) |
			(0 /*open_param.encodeVuiRbsp*/ << 1) |
			(0 /*open_param.encodeAUD*/ << 0);
		reg->vui_rbsp_addr = 0 /*open_param.vuiRbspDataAddr*/;
		reg->hrd_rbsp_addr = 0 /*open_param.hrdRbspDataAddr*/;
	} else if (codec == W_AVC_ENC) {
		reg->sps_param =
			(0 /*param.enScalingList*/ << 31) |
			(0 /*param.enLongTerm*/ << 21) |
			(1 /*chromaFormatIDC*/ << 19) |
			(8 /*param.internalBitDepth*/ << 14) |
			(ctx->enc_params.s_ctrl_level_value /*param.level*/ << 3) |
			(ctx->enc_params.h264_profile_idc /*param.profile*/ << 0);
		reg->pps_param = (1 /*param.enCABAC*/ << 30) |
				 (1 /*param.transform8x8*/ << 29) |
				 (0 /*(param.crQpOffset&0x1F)*/ << 19) |
				 (0 /*(param.cbQpOffset&0x1F)*/ << 14) |
				 (0 /*(param.tcOffsetDiv2&0xF)*/ << 10) |
				 (0 /*(param.betaOffsetDiv2&0xF)*/ << 6) |
				 (0 /*(!param.enDBK)*/ << 5) | //lint !e514
				 (1 /*param.lfCrossSliceBoundaryFlag*/ << 2) |
				 (1 /*param.constrainedIntraPred*/ << 1);
		reg->intra_param =
			(0 /*param.forcedIdrHeader*/ << 28) |
			(ctx->enc_params.gop_size /*param.idrPeriod*/ << 17) |
			(ctx->enc_params.gop_size /*param.intraPeriod*/ << 6) |
			(ctx->enc_params.intra_qp /*param.qp*/ << 0);
		reg->rdo_param = (0 /*param.enCustomLambda*/ << 22) |
				 (0 /*param.meCenter*/ << 21) |
				 (0 /*param.enQpMap*/ << 20) |
				 (0 /*param.enModeMap*/ << 19) |
				 (0 /*param.enQRoundOffset*/ << 17) |
				 (1 /*param.disableCoefClear*/ << 4) |
				 (0 /*param.enAdaptiveRound*/ << 3) |
				 (1 /*param.enHvsQp*/ << 2);
		reg->slice_param = (0 /*param.sliceArg*/ << 3) |
				   (0 /*param.sliceMode*/ << 0);
		reg->quant_param_2 =
			((10 /*param.lambdaDqpInter*/ & 0x3F) << 14) |
			((10 /*param.lambdaDqpIntra*/ & 0x3F) << 8);
		reg->non_vcl_param =
			(0 /*open_param.hrdRbspDataSize*/ << 18) |
			(0 /*open_param.vuiRbspDataSize*/ << 4) |
			(0 /*open_param.encodeHrdRbspInVPS*/ << 2) |
			(0 /*open_param.encodeVuiRbsp*/ << 1) |
			(0 /*open_param.encodeAUD*/ << 0);
		reg->vui_rbsp_addr = 0 /*open_param.vuiRbspDataAddr*/;
		reg->hrd_rbsp_addr = 0 /*open_param.hrdRbspDataAddr*/;
	} else if (codec == W_AV1_ENC) {
		reg->sps_param = (0 /*param.enScalingList*/ << 31) |
				 (1 /*param.intraTransSkip*/ << 25) |
				 (0 /*param.enWiener*/ << 24) |
				 (1 /*param.enCdef*/ << 23) |
				 (0 /*param.enLongTerm*/ << 21) |
				 (1 /*chromaFormatIDC*/ << 19) |
				 (8 /*param.internalBitDepth*/ << 14) |
				 (0 /*param.level*/ << 3);
		reg->pps_param = (0 /*param.lfSharpness*/ << 6) |
				 (0 /*(!param.enDBK)*/ << 5); //lint !e514
		reg->intra_param =
			(ctx->enc_params.gop_size /*param.intraPeriod*/ << 16) |
			(0 /*param.forcedIdrHeader*/ << 9) |
			(ctx->enc_params.intra_qp /*param.qp*/ << 3);
		reg->rdo_param = (0 /*param.enCustomLambda*/ << 22) |
				 (0 /*param.meCenter*/ << 21) |
				 (0 /*param.enQpMap*/ << 20) |
				 (0 /*param.enModeMap*/ << 19) |
				 (0 /*param.enQRoundOffset*/ << 17) |
				 (1 /*param.disableCoefClear*/ << 4) |
				 (0 /*param.enAdaptiveRound*/ << 3) |
				 (1 /*param.enHvsQp*/ << 2);
		reg->quant_param_1 = (0 /*(param.uDcQpDelta&0xFF)*/ << 24) |
				     (0 /*(param.vDcQpDelta&0xFF)*/ << 16) |
				     (0 /*(param.uAcQpDelta&0xFF)*/ << 8) |
				     (0 /*(param.vAcQpDelta&0xFF)*/ << 0);
		reg->quant_param_2 =
			((10 /*param.lambdaDqpInter*/ & 0x3F) << 14) |
			((10 /*param.lambdaDqpIntra*/ & 0x3F) << 8) |
			((0 /*param.yDcQpDelta*/ & 0xFF) << 0);
		reg->tile_param = (0 /*(param.rowTileNum-1)*/ << 4) |
				  (0 /*(param.colTileNum-1)*/ << 0);
		reg->color_param =
			(0 /*(param.av1Color.chromaSamplePosition&0x3)*/ << 26) |
			(0 /*param.av1Color.colorRange*/ << 25) |
			(0 /*(param.av1Color.matrixCoefficients&0xFF)*/ << 17) |
			(0 /*(param.av1Color.transferCharacteristics&0xFF)*/ << 9) |
			(0 /*(param.av1Color.colorPrimaries&0xFF)*/ << 1) |
			(0 /*param.av1Color.colorDescriptionPresentFlag*/ << 0);
	}

	if (ctx->enableCrop) {
		reg->src_size = (ctx->crop.height << 16) |
				(ctx->crop.width << 0);
	} else {
		reg->src_size = (ctx->src_fmt.height << 16) |
				(ctx->src_fmt.width << 0);
	}

	reg->custom_map_endian = 0xf;
	reg->gop_param = (1 /*param.tempLayerCnt*/ << 16) |
			 (0 /*param.tempLayer[3].enChangeQp*/ << 11) |
			 (0 /*param.tempLayer[2].enChangeQp*/ << 10) |
			 (0 /*param.tempLayer[1].enChangeQp*/ << 9) |
			 (0 /*param.tempLayer[0].enChangeQp*/ << 8) |
			 (9 /*param.gopPreset*/ << 0);
	reg->intra_refresh = (2 /*param.intraRefreshArg*/ << 16) |
			     (1 /*param.intraRefreshMode*/ << 0);
	reg->intra_min_max_qp = (51 /*param.maxQpI*/ << 6) |
				(1 /*param.minQpI*/ << 0);
	reg->rc_frame_rate = ctx->enc_params.framerate /*param.frameRate*/;
	reg->rc_target_rate = ctx->enc_params.bitrate /*param.encBitrate*/;
	reg->rc_param = (16 /*param.rcUpdateSpeed*/ << 24) |
			(8 /*param.rcInitialLevel*/ << 20) |
			((30 /*param.rcInitialQp*/ & 0x3f) << 14) |
			(1 /*param.rcMode*/ << 13) |
			(3 /*param.picRcMaxDqp*/ << 7) |
			(1 /*param.cuLevelRateControl*/ << 1) |
			(1 /*param.enRateControl*/ << 0);
	reg->hvs_param = (10 /*param.maxDeltaQp*/ << 12) |
			 (2 /*param.hvsQpScaleDiv2*/ << 0);
	reg->rc_max_bitrate = 0 /*param.maxBitrate*/;
	reg->rc_vbv_buffer_size = 10000 /*param.vbvBufferSize*/;
	reg->inter_min_max_qp =
		(51 /*param.maxQpB*/ << 18) | (1 /*param.minQpB*/ << 12) |
		(51 /*param.maxQpP*/ << 6) | (1 /*param.minQpP*/ << 0);
	reg->rot_param = 0 /*rot*/;
	reg->conf_win_top_bot = (0 /*param.confWin.bottom*/ << 16) |
				(0 /*param.confWin.top*/ << 0);
	reg->conf_win_left_right = (0 /*param.confWin.right*/ << 16) |
				   (0 /*param.confWin.left*/ << 0);
	reg->num_units_in_tick = 0 /*param.numUnitsInTick*/;
	reg->time_scale = 0 /*param.timeScale*/;
	reg->num_ticks_poc_diff_one = 1 /*param.numTicksPocDiffOne*/;
	reg->max_intra_pic_bit = 0 /*param.maxIntraPicBit*/;
	reg->max_inter_pic_bit = 0 /*param.maxInterPicBit*/;
	reg->bg_param = ((5 /*param.bgDeltaQp*/ & 0x3F) << 24) |
			(1 /*param.bgThMeanDiff*/ << 10) |
			(8 /*param.bgThDiff*/ << 1) |
			(1 /*param.enBgDetect*/ << 0);
	reg->qround_offset = (85 /*param.qRoundInter*/ << 13) |
			     (171 /*param.qRoundIntra*/ << 2);
	reg->custom_gop_param = 1 /*param.gopParam.customGopSize*/;
	for (i = 0; i < 1 /*param.gopParam.customGopSize*/; i++) {
		reg->custom_gop_pic_param[i] =
			(0 /*pic_param.temporalId*/ << 26) |
			((0 /*pic_param.refPocL1*/ & 0x3F) << 20) |
			((0 /*pic_param.refPocL0*/ & 0x3F) << 14) |
			(0 /*pic_param.useMultiRefP*/ << 13) |
			(ctx->enc_params.intra_qp /*pic_param.picQp*/ << 7) |
			(0 /*pic_param.pocOffset*/ << 2) |
			(0 /*pic_param.picType*/ << 0);
	}
	for (i = 0; i < MAX_CUSTOM_LAMBDA_NUM; i++) {
		reg->custom_lambda[i] = (0 /*param.customLambdaSSD[i]*/ << 7) |
					(0 /*param.customLambdaSAD[i]*/ << 0);
	}
	for (i = 0; i < MAX_NUM_CHANGEABLE_TEMPORAL_LAYER; i++) {
		reg->temporal_layer_qp[i] =
			(ctx->enc_params.intra_qp /*param.tempLayer[i].qpB*/ << 12) |
			(ctx->enc_params.intra_qp /*param.tempLayer[i].qpP*/ << 6) |
			(ctx->enc_params.intra_qp /*param.tempLayer[i].qpI*/ << 0);
	}
	reg->sfs_param = (0 /*open_param.enableInputRingBuffer*/ << 4) |
			 (1 /*open_param.subFrameSyncMode*/ << 1) |
			 (0 /*open_param.subFrameSyncEnable*/ << 0);
	reg->crop_pos = (ctx->crop.left << 16) | (ctx->crop.top << 0);
	reg->crop_src_size = (ctx->src_fmt.height << 16) |
			     (ctx->src_fmt.width << 0);
	reg->ref_ring_buf_param = 0 /*open_param.refRingBufMode*/;
}

static void gen_set_fb_reg(struct rtkve4enc_ctx *ctx,
			   struct enc_cmd_set_fb_reg *reg)
{
	uint32_t buf_width = 0;
	uint32_t buf_height = 0;
	uint32_t stride_l = 0;
	uint32_t stride_c = 0;
	uint32_t i = 0;

	buf_width = ctx->align_fmt.width;
	buf_height = ctx->align_fmt.height;

	stride_l = ctx->align_fmt.stride;
	stride_c = ctx->align_fmt.stride / 2;

	reg->option =
		0 /*(open_param.enableNonRefFbcWrite <<26)*/ |
		(VDI_128BIT_LITTLE_ENDIAN /*info.frameBufPool[0].endian*/ << 16) |
		(1 << 4) | (1 << 3);
	reg->pic_size = (buf_width << 16) | (buf_height << 0);
	reg->num_fb = ((ctx->initialInfo.minFrameBufferCount - 1) << 16) |
		      ((ctx->initialInfo.reqMvColBufferCount - 1) << 0);
	reg->fbc_stride = (stride_l << 16) | (stride_c << 0);
	reg->default_cdf = ctx->vbDefCdf.paddr;

	for (i = 0; i < ctx->initialInfo.minFrameBufferCount; i++) {
		reg->fbc_y[i] = ctx->framebuf[i].paddr;
		reg->fbc_c[i] = ctx->framebuf[i].paddr +
				ctx->src_buf_width * ctx->src_buf_height;
		reg->fbc_y_offset[i] = ctx->vbFbcYTbl[i].paddr;
		reg->fbc_c_offset[i] = ctx->vbFbcCTbl[i].paddr;
		reg->sub_sampled[i] = ctx->vbSubSamBuf[i].paddr;
	}
	for (i = 0; i < ctx->initialInfo.reqMvColBufferCount; i++)
		reg->mv_col[i] = ctx->vbMV[i].paddr;
	reg->fbc_y_end = ctx->framebuf[0].paddr +
			 ctx->src_buf_width * ctx->src_buf_height - 1;
	reg->fbc_c_end = ctx->framebuf[0].paddr +
			 ctx->src_buf_width * ctx->src_buf_height * 3 / 2 - 1;
}

static void gen_enc_pic_reg(struct rtkve4enc_ctx *ctx,
			    struct enc_cmd_enc_pic_reg *reg)
{
	bool is_lsb = FALSE;
	bool is_10bit = FALSE;
	bool is_3p4b = FALSE;
	uint32_t stride_l = 0;
	uint32_t stride_c = 0;
	uint32_t src_format = 0;
	bool is_ayuv = FALSE;
	struct videc_dev *dev = ctx->dev;
	u32 cbcrInterleave = 0;
	u32 nv21 = 0;
	dma_addr_t src_buf_y = 0, src_buf_cb = 0, src_buf_cr = 0;

	switch (ctx->src_fmt.pixelformat) {
	case V4L2_PIX_FMT_NV12:
		cbcrInterleave = 1;
		nv21 = 0;
		break;
	case V4L2_PIX_FMT_NV21:
		cbcrInterleave = 1;
		nv21 = 1;
		break;
	default:
		break;
	}

	stride_l = ctx->align_fmt.stride;
	stride_c = (cbcrInterleave == 1) ? stride_l : (stride_l / 2);

	is_lsb = FALSE;
	is_3p4b = FALSE;

	src_format = (nv21 << 2) | (cbcrInterleave << 1);

	src_buf_y = ctx->src_buf_addr;
	src_buf_cb =
		ctx->src_buf_addr + ctx->src_buf_width * ctx->src_buf_height;
	src_buf_cr =
		src_buf_cb + (ctx->src_buf_width * ctx->src_buf_height / 4);
	if (cbcrInterleave) {
		src_buf_cr = 0xffffffff;
	}

	dev_dbg(dev->dev,
		"%d.%s.src_buf_y:0x%llx.src_buf_cb:0x%llx.src_buf_cr:0x%llx\n",
		__LINE__, __func__, src_buf_y, src_buf_cb, src_buf_cr);

	reg->bs_start = ctx->rdPtr /*opt.picStreamBufferAddr*/;
	reg->bs_size = ctx->bsSize /*opt.picStreamBufferSize*/;
	reg->bs_option = (1 /*info.lineBufIntEn*/ << 6);

	switch (ctx->codec_mode) {
	case W_AV1_ENC:
		if (ctx->src_fmt.width <= 2048) {
			ctx->useEncRdoEnable = 0;
			ctx->useEncLfEnable = 1; // 2048 use 32768 bytes
			dev_dbg(dev->dev,
				"[%d]%s.encWidth:%d.set axi bit:%d,%d\n",
				__LINE__, __func__, ctx->src_fmt.width,
				ctx->useEncRdoEnable, ctx->useEncLfEnable);
		} else if (ctx->src_fmt.width <= 4096) {
			ctx->useEncRdoEnable = 1; // 4096 use 26624 bytes
			ctx->useEncLfEnable = 0;
			dev_dbg(dev->dev,
				"[%d]%s.encWidth:%d.set axi bit:%d,%d\n",
				__LINE__, __func__, ctx->src_fmt.width,
				ctx->useEncRdoEnable, ctx->useEncLfEnable);
		} else {
			ctx->useEncRdoEnable = 0;
			ctx->useEncLfEnable = 0;
			dev_dbg(dev->dev,
				"[%d]%s.encWidth:%d.set axi bit:%d,%d\n",
				__LINE__, __func__, ctx->src_fmt.width,
				ctx->useEncRdoEnable, ctx->useEncLfEnable);
		}
		break;
	case W_HEVC_ENC:
		if (ctx->src_fmt.width <= 4096) {
			ctx->useEncRdoEnable = 0;
			ctx->useEncLfEnable = 1; // 4096 use 32768 bytes
			dev_dbg(dev->dev,
				"[%d]%s.encWidth:%d.set axi bit:%d,%d\n",
				__LINE__, __func__, ctx->src_fmt.width,
				ctx->useEncRdoEnable, ctx->useEncLfEnable);
		} else {
			ctx->useEncRdoEnable = 0;
			ctx->useEncLfEnable = 0;
			dev_dbg(dev->dev,
				"[%d]%s.encWidth:%d.set axi bit:%d,%d\n",
				__LINE__, __func__, ctx->src_fmt.width,
				ctx->useEncRdoEnable, ctx->useEncLfEnable);
		}
		break;
	case W_AVC_ENC:
		if (ctx->src_fmt.width <= 4096) {
			ctx->useEncRdoEnable = 0;
			ctx->useEncLfEnable = 1; // 4096 use 24576 bytes
			dev_dbg(dev->dev,
				"[%d]%s.encWidth:%d.set axi bit:%d,%d\n",
				__LINE__, __func__, ctx->src_fmt.width,
				ctx->useEncRdoEnable, ctx->useEncLfEnable);
		} else {
			ctx->useEncRdoEnable = 0;
			ctx->useEncLfEnable = 0;
			dev_dbg(dev->dev,
				"[%d]%s.encWidth:%d.set axi bit:%d,%d\n",
				__LINE__, __func__, ctx->src_fmt.width,
				ctx->useEncRdoEnable, ctx->useEncLfEnable);
		}
		break;
	default:
		break;
	}

	reg->use_sec_axi = (ctx->useEncRdoEnable << 1) |
			   (ctx->useEncLfEnable << 0);
	reg->report_param = (0 /*param.enReportMvHisto*/ << 1);
	reg->mv_histo_class0 = (0 /*param.reportMvHistoThreshold0*/ << 16) |
			       (0 /*param.reportMvHistoThreshold1*/ << 0);
	reg->mv_histo_class1 = (0 /*param.reportMvHistoThreshold2*/ << 16) |
			       (0 /*param.reportMvHistoThreshold3*/ << 0);
	reg->custom_map_param =
		(0 /*opt.customMapOpt.customModeMapEnable*/ << 1) |
		(0 /*opt.customMapOpt.customRoiMapEnable*/ << 0);
	reg->custom_map_addr = 0 /*opt.customMapOpt.customMapAddr*/;

	if (0 /*opt.srcEndFlag*/)
		reg->src_pic_idx = 0xFFFFFFFF;
	else
		reg->src_pic_idx = 0 /*opt.srcIdx*/;

	reg->src_addr_y = (u32)ctx->src_buf_addr;
	reg->src_size_y = ctx->src_buf_width * ctx->src_buf_height;
	reg->src_addr_u = (u32)src_buf_cb;
	reg->src_addr_v = (u32)src_buf_cr;
	reg->src_size_u = (cbcrInterleave == 1) ?
				  ctx->src_buf_width * ctx->src_buf_height / 2 :
				  ctx->src_buf_width * ctx->src_buf_height / 4;
	reg->src_size_v = (cbcrInterleave == 1) ?
				  0 :
				  ctx->src_buf_width * ctx->src_buf_height / 4;

	reg->src_stride = (stride_l << 16) | (stride_c << 0);
	reg->src_format = (is_ayuv << 24) | (0 /*opt.updateLast2Bit*/ << 23) |
			  (0 /*(opt.last2BitData&0x3)*/ << 21) |
			  (0 /*is_csc_format*/ << 20) |
			  (0 /*opt.csc.formatOrder*/ << 16) |
			  (0xf /*info.sourceEndian*/ << 12) | (is_lsb << 6) |
			  (is_3p4b << 5) | (is_10bit << 4) | (src_format << 0);
	reg->src_axi_sel = DEFAULT_SRC_AXI;
	if (1 /*opt.codeOption.implicitHeaderEncode*/) {
		reg->code_option = (ctx->eos /*opt.srcEndFlag*/ << 10) |
				   (0 /*opt.codeOption.encodeEOB*/ << 7) |
				   (0 /*opt.codeOption.encodeEOS*/ << 6) |
				   (CODEOPT_ENC_VCL) |
				   (CODEOPT_ENC_HEADER_IMPLICIT);
	} else {
		reg->code_option =
			(0 /*opt.codeOption.encodeEOB*/ << 7) |
			(0 /*opt.codeOption.encodeEOS*/ << 6) |
			(0 /*opt.codeOption.encodePPS*/ << 4) |
			(0 /*opt.codeOption.encodeSPS*/ << 3) |
			(0 /*opt.codeOption.encodeVPS*/ << 2) |
			(0 /*opt.codeOption.encodeVCL*/ << 1) |
			(0 /*opt.codeOption.implicitHeaderEncode*/ << 0);
	}
	reg->pic_param =
		(0 /*opt.intra4x4*/ << 28) | (1 /*opt.enFME*/ << 27) |
		(7 /*opt.cuSizeMode*/ << 24) | (0 /*opt.forcePicType*/ << 21) |
		(0 /*opt.forcePicTypeEnable*/ << 20) |
		(0 /*opt.forcePicQpB*/ << 14) | (0 /*opt.forcePicQpP*/ << 8) |
		(0 /*opt.forcePicQpI*/ << 2) |
		(0 /*opt.forcePicQpEnable*/ << 1) |
		(0 /*opt.skipPicture*/ << 0);
	reg->longterm_pic = (0 /*opt.useLongtermRef*/ << 1) |
			    (0 /*opt.useCurSrcAsLongtermPic*/ << 0);
	reg->prefix_sei_nal_addr = 0 /*opt.seiNalData.prefixSeiNalAddr*/;
	reg->prefix_sei_info = (0 /*opt.seiNalData.prefixSeiDataSize*/ << 16) |
			       (0 /*opt.seiNalData.prefixSeiNalEnable*/ << 0);
	reg->suffix_sei_nal_addr = 0 /*opt.seiNalData.suffixSeiNalAddr*/;
	reg->suffix_sei_info = (0 /*opt.seiNalData.suffixSeiDataSize*/ << 16) |
			       (0 /*opt.seiNalData.suffixSeiNalEnable*/ << 0);
	reg->timestamp = ((0 /*opt.timestamp.hour&0x1F*/) << 26) |
			 ((0 /*opt.timestamp.min&0x3F*/) << 20) |
			 ((0 /*opt.timestamp.sec&0x3F*/) << 14) |
			 ((0 /*opt.timestamp.ms&0x3FFF*/) << 0);

	reg->sfs_buf_idx = (1 << 0 /*opt.sfsBufIdx*/);
}

static int get_enc_result(struct rtkve4enc_ctx *ctx)
{
	u32 val;
	struct EncOutputInfo *ret;
	struct videc_dev *dev = ctx->dev;
	ret = &ctx->OutInfo;

	val = rtkve4_reg_readl(dev, W6_RET_SUCCESS);
	if (val == FALSE) {
		ret->errorReason = rtkve4_reg_readl(dev, W6_RET_FAIL_REASON);
		return -1;
	}

	ret->encPicCnt = rtkve4_reg_readl(dev, W6_RET_ENC_PIC_NUM);
	val = rtkve4_reg_readl(dev, W6_RET_ENC_PIC_TYPE);
	ret->picType = val & 0xFFFF;

	ret->encVclNut = rtkve4_reg_readl(dev, W6_RET_ENC_VCL_NUT);
	ret->reconFrameIndex = rtkve4_reg_readl(dev, W6_RET_ENC_PIC_IDX);
	dev_dbg(dev->dev, "%d.%s.encPicCnt:%d.picType:%d.reconFrameIndex:%d\n",
		__LINE__, __func__, ret->encPicCnt, ret->picType,
		ret->reconFrameIndex);

	ret->nonRefPicFlag =
		rtkve4_reg_readl(dev, W6_RET_ENC_PIC_NON_REF_PIC_FLAG);

	ret->numOfSlices = rtkve4_reg_readl(dev, W6_RET_ENC_PIC_SLICE_NUM);
	ret->picSkipped = rtkve4_reg_readl(dev, W6_RET_ENC_PIC_SKIP);
	ret->numOfIntra = rtkve4_reg_readl(dev, W6_RET_ENC_PIC_NUM_INTRA);
	ret->numOfMerge = rtkve4_reg_readl(dev, W6_RET_ENC_PIC_NUM_MERGE);
	ret->numOfSkipBlock = rtkve4_reg_readl(dev, W6_RET_ENC_PIC_NUM_SKIP);
	ret->bitstreamWrapAround = 0; // only support line-buffer mode.

	ret->avgCtuQp = rtkve4_reg_readl(dev, W6_RET_ENC_PIC_AVG_CTU_QP);
	ret->encPicByte = rtkve4_reg_readl(dev, W6_RET_ENC_PIC_BYTE);

	ret->encGopPicIdx = rtkve4_reg_readl(dev, W6_RET_ENC_GOP_PIC_IDX);
	ret->encPicPoc = rtkve4_reg_readl(dev, W6_RET_ENC_PIC_POC);
	ret->encSrcIdx = rtkve4_reg_readl(dev, W6_RET_ENC_USED_SRC_IDX);

	ctx->wrPtr = rtkve4_reg_readl(dev, W6_RET_ENC_WR_PTR);
	ctx->rdPtr = rtkve4_reg_readl(dev, W6_RET_ENC_RD_PTR);
	dev_dbg(dev->dev, "%d.%s.wrPtr:0x%x.rdPtr:0x%x.encPicByte:%d, POC:%d\n",
		__LINE__, __func__, ctx->wrPtr, ctx->rdPtr, ret->encPicByte,
		ret->encPicPoc);

	ret->picDistortionLow = rtkve4_reg_readl(dev, W6_RET_ENC_PIC_DIST_LOW);
	ret->picDistortionHigh =
		rtkve4_reg_readl(dev, W6_RET_ENC_PIC_DIST_HIGH);

	ret->reportMvHisto.cnt0 = rtkve4_reg_readl(dev, W6_RET_ENC_HISTO_CNT_0);
	ret->reportMvHisto.cnt1 = rtkve4_reg_readl(dev, W6_RET_ENC_HISTO_CNT_1);
	ret->reportMvHisto.cnt2 = rtkve4_reg_readl(dev, W6_RET_ENC_HISTO_CNT_2);
	ret->reportMvHisto.cnt3 = rtkve4_reg_readl(dev, W6_RET_ENC_HISTO_CNT_3);
	ret->reportMvHisto.cnt4 = rtkve4_reg_readl(dev, W6_RET_ENC_HISTO_CNT_4);

	ret->reportFmeSum.lowerX0 =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUM_ME0_X_DIR_LOWER);
	ret->reportFmeSum.higherX0 =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUM_ME0_X_DIR_HIGHER);
	ret->reportFmeSum.lowerY0 =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUM_ME0_Y_DIR_LOWER);
	ret->reportFmeSum.higherY0 =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUM_ME0_Y_DIR_HIGHER);
	ret->reportFmeSum.lowerX1 =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUM_ME1_X_DIR_LOWER);
	ret->reportFmeSum.higherX1 =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUM_ME1_X_DIR_HIGHER);
	ret->reportFmeSum.lowerY1 =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUM_ME1_Y_DIR_LOWER);
	ret->reportFmeSum.higherY1 =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUM_ME1_Y_DIR_HIGHER);

	ret->reportPicAvgRcVar.lower =
		rtkve4_reg_readl(dev, W6_RET_ENC_PIC_AVG_RC_VAR_LOWER);
	ret->reportPicAvgRcVar.higher =
		rtkve4_reg_readl(dev, W6_RET_ENC_PIC_AVG_RC_VAR_HIGHER);
	ret->reportMvMagSum.l0Lower =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUM_MV_MAG_L0_LOWER);
	ret->reportMvMagSum.l0Higher =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUM_MV_MAG_L0_HIGHER);
	ret->reportMvMagSum.l1Lower =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUM_MV_MAG_L1_LOWER);
	ret->reportMvMagSum.l1Higher =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUM_MV_MAG_L1_HIGHER);

	ret->sourceYAddr = rtkve4_reg_readl(dev, W6_RET_ENC_SRC_Y_ADDR);
	ret->customMapAddr =
		rtkve4_reg_readl(dev, W6_RET_ENC_CUSTOM_MAP_OPTION_ADDR);
	ret->prefixSeiNalAddr =
		rtkve4_reg_readl(dev, W6_RET_ENC_PREFIX_SEI_NAL_ADDR);
	ret->suffixSeiNalAddr =
		rtkve4_reg_readl(dev, W6_RET_ENC_SUFFIX_SEI_NAL_ADDR);

	val = rtkve4_reg_readl(dev, W6_RET_ENC_TIMESTAMP);
	ret->timestamp.hour = (val >> 26) & 0x1F;
	ret->timestamp.min = (val >> 20) & 0x3F;
	ret->timestamp.sec = (val >> 14) & 0x3F;
	ret->timestamp.ms = (val >> 0) & 0x3FFF;

	ret->bitstreamBuffer = rtkve4_reg_readl(dev, W6_RET_ENC_RD_PTR);
	ret->rdPtr = ctx->rdPtr;
	ret->wrPtr = ctx->wrPtr;

	if (ret->reconFrameIndex ==
	    RECON_IDX_FLAG_HEADER_ONLY) //result for header only(no vcl) encoding
		ret->bitstreamSize = ret->encPicByte;
	else if (ret->reconFrameIndex < 0)
		ret->bitstreamSize = 0;
	else
		ret->bitstreamSize = ret->encPicByte;

	ret->cycle.hostCmdStartTick = rtkve4_reg_readl(dev, W6_CMD_CQ_IN_TICK);
	ret->cycle.hostCmdEndTick = rtkve4_reg_readl(dev, W6_CMD_RQ_OUT_TICK);
	ret->cycle.processingStartTick =
		rtkve4_reg_readl(dev, W6_CMD_HW_RUN_TICK);
	ret->cycle.processingEndTick =
		rtkve4_reg_readl(dev, W6_CMD_HW_DONE_TICK);
	ret->cycle.vpuStartTick = rtkve4_reg_readl(dev, W6_CMD_FW_RUN_TICK);
	ret->cycle.vpuEndTick = rtkve4_reg_readl(dev, W6_CMD_FW_DONE_TICK);
	ret->cycle.frameCycle =
		(ret->cycle.vpuEndTick - ret->cycle.hostCmdStartTick) * 256;
	ret->cycle.processingCycle = (ret->cycle.processingEndTick -
				      ret->cycle.processingStartTick) *
				     256;
	ret->cycle.vpuCycle =
		((ret->cycle.vpuEndTick - ret->cycle.vpuStartTick) -
		 (ret->cycle.processingEndTick -
		  ret->cycle.processingStartTick)) *
		256;

	return 0;
}

static int enc_vpu_encopen(struct rtkve4enc_ctx *ctx)
{
	struct videc_dev *dev = ctx->dev;
	int ret = 0;
	u32 temp = 0;

	lockdep_assert_held(&dev->ve4_hw_mutex);

	dev_dbg(dev->dev, "%d.%s.[+]\n", __LINE__, __func__);

	if (ctx->dst_fmt.pixelformat == V4L2_PIX_FMT_HEVC) {
		ctx->codec_mode = W_HEVC_ENC;
	} else if (ctx->dst_fmt.pixelformat == V4L2_PIX_FMT_H264) {
		ctx->codec_mode = W_AVC_ENC;
	} else if (ctx->dst_fmt.pixelformat == V4L2_PIX_FMT_AV1) {
		ctx->codec_mode = W_AV1_ENC;
	} else {
		dev_err(dev->dev, "%d.%s.RETCODE_INVALID_PARAM\n", __LINE__,
			__func__);
		return -EINVAL;
	}

	rtkve4_reg_writel(dev, W6_CMD_ENC_CREATE_INST_TEMP_BASE,
			  ctx->vbTemp.paddr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_CREATE_INST_TEMP_SIZE,
			  ctx->vbTemp.size);
	rtkve4_reg_writel(dev, W6_CMD_ENC_CREATE_INST_AR_TABLE_BASE,
			  ctx->vbAr.paddr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_CREATE_INST_WORK_BASE,
			  ctx->workbuf.paddr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_CREATE_INST_WORK_SIZE,
			  ctx->workbuf.size);
	rtkve4_reg_writel(dev, W6_CMD_ENC_CREATE_INST_BS_PARAM, 0xf);
	rtkve4_reg_writel(dev, W6_CMD_ENC_CREATE_INST_SRC_OPT, 0);
	rtkve4_reg_writel(dev, W6_CMD_ENC_CREATE_INST_ADDR_EXT,
			  0); //param->extAddrVcpu

	rtkve4_reg_writel(dev, W6_CMD_ENC_CREATE_INST_CORE_INFO,
			  (1 << 4) | (1 << 0));
	rtkve4_reg_writel(dev, W6_CMD_ENC_CREATE_INST_SEC_AXI_BASE_CORE0,
			  ctx->vbSecAxi.paddr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_CREATE_INST_SEC_AXI_SIZE_CORE0,
			  ctx->vbSecAxi.size);
	rtkve4_reg_writel(
		dev, W6_CMD_ENC_CREATE_INST_PRIORITY,
		0); //(param->isSecureInst        <<8) |((param->instPriority&0xFF) <<0)
	rtkve4_reg_writel(dev, W6_CMD_ENC_CREATE_INST_CLK_CTRL,
			  0); //param->disableFCG

	//W6_CREATE_INSTANCE
	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_CMD_INSTANCE_INFO:0x%x.value:0x%x\n",
		__LINE__, __func__, W6_CMD_INSTANCE_INFO,
		(ctx->codec_mode << 16));
	rtkve4_reg_writel(dev, W6_CMD_INSTANCE_INFO,
			  (ctx->codec_mode << 16) | (ctx->inst_index & 0xffff));
	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_VPU_CMD_BUSY_STATUS:0x%x.value:1\n",
		__LINE__, __func__, W6_VPU_CMD_BUSY_STATUS);
	rtkve4_reg_writel(dev, W6_VPU_CMD_BUSY_STATUS, 1);
	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_COMMAND:0x%x.value:0x%x\n",
		__LINE__, __func__, W6_COMMAND, W6_CREATE_INSTANCE);
	rtkve4_reg_writel(dev, W6_COMMAND, W6_CREATE_INSTANCE);
	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_VPU_HOST_INT_REQ:0x%x.value:1\n",
		__LINE__, __func__, W6_VPU_HOST_INT_REQ);
	rtkve4_reg_writel(dev, W6_VPU_HOST_INT_REQ, 1);
	dev_dbg(dev->dev,
		"[%d]%s.cmd:0x%x.W6_VPU_VPU_INT_STS:0x%x.W6_VPU_VINT_REASON:0x%x\n",
		__LINE__, __func__, W6_CREATE_INSTANCE,
		rtkve4_reg_readl(dev, W6_VPU_VPU_INT_STS),
		rtkve4_reg_readl(dev, W6_VPU_VINT_REASON));

	ret = rtkve4_wait_busy(dev, W6_VPU_CMD_BUSY_STATUS);
	if (ret) {
		dev_err(dev->dev,
			"%d.%s.timeout for checking BIT_BUSY_FLAG.ret:%d\n",
			__LINE__, __func__, ret);
		return -ETIMEDOUT;
	}

	if (rtkve4_reg_readl(dev, W6_RET_SUCCESS) == FALSE) {
		temp = rtkve4_reg_readl(dev, W6_RET_FAIL_REASON);
		dev_err(dev->dev, "FAIL_REASON = 0x%x\n", temp);
		ret = -1;
	}

	temp = rtkve4_reg_readl(dev, W6_RET_INSTANCE_ID);
	dev_dbg(dev->dev, "%d.%s.[-] ret:%d.instIndex:%d\n", __LINE__, __func__,
		ret, temp);

	ctx->open_encoder_done = 1;

	return ret;
}

static int enc_seq_init(struct rtkve4enc_ctx *ctx)
{
	struct enc_cmd_set_param_reg reg;
	struct videc_dev *dev = ctx->dev;
	u32 i;
	int ret = 0;
	int intr_reason = 0;

	lockdep_assert_held(&dev->ve4_hw_mutex);

	/* VPU_EncIssueSeqInit() */

	memset(&reg, 0, sizeof(struct enc_cmd_set_param_reg));

	gen_set_param_reg(ctx, ctx->codec_mode, &reg);

	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_OPTION,
			  W6_SET_PARAM_OPT_COMMON);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_ENABLE, reg.enable);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_SRC_SIZE, reg.src_size);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_CUSTOM_MAP_ENDIAN,
			  reg.custom_map_endian);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_SPS_PARAM, reg.sps_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_PPS_PARAM, reg.pps_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_GOP_PARAM, reg.gop_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_INTRA_PARAM,
			  reg.intra_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_CONF_WIN_TOP_BOT,
			  reg.conf_win_top_bot);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_CONF_WIN_LEFT_RIGHT,
			  reg.conf_win_left_right);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_RDO_PARAM, reg.rdo_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_SLICE_PARAM,
			  reg.slice_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_INTRA_REFRESH,
			  reg.intra_refresh);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_INTRA_MIN_MAX_QP,
			  reg.intra_min_max_qp);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_RC_FRAME_RATE,
			  reg.rc_frame_rate);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_RC_TARGET_RATE,
			  reg.rc_target_rate);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_RC_PARAM, reg.rc_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_HVS_PARAM, reg.hvs_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_RC_MAX_BITRATE,
			  reg.rc_max_bitrate);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_RC_VBV_BUFFER_SIZE,
			  reg.rc_vbv_buffer_size);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_INTER_MIN_MAX_QP,
			  reg.inter_min_max_qp);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_ROT_PARAM, reg.rot_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_NUM_UNITS_IN_TICK,
			  reg.num_units_in_tick);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_TIME_SCALE, reg.time_scale);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_NUM_TICKS_POC_DIFF_ONE,
			  reg.num_ticks_poc_diff_one);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_MAX_INTRA_PIC_BIT,
			  reg.max_intra_pic_bit);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_MAX_INTER_PIC_BIT,
			  reg.max_inter_pic_bit);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_BG_PARAM, reg.bg_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_NON_VCL_PARAM,
			  reg.non_vcl_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_VUI_RBSP_ADDR,
			  reg.vui_rbsp_addr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_HRD_RBSP_ADDR,
			  reg.hrd_rbsp_addr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_QROUND_OFFSET,
			  reg.qround_offset);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_QUANT_PARAM_1,
			  reg.quant_param_1);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_QUANT_PARAM_2,
			  reg.quant_param_2);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_CUSTOM_GOP_PARAM,
			  reg.custom_gop_param);
	for (i = 0; i < MAX_GOP_NUM; i++) {
		rtkve4_reg_writel(dev,
				  W6_CMD_ENC_SET_PARAM_CUSTOM_GOP_PIC_PARAM_0 +
					  (i * 4),
				  reg.custom_gop_pic_param[i]);
	}
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_TILE_PARAM, reg.tile_param);
	for (i = 0; i < MAX_CUSTOM_LAMBDA_NUM; i++) {
		rtkve4_reg_writel(
			dev, W6_CMD_ENC_SET_PARAM_CUSTOM_LAMBDA_0 + (i * 4),
			reg.custom_lambda[i]);
	}
	for (i = 0; i < MAX_NUM_CHANGEABLE_TEMPORAL_LAYER; i++) {
		rtkve4_reg_writel(
			dev, W6_CMD_ENC_SET_PARAM_TEMPORAL_LAYER_0_QP + (i * 4),
			reg.temporal_layer_qp[i]);
	}
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_SFS_PARAM, reg.sfs_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_CROP_ENABLE,
			  ctx->enableCrop ? 1 : 0);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_CROP_POS, reg.crop_pos);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_CROP_SRC_SIZE,
			  reg.crop_src_size);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_REF_RINGBUF_PARAM,
			  reg.ref_ring_buf_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_PARAM_COLOR_PARAM,
			  reg.color_param);

	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_CMD_INSTANCE_INFO:0x%x.value:0x%x\n",
		__LINE__, __func__, W6_CMD_INSTANCE_INFO,
		(ctx->codec_mode << 16) | (ctx->inst_index & 0xffff));
	rtkve4_reg_writel(dev, W6_CMD_INSTANCE_INFO,
			  (ctx->codec_mode << 16) | (ctx->inst_index & 0xffff));

	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_VPU_CMD_BUSY_STATUS:0x%x.value:1\n",
		__LINE__, __func__, W6_VPU_CMD_BUSY_STATUS);
	rtkve4_reg_writel(dev, W6_VPU_CMD_BUSY_STATUS, 1);
	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_COMMAND:0x%x.value:0x%x\n",
		__LINE__, __func__, W6_COMMAND, W6_ENC_SET_PARAM);
	rtkve4_reg_writel(dev, W6_COMMAND, W6_ENC_SET_PARAM);

	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_VPU_HOST_INT_REQ:0x%x.value:1\n",
		__LINE__, __func__, W6_VPU_HOST_INT_REQ);
	rtkve4_reg_writel(dev, W6_VPU_HOST_INT_REQ, 1);

	dev_dbg(dev->dev,
		"[%d]%s.cmd:0x%x.W6_VPU_VPU_INT_STS:0x%x.W6_VPU_VINT_REASON:0x%x\n",
		__LINE__, __func__, W6_ENC_SET_PARAM,
		rtkve4_reg_readl(dev, W6_VPU_VPU_INT_STS),
		rtkve4_reg_readl(dev, W6_VPU_VINT_REASON));

	/* wait interrupt HandlingInterruptFlag() */
	intr_reason = rtkve4_wait_interrupt(ctx, RTKVE4_ENC_TIMEOUT);
	if (intr_reason < 0) {
		dev_err(dev->dev, "%d.%s.rtkve4_wait_interrupt() fail\n",
			__LINE__, __func__);
		return intr_reason;
	}
	dev_dbg(dev->dev, "%d.%s.intr_reason:0x%x\n", __LINE__, __func__,
		intr_reason);

	rtkve4_clear_interrupt(ctx);

	/* VPU_EncCompleteSeqInit() -> Wave6VpuEncGetSeqInfo() */
	// get result
	dev_dbg(dev->dev, "%d.%s.[+] supportCommandQueue:%d\n", __LINE__,
		__func__, 0);

	if (1 != rtkve4_reg_readl(dev, W6_RET_SUCCESS)) {
		ctx->initialInfo.seqInitErrReason =
			rtkve4_reg_readl(dev, W6_RET_FAIL_REASON);
		ret = -1;
		dev_err(dev->dev, "%d.%s.RETCODE_FAILURE. Reason: 0x%x\n",
			__LINE__, __func__, ctx->initialInfo.seqInitErrReason);
	}

	ctx->initialInfo.minFrameBufferCount =
		rtkve4_reg_readl(dev, W6_RET_ENC_NUM_REQUIRED_FBC_FB);
	ctx->initialInfo.minSrcFrameCount =
		rtkve4_reg_readl(dev, W6_RET_ENC_MIN_SRC_BUF_NUM);
	ctx->initialInfo.reqMvColBufferCount =
		rtkve4_reg_readl(dev, W6_RET_ENC_NUM_REQUIRED_COL_BUF);
	ctx->initialInfo.maxLatencyPictures =
		rtkve4_reg_readl(dev, W6_RET_ENC_PIC_MAX_LATENCY_PICTURES);
	dev_dbg(dev->dev,
		"[%d]%s.minFrameBufferCount:0x%x,minSrcFrameCount:0x%x,reqMvColBufferCount:0x%x,maxLatencyPictures:0x%x\n",
		__LINE__, __func__, ctx->initialInfo.minFrameBufferCount,
		ctx->initialInfo.minSrcFrameCount,
		ctx->initialInfo.reqMvColBufferCount,
		ctx->initialInfo.maxLatencyPictures);

	dev_dbg(dev->dev, "%d.%s.[-] retCode:%d\n", __LINE__, __func__, ret);
	ctx->enc_min_fb_num =
		ctx->initialInfo
			.minFrameBufferCount; // reconstructed frame + reference frame
	ctx->seq_init_done = 1;

	return ret;
}

static int enc_reg_fbs(struct rtkve4enc_ctx *ctx, TiledMapType mapType)
{
	int ret = 0;
	struct videc_dev *dev = ctx->dev;
	u32 idx;
	struct enc_cmd_set_fb_reg reg;

	lockdep_assert_held(&dev->ve4_hw_mutex);

	memset(&reg, 0x00, sizeof(struct enc_cmd_set_fb_reg));

	if (ctx->codec_mode == W_AV1_ENC) {
		if (!ctx->vbDefCdf.vaddr)
			return -1;

		ret = load_av1_cdf_table(ctx);
		if (ret < 0)
			return ret;
	}

	gen_set_fb_reg(ctx, &reg);

	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_FB_OPTION, reg.option);
	//rtkve4_reg_writel(dev, W6_CMD_ENC_SET_FB_PIC_INFO, reg.pic_info); // NOT used in current FW
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_FB_PIC_SIZE, reg.pic_size);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_FB_NUM, reg.num_fb);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_FB_FBC_STRIDE, reg.fbc_stride);
	rtkve4_reg_writel(dev, W6_CMD_ENC_SET_FB_DEFAULT_CDF, reg.default_cdf);
	for (idx = 0; idx < ctx->initialInfo.minFrameBufferCount; idx++) {
		rtkve4_reg_writel(dev, W6_CMD_ENC_SET_FB_FBC_Y0 + (idx * 24),
				  reg.fbc_y[idx]);
		rtkve4_reg_writel(dev, W6_CMD_ENC_SET_FB_FBC_C0 + (idx * 24),
				  reg.fbc_c[idx]);
		rtkve4_reg_writel(dev,
				  W6_CMD_ENC_SET_FB_FBC_Y_OFFSET0 + (idx * 24),
				  reg.fbc_y_offset[idx]);
		rtkve4_reg_writel(dev,
				  W6_CMD_ENC_SET_FB_FBC_C_OFFSET0 + (idx * 24),
				  reg.fbc_c_offset[idx]);
		rtkve4_reg_writel(dev,
				  W6_CMD_ENC_SET_FB_SUB_SAMPLED0 + (idx * 24),
				  reg.sub_sampled[idx]);
	}
	for (idx = 0; idx < ctx->initialInfo.reqMvColBufferCount; idx++)
		rtkve4_reg_writel(dev, W6_CMD_ENC_SET_FB_MV_COL0 + (idx * 24),
				  reg.mv_col[idx]);
	if (0 /*info->openParam.refRingBufMode*/) {
		rtkve4_reg_writel(dev, W6_CMD_ENC_SET_FB_FBC_Y0_END,
				  reg.fbc_y_end);
		rtkve4_reg_writel(dev, W6_CMD_ENC_SET_FB_FBC_C0_END,
				  reg.fbc_c_end);
	}

	rtkve4_reg_writel(dev, W6_CMD_INSTANCE_INFO,
			  (ctx->codec_mode << 16) | (ctx->inst_index & 0xffff));
	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_VPU_CMD_BUSY_STATUS:0x%x.value:1\n",
		__LINE__, __func__, W6_VPU_CMD_BUSY_STATUS);
	rtkve4_reg_writel(dev, W6_VPU_CMD_BUSY_STATUS, 1);
	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_COMMAND:0x%x.value:0x%x\n",
		__LINE__, __func__, W6_COMMAND, W6_SET_FB);
	rtkve4_reg_writel(dev, W6_COMMAND, W6_SET_FB);

	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_VPU_HOST_INT_REQ:0x%x.value:1\n",
		__LINE__, __func__, W6_VPU_HOST_INT_REQ);
	rtkve4_reg_writel(dev, W6_VPU_HOST_INT_REQ, 1);

	dev_dbg(dev->dev,
		"[%d]%s.cmd:0x%x.W6_VPU_VPU_INT_STS:0x%x.W6_VPU_VINT_REASON:0x%x\n",
		__LINE__, __func__, W6_SET_FB,
		rtkve4_reg_readl(dev, W6_VPU_VPU_INT_STS),
		rtkve4_reg_readl(dev, W6_VPU_VINT_REASON));

	if (rtkve4_wait_busy(dev, W6_VPU_CMD_BUSY_STATUS) == -1) {
		dev_err(dev->dev, "%d.%s.wait busy timeout\n", __LINE__,
			__func__);
		return -ETIMEDOUT;
	}

	if (rtkve4_reg_readl(dev, W6_RET_SUCCESS) == 0) {
		dev_err(dev->dev, "%d.%s.set frame buffer fail\n", __LINE__,
			__func__);
		return -1;
	}

	ctx->reg_fbs_done = 1;

	return ret;
}

static int enc_header(struct rtkve4enc_ctx *ctx)
{
	int ret = 0;
	struct videc_dev *dev = ctx->dev;
	int intr_reason = 0;
	u32 reason = 0;

	if (ctx->codec_mode == W_HEVC_ENC) {
		ctx->headerType =
			CODEOPT_ENC_VPS | CODEOPT_ENC_SPS | CODEOPT_ENC_PPS;
	} else {
		// H.264, AV1
		ctx->headerType = CODEOPT_ENC_SPS | CODEOPT_ENC_PPS;
	}

	/* rdPtr, wrPtr */
	ctx->rdPtr = (u32)(ctx->bitstream.paddr);
	ctx->wrPtr = (u32)(ctx->bitstream.paddr);

	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_BS_START, ctx->wrPtr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_BS_SIZE, ctx->bitstream.size);

	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_CODE_OPTION, ctx->headerType);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_SRC_PIC_IDX, 0);

	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_CMD_INSTANCE_INFO:0x%x.value:0x%x\n",
		__LINE__, __func__, W6_CMD_INSTANCE_INFO,
		(ctx->codec_mode << 16) | (ctx->inst_index && 0xffff));
	rtkve4_reg_writel(dev, W6_CMD_INSTANCE_INFO,
			  (ctx->codec_mode << 16) | (ctx->inst_index & 0xffff));
	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_VPU_CMD_BUSY_STATUS:0x%x.value:1\n",
		__LINE__, __func__, W6_VPU_CMD_BUSY_STATUS);
	rtkve4_reg_writel(dev, W6_VPU_CMD_BUSY_STATUS, 1);
	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_COMMAND:0x%x.value:0x%x\n",
		__LINE__, __func__, W6_COMMAND, W6_ENC_PIC);
	rtkve4_reg_writel(dev, W6_COMMAND, W6_ENC_PIC);
	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_VPU_HOST_INT_REQ:0x%x.value:1\n",
		__LINE__, __func__, W6_VPU_HOST_INT_REQ);
	rtkve4_reg_writel(dev, W6_VPU_HOST_INT_REQ, 1);
	dev_dbg(dev->dev,
		"[%d]%s.cmd:0x%x.W6_VPU_VPU_INT_STS:0x%x.W6_VPU_VINT_REASON:0x%x\n",
		__LINE__, __func__, W6_ENC_PIC,
		rtkve4_reg_readl(dev, W6_VPU_VPU_INT_STS),
		rtkve4_reg_readl(dev, W6_VPU_VINT_REASON));

	/* wait interrupt HandlingInterruptFlag() */
	intr_reason = rtkve4_wait_interrupt(ctx, RTKVE4_ENC_TIMEOUT);
	if (intr_reason < 0) {
		dev_err(dev->dev, "%d.%s.rtkve4_wait_interrupt() fail\n",
			__LINE__, __func__);
		return intr_reason;
	}
	dev_dbg(dev->dev, "%d.%s.intr_reason:0x%x\n", __LINE__, __func__,
		intr_reason);

	rtkve4_clear_interrupt(ctx);

	ctx->wrPtr = rtkve4_reg_readl(dev, W6_RET_ENC_WR_PTR);
	ctx->rdPtr = rtkve4_reg_readl(dev, W6_RET_ENC_RD_PTR);
	ctx->bsSize = ctx->enc_hdr_buf_size = ctx->enc_hdr_bytes =
		rtkve4_reg_readl(dev, W6_RET_ENC_PIC_BYTE);
	ctx->enc_hdr_buf = (void *)(ctx->bitstream.vaddr);
	dev_dbg(dev->dev, "%d.%s.streamWrPtr:0x%x.streamRdPtr:0x%x.size:%d\n",
		__LINE__, __func__, ctx->rdPtr, ctx->wrPtr, ctx->bsSize);

	if (rtkve4_reg_readl(dev, W6_RET_SUCCESS) == FALSE) {
		reason = rtkve4_reg_readl(dev, W6_RET_FAIL_REASON);
		dev_err(dev->dev, "%d.%s.reason:0x%x\n", __LINE__, __func__,
			reason);
		ret = -1;
	}

	ctx->enc_header_done = 1;

	return ret;
}

static int enc_copy_hdr(struct rtkve4enc_ctx *ctx, void *cap_buf,
			int cap_buf_size, int frm_bytes)
{
	int ret = 0;
	struct videc_dev *dev = ctx->dev;
	void *tmp_buf = NULL;

	if ((frm_bytes + ctx->enc_hdr_bytes) > cap_buf_size) {
		dev_err(dev->dev, "[%d]%s.no space for copy hdr to cap buf\n",
			__LINE__, __func__);
		return -EINVAL;
	}
	if ((ctx->enc_hdr_bytes == 0) || (ctx->enc_hdr_buf_size == 0) ||
	    (ctx->enc_hdr_buf == NULL)) {
		dev_err(dev->dev, "[%d]%s.hdr buf is empty\n", __LINE__,
			__func__);
		return -EINVAL;
	}

	tmp_buf = (unsigned char *)vmalloc(frm_bytes);
	if (!tmp_buf) {
		dev_err(dev->dev, "[%d]%s.vmalloc() fail\n", __LINE__,
			__func__);
		return -ENOMEM;
	}

	memcpy(tmp_buf, cap_buf, frm_bytes);
	memcpy(cap_buf, ctx->enc_hdr_buf, ctx->enc_hdr_bytes);
	memcpy(((unsigned char *)cap_buf + ctx->enc_hdr_bytes), tmp_buf,
	       frm_bytes);

	vfree(tmp_buf);
	tmp_buf = NULL;

	return ret;
}

static int enc_pic(struct rtkve4enc_ctx *ctx)
{
	int ret = 0;
	struct vb2_v4l2_buffer *src_buf = NULL;
	struct vb2_v4l2_buffer *dst_buf = NULL;
	unsigned char *p = NULL;
	u32 offset = 0;
	u32 len = 0;
	dma_addr_t src_buf_y = 0;
	dma_addr_t dst_buf_paddr = 0;
	u32 dst_buf_size = 0;
	u32 dst_buf_payload = 0;
	void *dst_buf_vaddr = NULL;
	struct videc_dev *dev = ctx->dev;
	u32 is_idr = 0;
	u32 enc_frm_bs_bytes;
	int intr_reason = 0;
	struct enc_cmd_enc_pic_reg reg;

	ctx->enc_pic_done = 0;

	rtk_set_ve4_prot_mode(
		ctx, 0 /*inst->isUseProtectBuffer*/); // ENABLE_TEE_DRM_FLOW

	memset(&reg, 0x00, sizeof(struct enc_cmd_enc_pic_reg));

	src_buf = v4l2_m2m_next_src_buf(ctx->v4l2_fh.m2m_ctx);
	if (!src_buf) {
		dev_err(dev->dev, "%d.%s.v4l2_m2m_next_src_buf() fail\n",
			__LINE__, __func__);
		ret = -EINVAL;
		return ret;
	}

	dst_buf = v4l2_m2m_next_dst_buf(ctx->v4l2_fh.m2m_ctx);
	if (!dst_buf) {
		dev_err(dev->dev, "%d.%s.v4l2_m2m_next_dst_buf() fail\n",
			__LINE__, __func__);
		ret = -EINVAL;
		return ret;
	}

	dev_dbg(dev->dev, "%d.%s.src_buf:0x%px.index:%d.sequence:%d\n",
		__LINE__, __func__, src_buf, src_buf->vb2_buf.index,
		src_buf->sequence);
	dev_dbg(dev->dev, "%d.%s.dst_buf:0x%px.index:%d.sequence:%d\n",
		__LINE__, __func__, dst_buf, dst_buf->vb2_buf.index,
		dst_buf->sequence);

	p = (unsigned char *)vb2_plane_vaddr(&src_buf->vb2_buf, 0);
	len = src_buf->vb2_buf.planes[0].bytesused;
	offset = src_buf->vb2_buf.planes[0].data_offset;

	if (src_buf->sequence == 0) {
		ctx->outbuf_new_file = 1;
#if defined(RTKVE4_DUMP_OUTBUF_EN)
		dump_outbuf(ctx, p, offset, len);
#endif
	}

	src_buf_y = vb2_dma_contig_plane_dma_addr(&src_buf->vb2_buf, 0) +
		    src_buf->vb2_buf.planes[0].data_offset;
	ctx->src_buf_addr = src_buf_y;

	dst_buf_paddr = vb2_dma_contig_plane_dma_addr(&dst_buf->vb2_buf, 0) +
			dst_buf->vb2_buf.planes[0].data_offset;
	dst_buf_size = vb2_plane_size(&dst_buf->vb2_buf, 0);
	dst_buf_vaddr = vb2_plane_vaddr(&dst_buf->vb2_buf, 0);
	dev_dbg(dev->dev,
		"%d.%s.dst_buf_paddr:0x%llx.dst_buf_size:%d.dst_buf_vaddr:%px\n",
		__LINE__, __func__, dst_buf_paddr, dst_buf_size, dst_buf_vaddr);

	/* rdPtr, wrPtr */
	ctx->wrPtr = (u32)dst_buf_paddr;
	ctx->rdPtr = (u32)dst_buf_paddr;
	ctx->bsSize = dst_buf_size;

	gen_enc_pic_reg(ctx, &reg);

	/* if ringBufferEnable == 0 */
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_BS_START, reg.bs_start);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_BS_SIZE, reg.bs_size);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_BS_OPTION, reg.bs_option);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_USE_SEC_AXI, reg.use_sec_axi);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_REPORT_PARAM, reg.report_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_MV_HISTO_CLASS0,
			  reg.mv_histo_class0);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_MV_HISTO_CLASS1,
			  reg.mv_histo_class1);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_CUSTOM_MAP_OPTION_PARAM,
			  reg.custom_map_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_CUSTOM_MAP_OPTION_ADDR,
			  reg.custom_map_addr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_SRC_PIC_IDX, reg.src_pic_idx);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_SRC_ADDR_Y, reg.src_addr_y);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_SRC_ADDR_U, reg.src_addr_u);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_SRC_ADDR_V, reg.src_addr_v);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_SRC_STRIDE, reg.src_stride);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_SRC_FORMAT, reg.src_format);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_SRC_AXI_SEL, reg.src_axi_sel);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_CODE_OPTION, reg.code_option);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_PIC_PARAM, reg.pic_param);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_LONGTERM_PIC, reg.longterm_pic);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_PREFIX_SEI_NAL_ADDR,
			  reg.prefix_sei_nal_addr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_PREFIX_SEI_INFO,
			  reg.prefix_sei_info);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_SUFFIX_SEI_NAL_ADDR,
			  reg.suffix_sei_nal_addr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_SUFFIX_SEI_INFO,
			  reg.suffix_sei_info);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_CF50D_CTRL, reg.cf50d_ctrl);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_CF50D_OFST_BASE_Y,
			  reg.cf50d_ofst_base_y);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_CF50D_OFST_BASE_CB,
			  reg.cf50d_ofst_base_cb);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_CF50D_OFST_BASE_CR,
			  reg.cf50d_ofst_base_cr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_IRB_CF50D_OFST_CURR_Y,
			  reg.irb_cf50d_ofst_curr_y);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_IRB_CF50D_OFST_CURR_CB,
			  reg.irb_cf50d_ofst_curr_cb);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_IRB_CF50D_OFST_CURR_CR,
			  reg.irb_cf50d_ofst_curr_cr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_IRB_CF50D_OFST_END_Y,
			  reg.irb_cf50d_ofst_end_y);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_IRB_CF50D_OFST_END_CB,
			  reg.irb_cf50d_ofst_end_cb);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_IRB_CF50D_OFST_END_CR,
			  reg.irb_cf50d_ofst_end_cr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_TIMESTAMP, reg.timestamp);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_SFS_BUF_IDX, reg.sfs_buf_idx);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_IRB_CURR_Y, reg.irb_curr_y);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_IRB_CURR_CB, reg.irb_curr_cb);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_IRB_CURR_CR, reg.irb_curr_cr);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_IRB_END_Y, reg.irb_end_y);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_IRB_END_CB, reg.irb_end_cb);
	rtkve4_reg_writel(dev, W6_CMD_ENC_PIC_IRB_END_CR, reg.irb_end_cr);

	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_CMD_INSTANCE_INFO:0x%x.value:0x%x\n",
		__LINE__, __func__, W6_CMD_INSTANCE_INFO,
		(ctx->codec_mode << 16) | (ctx->inst_index & 0xffff));
	rtkve4_reg_writel(dev, W6_CMD_INSTANCE_INFO,
			  (ctx->codec_mode << 16) | (ctx->inst_index & 0xffff));

	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_VPU_CMD_BUSY_STATUS:0x%x.value:1\n",
		__LINE__, __func__, W6_VPU_CMD_BUSY_STATUS);
	rtkve4_reg_writel(dev, W6_VPU_CMD_BUSY_STATUS, 1);
	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_COMMAND:0x%x.value:0x%x\n",
		__LINE__, __func__, W6_COMMAND, W6_ENC_PIC);
	rtkve4_reg_writel(dev, W6_COMMAND, W6_ENC_PIC);

	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_VPU_HOST_INT_REQ:0x%x.value:1\n",
		__LINE__, __func__, W6_VPU_HOST_INT_REQ);
	rtkve4_reg_writel(dev, W6_VPU_HOST_INT_REQ, 1);

	dev_dbg(dev->dev,
		"[%d]%s.cmd:0x%x.W6_VPU_VPU_INT_STS:0x%x.W6_VPU_VINT_REASON:0x%x\n",
		__LINE__, __func__, W6_ENC_PIC,
		rtkve4_reg_readl(dev, W6_VPU_VPU_INT_STS),
		rtkve4_reg_readl(dev, W6_VPU_VINT_REASON));

	dev_dbg(dev->dev, "%d.%s.enter, src_buf->sequence %d\n", __LINE__,
		__func__, src_buf->sequence);

	/* wait interrupt HandlingInterruptFlag() */
	intr_reason = rtkve4_wait_interrupt(ctx, RTKVE4_ENC_TIMEOUT);
	if (intr_reason < 0) {
		dev_err(dev->dev, "%d.%s.rtkve4_wait_interrupt() fail\n",
			__LINE__, __func__);
		return intr_reason;
	}
	dev_dbg(dev->dev, "%d.%s.intr_reason:0x%x\n", __LINE__, __func__,
		intr_reason);

	rtkve4_clear_interrupt(ctx);

	/* pic option, related to fieldRun/forceIPicture */
	if (src_buf->sequence == 0 || ctx->enc_params.force_key_frame) {
		is_idr = 1;
		/* clear one-shot request */
		ctx->enc_params.force_key_frame = false;
	}

	//Wave6VpuEncGetResult
	get_enc_result(ctx);

	enc_frm_bs_bytes = ctx->wrPtr - ctx->rdPtr;
	dev_dbg(dev->dev, "%d.%s.encoded frame bytes:0x%llx, 0x%px, %d\n",
		__LINE__, __func__, dst_buf_paddr, dst_buf_vaddr,
		enc_frm_bs_bytes);
	//enc_dump_bs(ctx, (unsigned char *)dst_buf_vaddr, enc_frm_bs_bytes);
	dst_buf_payload = enc_frm_bs_bytes;

	if (src_buf->sequence == 0) {
		enc_copy_hdr(ctx, dst_buf_vaddr, dst_buf_size,
			     enc_frm_bs_bytes);
		dst_buf_payload = enc_frm_bs_bytes + ctx->enc_hdr_bytes;
		ctx->enc_bs_new_file = 1;
		dev_dbg(dev->dev, "%d.%s.dst_buf_payload:%d\n", __LINE__,
			__func__, dst_buf_payload);
	}
	dev_dbg(dev->dev, "%d.%s.dst_buf_payload:%d\n", __LINE__, __func__,
		dst_buf_payload);

	v4l2_m2m_buf_copy_metadata(src_buf, dst_buf, false);
	if (is_idr)
		dst_buf->flags |= V4L2_BUF_FLAG_KEYFRAME;
	else
		dst_buf->flags |= V4L2_BUF_FLAG_PFRAME;
	dst_buf->flags |= src_buf->flags & V4L2_BUF_FLAG_LAST;
	dev_dbg(dev->dev, "%d.%s.dst_buf->flags:0x%x.src_buf->flags:0x%x\n",
		__LINE__, __func__, dst_buf->flags, src_buf->flags);

	vb2_set_plane_payload(&dst_buf->vb2_buf, 0, dst_buf_payload);

	dst_buf = v4l2_m2m_dst_buf_remove(ctx->v4l2_fh.m2m_ctx);
	dev_dbg(dev->dev, "%d.%s.v4l2_m2m_buf_done.dst_buf:0x%px\n", __LINE__,
		__func__, dst_buf);
	v4l2_m2m_buf_done(dst_buf, VB2_BUF_STATE_DONE);

	src_buf = v4l2_m2m_src_buf_remove(ctx->v4l2_fh.m2m_ctx);
	dev_dbg(dev->dev,
		"%d.%s.v4l2_m2m_buf_done.src_buf:0x%px.src_buf_y:0x%llx\n",
		__LINE__, __func__, src_buf, src_buf_y);
	v4l2_m2m_buf_done(src_buf, VB2_BUF_STATE_DONE);

	ctx->enc_pic_done = 1;

	return ret;
}

static int enc_seq_end(struct rtkve4enc_ctx *ctx)
{
	struct videc_dev *dev = ctx->dev;
	int ret = 0;

	lockdep_assert_held(&dev->ve4_hw_mutex);

	// W6SendCommand(core_idx, inst, W6_DESTROY_INSTANCE);

	rtkve4_reg_writel(dev, W6_CMD_INSTANCE_INFO,
			  (ctx->codec_mode << 16) | (ctx->inst_index & 0xffff));
	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_VPU_CMD_BUSY_STATUS:0x%x.value:1\n",
		__LINE__, __func__, W6_VPU_CMD_BUSY_STATUS);
	rtkve4_reg_writel(dev, W6_VPU_CMD_BUSY_STATUS, 1);
	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_COMMAND:0x%x.value:0x%x\n",
		__LINE__, __func__, W6_COMMAND, W6_SET_FB);
	rtkve4_reg_writel(dev, W6_COMMAND, W6_DESTROY_INSTANCE);

	dev_dbg(dev->dev,
		"[%d]%s.VpuWriteReg W6_VPU_HOST_INT_REQ:0x%x.value:1\n",
		__LINE__, __func__, W6_VPU_HOST_INT_REQ);
	rtkve4_reg_writel(dev, W6_VPU_HOST_INT_REQ, 1);

	dev_dbg(dev->dev,
		"[%d]%s.cmd:0x%x.W6_VPU_VPU_INT_STS:0x%x.W6_VPU_VINT_REASON:0x%x\n",
		__LINE__, __func__, W6_DESTROY_INSTANCE,
		rtkve4_reg_readl(dev, W6_VPU_VPU_INT_STS),
		rtkve4_reg_readl(dev, W6_VPU_VINT_REASON));

	if (rtkve4_wait_busy(dev, W6_VPU_CMD_BUSY_STATUS) == -1) {
		dev_err(dev->dev, "%d.%s.wait busy timeout\n", __LINE__,
			__func__);
		return -ETIMEDOUT;
	}

	if (rtkve4_reg_readl(dev, W6_RET_SUCCESS) == 0) {
		dev_err(dev->dev, "%d.%s.set frame buffer fail\n", __LINE__,
			__func__);
		return -1;
	}

	ctx->seq_end_done = 1;
	ctx->stopping = 0;

	return ret;
}

static void enc_clear_ctx(struct rtkve4enc_ctx *ctx)
{
	/* clear state variables */
	ctx->enc_state = RTK_VE4_STATE_ENC_IDLE;
	ctx->seq_init_done = 0;
	ctx->reg_fbs_done = 0;
	ctx->enc_header_done = 0;
	ctx->enc_pic_done = 0;
	ctx->seq_end_done = 0;

	/* clear flags */
	ctx->stopping = 0;
	ctx->eos = 0;
	ctx->hdr_enc_flag = 0;
	ctx->encodeVuiRbsp = 0;
	ctx->encodeHrdRbsp = 0;

	ctx->rdPtr = 0;
	ctx->wrPtr = 0;
	ctx->enc_min_fb_num = 0;

	ctx->enc_hdr_buf_size = 0;
	ctx->enc_hdr_bytes = 0;

	ctx->outbuf_new_file = 0;
	ctx->enc_bs_new_file = 0;
}

static int rtkve4enc_queue_init(void *priv, struct vb2_queue *src_vq,
				struct vb2_queue *dst_vq)
{
	struct rtkve4enc_ctx *ctx = priv;
	int ret;

	dev_dbg(ctx->dev->dev, "%d.%s.[+] ctx:0x%px\n", __LINE__, __func__,
		ctx);

	src_vq->type = V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE;
	src_vq->io_modes = VB2_MMAP | VB2_DMABUF;
	src_vq->mem_ops = &vb2_dma_contig_memops;
	src_vq->ops = &rtkve4enc_vb2_ops;
	src_vq->timestamp_flags = V4L2_BUF_FLAG_TIMESTAMP_COPY;
	src_vq->buf_struct_size = sizeof(struct v4l2_m2m_buffer);
	src_vq->drv_priv = ctx;
	src_vq->lock = &ctx->dev->dev_mutex;
	src_vq->dev = ctx->dev->v4l2_dev.dev;
	ret = vb2_queue_init(src_vq);
	if (ret)
		goto exit;

	dst_vq->type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	dst_vq->io_modes = VB2_MMAP | VB2_DMABUF;
	dst_vq->mem_ops = &vb2_dma_contig_memops;
	dst_vq->ops = &rtkve4enc_vb2_ops;
	dst_vq->timestamp_flags = V4L2_BUF_FLAG_TIMESTAMP_COPY;
	dst_vq->buf_struct_size = sizeof(struct v4l2_m2m_buffer);
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 8, 0)
	dst_vq->min_buffers_needed = 1;
#endif
	dst_vq->drv_priv = ctx;
	dst_vq->lock = &ctx->dev->dev_mutex;
	dst_vq->dev = ctx->dev->v4l2_dev.dev;
	ret = vb2_queue_init(dst_vq);
	if (ret)
		goto exit;

exit:
	dev_dbg(ctx->dev->dev, "%d.%s.[-] ret:%d\n", __LINE__, __func__, ret);
	return ret;
}

static int rtkve4enc_s_ctrl(struct v4l2_ctrl *ctrl)
{
	int ret = 0;
	struct rtkve4enc_ctx *ctx = container_of(
		ctrl->handler, struct rtkve4enc_ctx, v4l2_ctrl_hdl);

	dev_dbg(ctx->dev->dev, "%d.%s.id:%d(%s)\n", __LINE__, __func__,
		ctrl->id, v4l2_ctrl_get_name(ctrl->id));

	switch (ctrl->id) {
	case V4L2_CID_MPEG_VIDEO_BITRATE_MODE:
		dev_dbg(ctx->dev->dev, "CTRL set bitrate mode = %d", ctrl->val);
		/*
			* The menu control is created with a mask that skips every entry
			* except V4L2_MPEG_VIDEO_BITRATE_MODE_CBR, so the only legal value
			* that can arrive here is CBR.  Keep a defensive default in case the
			* mask is widened later.
			*/
		if (ctrl->val == V4L2_MPEG_VIDEO_BITRATE_MODE_CBR) {
			ctx->enc_params.bitrate_mode = VIDEO_RATE_CBR;
		} else {
			dev_warn(ctx->dev->dev,
				 "unexpected bitrate mode %u, using CBR\n",
				 ctrl->val);
			ctx->enc_params.bitrate_mode = VIDEO_RATE_CBR;
		}
		break;
	case V4L2_CID_MPEG_VIDEO_H264_PROFILE:
		dev_dbg(ctx->dev->dev, "%d.%s.H264_PROFILE.val:%d\n", __LINE__,
			__func__, ctrl->val);
		if (ctrl->val >= V4L2_MPEG_VIDEO_H264_PROFILE_BASELINE &&
		    ctrl->val <= V4L2_MPEG_VIDEO_H264_PROFILE_HIGH_10) {
			ctx->enc_params.h264_profile_idc = ctrl->val;
		} else {
			dev_err(ctx->dev->dev, "Unsupported H264 profile = %d",
				ctrl->val);
			ret = -EINVAL;
		}
		break;
	case V4L2_CID_MPEG_VIDEO_H264_LEVEL:
		dev_dbg(ctx->dev->dev, "%d.%s.H264_LEVEL.val:%d\n", __LINE__,
			__func__, ctrl->val);
		if (ctrl->val >= V4L2_MPEG_VIDEO_H264_LEVEL_1_0 &&
		    ctrl->val <= V4L2_MPEG_VIDEO_H264_LEVEL_6_2) {
			ctx->enc_params.s_ctrl_level_value = ctrl->val;
		} else {
			dev_err(ctx->dev->dev, "Unsupported H264 level = %d",
				ctrl->val);
			ret = -EINVAL;
		}
		break;
	case V4L2_CID_MPEG_VIDEO_GOP_SIZE:
		dev_dbg(ctx->dev->dev, "%d.%s.GOP_SIZE.val:%d\n", __LINE__,
			__func__, ctrl->val);
		if ((ctrl->val >= 0) && (ctrl->val <= 60)) {
			ctx->enc_params.gop_size = ctrl->val;
		} else {
			dev_err(ctx->dev->dev, "Unsupported GOP size = %d",
				ctrl->val);
			ret = -EINVAL;
		}
		break;
	case V4L2_CID_MPEG_VIDEO_H264_I_FRAME_QP:
		dev_dbg(ctx->dev->dev, "%d.%s.I_FRAME_QP.val:%d\n", __LINE__,
			__func__, ctrl->val);
		if ((ctrl->val >= 0) && (ctrl->val <= 51)) {
			ctx->enc_params.intra_qp = ctrl->val;
		} else {
			dev_err(ctx->dev->dev, "Unsupported I frame QP = %d",
				ctrl->val);
			ret = -EINVAL;
		}
		break;
	case V4L2_CID_MPEG_VIDEO_BITRATE:
		dev_dbg(ctx->dev->dev, "%d.%s.VIDEO_BITRATE.val:%d\n", __LINE__,
			__func__, ctrl->val);
		if ((ctrl->val >= MIN_BITRATE) && (ctrl->val <= MAX_BITRATE)) {
			ctx->enc_params.bitrate = ctrl->val;
		} else {
			dev_err(ctx->dev->dev, "Unsupported bitrate = %d",
				ctrl->val);
			ret = -EINVAL;
		}
		break;
	case V4L2_CID_MPEG_VIDEO_HEVC_PROFILE:
		dev_dbg(ctx->dev->dev, "CTRL set profile = %d", ctrl->val);
		if (ctrl->val != V4L2_MPEG_VIDEO_HEVC_PROFILE_MAIN) {
			dev_err(ctx->dev->dev, "Unsupported profile = %d",
				ctrl->val);
		}
		break;
	case V4L2_CID_MPEG_VIDEO_HEVC_LEVEL:
		dev_dbg(ctx->dev->dev, "CTRL set level = %d", ctrl->val);
		if (ctrl->val > V4L2_MPEG_VIDEO_HEVC_LEVEL_4_1) {
			dev_err(ctx->dev->dev, "Unsupported level = %d",
				ctrl->val);
		}
		break;
	case V4L2_CID_MPEG_VIDEO_FRAME_RC_ENABLE:
		dev_dbg(ctx->dev->dev, "frame_rc_enable = %d", ctrl->val);
		ctx->enc_params.frame_rc_enable = ctrl->val;
		break;
	case V4L2_CID_MPEG_VIDEO_FORCE_KEY_FRAME:
		dev_dbg(ctx->dev->dev, "CTRL set force_key_frame");
		ctx->enc_params.force_key_frame = true;
		break;
	default:
		break;
	}
	return ret;
}

static const struct v4l2_ctrl_ops rtkve4enc_ctrl_ops = {
	.s_ctrl = rtkve4enc_s_ctrl,
};

static int rtkve4enc_ctrls_setup(struct rtkve4enc_ctx *ctx)
{
	struct v4l2_ctrl_handler *hdl = &ctx->v4l2_ctrl_hdl;
	int ret = 0;
	int max_gop_size = 60;

	dev_dbg(ctx->dev->dev, "%d.%s.[+] ctx:0x%px\n", __LINE__, __func__,
		ctx);

	v4l2_ctrl_handler_init(hdl, 17);

	v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
			  V4L2_CID_MIN_BUFFERS_FOR_OUTPUT, 1, 32, 1, 4);

	v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
			  V4L2_CID_MIN_BUFFERS_FOR_CAPTURE, 1, 32, 1, 4);

	v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops, V4L2_CID_MPEG_VIDEO_BITRATE,
			  MIN_BITRATE, MAX_BITRATE, 1, DEF_BITRATE);

	v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
			  V4L2_CID_MPEG_VIDEO_FRAME_RC_ENABLE, 0, 1, 1, 1);

	v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
			  V4L2_CID_MPEG_VIDEO_FORCE_KEY_FRAME, 0, 0, 0, 0);

	v4l2_ctrl_new_std_menu(hdl, &rtkve4enc_ctrl_ops,
			       V4L2_CID_MPEG_VIDEO_BITRATE_MODE,
			       V4L2_MPEG_VIDEO_BITRATE_MODE_CBR,
			       ~(1 << V4L2_MPEG_VIDEO_BITRATE_MODE_CBR),
			       V4L2_MPEG_VIDEO_BITRATE_MODE_CBR);

	v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
			  V4L2_CID_MPEG_VIDEO_GOP_SIZE, 0, max_gop_size, 1,
			  DEFAULT_GOP);
	v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
			  V4L2_CID_MPEG_VIDEO_H264_I_FRAME_QP, 1, 51, 1,
			  DEFAULT_I_FRAME_QP);
	/*
    v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
        V4L2_CID_MPEG_VIDEO_H264_P_FRAME_QP, 0, 51, 1, 25);
    v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
        V4L2_CID_MPEG_VIDEO_H264_MAX_QP, 0, 51, 1, 51);
    v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
        V4L2_CID_MPEG_VIDEO_H264_CONSTRAINED_INTRA_PREDICTION, 0, 1, 1,
        0);

    v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
        V4L2_CID_MPEG_VIDEO_MB_RC_ENABLE, 0, 1, 1, 1);
    v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
        V4L2_CID_MPEG_VIDEO_H264_CHROMA_QP_INDEX_OFFSET, -12, 12, 1, 0);
*/

	v4l2_ctrl_new_std_menu(hdl, &rtkve4enc_ctrl_ops,
			       V4L2_CID_MPEG_VIDEO_H264_PROFILE,
			       V4L2_MPEG_VIDEO_H264_PROFILE_HIGH,
			       ~((1 << V4L2_MPEG_VIDEO_H264_PROFILE_BASELINE) |
				 (1 << V4L2_MPEG_VIDEO_H264_PROFILE_MAIN) |
				 (1 << V4L2_MPEG_VIDEO_H264_PROFILE_HIGH)),
			       V4L2_MPEG_VIDEO_H264_PROFILE_HIGH);
	v4l2_ctrl_new_std_menu(hdl, &rtkve4enc_ctrl_ops,
			       V4L2_CID_MPEG_VIDEO_H264_LEVEL,
			       V4L2_MPEG_VIDEO_H264_LEVEL_4_2, 0x0,
			       V4L2_MPEG_VIDEO_H264_LEVEL_4_2);
	v4l2_ctrl_new_std_menu(hdl, &rtkve4enc_ctrl_ops,
			       V4L2_CID_MPEG_VIDEO_MULTI_SLICE_MODE,
			       V4L2_MPEG_VIDEO_MULTI_SLICE_MODE_MAX_BYTES, 0x0,
			       V4L2_MPEG_VIDEO_MULTI_SLICE_MODE_SINGLE);
	v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
			  V4L2_CID_MPEG_VIDEO_MULTI_SLICE_MAX_MB, 1, 0x3fffffff,
			  1, 1);
	v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
			  V4L2_CID_MPEG_VIDEO_MULTI_SLICE_MAX_BYTES, 1,
			  0x3fffffff, 1, 500);
	v4l2_ctrl_new_std_menu(
		hdl, &rtkve4enc_ctrl_ops, V4L2_CID_MPEG_VIDEO_HEADER_MODE,
		V4L2_MPEG_VIDEO_HEADER_MODE_JOINED_WITH_1ST_FRAME,
		(1 << V4L2_MPEG_VIDEO_HEADER_MODE_SEPARATE),
		V4L2_MPEG_VIDEO_HEADER_MODE_JOINED_WITH_1ST_FRAME);
	v4l2_ctrl_new_std(hdl, &rtkve4enc_ctrl_ops,
			  V4L2_CID_MPEG_VIDEO_CYCLIC_INTRA_REFRESH_MB, 0,
			  1920 * 1088 / 256, 1, 0);

	v4l2_ctrl_new_std_menu(hdl, &rtkve4enc_ctrl_ops,
			       V4L2_CID_MPEG_VIDEO_HEVC_PROFILE,
			       V4L2_MPEG_VIDEO_HEVC_PROFILE_MAIN_10,
			       ~(1 << V4L2_MPEG_VIDEO_HEVC_PROFILE_MAIN),
			       V4L2_MPEG_VIDEO_HEVC_PROFILE_MAIN);

	v4l2_ctrl_new_std_menu(hdl, &rtkve4enc_ctrl_ops,
			       V4L2_CID_MPEG_VIDEO_HEVC_LEVEL,
			       V4L2_MPEG_VIDEO_HEVC_LEVEL_6_2,
			       ~((1 << V4L2_MPEG_VIDEO_HEVC_LEVEL_1) |
				 (1 << V4L2_MPEG_VIDEO_HEVC_LEVEL_2) |
				 (1 << V4L2_MPEG_VIDEO_HEVC_LEVEL_2_1) |
				 (1 << V4L2_MPEG_VIDEO_HEVC_LEVEL_3) |
				 (1 << V4L2_MPEG_VIDEO_HEVC_LEVEL_3_1) |
				 (1 << V4L2_MPEG_VIDEO_HEVC_LEVEL_4) |
				 (1 << V4L2_MPEG_VIDEO_HEVC_LEVEL_4_1)),
			       V4L2_MPEG_VIDEO_HEVC_LEVEL_4_1);

	if (hdl->error) {
		dev_err(ctx->dev->dev,
			"%d.%s.Failed to initialize control handler\n",
			__LINE__, __func__);
		v4l2_ctrl_handler_free(hdl);
		ret = hdl->error;
		goto exit;
	}

	ctx->enc_params.transform_8x8_mode = 1;
	dev_dbg(ctx->dev->dev, "%d.%s.set default.transform_8x8_mode:%d\n",
		__LINE__, __func__, ctx->enc_params.transform_8x8_mode);

	ctx->enc_params.field_flag = 0;
	ctx->enc_params.field_ref_mode = 1;
	dev_dbg(ctx->dev->dev,
		"%d.%s.set default.field_flag:%d.field_ref_mode:%d\n", __LINE__,
		__func__, ctx->enc_params.field_flag,
		ctx->enc_params.field_ref_mode);

	ctx->enc_params.entropy_coding_mode = 1;
	dev_dbg(ctx->dev->dev, "%d.%s.set default.entropy_coding_mode:%d\n",
		__LINE__, __func__, ctx->enc_params.entropy_coding_mode);

	ctx->enc_params.gop_size = DEFAULT_GOP;
	dev_dbg(ctx->dev->dev, "%d.%s.set default.gop_size:%d\n", __LINE__,
		__func__, ctx->enc_params.gop_size);

	ctx->enc_params.bitrate = DEF_BITRATE;
	dev_dbg(ctx->dev->dev, "%d.%s.set default.bitrate:%d\n", __LINE__,
		__func__, ctx->enc_params.bitrate);

	ctx->enc_params.framerate_num = DEFAULT_FRAMERATE_DENOM;
	ctx->enc_params.framerate_denom = DEFAULT_FRAMERATE_NUM;
	dev_dbg(ctx->dev->dev,
		"%d.%s.set default.framerate_num:%d.framerate_denom:%d\n",
		__LINE__, __func__, ctx->enc_params.framerate_num,
		ctx->enc_params.framerate_denom);

	ctx->enc_params.intra_qp = 30;
	dev_dbg(ctx->dev->dev, "%d.%s.set default.intra_qp:%d\n", __LINE__,
		__func__, ctx->enc_params.intra_qp);

	ctx->v4l2_fh.ctrl_handler = hdl;
	v4l2_ctrl_handler_setup(hdl);
exit:
	dev_dbg(ctx->dev->dev, "%d.%s.[-] ret:%d\n", __LINE__, __func__, ret);
	return ret;
}

static void rtkve4enc_free_all_buffers(struct rtkve4enc_ctx *ctx)
{
	struct videc_dev *dev = ctx->dev;
	char dbg_name[16];
	int i;
	for (i = 0; i < ctx->enc_min_fb_num; i++) {
		if (ctx->framebuf[i].size != 0) {
			memset(dbg_name, 0, sizeof(dbg_name));
			snprintf(dbg_name, 16, "framebuf%d", i);
			dev_dbg(dev->dev,
				"%d.%s.free_dma.%d.name:%s.size:%d.paddr:0x%llx.vaddr:0x%px\n",
				__LINE__, __func__, i, dbg_name,
				ctx->framebuf[i].size, ctx->framebuf[i].paddr,
				ctx->framebuf[i].vaddr);
			rtkve4_free_dma_memory(dev, &ctx->framebuf[i],
					       dbg_name);
			ctx->framebuf[i].size = 0;
			ctx->framebuf[i].paddr = 0;
			ctx->framebuf[i].vaddr = NULL;
		}
		if (ctx->vbFbcYTbl[i].size != 0) {
			dev_dbg(dev->dev,
				"%d.%s.free_dma.name:vbFbcYTbl.size:%d.paddr:0x%llx.vaddr:0x%px\n",
				__LINE__, __func__, ctx->vbFbcYTbl[i].size,
				ctx->vbFbcYTbl[i].paddr,
				ctx->vbFbcYTbl[i].vaddr);
			rtkve4_free_dma_memory(dev, &ctx->vbFbcYTbl[i],
					       "vbFbcYTbl");
			ctx->vbFbcYTbl[i].size = 0;
			ctx->vbFbcYTbl[i].paddr = 0;
			ctx->vbFbcYTbl[i].vaddr = NULL;
		}
		if (ctx->vbFbcCTbl[i].size != 0) {
			dev_dbg(dev->dev,
				"%d.%s.free_dma.name:vbFbcCTbl.size:%d.paddr:0x%llx.vaddr:0x%px\n",
				__LINE__, __func__, ctx->vbFbcCTbl[i].size,
				ctx->vbFbcCTbl[i].paddr,
				ctx->vbFbcCTbl[i].vaddr);
			rtkve4_free_dma_memory(dev, &ctx->vbFbcCTbl[i],
					       "vbFbcCTbl");
			ctx->vbFbcCTbl[i].size = 0;
			ctx->vbFbcCTbl[i].paddr = 0;
			ctx->vbFbcCTbl[i].vaddr = NULL;
		}
		if (ctx->vbSubSamBuf[i].size != 0) {
			dev_dbg(dev->dev,
				"%d.%s.free_dma.name:vbSubSamBuf.size:%d.paddr:0x%llx.vaddr:0x%px\n",
				__LINE__, __func__, ctx->vbSubSamBuf[i].size,
				ctx->vbSubSamBuf[i].paddr,
				ctx->vbSubSamBuf[i].vaddr);
			rtkve4_free_dma_memory(dev, &ctx->vbSubSamBuf[i],
					       "vbSubSamBuf");
			ctx->vbSubSamBuf[i].size = 0;
			ctx->vbSubSamBuf[i].paddr = 0;
			ctx->vbSubSamBuf[i].vaddr = NULL;
		}
	}

	for (i = 0; i < ctx->initialInfo.reqMvColBufferCount; i++) {
		if (ctx->vbMV[i].size != 0) {
			dev_dbg(dev->dev,
				"%d.%s.free_dma.name:vbMV.size:%d.paddr:0x%llx.vaddr:0x%px\n",
				__LINE__, __func__, ctx->vbMV[i].size,
				ctx->vbMV[i].paddr, ctx->vbMV[i].vaddr);
			rtkve4_free_dma_memory(dev, &ctx->vbMV[i], "vbMV");
			ctx->vbMV[i].size = 0;
			ctx->vbMV[i].paddr = 0;
			ctx->vbMV[i].vaddr = NULL;
		}
	}

	if (ctx->bitstream.size != 0) {
		dev_dbg(dev->dev,
			"%d.%s.free_dma.name:bsbuf.size:%d.paddr:0x%llx.vaddr:0x%px\n",
			__LINE__, __func__, ctx->bitstream.size,
			ctx->bitstream.paddr, ctx->bitstream.vaddr);
		rtkve4_free_dma_memory(dev, &ctx->bitstream, "bsbuf");
		ctx->bitstream.size = 0;
		ctx->bitstream.paddr = 0;
		ctx->bitstream.vaddr = NULL;
	}
	if (ctx->workbuf.size != 0) {
		dev_dbg(dev->dev,
			"%d.%s.free_dma.name:workbuf.size:%d.paddr:0x%llx.vaddr:0x%px\n",
			__LINE__, __func__, ctx->workbuf.size,
			ctx->workbuf.paddr, ctx->workbuf.vaddr);
		rtkve4_free_dma_memory(dev, &ctx->workbuf, "workbuf");
		ctx->workbuf.size = 0;
		ctx->workbuf.paddr = 0;
		ctx->workbuf.vaddr = NULL;
	}

	if (ctx->vbVuiRbsp.size != 0) {
		dev_dbg(dev->dev,
			"%d.%s.free_dma.name:vbVuiRbsp.size:%d.paddr:0x%llx.vaddr:0x%px\n",
			__LINE__, __func__, ctx->vbVuiRbsp.size,
			ctx->vbVuiRbsp.paddr, ctx->vbVuiRbsp.vaddr);
		rtkve4_free_dma_memory(dev, &ctx->vbVuiRbsp, "vbVuiRbsp");
		ctx->vbVuiRbsp.size = 0;
		ctx->vbVuiRbsp.paddr = 0;
		ctx->vbVuiRbsp.vaddr = NULL;
	}

	if (ctx->vbHrdRbsp.size != 0) {
		dev_dbg(dev->dev,
			"%d.%s.free_dma.name:vbHrdRbsp.size:%d.paddr:0x%llx.vaddr:0x%px\n",
			__LINE__, __func__, ctx->vbHrdRbsp.size,
			ctx->vbHrdRbsp.paddr, ctx->vbHrdRbsp.vaddr);
		rtkve4_free_dma_memory(dev, &ctx->vbHrdRbsp, "vbHrdRbsp");
		ctx->vbHrdRbsp.size = 0;
		ctx->vbHrdRbsp.paddr = 0;
		ctx->vbHrdRbsp.vaddr = NULL;
	}

	if (ctx->vbTemp.size != 0) {
		dev_dbg(dev->dev,
			"%d.%s.free_dma.name:vbTemp.size:%d.paddr:0x%llx.vaddr:0x%px\n",
			__LINE__, __func__, ctx->vbTemp.size, ctx->vbTemp.paddr,
			ctx->vbTemp.vaddr);
		rtkve4_free_dma_memory(dev, &ctx->vbTemp, "vbTemp");
		ctx->vbTemp.size = 0;
		ctx->vbTemp.paddr = 0;
		ctx->vbTemp.vaddr = NULL;
	}

	if (ctx->vbAr.size != 0) {
		dev_dbg(dev->dev,
			"%d.%s.free_dma.name:vbAr.size:%d.paddr:0x%llx.vaddr:0x%px\n",
			__LINE__, __func__, ctx->vbAr.size, ctx->vbAr.paddr,
			ctx->vbAr.vaddr);
		rtkve4_free_dma_memory(dev, &ctx->vbAr, "vbAr");
		ctx->vbAr.size = 0;
		ctx->vbAr.paddr = 0;
		ctx->vbAr.vaddr = NULL;
	}

	if (ctx->vbDefCdf.size != 0) {
		dev_dbg(dev->dev,
			"%d.%s.free_dma.name:vbDefCdf.size:%d.paddr:0x%llx.vaddr:0x%px\n",
			__LINE__, __func__, ctx->vbDefCdf.size,
			ctx->vbDefCdf.paddr, ctx->vbDefCdf.vaddr);
		rtkve4_free_dma_memory(dev, &ctx->vbDefCdf, "vbDefCdf");
		ctx->vbDefCdf.size = 0;
		ctx->vbDefCdf.paddr = 0;
		ctx->vbDefCdf.vaddr = NULL;
	}
}

static int rtkve4enc_create_encoder(struct rtkve4enc_ctx *ctx,
				    struct v4l2_requestbuffers *rb)
{
	int ret = 0;

	dev_dbg(ctx->dev->dev, "%d.%s.ctx:0x%px.type:%s.count:%d\n", __LINE__,
		__func__, ctx, v4l2_type_names[rb->type], rb->count);

	if (V4L2_TYPE_IS_OUTPUT(rb->type) && rb->count) {
		ret = rtkve4_initialize(ctx);
		if (ret < 0)
			return ret;
	}

	if ((ctx->reqbuf_cnt_out == 0) && (ctx->reqbuf_cnt_cap == 0)) {
		dev_dbg(ctx->dev->dev,
			"%d.%s.ctx:0x%px.enc_initialized:%s.enc_state:%d\n",
			__LINE__, __func__, ctx,
			ctx->enc_initialized ? "Y" : "N", ctx->enc_state);
		if (ctx->enc_initialized) {
			if (ctx->enc_state >= RTK_VE4_STATE_ENC_SEQ_INIT) {
				ctx->ops->seq_end(ctx);
			}
			rtkve4_finalize(ctx);
		}
	}

	return ret;
}

static int rtkve4enc_open_encoder(struct rtkve4enc_ctx *ctx)
{
	int ret = 0;
	struct videc_dev *dev = ctx->dev;

	dev_dbg(dev->dev, "%d.%s.[+]\n", __LINE__, __func__);
	mutex_lock(&dev->ve4_hw_mutex);

	ret = enc_alloc_custom_buffers(ctx);
	if (ret < 0)
		goto exit;

	ret = enc_alloc_bsbuf_workbuf(ctx);
	if (ret < 0)
		goto exit;

	ret = rtkve4_get_sram_memory(dev, &ctx->vbSecAxi);
	if (ret < 0)
		goto exit;

	ret = enc_alloc_tempbuf_arTbuf(ctx);
	if (ret < 0)
		goto exit;

	ret = enc_vpu_encopen(ctx);
	if (ret < 0) {
		dev_err(dev->dev, "%d.%s.enc_vpu_encopen failed.ret:%d\n",
			__LINE__, __func__, ret);
		goto exit;
	}

exit:
	if (ret < 0) {
		rtkve4enc_free_all_buffers(ctx);
		rtkve4_finalize(ctx);
	}

	mutex_unlock(&dev->ve4_hw_mutex);
	dev_dbg(dev->dev, "%d.%s.[-]\n", __LINE__, __func__);

	return ret;
}

static int rtkve4enc_seq_init(struct rtkve4enc_ctx *ctx)
{
	int ret = 0;
	struct videc_dev *dev = ctx->dev;

	dev_dbg(dev->dev, "%d.%s.[+]\n", __LINE__, __func__);
	mutex_lock(&dev->ve4_hw_mutex);

	ret = enc_alloc_bsbuf_workbuf(ctx);
	if (ret < 0) {
		dev_err(dev->dev,
			"%d.%s.enc_alloc_bsbuf_workbuf failed.ret:%d\n",
			__LINE__, __func__, ret);
		goto exit;
	}

	ctx->enc_state = RTK_VE4_STATE_ENC_SEQ_INIT;
	if (!ctx->seq_init_done) {
		ret = enc_seq_init(ctx);
		if (ret < 0)
			dev_err(dev->dev, "%d.%s.enc_seq_init failed.ret:%d\n",
				__LINE__, __func__, ret);
	}

exit:
	if (ret < 0) {
		rtkve4enc_free_all_buffers(ctx);
		rtkve4_finalize(ctx);
	}

	mutex_unlock(&dev->ve4_hw_mutex);
	dev_dbg(dev->dev, "%d.%s.[-]\n", __LINE__, __func__);

	return ret;
}

static int rtkve4enc_GetAuxBufSize(struct rtkve4enc_ctx *ctx,
				   AuxBufferType type)
{
	uint32_t width = 0;
	uint32_t height = 0;
	uint32_t bufSize = 0;

	width = ctx->align_fmt.width;
	height = ctx->align_fmt.height;

	if (type == AUX_BUF_FBC_Y_TBL) {
		switch (ctx->codec_mode) {
		case W_HEVC_ENC:
			bufSize = WAVE6_FBC_LUMA_TABLE_SIZE(width, height);
			break;
		case W_AVC_ENC:
			bufSize = WAVE6_FBC_LUMA_TABLE_SIZE(width, height);
			break;
		case W_AV1_ENC:
			bufSize = WAVE6_FBC_LUMA_TABLE_SIZE(width, height);
			break;
		default:
			return -1;
		}
	} else if (type == AUX_BUF_FBC_C_TBL) {
		switch (ctx->codec_mode) {
		case W_HEVC_ENC:
			bufSize = WAVE6_FBC_CHROMA_TABLE_SIZE(width, height);
			break;
		case W_AVC_ENC:
			bufSize = WAVE6_FBC_CHROMA_TABLE_SIZE(width, height);
			break;
		case W_AV1_ENC:
			bufSize = WAVE6_FBC_CHROMA_TABLE_SIZE(width, height);
			break;
		default:
			return -1;
		}
	} else if (type == AUX_BUF_MV_COL) {
		switch (ctx->codec_mode) {
		case W_HEVC_ENC:
			bufSize = WAVE6_ENC_HEVC_MVCOL_BUF_SIZE(width, height);
			break;
		case W_AVC_ENC:
			bufSize = WAVE6_ENC_AVC_MVCOL_BUF_SIZE(width, height);
			break;
		case W_AV1_ENC:
			bufSize = WAVE6_ENC_AV1_MVCOL_BUF_SIZE;
			break;
		default:
			return -1;
		}
	} else if (type == AUX_BUF_DEF_CDF) {
		if (ctx->codec_mode == W_AV1_ENC) {
			bufSize = WAVE6_AV1_DEFAULT_CDF_BUF_SIZE;
		} else {
			return -1;
		}
	} else if (type == AUX_BUF_SUB_SAMPLE) {
		switch (ctx->codec_mode) {
		case W_HEVC_ENC:
			bufSize = WAVE6_ENC_SUBSAMPLED_SIZE(width, height);
			break;
		case W_AVC_ENC:
			bufSize = WAVE6_ENC_SUBSAMPLED_SIZE(width, height);
			break;
		case W_AV1_ENC:
			bufSize = WAVE6_ENC_SUBSAMPLED_SIZE(width, height);
			break;
		default:
			return -1;
		}
	} else {
		return -1;
	}

	return bufSize;
}

static int rtkve4enc_AllocateAuxBuffer(struct rtkve4enc_ctx *ctx,
				       AuxBufferType type,
				       int isUseProtectBuffer)
{
	int i, num, ret_code = 0, size;
	char dbg_name[16];
	struct videc_dev *dev = ctx->dev;
	struct rtkve4_buf *bufArray;

	/* make sure size is valid before allocating */
	size = rtkve4enc_GetAuxBufSize(ctx, type);
	if (size <= 0) {
		dev_err(dev->dev,
			"%d.%s.invalid aux buffer size %d for type %d\n",
			__LINE__, __func__, size, type);
		return -EINVAL;
	}

	if (type == AUX_BUF_DEF_CDF)
		num = 1;
	else if (type == AUX_BUF_MV_COL)
		num = ctx->initialInfo.reqMvColBufferCount;
	else
		num = ctx->enc_min_fb_num;

	for (i = 0; i < num; i++) {
		switch (type) {
		case AUX_BUF_FBC_Y_TBL:
			bufArray = &ctx->vbFbcYTbl[i];
			break;
		case AUX_BUF_FBC_C_TBL:
			bufArray = &ctx->vbFbcCTbl[i];
			break;
		case AUX_BUF_MV_COL:
			bufArray = &ctx->vbMV[i];
			break;
		case AUX_BUF_DEF_CDF:
			bufArray = &ctx->vbDefCdf;
			break;
		case AUX_BUF_SUB_SAMPLE:
			bufArray = &ctx->vbSubSamBuf[i];
			break;
		default:
			return -1;
		}

		memset(bufArray, 0x00, sizeof(struct rtkve4_buf));
		memset(dbg_name, 0, sizeof(dbg_name));
		snprintf(dbg_name, 16, "AuxBuf%d_%d", type, i);
		ret_code = rtkve4_alloc_dma_memory(
			dev, bufArray, size, dbg_name, ctx->debugfs_entry);
		if (ret_code < 0) {
			dev_err(dev->dev,
				"%d.%s.rtkve4_alloc_dma_memory failed for type %d index %d size %d ret_code %d\n",
				__LINE__, __func__, type, i, size, ret_code);
			return -ENOMEM;
		}
		dev_dbg(dev->dev,
			"%d.%s.vdi_allocate_dma_memory.vbAux[%d][%d].phys_addr:0x%llx..vaddr:0x%px.size:%d.\n",
			__LINE__, __func__, type, i, bufArray->paddr,
			bufArray->vaddr, bufArray->size);
	}

	return ret_code;
}

static int rtkve4enc_reg_fbs(struct rtkve4enc_ctx *ctx)
{
	int ret = 0;
	struct videc_dev *dev = ctx->dev;
	TiledMapType mapType;
	struct vb2_v4l2_buffer *src_buf = NULL;

	dev_dbg(dev->dev, "%d.%s.[+]\n", __LINE__, __func__);
	mutex_lock(&dev->ve4_hw_mutex);

	src_buf = v4l2_m2m_next_src_buf(ctx->v4l2_fh.m2m_ctx);
	if (!src_buf) {
		dev_err(dev->dev, "%d.%s.v4l2_m2m_next_src_buf() fail\n",
			__LINE__, __func__);
		ret = -EINVAL;
		return ret;
	}
	ctx->src_buf_size = vb2_get_plane_payload(&src_buf->vb2_buf, 0);
	calc_src_buf_w_h(ctx->src_fmt.pixelformat, ctx->src_buf_size,
			 ctx->src_fmt.width, ctx->src_fmt.height,
			 &ctx->src_buf_width, &ctx->src_buf_height);
	dev_dbg(dev->dev,
		"%d.%s.src_fmt(w:%d.h:%d).src_buf(w:%d.h:%d).src_buf_size:%d\n",
		__LINE__, __func__, ctx->src_fmt.width, ctx->src_fmt.height,
		ctx->src_buf_width, ctx->src_buf_height, ctx->src_buf_size);

	//allocate reconFb
	ret = enc_alloc_frame_buffers(ctx);
	if (ret < 0) {
		goto exit;
	}

	//allocate AuxBuffer
	mapType = COMPRESSED_FRAME_MAP;

	if ((ret = rtkve4enc_AllocateAuxBuffer(ctx, AUX_BUF_FBC_Y_TBL,
					       0 /*ctx->is_secure*/)) != 0) {
		dev_err(dev->dev, "<%s:%d> return code : %d \n", __FUNCTION__,
			__LINE__, ret);
		goto exit;
	}
	if ((ret = rtkve4enc_AllocateAuxBuffer(ctx, AUX_BUF_FBC_C_TBL,
					       0 /*ctx->is_secure*/)) != 0) {
		dev_err(dev->dev, "<%s:%d> return code : %d \n", __FUNCTION__,
			__LINE__, ret);
		goto exit;
	}
	if ((ret = rtkve4enc_AllocateAuxBuffer(ctx, AUX_BUF_MV_COL,
					       0 /*ctx->is_secure*/)) != 0) {
		dev_err(dev->dev, "<%s:%d> return code : %d \n", __FUNCTION__,
			__LINE__, ret);
		goto exit;
	}
	if ((ret = rtkve4enc_AllocateAuxBuffer(ctx, AUX_BUF_SUB_SAMPLE,
					       0 /*ctx->is_secure*/)) != 0) {
		dev_err(dev->dev, "<%s:%d> return code : %d \n", __FUNCTION__,
			__LINE__, ret);
		goto exit;
	}
	if (ctx->codec_mode == W_AV1_ENC) {
		if ((ret = rtkve4enc_AllocateAuxBuffer(ctx, AUX_BUF_DEF_CDF,
						       0)) != 0) {
			dev_err(dev->dev, "<%s:%d> return code : %d \n",
				__FUNCTION__, __LINE__, ret);
			goto exit;
		}
	}

	ctx->enc_state = RTK_VE4_STATE_ENC_REG_FBS;
	if (!ctx->reg_fbs_done) {
		ret = enc_reg_fbs(ctx, mapType);
	}

exit:
	mutex_unlock(&dev->ve4_hw_mutex);
	dev_dbg(dev->dev, "%d.%s.[-]\n", __LINE__, __func__);

	return ret;
}

static int rtkve4enc_pic(struct rtkve4enc_ctx *ctx)
{
	int ret = 0;
	struct videc_dev *dev = ctx->dev;

	dev_dbg(dev->dev, "%d.%s.[+]\n", __LINE__, __func__);
	mutex_lock(&dev->ve4_hw_mutex);

	if (!ctx->hdr_enc_flag) {
		ret = enc_header(ctx);
		if (ret) {
			dev_err(dev->dev, "%d.%s.enc_header failed.ret:%d\n",
				__LINE__, __func__, ret);
			mutex_unlock(&dev->ve4_hw_mutex);
			return ret;
		}

		ctx->hdr_enc_flag = true;
		ctx->enc_state = RTK_VE4_STATE_ENC_HEADER;
		mutex_unlock(&dev->ve4_hw_mutex);
		return 0;
	}

	ctx->enc_state = RTK_VE4_STATE_ENC_PIC;
	ret = enc_pic(ctx);
	mutex_unlock(&dev->ve4_hw_mutex);
	dev_dbg(dev->dev, "%d.%s.[-]\n", __LINE__, __func__);

	return ret;
}

static void rtkve4enc_seq_end(struct rtkve4enc_ctx *ctx)
{
	int ret = 0;
	struct videc_dev *dev = ctx->dev;

	dev_dbg(dev->dev, "%d.%s.[+]\n", __LINE__, __func__);
	mutex_lock(&dev->ve4_hw_mutex);
	ctx->enc_state = RTK_VE4_STATE_ENC_SEQ_END;
	if (!ctx->seq_end_done) {
		ret = enc_seq_end(ctx);
		if (ret == -ETIMEDOUT) {
			dev_err(dev->dev, "%d.%s.enc_seq_end timeout!\n",
				__LINE__, __func__);
		}
	}

	rtkve4enc_free_all_buffers(ctx);
	enc_clear_ctx(ctx);

	mutex_unlock(&dev->ve4_hw_mutex);
	dev_dbg(dev->dev, "%d.%s.[-]\n", __LINE__, __func__);
}

static void rtkve4enc_timeout(struct rtkve4enc_ctx *ctx)
{
}

const struct rtkve4_context_ops rtkve4enc_ops = {
	.find_vpu_fmt = rtkve_enc_find_fmt,
	.find_vpu_fmt_by_idx = rtkve_enc_find_fmt_by_idx,
	.queue_init = rtkve4enc_queue_init,
	.ctrls_setup = rtkve4enc_ctrls_setup,
	.create_encoder = rtkve4enc_create_encoder,
	.open_encoder = rtkve4enc_open_encoder,
	.seq_init = rtkve4enc_seq_init,
	.reg_fbs = rtkve4enc_reg_fbs,
	.enc_pic = rtkve4enc_pic,
	.seq_end = rtkve4enc_seq_end,
	.run_timeout = rtkve4enc_timeout,
};
