// SPDX-License-Identifier: (GPL-2.0 OR BSD-3-Clause)
/*
 * Realtek video encoder v4l2 driver
 *
 * Copyright (c) 2024 Realtek Semiconductor Corp. All rights reserved.
 *
 * SPDX-License-Identifier: LicenseRef-Realtek-Proprietary
 *
 * This software component is confidential and proprietary to Realtek
 * Semiconductor Corp. Disclosure, reproduction, redistribution, in whole
 * or in part, of this work and its derivatives without express permission
 * is prohibited.
 */
#include <linux/iopoll.h>
#include <linux/firmware.h>
#include <crypto/hash.h>
#include "rtkve4enc_common.h"
#include "rtkve4_regdefine.h"
#include "ve4_vdi.h"

#define VDI_SYSTEM_ENDIAN VDI_LITTLE_ENDIAN
#define VDI_128BIT_BUS_SYSTEM_ENDIAN VDI_128BIT_LITTLE_ENDIAN
#define VDI_SRAM_BASE_ADDR                  0x00000000    // if we can know the sram address in SOC directly for vdi layer. it is possible to set in vdi layer without allocation from driver
#define VDI_WAVE6_RTK_SRAM_SIZE             0xB400 // 46080 bytes

#define RTKVE4_BUSY_CHECK_TIMEOUT_US 10000000
#define RTKVE4_WAIT_CMD_IDLE_TIMEOUT_US 10000000
#define MBC_SET_SUBBLK_EN                                                      \
	(MBC_BASE + 0xA0) // subblk_man_mode[20] cr_subblk_man_en[19:0]

#define WAVE6_BITCODE_PATH                "realtek/rtd1625/seurat.bin"

typedef enum {
	INT_WAVE6_INIT_VPU          = 0,
	INT_WAVE6_WAKEUP_VPU        = 1,
	INT_WAVE6_SLEEP_VPU         = 2,
	INT_WAVE6_CREATE_INSTANCE   = 3,
	INT_WAVE6_FLUSH_INSTANCE    = 4,
	INT_WAVE6_DESTROY_INSTANCE  = 5,
	INT_WAVE6_INIT_SEQ          = 6,
	INT_WAVE6_SET_FRAMEBUF      = 7,
	INT_WAVE6_DEC_PIC           = 8,
	INT_WAVE6_ENC_PIC           = 8,
	INT_WAVE6_ENC_SET_PARAM     = 9,
	INT_WAVE6_UPDATE_FB         = 10,
	INT_WAVE6_ENC_SLICE         = 12,
	INT_WAVE6_BSBUF_EMPTY       = 15,
	INT_WAVE6_BSBUF_FULL        = 15,
} Wave6InterruptBit;

int rtkve4_md5_hash(unsigned char *result, int resultLen, char *data, int dataLen)
{
	int ret = 0;
	struct crypto_shash *tfm = NULL;
	struct shash_desc *desc = NULL;

	if ((result == NULL) || (resultLen <= 0) || (data == NULL) ||
	    (dataLen <= 0)) {
		return -1;
	}
	pr_info("data:0x%px.dataLen:%d\n", data,
		dataLen);
	memset(result, 0, resultLen);

	tfm = crypto_alloc_shash("md5", 0, 0);
	if (IS_ERR(tfm)) {
		tfm = NULL;
		pr_err("IS_ERR(tfm)\n");
		ret = -1;
		goto out;
	}

	desc = kmalloc(sizeof(*desc) + crypto_shash_descsize(tfm), GFP_KERNEL);
	if (desc == NULL) {
		pr_err("kmalloc desc fail\n");
		ret = -1;
		goto out;
	}

	desc->tfm = tfm;

	if (crypto_shash_init(desc) < 0) {
		pr_err("crypto_shash_init() fail\n");
		ret = -1;
		goto out;
	}

	if (crypto_shash_update(desc, data, dataLen) < 0) {
		pr_err("crypto_shash_update() fail\n");
		ret = -1;
		goto out;
	}

	if (crypto_shash_final(desc, result) < 0) {
		pr_err("crypto_shash_final() fail\n");
		ret = -1;
		goto out;
	}

out:
	if (desc) {
		kfree(desc);
	}
	if (tfm) {
		crypto_free_shash(tfm);
	}

	return ret;
}

int rtkve4_alloc_dma_memory(struct videc_dev *dev, struct rtkve4_buf *buf,
        size_t size, const char *name, struct dentry *parent)
{
    buf->vaddr = dma_alloc_coherent(dev->dev, size, &buf->paddr,
                    GFP_KERNEL);
    if (!buf->vaddr) {
        dev_err(dev->dev, "%d.%s.dma_alloc_coherent() fail.name:%s.size:%zu\n",
            __LINE__, __func__,
            name, size);
        return -ENOMEM;
    }
    buf->size = size;
    dev_dbg(dev->dev, "%d.%s.alloc memory.name:%s.size:%zu.paddr:0x%llx.vaddr:0x%px\n",
        __LINE__, __func__,
        name, size,
        buf->paddr, buf->vaddr);

    if (name && parent) {
        buf->blob.data = buf->vaddr;
        buf->blob.size = size;
        buf->dentry = debugfs_create_blob(name, 0444, parent,
                        &buf->blob);
	}

	return 0;
}

void rtkve4_free_dma_memory(struct videc_dev *dev,
        struct rtkve4_buf *buf, const char *name)
{
    if (buf->vaddr) {
        dev_dbg(dev->dev, "%d.%s.free memory.name:%s.size:%d.paddr:0x%llx.vaddr:0x%px\n",
            __LINE__, __func__,
            name, buf->size,
            buf->paddr, buf->vaddr);

        dma_free_coherent(dev->dev, buf->size, buf->vaddr, buf->paddr);
        buf->vaddr = NULL;
        buf->size = 0;
        debugfs_remove(buf->dentry);
        buf->dentry = NULL;
	}
}


int rtkve4_get_sram_memory(struct videc_dev *dev, struct rtkve4_buf *vb)
{
    u32 sram_size = 0;

    sram_size = VDI_WAVE6_RTK_SRAM_SIZE;

    // if we can know the sram address directly in vdi layer, we use it first for sdram address
    vb->paddr = VDI_SRAM_BASE_ADDR;
    vb->size      = sram_size;
    dev_dbg(dev->dev, "[%d]%s.phys_addr:0x%llx.size:%d\n", __LINE__, __func__,
        vb->paddr, vb->size);

    return 0;
}
void rtkve4_parabuf_write(struct rtkve4enc_ctx *ctx, int index, u32 value)
{
    struct rtkve4_dev_info* ve4_devinfo = (struct rtkve4_dev_info*)ctx->dev->ve4_devinfo;
	u32 *p = ve4_devinfo->parabuf.vaddr;

	p[index ^ 1] = value;
}

static int convert_endian(unsigned int endian)
{
    switch (endian) {
        case VDI_LITTLE_ENDIAN:       endian = 0x00; break;
        case VDI_BIG_ENDIAN:          endian = 0x0f; break;
        case VDI_32BIT_LITTLE_ENDIAN: endian = 0x04; break;
        case VDI_32BIT_BIG_ENDIAN:    endian = 0x03; break;
    }

    return (endian&0x0f);
}

static void byte_swap(unsigned char *data, int len)
{
	u8 temp;
	int i;

	for (i = 0; i < len; i += 2) {
		temp = data[i];
		data[i] = data[i + 1];
		data[i + 1] = temp;
	}
}

static void word_swap(unsigned char *data, int len)
{
	u16 temp;
	u16 *ptr = (u16 *)data;
	int i;
	s32 size = len / sizeof(uint16_t);

	for (i = 0; i < size; i += 2) {
		temp = ptr[i];
		ptr[i] = ptr[i + 1];
		ptr[i + 1] = temp;
	}
}

static void dword_swap(unsigned char *data, int len)
{
	u32 temp;
	u32 *ptr = (u32 *)data;
	s32 size = len / sizeof(uint32_t);
	int i;

	for (i = 0; i < size; i += 2) {
		temp = ptr[i];
		ptr[i] = ptr[i + 1];
		ptr[i + 1] = temp;
	}
}

static void lword_swap(unsigned char *data, int len)
{
	u64 temp;
	u64 *ptr = (u64 *)data;
	s32 size = len / sizeof(uint64_t);
	int i;

	for (i = 0; i < size; i += 2) {
		temp = ptr[i];
		ptr[i] = ptr[i + 1];
		ptr[i + 1] = temp;
	}
}

static int swap_endian(unsigned char *data, int len, int endian)
{
	int changes;
	int sys_endian;
	bool byteChange, wordChange, dwordChange, lwordChange;

	sys_endian = VDI_128BIT_BUS_SYSTEM_ENDIAN;

	endian = convert_endian(endian);
	sys_endian = convert_endian(sys_endian);
	if (endian == sys_endian)
		return 0;

	changes = endian ^ sys_endian;
	byteChange = changes & 0x01;
	wordChange = ((changes & 0x02) == 0x02);
	dwordChange = ((changes & 0x04) == 0x04);
	lwordChange = ((changes & 0x08) == 0x08);

	if (byteChange)
		byte_swap(data, len);
	if (wordChange)
		word_swap(data, len);
	if (dwordChange)
		dword_swap(data, len);
	if (lwordChange)
		lword_swap(data, len);

	return 1;
}

int rtkve4_write_memory(struct videc_dev *dev,
    void *vaddr, size_t bufsize,
    size_t offset, u8 *data, int len, int endian)
{
    if (!vaddr || bufsize <= 0) {
        dev_err(dev->dev, "%d.%s.vaddr is NULL or bufsize <= 0\n",
            __LINE__, __func__);
        return -EINVAL;
    }

    if (offset > bufsize || len > bufsize || offset + len > bufsize) {
        dev_err(dev->dev, "%d.%s.invalid params.offset:%ld.len:%d.bufsize:%ld\n",
            __LINE__, __func__,
            offset, len, bufsize);
        return -ENOSPC;
    }

    swap_endian(data, len, endian);
    memcpy(vaddr + offset, data, len);
    return len;
}

int rtkve4_read_memory(struct videc_dev *dev,
    void *vaddr, size_t bufsize,
    size_t offset, u8 *data, int len, int endian)
{
    if (!vaddr || bufsize <= 0) {
        dev_err(dev->dev, "%d.%s.vaddr is NULL or bufsize <= 0\n",
            __LINE__, __func__);
        return -EINVAL;
    }

    if (offset > bufsize || len > bufsize || offset + len > bufsize) {
        dev_err(dev->dev, "%d.%s.invalid params.offset:%ld.len:%d.bufsize:%ld\n",
            __LINE__, __func__,
            offset, len, bufsize);
        return -ENOSPC;
    }

    memcpy(data, vaddr + offset, len);
    swap_endian(data, len, endian);
    return len;
}

void rtkve4_reg_writel(struct videc_dev *dev, unsigned int addr,
        unsigned int data)
{
	dev_dbg(dev->dev, "%d.%s.reg_wirte(VE4_IP_BASE_ADDR+0x%x, 0x%x)\n",
		__LINE__, __func__, addr, data);

	writel(data, dev->ve4_register + addr);
}

unsigned int rtkve4_reg_readl(struct videc_dev *dev, u32 addr)
{
	u32 value = 0;
	value = readl(dev->ve4_register + addr);
	return value;
}

void rtkve4_wrap_reg_writel(struct videc_dev *dev, unsigned int addr,
        unsigned int data)
{
	writel(data, dev->ve4_wrap_register + addr);
}

unsigned int rtkve4_wrap_reg_readl(struct videc_dev *dev, u32 addr)
{
	u32 value = 0;
	value = readl(dev->ve4_wrap_register + addr);
	return value;
}

int rtkve4_wait_interrupt(struct rtkve4enc_ctx *ctx, unsigned int timeout)
{
    int ret = 0;
    int intr_reason = 0;
    vpudrv_intr_info_t intr_info;

    intr_info.core_idx = 0;
    intr_info.timeout = timeout;
    intr_info.intr_reason = 0;

	ret = kent_ve4_vdi_ioctl_wait_interrupt(&intr_info);
	if (ret != 0) {
		pr_err("[err]%d.%s.exit\n", __LINE__, __func__);
		return -ETIMEDOUT;
	}
	intr_reason = intr_info.intr_reason;
    return intr_reason;
}

void rtkve4_clear_interrupt(struct rtkve4enc_ctx *ctx)
{
	// Interrupt is already cleared in driver layer.

//    rtkve4_reg_writel(ctx->dev, BIT_INT_CLEAR, 1);
//    rtkve4_reg_writel(ctx->dev, BIT_INT_REASON, 0);
}

bool rtkve4_is_init(struct videc_dev *dev)
{
    u32 pc = rtkve4_reg_readl(dev, W6_VCPU_CUR_PC);
    dev_dbg(dev->dev, "%d.%s.pc:0x%x\n",
        __LINE__, __func__,
        pc);
	return rtkve4_reg_readl(dev, W6_VCPU_CUR_PC) != 0;
}

int rtkve4_wait_cmd_traffic_idle(struct videc_dev *dev)
{
	u32 data;

	return read_poll_timeout(rtkve4_reg_readl, data, ((data & 0x70000) == 0x70000), 0,
                RTKVE4_WAIT_CMD_IDLE_TIMEOUT_US, false, dev, RTKVE4_CMD_TRAFFIC);
}

int rtkve4_wait_busy(struct videc_dev *dev, unsigned int addr)
{
    int ret = 0;
	u32 data;
    u32 pc;

    pc = W6_VCPU_CUR_PC;
    dev_dbg(dev->dev, "[%d]%s.timeout:%d.addr_bit_busy_flag:0x%x.pc:0x%x\n",__LINE__,__func__,
        RTKVE4_BUSY_CHECK_TIMEOUT_US,addr,pc);

	ret = read_poll_timeout(rtkve4_reg_readl, data, data == 0, 0,
            RTKVE4_BUSY_CHECK_TIMEOUT_US, false, dev, addr);

    if (ret < 0) {
        dev_dbg(dev->dev, "%d.%s.poll reg 0x%X timeout\n",
            __LINE__, __func__,
            data);
        return ret;
    }

    return ret;
}

static int rtkve4_load_firmware(struct videc_dev *dev, const char *fw_name)
{
	const struct firmware *fw;
	int ret, i;
	struct rtkve4_dev_info *dev_info = NULL;
	int codeBase, regVal;
	vpu_bit_firmware_info_t bit_firmware_info;

	dev_info = (struct rtkve4_dev_info *)dev->ve4_devinfo;

	ret = request_firmware(&fw, fw_name, dev->dev);
	if (ret) {
		dev_err(dev->dev, "request_firmware fail\n");
		return ret;
	}
	dev_dbg(dev->dev, "%d.%s.fw size : %ld\n", __LINE__, __func__, fw->size);

	if (WAVE6_MAX_CODE_BUF_SIZE < fw->size) {
		dev_err(dev->dev, "[%d]%s.fw->size:%ld.RETCODE_INSUFFICIENT_RESOURCE\n",__LINE__,__func__,fw->size);
		return -1;
	}
	dev_dbg(dev->dev, "\nVPU INIT Start00!!! codeBase = 0x%llx\n", dev_info->codebuf.paddr);

	ret = rtkve4_write_memory(dev,
			dev_info->codebuf.vaddr, dev_info->codebuf.size,
			0,
			(u8 *)fw->data,
			fw->size,
			VDI_128BIT_LITTLE_ENDIAN);

	dev_dbg(dev->dev, "\nVPU INIT Start11!!! codeBase = 0x%px\n", dev_info->codebuf.vaddr);

	if (ret <= 0) {
		dev_err(dev->dev, "write a firmware fail\n");
		goto release_fw;
	}

	//W6RemapCodeBuffer
	codeBase = dev_info->codebuf.paddr;
	dev_dbg(dev->dev, "[%d]%s.codeBase:0x%x.sizeof(codeBase):%ld.WAVE6_MAX_CODE_BUF_SIZE:%d.W_REMAP_MAX_SIZE:%d\n",__LINE__,__func__,
		codeBase,sizeof(codeBase),WAVE6_MAX_CODE_BUF_SIZE,W_REMAP_MAX_SIZE);

    for (i = 0; i < WAVE6_MAX_CODE_BUF_SIZE/W_REMAP_MAX_SIZE; i++) {
        regVal = 0x80000000 | (WAVE_UPPER_PROC_AXI_ID<<20) | (0<<16) | (i<<12) | (1<<11) | ((W_REMAP_MAX_SIZE>>12)&0x1ff);
        dev_dbg(dev->dev, "[%d]%s.regVal:0x%x.WAVE_UPPER_PROC_AXI_ID:%d.W_REMAP_MAX_SIZE:%d\n",__LINE__,__func__,regVal,WAVE_UPPER_PROC_AXI_ID,W_REMAP_MAX_SIZE);
        dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_VPU_REMAP_CTRL:0x%x.value:0x%x\n",__LINE__,__func__,W6_VPU_REMAP_CTRL,regVal);
		rtkve4_reg_writel(dev, W6_VPU_REMAP_CTRL, regVal);
        dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_VPU_REMAP_VADDR:0x%x.value:0x%x\n",__LINE__,__func__,W6_VPU_REMAP_VADDR,(i*W_REMAP_MAX_SIZE));
		rtkve4_reg_writel(dev, W6_VPU_REMAP_VADDR, i*W_REMAP_MAX_SIZE);
        dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_VPU_REMAP_PADDR:0x%x.value:0x%x\n",__LINE__,__func__,W6_VPU_REMAP_PADDR,(unsigned int)(codeBase + i*W_REMAP_MAX_SIZE));
		rtkve4_reg_writel(dev, W6_VPU_REMAP_PADDR, codeBase + i*W_REMAP_MAX_SIZE);
    }

    bit_firmware_info.size = sizeof(vpu_bit_firmware_info_t);
    bit_firmware_info.core_idx = 0;
    bit_firmware_info.reg_base_offset = 0;

    for (i = 0; i < 512; i++)
        bit_firmware_info.bit_code[i] = fw->data[i];

    if (kent_ve4_vdi_write_bit_firmware(&bit_firmware_info,
        bit_firmware_info.size) < 0) {
        return -EINVAL;
    }

	release_firmware(fw);
	return 0;

release_fw:
	release_firmware(fw);
	return ret;
}

static void rtkve4_en_interrupt(struct videc_dev *dev)
{
    u32 regVal = 0;
    // encoder
    regVal  = (1<<INT_WAVE6_ENC_SET_PARAM);
    regVal |= (1<<INT_WAVE6_ENC_PIC);
    regVal |= (1<<INT_WAVE6_BSBUF_FULL);
    dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_VPU_VINT_ENABLE:0x%x.value:0x%x\n",__LINE__,__func__,W6_VPU_VINT_ENABLE,regVal);
    rtkve4_reg_writel(dev, W6_VPU_VINT_ENABLE, regVal);
}

int rtkve4_init(struct videc_dev *dev, u8 *firmware, uint32_t size)
{
	struct rtkve4_dev_info *dev_info = NULL;
	int ret;
	char* fwPath = NULL;

	dev_info = (struct rtkve4_dev_info *)dev->ve4_devinfo;
	fwPath = WAVE6_BITCODE_PATH;

	ret = rtkve4_load_firmware(dev, fwPath);
	if (ret < 0) {
		dev_err(dev->dev, "%d.%s.failed to load a firmware.ret:%d\n",
			__LINE__, __func__, ret);
		return ret;
	}

	rtkve4_en_interrupt(dev);

	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_VPU_CMD_BUSY_STATUS:0x%x.value:1\n",__LINE__,__func__,W6_VPU_CMD_BUSY_STATUS);
	rtkve4_reg_writel(dev, W6_VPU_CMD_BUSY_STATUS, 1);
	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_COMMAND:0x%x.value:0x%x\n",__LINE__,__func__,W6_COMMAND,W6_INIT_VPU);
	rtkve4_reg_writel(dev, W6_COMMAND, W6_INIT_VPU);
		
	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_VPU_REMAP_CORE_START:0x%x.value:1\n",__LINE__,__func__,W6_VPU_REMAP_CORE_START);
	rtkve4_reg_writel(dev, W6_VPU_REMAP_CORE_START, 1);

	dev_dbg(dev->dev, "[%d]%s.cmd:0x%x.W6_VPU_VPU_INT_STS:0x%x.W6_VPU_VINT_REASON:0x%x\n",__LINE__,__func__,
        W6_INIT_VPU, rtkve4_reg_readl(dev, W6_VPU_VPU_INT_STS),
        rtkve4_reg_readl(dev, W6_VPU_VINT_REASON));

	ret = rtkve4_wait_busy(dev, W6_VPU_CMD_BUSY_STATUS);
	if (ret) {
		dev_err(dev->dev,
			"%d.%s.timeout for checking BIT_BUSY_FLAG.ret:%d\n",
			__LINE__, __func__, ret);
		return -ETIMEDOUT;
	}

    ret = rtkve4_reg_readl(dev, W6_RET_SUCCESS);
    dev_dbg(dev->dev, "[%d]%s.ret:0x%x\n",__LINE__,__func__,ret);
    if (ret == 0) {
        u32 reasonCode = rtkve4_reg_readl(dev, W6_RET_FAIL_REASON);
        dev_err(dev->dev, "VPU init(W6_RET_SUCCESS) failed(%d) REASON CODE(%08x)\n", ret, reasonCode);
        return -EINVAL;
    }

	return 0;
}

int rtkve4_initialize(struct rtkve4enc_ctx *ctx)
{
    int ret = 0, val;
    struct videc_dev *dev = ctx->dev;
    struct vpudrv_buffer_t reg;
    u32 product_code;
    struct rtkve4_dev_info *dev_info = NULL;
    vpu_clock_info_t clockInfo;
    int i = 0;
    vpudrv_buffer_t vdb;
    unsigned int product_name = 0;
    unsigned int pc = 0;

    if (kent_ve4_vdi_ioctl_get_register_info(&reg) < 0) {
        return -EINVAL;
    }
    dev_dbg(dev->dev, "%d.%s.reg.size:%d.virt_addr:0x%lx\n",
        __LINE__, __func__,
        reg.size,
        reg.virt_addr);
    dev->ve4_register = (void __iomem *)reg.virt_addr;

    dev_dbg(dev->dev, "[VDI] map vdb_register core_idx=0, virtaddr=0x%lx, size=%d\n", reg.virt_addr, reg.size);

    if (kent_ve4_vdi_ioctl_get_wrap_register_info(&reg) < 0) {
        return -EINVAL;
    }
    dev_dbg(dev->dev, "%d.%s.wrap_reg.size:%d.virt_addr:0x%lx\n",
            __LINE__, __func__,
            reg.size,
            reg.virt_addr);
    dev->ve4_wrap_register = (void __iomem *)reg.virt_addr;

    mutex_lock(&dev->ve4_hw_mutex);

    ctx->inst_index = dev->ve4_instance_nums;
    dev->ve4_instance_nums++;
    dev_dbg(dev->dev, "%d.%s.ctx:0x%px.inst_index:%d.ve4_instance_nums:%d\n",
        __LINE__, __func__, ctx,
        ctx->inst_index,
        dev->ve4_instance_nums);

    if (dev->ve4_instance_nums == 1) {
        clockInfo.core_idx = 0;
        clockInfo.enable = 1;
        kent_ve4_vdi_ioctl_set_rtk_clk_gating(&clockInfo);
        dev_dbg(dev->dev, "%d.%s.set rtk_clk_gating on\n",
            __LINE__, __func__);
		dev_dbg(dev->dev, "[VDI]  %s, %d... core_idx:0, clk_en:%d\n", __FUNCTION__, __LINE__, clockInfo.enable);
    }
    ctx->enc_initialized = true;

    product_code = rtkve4_reg_readl(dev, VPU_PRODUCT_CODE_REGISTER);
    // RTK
    if (product_code == WAVE677_CODE) {
        product_code = WAVE627_CODE;
    }
    product_name = rtkve4_reg_readl(dev, VPU_PRODUCT_NAME_REGISTER);
    pc = rtkve4_reg_readl(dev, W6_VCPU_CUR_PC);
    dev_dbg(dev->dev, "%d.%s.product_code:0x%x.product_name:0x%x\n",
        __LINE__, __func__,
        product_code, product_name);

    dev_dbg(dev->dev, "[%d]%s.product_code:0x%x.product_name:0x%x.pc:0x%x\n", __LINE__, __func__,
        product_code, product_name, pc);

    if (!rtkve4_is_init(dev)) {
        /* Clear registers */
        dev_dbg(dev->dev, "%d.%s.w_register clear start\n", __LINE__, __func__);
        for (i = 0; i < 256; i++)
            rtkve4_reg_writel(dev, W6_COMMAND + i * 4, 0);
        dev_dbg(dev->dev, "%d.%s.w_register clear end\n", __LINE__, __func__);
    }
    
    dev_info = (struct rtkve4_dev_info *)dev->ve4_devinfo;

    vdb.size = SIZE_COMMON;
    if (kent_ve4_vdi_ioctl_get_common_memory(&vdb) < 0) {
        dev_err(dev->dev, "%d.%s.kent_ve4_vdi_ioctl_get_common_memory() fail\n",
            __LINE__, __func__);
        ret = -EINVAL;
        goto mutex_unlock;
    }
    dev_info->codebuf.size = WAVE6_MAX_CODE_BUF_SIZE;
    dev_info->codebuf.paddr = (dma_addr_t)(vdb.phys_addr);
    dev_info->codebuf.vaddr = (void *)(vdb.virt_addr);
    dev_dbg(dev->dev, "%d.%s.get_dma.name:codebuf.size:%d.paddr:0x%llx.vaddr:0x%px\n",
        __LINE__, __func__,
        dev_info->codebuf.size,
        dev_info->codebuf.paddr,
        dev_info->codebuf.vaddr);
    dev_dbg(dev->dev, "[VDI] Internal_allocate_common_memory, physaddr=0x%llx, size=%d, virtaddr=0x%px\n", dev_info->codebuf.paddr, vdb.size, dev_info->codebuf.vaddr);

    if (rtkve4_is_init(dev))
        goto mutex_unlock;

    ret = rtkve4_init(dev, (u8 *)0, sizeof(0));
    if (ret) {
        dev_err(dev->dev,
            "%d.%s.failed to initialize rtkve4.ret:%d\n",
            __LINE__, __func__,
            ret);
        goto mutex_unlock;
    }

	//ret = Wave6VpuGetVersion(core_idx, NULL, NULL);
	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_CMD_INSTANCE_INFO:0x%x.value:0x%x\n",__LINE__,__func__,W6_CMD_INSTANCE_INFO,(ctx->codec_mode<<16)|(ctx->inst_index&0xffff));
	rtkve4_reg_writel(dev, W6_CMD_INSTANCE_INFO, (ctx->codec_mode<<16)|(ctx->inst_index&0xffff));

	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_VPU_CMD_BUSY_STATUS:0x%x.value:1\n",__LINE__,__func__,W6_VPU_CMD_BUSY_STATUS);
	rtkve4_reg_writel(dev, W6_VPU_CMD_BUSY_STATUS, 1);

	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_COMMAND:0x%x.value:0x%x\n",__LINE__,__func__,W6_COMMAND,W6_GET_VPU_INFO);
	rtkve4_reg_writel(dev, W6_COMMAND, W6_GET_VPU_INFO);

	dev_dbg(dev->dev, "[%d]%s.VpuWriteReg W6_VPU_HOST_INT_REQ:0x%x.value:1\n",__LINE__,__func__,W6_VPU_HOST_INT_REQ);
	rtkve4_reg_writel(dev, W6_VPU_HOST_INT_REQ, 1);
    dev_dbg(dev->dev, "[%d]%s.cmd:0x%x.W6_VPU_VPU_INT_STS:0x%x.W6_VPU_VINT_REASON:0x%x\n",__LINE__,__func__,
        W6_GET_VPU_INFO, rtkve4_reg_readl(dev, W6_VPU_VPU_INT_STS),
        rtkve4_reg_readl(dev, W6_VPU_VINT_REASON));

	dev_dbg(dev->dev, "%d.%s.W6_VCPU_CUR_PC:0x%x\n",
        __LINE__, __func__,
        rtkve4_reg_readl(dev, W6_VCPU_CUR_PC));

	val = rtkve4_wait_busy(dev, W6_VPU_CMD_BUSY_STATUS);
	if (val) {
		dev_err(dev->dev,
			"%d.%s.timeout for checking BIT_BUSY_FLAG.ret:%d\n",
            __LINE__, __func__, val);
		ret =  -ETIMEDOUT;
        goto mutex_unlock;
	}

    val = rtkve4_reg_readl(dev, W6_RET_SUCCESS);
    dev_dbg(dev->dev, "[%d]%s.ret:0x%x\n",__LINE__,__func__,ret);
    if (val == 0) {
        dev_err(dev->dev, "VPU init(W6_RET_SUCCESS) failed(%d)\n", val);
		ret =  -EINVAL;
        goto mutex_unlock;
    }

mutex_unlock:
    mutex_unlock(&dev->ve4_hw_mutex);

    return ret;
}

int rtkve4_finalize(struct rtkve4enc_ctx *ctx)
{
    int ret = 0;
    struct videc_dev *dev = ctx->dev;
    vpu_clock_info_t clockInfo;

	dev_dbg(dev->dev, "%d.%s.[+]\n", __LINE__, __func__);

	if (!ctx->enc_initialized) {
		dev_info(dev->dev, "%d.%s.[-] not initialized yet\n",
			__LINE__, __func__);
		return -EINVAL;
	}

	mutex_lock(&dev->ve4_hw_mutex);

	if (dev->ve4_instance_nums <= 0) {
		dev_err(dev->dev,
			"%d.%s.ve4_instance_nums:%d invalid value\n",
			__LINE__, __func__,
			dev->ve4_instance_nums);
		mutex_unlock(&dev->ve4_hw_mutex);
		return -EINVAL;
	} else {
		dev->ve4_instance_nums--;
		dev_dbg(dev->dev, "%d.%s.ve4_instance_nums:%d\n",
			__LINE__, __func__, dev->ve4_instance_nums);

		if (dev->ve4_instance_nums == 0) {
			clockInfo.core_idx = 0;
			clockInfo.enable = 0;
			kent_ve4_vdi_ioctl_set_rtk_clk_gating(&clockInfo);
			dev_dbg(dev->dev, "%d.%s.set rtk_clk_gating off\n",
				__LINE__, __func__);
		}
	}

	ctx->enc_initialized = false;
	mutex_unlock(&dev->ve4_hw_mutex);
	dev_dbg(dev->dev, "%d.%s.[-]\n", __LINE__, __func__);

    return ret;
}
